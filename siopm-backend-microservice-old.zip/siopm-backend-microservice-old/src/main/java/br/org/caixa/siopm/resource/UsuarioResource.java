package br.org.caixa.siopm.resource;

import java.util.List;
import java.util.Optional;

import javax.annotation.security.RolesAllowed;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.eclipse.microprofile.openapi.annotations.enums.SecuritySchemeType;
import org.eclipse.microprofile.openapi.annotations.security.OAuthFlow;
import org.eclipse.microprofile.openapi.annotations.security.OAuthFlows;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirements;
import org.eclipse.microprofile.openapi.annotations.security.SecurityScheme;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.jboss.resteasy.links.impl.NotFoundException;

import br.org.caixa.siopm.model.Usuario;





@Path("/usuarios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name="usuario")
@RolesAllowed("role_usuario")
@SecurityScheme(securitySchemeName = "siopm-oauth", type = SecuritySchemeType.OAUTH2, flows = @OAuthFlows(password=@OAuthFlow(tokenUrl="http://localhost:8180/auth/realms/intranet/protocol/openid-connect/token")))
@SecurityRequirement(name = "siopm-oauth", scopes = {})
public class UsuarioResource {
	



    @GET
    @SecurityRequirement(name = "siopm-oauth",scopes = "roles")
    public List<Usuario> hello() {
        return Usuario.listAll();
    }
    
    @POST
    @Transactional
    public Response addicionar(Usuario usuarioDto) {
    	usuarioDto.persist();
    	return Response.status(Status.CREATED).build();
    }
    
    @PUT
    @Path("{id}")
    @Transactional
    public void atualizar(@PathParam("id") Long id,  Usuario usuarioDto) throws NotFoundException {
    	Optional<Usuario> usuarioOp = Usuario.findByIdOptional(id);
    	if(usuarioOp.isEmpty()) {
    		throw new NotFoundException();
    	}
    	Usuario usuario = usuarioOp.get();
    	usuario.nome = usuarioDto.nome;
    	
    	usuario.persist();
    }
    
    
    @DELETE
    @Path("{id}")
    @Transactional
    public void atualizar(@PathParam("id") Long id) throws NotFoundException {
    	Optional<Usuario> usuarioOp = Usuario.findByIdOptional(id);
    	
    	if(usuarioOp.isEmpty()) {
    		throw new NotFoundException();
    	}
    	
    	Usuario.deleteById(id);
    
    }
    
    
    
    
    
}