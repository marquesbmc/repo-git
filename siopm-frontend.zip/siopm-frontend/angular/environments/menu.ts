export const Menu = [
   {
      "tipo":"vertical",
      "itensMenu":[
         {
            "icon":"fa-home",
            "description":"Tela Principal",
            "title":"Principal",
            "locked":true,
            "target":"principal"
         },
         {
            "icon":"fa-home",
            "description":"Tela Manter Arquivo",
            "title":"Arquivo Físico",
            "locked":true,
            "target":"arquivo"
         },
         {
            "icon":"fa-home",
            "description":"Tela Manter Evento",
            "title":"Evento",
            "locked":true,
            "target":"evento"
         },
         {
            "icon":"fa-home",
            "description":"Tela Manter Tipo de Mensagem",
            "title":"Tipo de Mensagem",
            "locked":true,
            "target":"mensagem"
         },
         {
            "icon":"fa-question",
            "description":"Sobre a aplicação",
            "title":"Sobre",
            "target":"sobre"
         }
      ]
   }
]
