import { Injectable } from '@angular/core';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from "rxjs";
import { TimerObservable } from "rxjs/observable/TimerObservable";

import { ModalAlertComponent } from '../../resources/modal-alert/modal-alert.component';
import { ModalConfirmComponent } from '../../resources/modal-confirm/modal-confirm.component';
import { ModalInputComponent } from '../../resources/modal-input/modal-input.component';
import { ModalWarningComponent } from '../../resources/modal-warning/modal-warning.component';
import { ModalErrorComponent } from '../../resources/modal-error/modal-error.component';

import { ErrorService } from "../../services/error/error.service";
import { LogService } from "../../services/log/log.service";

const VERSION: string = '2.0.0';

@Injectable()
export class AlertService {
  private subscription: Subscription = null;

  constructor(private modalService: NgbModal, private log: LogService) { }

  modalConfig: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false
  }

  version():string {
    return VERSION;
  }   

  showModal(template: any) {
    this.log.debug("showModal()");
    const modalRef = this.modalService.open(template, this.modalConfig);
  }  

  showMessage(title: string, message: string) {
    this.log.debug("showMessage(" + title + "," + message + ")");
    const modalRef = this.modalService.open(ModalAlertComponent, this.modalConfig);
    modalRef.componentInstance.title = title;
    modalRef.componentInstance.message = message;
  }

  showConfirm(title: string, message: string, confirm: any = null, deny: any = null) {
    this.log.debug("showConfirm(" + title + "," + message + ")");
    const modalRef = this.modalService.open(ModalConfirmComponent, this.modalConfig);
    modalRef.result.then((result) => {
      if (confirm) confirm(result);
    }, (reason) => {
      if (deny) deny(reason);

    });
    modalRef.componentInstance.title = title;
    modalRef.componentInstance.message = message;
  }

  showInput(title: string, message: string, inputValue: string = null, confirm: any = null, deny: any = null) {
    this.log.debug("showInput(" + title + "," + message + "," + inputValue + ")");
    const modalRef = this.modalService.open(ModalInputComponent, this.modalConfig);
    modalRef.result.then((result) => {
      if (confirm) confirm(result);
    }, (reason) => {
      if (deny) deny(reason);
    });
    modalRef.componentInstance.title = title;
    modalRef.componentInstance.message = message;
    modalRef.componentInstance.inputValue = inputValue;
  }

  showInputRequired(title: string, message: string, inputValue: string = null, confirm: any = null, deny: any = null) {
    this.log.debug("showInputRequired(" + title + "," + message + "," + inputValue + ")");
    const modalRef = this.modalService.open(ModalInputComponent, this.modalConfig);
    modalRef.result.then((result) => {
      if (confirm) confirm(result);
    }, (reason) => {
      if (deny) deny(reason);
    });
    modalRef.componentInstance.required = true;
    modalRef.componentInstance.title = title;
    modalRef.componentInstance.message = message;
    modalRef.componentInstance.inputValue = inputValue;
  }

  showWarning(title: string, message: string) {
    this.log.debug("showWarning(" + title + "," + message + ")");

    let modalRef = null;

    if (this.subscription) this.subscription.unsubscribe();
    this.log.debug("showWarning.delay");
    if (modalRef == null) {
      modalRef = this.modalService.open(ModalWarningComponent, this.modalConfig);
      modalRef.componentInstance.title = title;
      modalRef.componentInstance.message = message;
    } else {
      modalRef.close();
      if (this.subscription) this.subscription.unsubscribe();
    }
  }
  hideWarning() {
    this.log.debug("hideWarning()");
    if (this.subscription) this.subscription.unsubscribe();
  }

  showError(title: string, errorService: ErrorService = null) {
    this.log.debug("showError(" + title + ")");

    const modalRef = this.modalService.open(ModalErrorComponent, this.modalConfig);
    if (errorService != null) {
      modalRef.componentInstance.title = title;
      modalRef.componentInstance.message = errorService.getMessage();
      modalRef.componentInstance.cause = errorService.getCause();
      modalRef.componentInstance.stack = errorService.getStack();
    } else {
      modalRef.componentInstance.title = "Atenção";
      modalRef.componentInstance.message = title;
    }
  }

  showErrorMessage(title: string, message: string, cause: string = null, stack: any = null) {
    this.log.debug("showError(" + title + ")");

    const modalRef = this.modalService.open(ModalErrorComponent, this.modalConfig);
      modalRef.componentInstance.title = title;
      modalRef.componentInstance.message = message;
      modalRef.componentInstance.cause = cause;
      modalRef.componentInstance.stack = stack;
  }

  ngOnDestroy() {
    if (this.subscription) this.subscription.unsubscribe();
  }
  
  showTemplate(modalComponent: any, context: any, onClose = null, onDismiss = null, clazz = null) {
    this.log.debug("showTemplate()");
    const initialState = context;
    const modalRef = this.modalService.open(modalComponent, this.modalConfig);
  }
}