import { Injectable } from '@angular/core';
import { LogService } from "../../services/log/log.service";
import { ErrorService } from "../../services/error/error.service";
import * as Base64 from "base-64";
import { WebServiceService } from "../web-service/web-service.service";
import { ProfileService } from '../../services/profile/profile.service';
import { Config } from "../../../environments/config";

const VERSION: string = '2.0.0';
const applicationServerPublicKey: string = 'BB173l8rJtk3Q2PUyoCNHszuZ7EHUZdSRFQFFUwuHQB9X0AmssVKloJZuu6+9L9MnCI6piKFCZuIsyeGz9nWfcc=';
const SENDER_ID: string = "698680658532";
const WORKER_SOURCE: string = 'centralcaixaworker.js';

const API_VERSAO: string = "01.00";
const PUSH_SUBSCRIBE: string = 'ws/subscribe/create/' + API_VERSAO;
const PUSH_UNSUBSCRIBE: string = 'ws/subscribe/delete/' + API_VERSAO;
const PUSH_CHECK: string = 'ws/subscribe/check/' + API_VERSAO;

const MENSAGEM_INTERNA_SUBSCRIBE: string = 'ws/mensageminterna/subscribe/' + API_VERSAO;
const MENSAGEM_INTERNA_CONSULTAR: string = 'ws/mensageminterna/consultar/' + API_VERSAO;
const MENSAGEM_INTERNA_LISTA: string = 'ws/mensageminterna/usuario/listar/' + API_VERSAO;

const EMAIL_SUBSCRIBE: string = 'ws/email/subscribe/' + API_VERSAO;
const EMAIL_UNSUBSCRIBE: string = 'ws/email/unsubscribe/' + API_VERSAO;
const EMAIL_CHECK: string = 'ws/email/checksubscription/' + API_VERSAO;

declare var $: any;

@Injectable()
export class CentralCaixaService {

  constructor(private log: LogService, private errorService: ErrorService, private webservice: WebServiceService,
    private profileService: ProfileService) { }

  swRegistration = null;
  pushService = null;
  supported: boolean = false;
  initialized: boolean = false;
  date = null;
  subscribed: boolean = false;
  initStarting: boolean = false;
  initError: boolean = false;
  userSubscription = null;
  channelId = null;
  userId = "teste@email.com";
  browserApp = null;
  eventCallback = null;
  eventResponse = null;
  restriction = null;
  mailSubscribed: boolean = null;

  private _cordova() {
    return window['cordova'];
  }
  private _isNative() {
    var result = this._cordova() != null;
    if (!result) {
      result = navigator.userAgent.match(/NativeApp/i) != null;
    }
    return result;
  }

  private isAndroid() {
    return navigator.userAgent.match(/Android/i) != null;
  }

  private isIOS() {
    var found = navigator.userAgent.match(/iPhone/i) != null;
    if (!found) found = navigator.userAgent.match(/iPod/i) != null;

    return found;
  }

  private isTablet() {
    return navigator.userAgent.match(/Tablet|iPad/i);
  }

  private isOtherMobile() {
    var found = navigator.userAgent.match(/webOS/i) != null;
    if (!found) found = navigator.userAgent.match(/BlackBerry/i) != null;
    return found;
  }

  private isWPhone() {
    return navigator.userAgent.match(/Windows Phone/i) != null;
  }

  private isMobile() {
    return this.isAndroid() || this.isIOS() || this.isWPhone() || this.isOtherMobile();
  }

  private isWindows() {
    return navigator.userAgent.match(/Windows/i) != null;
  }

  private isLinux() {
    return navigator.userAgent.match(/Linux/i) != null;
  }

  private isMac() {
    return navigator.userAgent.match(/Mac/i) != null;
  }

  private isChrome() {
    return navigator.userAgent.match(/Chrome/i) != null;
  }

  private isIE() {
    return navigator.userAgent.match(/MSIE/i) != null;
  }

  private isEdge() {
    return navigator.userAgent.match(/Edge/i) != null;
  }

  private isFirefox() {
    return navigator.userAgent.match(/firefox/i) != null;
  }

  private isSafari() {
    return navigator.userAgent.match(/safari/i) != null;
  }

  private isOpera() {
    return navigator.userAgent.match(/Opera/i) != null;
  }

  private urlB64ToUint8Array(base64String) {
    var padding = '='.repeat((4 - base64String.length % 4) % 4);
    var base64 = (base64String + padding)
      .replace(/\-/g, '+')
      .replace(/_/g, '/');

    var rawData = window.atob(base64);
    var outputArray = new Uint8Array(rawData.length);

    for (var i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  private getDevice() {
    if (this.isMobile()) {
      return "DEVICE_MOBILE";
    } else if (this.isTablet()) {
      return "DEVICE_TABLET";
    }
    return "DEVICE_DESKTOP";
  }

  private getSO() {
    if (this.isAndroid()) {
      return "ANDROID_OS";
    } else if (this.isIOS()) {
      return "IOS_OS";
    } else if (this.isWPhone()) {
      return "WINPHONE_OS";
    } else if (this.isOtherMobile()) {
      return "OTHER_OS";
    } else if (this.isWindows()) {
      return "WINDOWS_OS";
    } else if (this.isLinux()) {
      return "LINUX_OS";
    } else if (this.isMac()) {
      return "MAC_OS";
    } else {
      return "UNKNOWN_OS";
    }
  }

  private getNavigator() {
    if (this.isChrome()) {
      return "NAV_CHROME";
    } else if (this.isIE()) {
      return "NAV_EXPLORER";
    } else if (this.isEdge()) {
      return "NAV_EDGE";
    } else if (this.isFirefox()) {
      return "NAV_FIREFOX";
    } else if (this.isSafari()) {
      return "NAV_SAFARI";
    } else if (this.isOpera()) {
      return "NAV_OPERA";
    } else {
      return "NAV_UNKNOWN";
    }
  }

  private getPlatform() {
    if (this.isMobile() || this.isTablet()) {
      if (this._isNative()) {
        return "NATIVE_PLATFORM";
      } else {
        return "BROWSER_PLATFORM";
      }
    } else {
      return "BROWSER_PLATFORM";
    }
  }

  private setRestriction() {
    var restriction = null;
    if (this.isMobile()) {
      restriction = "DEVICE_MOBILE";
    } else if (this.isTablet()) {
      restriction = "DEVICE_TABLET";
    } else {
      restriction = "DEVICE_DESKTOP";
    }
    if (this.isAndroid()) {
      restriction += " ANDROID_OS";
    } else if (this.isIOS()) {
      restriction += " IOS_OS";
    } else if (this.isWPhone()) {
      restriction += " WINPHONE_OS";
    } else if (this.isOtherMobile()) {
      restriction += " OTHER_OS";
    } else if (this.isWindows()) {
      restriction += " WINDOWS_OS";
    } else if (this.isLinux()) {
      restriction += " LINUX_OS";
    } else if (this.isMac()) {
      restriction += " MAC_OS";
    }

    if (this.isMobile() || this.isTablet()) {
      if (this._isNative()) {
        restriction += " NATIVE_PLATFORM";
      } else {
        restriction += " BROWSER_PLATFORM";
      }
    } else {
      restriction += " BROWSER_PLATFORM";
    }

    if (this.isChrome()) {
      restriction += " NAV_CHROME";
    } else if (this.isIE()) {
      restriction += " NAV_EXPLORER";
    } else if (this.isEdge()) {
      restriction += " NAV_EDGE";
    } else if (this.isFirefox()) {
      restriction += " NAV_FIREFOX";
    } else if (this.isSafari()) {
      restriction += " NAV_SAFARI";
    } else if (this.isOpera()) {
      restriction += " NAV_OPERA";
    }
    return restriction;
  }

  private PushNotification() {
    return window['this.PushNotification()'];
  }

  private post(endpoint, data, onsuccess, onfail) {
    var vm = this;

    function success(res) {
      if (onsuccess) onsuccess(res);
    }
    function fail(xhr, message) {
      if (onfail) onfail(xhr, message);
    }

    var headers = vm.webservice.headers();
    headers = headers.append('Content-Type', 'application/json');

    vm.webservice.postAnalytics(endpoint, JSON.stringify(data), { headers: headers }, success, fail);
  }

  public isSupported() {
    var vm = this;
    if ('serviceWorker' in navigator && 'PushManager' in window) {
      vm.supported = true;
      vm.browserApp = true;

    } else {
      try {
        if (vm.PushNotification() != null) {
          vm.supported = true;
          vm.browserApp = false;
        } else {
          vm.supported = false;
          vm.browserApp = null;
        }
      } catch (ignore) {
        vm.supported = false;
        vm.browserApp = null;
      }
    }
    if (vm.initError) {
      vm.supported = false;
    }
    return vm.supported;
  }

  public getRegistration(onDone) {
    this.log.debug("getRegistration(onDone)");
    var vm = this;
    if (vm.browserApp) {
      var applicationServerKey = this.urlB64ToUint8Array(applicationServerPublicKey);
      vm.swRegistration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey
      }).then(function (subscription) {
        console.log('User is subscribed:', subscription);
        var hasSubscription = !(subscription === null);
        vm.userSubscription = subscription;
        if (onDone) onDone(hasSubscription, subscription);
      }).catch(function (err) {
        console.log('Failed to subscribe the user: ', err);
        if (onDone) onDone(false, null, err.name);
      });
    } else {
      var hasSubscription = !(vm.userSubscription === null);
      if (onDone) onDone(hasSubscription, vm.userSubscription);
    }
  }

  public loadRegistration(onDone) {
    this.log.debug("loadRegistration()");
    var vm = this;
    vm.swRegistration.pushManager.getSubscription()
      .then(function (subscription) {
        var hasSubscription = !(subscription === null);
        vm.userSubscription = subscription;
        vm.log.debug('User has subscription.');
        if (onDone) onDone(hasSubscription, subscription);
      });
  }

  public initialize(channel, user, success, fail) {
    var vm = this;
    vm.log.debug("initialize()");

    if (!vm.isSupported()) {
      vm.log.warning("Notifications not supported on this platform");
      return;
    }

    if (vm.initStarting) {
      vm.log.warning("Starting up on process...");
      return;
    }

    vm.initStarting = true;
    vm.initError = false;

    vm.channelId = channel;

    vm.initialized = false;
    vm.subscribed = false;
    vm.userSubscription = null;

    if (this.browserApp) {
      navigator.serviceWorker.register(WORKER_SOURCE)
        .then(function (swReg) {
          vm.log.debug("initialize().serviceWorker.register.then");
          vm.log.info('Service Worker is registered ' + swReg);
          vm.swRegistration = swReg;
          vm.initStarting = false;
          vm.initialized = true;

          function onSuccessCheck(data) {
            vm.log.debug("initialize().checkSubscription.onSuccessCheck");
            var response = data;

            if (response.temErro) {
              vm.errorService.handleError("Falha ao verificar assinatura: " + response.code + " - " + response.message, response.stack);
              if (success) success(false);
              return;
            }

            if (response && response.data && response.data.length > 0) {
              vm.subscribed = true;
              data = response.data[0].dtSubscription;
            }

            if (success) success(vm.subscribed);
          }
          function onFailCheck(message) {
            vm.log.debug("initialize().checkSubscription.onFailCheck");
            if (fail) fail(message);
          }

          function onDone(hasSubscription, subscription) {
            vm.log.debug("initialize().loadRegistration.onDone");

            if (hasSubscription) {


              vm.checkSubscription(subscription, onSuccessCheck, onFailCheck);
            } else {
              if (success) success(vm.subscribed);
            }
          }

          vm.loadRegistration(onDone);
        })
        .catch(function (error) {
          vm.initError = true;
          vm.initialized = false;
          vm.initStarting = false;
          vm.log.error('Service Worker Error', error);
          if (fail) fail("Falha ao registrar serviço de notificações", error);
        });
    } else if (vm.PushNotification() != null) {
      this.pushService = vm.PushNotification().init({
        android: {
          senderID: SENDER_ID,
          icon: "icon",
          iconColor: "white"
        },
        ios: {
          //senderID: SENDER_ID,
          //gcmSandbox:"true",
          alert: "true",
          badge: "true",
          sound: "true"
        },
        windows: {}
      });

      vm.pushService.on('registration', function (data) {
        console.log('Token result:' + data.registrationId);

        vm.initialized = true;
        vm.subscribed = false;
        vm.userSubscription = data.registrationId;
        vm.initStarting = false;

        function onSuccessCheck(data) {
          vm.log.debug("initialize().checkSubscription.onSuccessCheck");

          var response = data;

          if (response.temErro) {
            vm.errorService.handleError("Falha ao verificar assinatura: " + response.code + " - " + response.message, response.stack);
            if (success) success(false);
            return;
          }

          if (response && response.data && response.data.length > 0) {
            vm.subscribed = true;
            data = response.data[0].dtSubscription;
          }

          if (success) success(vm.subscribed);
        }

        function onFailCheck(message) {
          vm.log.debug("initialize().checkSubscription.onFailCheck");
          if (fail) fail(message);
        }

        vm.checkSubscription(vm.userSubscription, onSuccessCheck, onFailCheck);
      });


      vm.pushService.on('notification', function (data) {
        vm.log.debug("cloud:push:notification " + data);

        try {
          if (!data) {
            vm.log.error("notificação não recebeu dados");
            return;
          }

          vm.log.debug("data: " + JSON.stringify(data));

          var msg = data.message;

          var push = {
            title: data.title,
            content: data.message,
            image: data.image,
            actions: null,
            url: null
          }

          if (data && data.additionalData) {
            push.url = data.additionalData.url;
            if (data.additionalData.image) {
              push.image = data.additionalData.image;
            }
            if (data.additionalData.actions) {
              push.actions = data.additionalData.actions;
            }
          }

          if (push.image == null) {
            push.image = "imgs/pin.png";
          }

          vm.log.debug("push: " + JSON.stringify(push));

          if (vm.eventCallback) {
            vm.eventCallback(push);
          }

          vm.log.debug("cloud:push:notification:DONE");
        } catch (error) {
          vm.log.error('Falha ao processar notificação', error);
          vm.log.error('error ' + error);
        }
      });

      this.pushService.on('error', function (e) {
        vm.log.error('Falha ao processar notificação' + e.message, e);
      });
    } else {
      vm.initStarting = false;
    }

  }

  public updateSubscriptionOnServer(subscription, url, onSuccess, onError) {
    var vm = this;
    vm.log.debug("updateSubscriptionOnServer()");

    var vm = this;
    var endPoint = url;
    var user = vm.profileService.getProfile();

    var device = vm.getDevice();
    var navigator = vm.getNavigator();
    var so = vm.getSO();
    var platform = vm.getPlatform();

    if (user == null) {
      user = vm.userId;
    }

    var strSubscription = JSON.stringify(subscription);
    var encodeSubscription = Base64.encode(strSubscription);

    var data = {
      subscription: encodeSubscription,
      channel: vm.channelId,
      user: user,
      platform: platform,
      navigator: navigator,
      device: device,
      so: so
    }

    function success(data) {
      vm.log.debug("updateSubscriptionOnServer().success");
      vm.log.debug("success:data: " + data);

      if (onSuccess) onSuccess(data);
    }

    function error(data, param, value) {
      vm.log.debug("updateSubscriptionOnServer().error");
      vm.log.debug("error:data: " + data);
      vm.log.debug("error:param: " + param);
      vm.log.debug("error:value: " + value);

      if (onError) onError(data, param, value);
    }

    vm.post(endPoint, data, success, error);
  }

  public checkSubscription(subscription, onSuccess, onError) {
    var vm = this;
    this.log.debug("checkSubscription()");

    var strSubscrption = JSON.stringify(subscription);
    var encodeSubscription = Base64.encode(strSubscrption);

    var data = {
      subscription: encodeSubscription,
      channel: vm.channelId
    }

    function success(data) {
      vm.log.debug("checkSubscription().success");
      vm.log.debug("success:data: " + data);

      if (onSuccess) onSuccess(data);
    }

    function error(data, param, value) {
      vm.log.debug("checkSubscription().error");
      vm.log.debug("error:data: " + data);
      vm.log.debug("error:param: " + param);
      vm.log.debug("error:value: " + value);

      if (onError) onError(data, param, value);
    }

    vm.post(Config.URL_CAIXA_SICPU + PUSH_CHECK, data, success, error);
  }

  public unsubscribe(success, fail) {
    var vm = this;
    vm.log.debug("unsubscribe()");
    var vm = this;

    if (!vm.isSupported()) {
      vm.log.warning("Notifications not supported on this platform");
      return;
    }

    if (!vm.subscribed) {
      vm.log.warning("Notifications is not subscribed");
      if (success) success();
      return;
    }

    function onsuccess(data) {
      vm.log.debug("unsubscribeUser().success");

      var response = data;

      if (response.temErro) {
        vm.errorService.handleError("Falha ao cancelar assinatura: " + response.code + " - " + response.message, response.stack);
        if (fail) fail(response.code + " - " + response.message, response.cause, response.stack);
        return;
      }

      vm.subscribed = false;

      if (success) success();
    }

    function onfail(message) {
      vm.log.debug("unsubscribeUser().onfail");

      if (fail) fail(message);
    }

    vm.updateSubscriptionOnServer(vm.userSubscription, Config.URL_CAIXA_SICPU + PUSH_UNSUBSCRIBE, onsuccess, onfail);
  }

  public testsubscribe(success, fail) {
    var vm = this;
    vm.log.debug("testsubscribe()");

    if (!vm.isSupported()) {
      vm.log.warning("Notifications not supported on this platform");
      return;
    }

    if (vm.subscribed) {
      vm.log.warning("Notifications subscribed already");
      if (success) success(vm.userSubscription);
      return;
    }

    function onDone(hasSubscription, subscription, errorname) {
      vm.log.debug("subscribeUser().getRegistration.onDone");

      if (!hasSubscription) {
        var message = "Falha ao obter assinatura";
        if (errorname == "NotAllowedError") {
          message = "Assinatura bloqueada pelo usuário";
        }

        if (fail) fail(message);

        return;
      }

      if (success) success(vm.userSubscription);
    }

    vm.getRegistration(onDone);
  }

  public subscribe(success, fail) {
    var vm = this;
    vm.log.debug("subscribe()");

    if (!vm.isSupported()) {
      vm.log.warning("Notifications not supported on this platform");
      return;
    }

    if (vm.subscribed) {
      vm.log.warning("Notifications subscribed already");
      if (success) success(vm.userSubscription);
      return;
    }

    function onDone(hasSubscription, subscription, errorname) {
      vm.log.debug("subscribeUser().getRegistration.onDone");

      if (!hasSubscription) {
        var message = "Falha ao obter assinatura";
        if (errorname == "NotAllowedError") {
          message = "Assinatura bloqueada pelo usuário";
        }

        if (fail) fail(message);
        return;
      }

      function onsuccess(data) {
        vm.log.debug("subscribeUser().updateSubscriptionOnServer.onsuccess");

        var response = data;

        if (response.temErro) {
          vm.errorService.handleError("Falha ao efetuar assinatura: " + response.code + " - " + response.message, response.stack);
          if (fail) fail(response.code + " - " + response.message, response.cause, response.stack);
          return;
        }

        vm.subscribed = true;

        if (success) success(vm.userSubscription);
      }

      function onfail(message) {
        vm.log.debug("subscribeUser().updateSubscriptionOnServer.onfail");

        if (fail) fail(message);
      }

      vm.updateSubscriptionOnServer(vm.userSubscription, Config.URL_CAIXA_SICPU + PUSH_SUBSCRIBE, onsuccess, onfail);
    }

    vm.getRegistration(onDone);
  }

  public setEvent = function (event) {
    this.log.debug("setEvent()");
    var vm = this;
    vm.eventCallback = event;
  }

  public setResponse = function (response) {
    this.log.debug("setResponse()");
    var vm = this;
    vm.eventResponse = response;
  }

  public isDevMode = function () {
    var vm = this;
    return vm.dev;
  }

  public isDev = function () {
    var vm = this;
    return vm.dev;
  }

  public setDevMode = function (code) {
    var vm = this;
    vm.devCode = code;
    vm.dev = (vm.devCode > 0);
  }
  isSubscribed() {
    return this.subscribed;
  }
  public isInitialized = function () {
    var vm = this;
    return vm.initialized;
  }
  public getSubscription = function () {
    var vm = this;
    return vm.userSubscription;
  }
  public destroy = function () {
    //this.destroy();
  }

  public pushcallback = function (data, action) {
    var vm = this;

    vm.log.debug("pushcallback: " + data);


    try {
      if (!data) {
        vm.log.error("notificação não recebeu dados");
        return;
      }

      vm.log.debug("data: " + JSON.stringify(data));

      var msg = data.message;

      var push = {
        title: data.title,
        content: data.message,
        image: data.image,
        action: null,
        actions: null,
        url: null
      }

      if (data && data.additionalData) {
        push.url = data.additionalData.url;
        if (data.additionalData.image) {
          push.image = data.additionalData.image;
        }
        if (data.additionalData.actions) {
          push.actions = data.additionalData.actions;
          push.action = push.actions[action];
        }
      }

      if (push.image == null) {
        push.image = "imgs/pin.png";
      }

      vm.log.debug("push: " + JSON.stringify(push));

      if (vm.eventResponse) {
        vm.eventResponse(push);
      }

      vm.log.debug("cloud:push:notification:DONE");
    } catch (error) {
      vm.log.error('Falha ao processar notificação', error);
      vm.log.error('error ' + error);
    }
  }

  subscribeMensagemInterna(onsuccess) {
    var vm = this;
    var request = {
				  "app": Config.CENTRAL_ID,
					"platform": this.getPlatform(),
					"device": this.getDevice(),
					"so": this.getSO(),
					"versaoSo": "versaoSo",
					"navigator": this.getNavigator(),
					"navigatorVersao": "navigatorVersao",
					"users":[{ "email": vm.profileService.getProfile() }]
		}

    function success(data) {
      if (onsuccess) onsuccess(data);
    }
    function fail(xhr, status, err) {}

    if (Config.URL_CAIXA_SICPU)
      vm.post(Config.URL_CAIXA_SICPU + MENSAGEM_INTERNA_SUBSCRIBE, request, success, fail);
  }
  
  verificaMensagemInterna(situacao, onsuccess) {
    var vm = this;
    var request = {
      "app": Config.CENTRAL_ID,
      "credencial": "credencial",
      "tokenAcesso": "tokenAcesso",
      "qtMensagens": 30,
      "situacaoMensagem": situacao,
      "usuario":{ "email": vm.profileService.getProfile() }
    }

    function success(data) {
      if (onsuccess) onsuccess(data);
    }
    function fail(xhr, status, err) {
      var message = "Falha ao efetuar assinatura de email";
      if (xhr && xhr.responseText) {
        try {
          var response = JSON.parse(xhr.responseText);
          if (response && response.msgsErro && response.msgsErro.length > 0) {
            message = response.msgsErro[0];
          }
        } catch (ignore) {
        }
      }
    }

    if (Config.URL_CAIXA_SICPU)
      vm.post(Config.URL_CAIXA_SICPU + MENSAGEM_INTERNA_LISTA, request, success, fail);
  }
  
  consultarMensagemInterna(arrayDetalheMensagem) {
    for(var i=0; i<arrayDetalheMensagem.length ; i++){
      var request = {
        "app": Config.CENTRAL_ID,
        "credencial": "credencial",
        "tokenAcesso": "tokenAcesso",
        "messageId": arrayDetalheMensagem[i].messageId,
        "mensagemLida": true,
        "usuario": { "email": this.profileService.getProfile() }
      }
  
      this.post(Config.URL_CAIXA_SICPU + MENSAGEM_INTERNA_CONSULTAR, request, null, null);
    }
  }

  subscribeEmail(onsuccess, onfail) {
    var vm = this;
    var user = [];
    
    var email = { email: vm.profileService.getProfile() };
    user.push(email);

    var request = {
        app: vm.channelId,
        users: user
    };

    function success(data) {
      if (onsuccess) {
        vm.mailSubscribed = true;
        onsuccess(data);
      }
    }
    function fail(xhr, status, err) {
      var message = "Falha ao efetuar assinatura de email";
      if (xhr && xhr.responseText) {
        try {
          var response = JSON.parse(xhr.responseText);
          if (response && response.msgsErro && response.msgsErro.length > 0) {
            message = response.msgsErro[0];
          }
        } catch (ignore) {
        }
      }
      vm.errorService.handleError(message, err);
      if (onfail) onfail(message, xhr);
    }

    vm.post(Config.URL_CAIXA_SICPU + EMAIL_SUBSCRIBE, request, success, fail);
  }

  unsubscribeEmail(onsuccess, onfail) {
    var vm = this;

    var user = [];
    
    var email = { email: vm.profileService.getProfile() };
    user.push(email);

    var request = {
        app: vm.channelId,
        users: user
    };

    function success(data) {
      if (onsuccess) {
        vm.mailSubscribed = false;
        onsuccess(data);
      }
    }

    function fail(xhr, status, err) {
      var message = "Falha ao cancelar assinatura de email";
      if (xhr && xhr.responseText) {
        try {
          var response = JSON.parse(xhr.responseText);
          if (response && response.msgsErro && response.msgsErro.length > 0) {
            message = response.msgsErro[0];
          }
        } catch (ignore) {
        }
      }
      vm.errorService.handleError(message, err);
      if (onfail) onfail(message, xhr);
    }

    vm.post(Config.URL_CAIXA_SICPU + EMAIL_UNSUBSCRIBE, request, success, fail);
  }

  isSubscribedEmail() {
    return this.mailSubscribed;
  }

  checkSubscribeEmail() {
    var vm = this;
    
    var request = {
        app: vm.channelId,
        email: vm.profileService.getProfile()
    };

    vm.mailSubscribed = null;
    function success(data) {
      var response = data;

      if (response.temErro) {
        vm.errorService.handleError("Falha ao verificar assinatura: " + response.code + " - " + response.message, response.stack);
        if (success) success(false);
        return;
      } else {
        vm.mailSubscribed = response.subscribed;
      }
    }

    function fail(xhr, status, err) {
      var message = "Falha ao cancelar assinatura de email";
      if (xhr && xhr.responseText) {
        try {
          var response = JSON.parse(xhr.responseText);
          if (response && response.msgsErro && response.msgsErro.length > 0) {
            message = response.msgsErro[0];
          }
        } catch (ignore) {
        }
      }
      vm.errorService.handleError(message, err);
    }
    vm.post(Config.URL_CAIXA_SICPU + EMAIL_CHECK, request, success, fail);
  }
}