import { Component, OnInit } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ErrorService } from '../../services/error/error.service';

@Component({
  selector: 'app-modal-error',
  templateUrl: './modal-error.component.html',
  styleUrls: ['./modal-error.component.css']
})
export class ModalErrorComponent implements OnInit {

  title: string;
  message: string;
  cause: string;
  isCollapsed: boolean = true;

  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {
  }

}
