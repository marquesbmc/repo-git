import { Component, OnInit } from '@angular/core';
import { CurrentView } from "../../../../environments/currentview";
import { Project } from "../../../../environments/project";
import { Menu } from "../../../../environments/menu";

@Component({
  selector: 'app-menu-principal',
  templateUrl: './menu-principal.component.html',
  styleUrls: ['./menu-principal.component.css']
})
export class MenuPrincipalComponent implements OnInit {

  currentview = CurrentView;
  project = Project
  menus = Menu;
  
  constructor() { }

  ngOnInit() {
  }

  getPlatforms(value) {
      return "";
  }
}