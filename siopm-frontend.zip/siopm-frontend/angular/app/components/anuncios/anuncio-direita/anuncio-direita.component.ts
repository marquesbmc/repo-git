import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anuncio-direita',
  templateUrl: './anuncio-direita.component.html',
  styleUrls: ['./anuncio-direita.component.css']
})
export class AnuncioDireitaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
