import { Component, OnInit } from '@angular/core';
import { ApplicationService } from '../../../services/application/application.service';
import { CurrentView } from "../../../../environments/currentview";
import { Project } from "../../../../environments/project";
import { InfoBuild } from "../../../../assets/infoBuild";
import { Menu } from "../../../../environments/menu";
import { LogService } from "../../../services/log/log.service";
import { TranslateService } from '@ngx-translate/core';
import { KeycloakService, KeycloakAuthGuard } from 'keycloak-angular';
import { CentralCaixaService } from "../../../services/central/central-caixa.service";
import { AlertService } from '../../../services/alert/alert.service';

@Component({
  selector: 'app-cabecalho-principal',
  templateUrl: './cabecalho-principal.component.html',
  styleUrls: ['./cabecalho-principal.component.css']
})
export class CabecalhoPrincipalComponent implements OnInit {

  currentview = CurrentView;
  project = Project;
  menus = Menu;
  infoBuild = InfoBuild;

  home = null;
  telainicial = false;
  mensagemNova: boolean = false;
  qtMensagens;

  constructor(private translate: TranslateService, private appService: ApplicationService,
        private central: CentralCaixaService, private log: LogService, private keycloak: KeycloakService,
        private alertService: AlertService) {
  	translate.setDefaultLang('pt');
  }

  title: string = this.appService.getTitle();

  ngOnInit() {
	    let currentview = this.appService.getCurrentState(this.appService.getState());

	    this.project.menuVertical = currentview.menuVertical? true : false;
	    this.project.menuHorizontal = currentview.menuHorizontal? true : false;

    if (this.project.views.length > 0 && this.appService.getState().indexOf(this.project.views[0].id) >= 0) {
      this.telainicial = true;
    }else{
      this.telainicial = false;
    }
    this.subscribeMensagemInterna();
  }

  subscribeMensagemInterna(){
    var vm = this;
    function success(res) {
      if (!res.temErro){
        vm.verificaMensagemInterna();
      }
    }

    return this.central.subscribeMensagemInterna(success);
  }

  verificaMensagemInterna(){
    var vm = this;
    function success(res) {
      if (res.data.length > 0){
        vm.mensagemNova = true;
        vm.qtMensagens = res.data.length;
      }
    }
    return this.central.verificaMensagemInterna("E", success);
  }

  ngAfterViewInit() {
    if (document.getElementsByClassName("navbar-toggle")[1])
      document.getElementsByClassName("navbar-toggle")[1].addEventListener("click", nvtFunction);
    document.getElementsByClassName("overlay")[0].addEventListener("click", nvtFunction);
    if (document.getElementsByClassName("setaleft")[0])
      document.getElementsByClassName("setaleft")[0].addEventListener("click", nvtFunction);

    function nvtFunction() {
      let aux = document.getElementsByClassName("navbar-collapse")[0];
      let auxAtrr = aux.getAttribute("aria-expanded");
      let auxhasAtrr = aux.hasAttribute("aria-expanded");
      if (  auxAtrr === 'false' || auxhasAtrr == false || typeof auxAtrr === "undefined"){
          document.getElementsByClassName("overlay")[0].setAttribute("style","display: block");
          document.getElementsByClassName("side-menubar")[0].setAttribute("style","margin-left: 0px");
      }else{
       document.getElementsByClassName("overlay")[0].setAttribute("style","display: none");
       document.getElementsByClassName("side-menubar")[0].setAttribute("style","margin-left: -700px");
      }
    }

    if (document.getElementsByClassName("item-calendario-intranet")[0])
      document.getElementsByClassName("item-calendario-intranet")[0].addEventListener("click", calendarFunction);
    if (document.getElementsByClassName("item-pesquisa-intranet")[0])
      document.getElementsByClassName("item-pesquisa-intranet")[0].addEventListener("click", pesquisaFunction);
    if (document.getElementsByClassName("item-config-intranet")[0])
      document.getElementsByClassName("item-config-intranet")[0].addEventListener("click", configFunction);

    function calendarFunction() {
      document.getElementsByClassName("config-intranet")[0].setAttribute("style","display: none");
      document.getElementsByClassName("pesquisa-intranet")[0].setAttribute("style","display: none");

      let calendar = document.getElementsByClassName("calendario-intranet")[0];
      if (calendar.hasAttribute('style')){
        if (calendar.getAttribute("style") == "display: none"){
           calendar.setAttribute("style","display: block");
           document.getElementsByClassName("overlay")[0].setAttribute("style","display: block");
        }else{
           calendar.setAttribute("style","display: none");
           document.getElementsByClassName("overlay")[0].setAttribute("style","display: none");
          }
      }else{
        calendar.setAttribute("style","display: block");
        document.getElementsByClassName("overlay")[0].setAttribute("style","display: block");
      }
    }

    function pesquisaFunction() {
      document.getElementsByClassName("calendario-intranet")[0].setAttribute("style","display: none");
      document.getElementsByClassName("config-intranet")[0].setAttribute("style","display: none");
      let pesquisa = document.getElementsByClassName("pesquisa-intranet")[0];
      if (pesquisa.hasAttribute('style')){
        if (pesquisa.getAttribute("style") == "display: none"){
          pesquisa.setAttribute("style","display: block");
          document.getElementsByClassName("overlay")[0].setAttribute("style","display: block");
        } else {
          pesquisa.setAttribute("style","display: none");
          document.getElementsByClassName("overlay")[0].setAttribute("style","display: none");
        }
      } else {
        pesquisa.setAttribute("style","display: block");
        document.getElementsByClassName("overlay")[0].setAttribute("style","display: block");
      }
    }

    function configFunction() {
      document.getElementsByClassName("calendario-intranet")[0].setAttribute("style","display: none");
      document.getElementsByClassName("pesquisa-intranet")[0].setAttribute("style","display: none");
      let config = document.getElementsByClassName("config-intranet")[0];
      if (config.hasAttribute('style')){
        if (config.getAttribute("style") == "display: none"){
          config.setAttribute("style","display: block");
          document.getElementsByClassName("overlay")[0].setAttribute("style","display: block");
        }
        else{
          config.setAttribute("style","display: none");
          document.getElementsByClassName("overlay")[0].setAttribute("style","display: none");
          }
      }
      else{
        config.setAttribute("style","display: block");
        document.getElementsByClassName("overlay")[0].setAttribute("style","display: block");
      }
    }
  };

  pesquisarTelas(str, telas) {
    var matches = [];

    telas.forEach(function(tela) {
        if (tela.title.toLowerCase().indexOf(str.toString().toLowerCase()) >= 0) {
            matches.push(tela);
        }
    });
    return matches;
  };

  goHome() {
  }

  compiler(value) {
    return value;
  }

  getPlatforms() {
  	return null;
  }

  switchLanguage(language: string) {
    this.translate.use(language);
  }

  doLogout() {
    var vm = this;
    function confirm() {
      vm.keycloak.logout();
      vm.appService.openPage("splash");
    }
    this.alertService.showConfirm("Atenção", "Confirma deslogar o usuário?", confirm);
  }
}
