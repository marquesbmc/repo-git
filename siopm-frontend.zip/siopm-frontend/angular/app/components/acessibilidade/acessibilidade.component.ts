import { Component, OnInit, Inject  } from '@angular/core';
import { Project } from "../../../environments/project";
import { LogService } from "../../services/log/log.service";
import { ApplicationService } from "../../services/application/application.service";
import { DOCUMENT } from '@angular/common';

declare var $ :any;

@Component({
  selector: 'app-acessibilidade',
  templateUrl: './acessibilidade.component.html',
  styleUrls: ['./acessibilidade.component.css']
})
export class AcessibilidadeComponent implements OnInit {

  constructor(@Inject(DOCUMENT) private document: any, private log: LogService, private appService: ApplicationService) {     
  }
  
  project = Project
  contraste = null;
  theme = this.project.themeEscolhido;
  checkboxModel = {
    alteraTemaContraste: {
      selected: false
    }
  };

  adequacaoAcessibilidade(){
    var size = $("body").css('font-size').replace('px', '');
    var sizenum = parseInt(size);

    for (var i = 1; i <= 6; i++) {
      var sizeh: string = $("h" + i).css('font-size');
      if (sizeh) {
        $("h" + i).css("cssText", "font-size : " + sizenum + "px");
      }
    }
    $(".btn-group-sm>.btn, .btn-sm").css("cssText", "font-size : " + sizenum + "px !important");
    $(".form-control").css("cssText", "font-size : " + sizenum + "px !important");
    $("body").css("cssText", "font-size: " + sizenum + "px !important");
    $(".theme-menu-item").css("cssText", "font-size: " + sizenum + "px !important");
    $(".theme-header-acessibilidade").css("cssText", "height: " + (sizenum + 12) + "px !important");
  }

  ngOnInit() {
    this.contraste = this.project.contraste;
    this.document.getElementById('theme').setAttribute('href', './assets/css/' + this.theme.value );
    this.adequacaoAcessibilidade();
    this.checkboxModel.alteraTemaContraste.selected = this.project.themeEscolhido.id == this.project.contraste.id ? true : false;
  }

  goElement(id) {
    var element = document.getElementById(id);
    element.focus();
    element.scrollIntoView();
  }
  
  myClick(item) {
    if (item && !item.selected && this.project.theme.value == this.project.themeEscolhido.value) {
    	this.project.themeEscolhido = this.project.contraste ;
    	this.document.getElementById('theme').setAttribute('href', './assets/css/' + this.contraste.value);    	
    } else {
  	  this.project.themeEscolhido = this.project.theme;  
    	this.document.getElementById('theme').setAttribute('href', './assets/css/' + this.project.themeEscolhido.value );    	
    }
    this.checkboxModel.alteraTemaContraste = item;
  }
  
  alterarFonte(isAumentar) {
    var size = $("body").css('font-size').replace('px', '');
    var sizenum = parseInt(size);

    if (isAumentar && sizenum <= 18) {
      var sizenum = parseInt(size) + 2;
      
      for (var i = 1; i <= 6; i++) {
        var sizeh: string = $("h" + i).css('font-size');
        if (sizeh) {
          sizeh = sizeh.replace('px', '');
          var sizehstr: Number = parseInt(sizeh) + 2;
          $("h" + i).css("cssText", "font-size : " + sizehstr + "px");
        }
      }
      $(".btn-group-sm>.btn, .btn-sm").css("cssText", "font-size : " + sizenum + "px !important");
      $(".form-control").css("cssText", "font-size : " + sizenum + "px !important");
      $("body").css("cssText", "font-size: " + sizenum + "px !important");
      $(".theme-menu-item").css("cssText", "font-size: " + sizenum + "px !important");
      $(".theme-header-acessibilidade").css("cssText", "height: " + (sizenum + 12) + "px !important");
    } else if (sizenum > 14 && !isAumentar) {
      var sizenum = parseInt(size) - 2;
  
      for (var i = 1; i <= 6; i++) {
        var sizeh: string = $("h" + i).css('font-size');
        if (sizeh) {
          sizeh = sizeh.replace('px', '');
          var sizehnum: Number = parseInt(sizeh) - 2;
          $("h" + i).css("cssText", "font-size : " + sizehnum + "px");
        }
      }
      $(".btn-group-sm>.btn, .btn-sm").css("cssText", "font-size : " + sizenum + "px !important");
      $(".form-control").css("cssText", "font-size : " + sizenum + "px !important");
      $("body").css("cssText", "font-size: " + sizenum + "px !important");
      $(".theme-menu-item").css("cssText", "font-size: " + sizenum + "px !important");
      $(".theme-header-acessibilidade").css("cssText", "height: " + (sizenum + 10) + "px !important");
    }
  }
  
  controlaMenu(){	
    var teste = $(".tabbar.show-tabbar").children("li");
    var num = teste.length / 2;
    
    for (var i=0; i < teste.length; i++){
      if (num > i){
        if (teste[i].children[1]) teste[i].children[1].classList.add("submenu-right");
      } else {
        if (teste[i].children[1]) teste[i].children[1].classList.add("submenu-left");
      }
    }
  }
}