import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd, Params, PRIMARY_OUTLET } from "@angular/router";
import 'rxjs/add/operator/filter';

interface IBreadcrumb {
  label: string;
  params?: Params;
  url: string;
}

@Component({
  selector: 'breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbComponent implements OnInit {

  private static Breadcrumbs: IBreadcrumb[] = [];
  public breadcrumbs: IBreadcrumb[];
  private root = null;

    constructor(private activatedRoute: ActivatedRoute,private router: Router ) {
      this.breadcrumbs = BreadcrumbComponent.Breadcrumbs;   
      this.root = router;
    }
  
    ngOnInit() {

      /*this.router.events.subscribe(event => { if(event instanceof NavigationEnd){

          let root: ActivatedRoute = this.activatedRoute.root;
          this.breadcrumbs = this.getBreadcrumbs(event,this.breadcrumbs);


        }
      });    */
      this.router.events.filter(event => event instanceof NavigationEnd).subscribe(event => {
        
        let root: ActivatedRoute = this.activatedRoute.root;
        BreadcrumbComponent.Breadcrumbs = this.getBreadcrumbs(event,BreadcrumbComponent.Breadcrumbs);
    });      

    }

    private getBreadcrumbs(event, breadcrumbs: IBreadcrumb[]): IBreadcrumb[] { 

      var routeConfig = this.root.config;
      var routePath =  event.url.replace("/","");


      var currentState = null;
      for (var i=0; i< routeConfig.length -1; i++ ) {
        var currentRoute = routeConfig[i];
        if (currentRoute.path == routePath) {
          currentState = currentRoute;
          break;
        }

      }
      if (currentState != null && currentState.data && currentState.data.label)  {
        var breadcrumb: IBreadcrumb = {
          label: currentState.data.label,
          params: [],
          url:  event.url
        };
        while(breadcrumbs.length > 0) {
				    breadcrumbs.pop();
				}
        breadcrumbs.push(breadcrumb);  
      }


      return breadcrumbs;
    }
    
    

}
