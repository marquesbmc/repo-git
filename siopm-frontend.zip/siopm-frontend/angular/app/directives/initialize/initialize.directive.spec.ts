import { InitializeDirective } from './initialize.directive';

describe('InitializeDirective', () => {
  it('should create an instance', () => {
    const directive = new InitializeDirective();
    expect(directive).toBeTruthy();
  });
});
