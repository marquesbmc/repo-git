/* 
Este arquivo é gerado automaticamente através do build executado pelo Jenkins. 
A variavel VERSAO_SISTEMA contempla a versão no padrão VEC que foi construida no build. 
*/ 
export const InfoBuild = {
    VERSAO_SISTEMA: '01.00.00.005',
    BUILD_NUMBER: '339',
    JOB_NAME: 'PROJ',
    BUILD_TIMESTAMP: '03/07/2019 - 10:26:55'
}