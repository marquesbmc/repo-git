package br.gov.caixa.sixxx.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ValidationUtils {

	public static Boolean isValidTextField(String text) {
		return !"".equalsIgnoreCase(text.trim());
	}
	
	public static Boolean isValidDateField(String date, String format) {
		if(!isValidTextField(date)){
			return false;
		}
		
		DateFormat sdf = new SimpleDateFormat(format);
        sdf.setLenient(false);
        try {
            sdf.parse(date);
        } catch (ParseException e) {
            return false;
        }
        return true;
	}
}
