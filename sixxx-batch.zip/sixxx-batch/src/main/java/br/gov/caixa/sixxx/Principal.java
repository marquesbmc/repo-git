package br.gov.caixa.sixxx;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Principal {

	// private static final Logger LOGGER = Logger.getLogger(Principal.class);

	public static void main(String[] args) {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:sqlserver://10.116.92.87:1433;databaseName=OBRDB003;user=SOBRRD03;password=UrzWPGEBu4Vq2m");

			Statement stm = con.createStatement();
			ResultSet rs = stm.executeQuery("SELECT * FROM OBRTBO01_OPERACAO ");

			while (rs.next()) {
				System.out.println(rs.getObject(1));
				System.out.println(rs.getObject(2));
				System.out.println(rs.getObject(3));
				System.out.println(rs.getObject(4));
				System.out.println(rs.getObject(5));
			}

			rs.close();
			stm.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}