package br.gov.caixa.sixxx.util;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class FormatterUtils {

	public static ZonedDateTime stringDateToZonedDateTime(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss.SSSSSS").withZone(ZoneId.systemDefault());
		ZonedDateTime formattedDate = ZonedDateTime.parse(date + " 00:00:00.000000", formatter); 
		ZonedDateTime minDate       = ZonedDateTime.parse("01/01/1900 00:00:00.000000", formatter);
		return formattedDate.compareTo(minDate) < 0 ? minDate : formattedDate;
	}
	
	public static BigDecimal stringToBigDecimal(String number) {
		return new BigDecimal(number.substring(0, 15) + "." + number.substring(15));
	}
	
	public static Date stringToDate(String date) throws ParseException {
		DateFormat formatoData = new SimpleDateFormat("dd/MM/yyyy");
		return formatoData.parse(date);
	}
	
	public static LocalDate stringToLocalDate(String date) throws ParseException {
		DateTimeFormatter formatter_1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		return  date.equals("0000000000") ? null : LocalDate.parse(date, formatter_1);
	}
	
	
}
