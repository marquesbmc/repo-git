package br.gov.caixa.sixxx;

import java.util.Date;

import javax.inject.Inject;

import org.apache.log4j.Logger;

//import br.gov.caixa.siobr.service.LocalidadeOperacaoServiceDB003;
//import br.gov.caixa.siobr.service.OperacaoServiceDB003;
//import br.gov.caixa.siobr.service.OrigemRecursoServiceDB003;
//import br.gov.caixa.siobr.service.ProgramaGovernoServiceDB003;

public class Main {
	
	private static final Logger LOGGER = Logger.getLogger(Main.class);
	
	//@Inject
	//private static OperacaoServiceDB003 operacaoService;
	
	//@Inject
	//private static LocalidadeOperacaoServiceDB003 localidadeService;
	
	//@Inject
	//private static OrigemRecursoServiceDB003 origemRecursoService;
	
	//@Inject
	//private static ProgramaGovernoServiceDB003 programaGovernoService;

	
    public static void main( String[] args ){    
    	
    	//operacaoService = new OperacaoServiceDB003();
    	//localidadeService = new LocalidadeOperacaoServiceDB003();
    	//origemRecursoService = new OrigemRecursoServiceDB003();
    	//programaGovernoService = new ProgramaGovernoServiceDB003();

    	
    	
    	try {
    		
    		LOGGER.info("Iniciando processamento SIOBR-BATCH");
    		
   		 // localidadeService.executarCarga();
   	     // origemRecursoService.executarCarga();
   	     // programaGovernoService.executarCarga();
    	 // operacaoService.executarCarga();
    		
    		
    		String val1 = args[0];
            String val2 = args[1];
            System.out.println(val1);
            System.out.println(val2);
   	     
   	     
   	  LOGGER.info("Finalizando SIOBR-BATCH com sucesso");
      LOGGER.info("Data de Finalização: " + new Date());
   		
//    		Connection conn = DriverManager.getConnection("jdbc:sqlserver://10.116.92.87:1433;databaseName=OBRDB002;integratedSecurity=true");
//    		Statement stm = conn.createStatement();
//    		ResultSet rs = stm.executeQuery("SELECT * FROM OBRTBO01_OPERACAO");
//    		
//    		while(rs.next()) {
//    			System.out.println(rs.getObject(1));
//    			System.out.println(rs.getObject(2));
//    			System.out.println(rs.getObject(3));
//    			System.out.println(rs.getObject(4));
//    			System.out.println(rs.getObject(5));
//    		}
//    		
//    		rs.close();
//    		stm.close();
//    		conn.close();
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	
//    	Integer      codigoRetorno = 1;
//    	CargaService cargaService  = new CargaService();
//    	
//    	try {
//    		String propertiesPath = args[0];
//        	String sistema        = args[1];
//    		
//    		PropertiesUtil.loadProperties(propertiesPath);
//    		
//    		if("APF".equalsIgnoreCase(sistema)) {
//    			cargaService.executarCargaAPF();
//    		}else if("IGF".equalsIgnoreCase(sistema)){
//    			cargaService.executarCargaIGF();
//    		} else {
//    			throw new BusinessException("Argumento especificado para c\u00F3digo do sistema \u00E9 inv\u00E1lido. C\u00F3digo do sistema deve ser APF ou IGF.");
//    		}
//    		
//			codigoRetorno = 0;
//			
//    	} catch (BusinessException be) {
//    		LOGGER.error(be.getMessage(), be);
//		} catch (Exception e) {
//			LOGGER.error("Ocorreu um erro n\u00E3o esperado.", e);
//		}finally {
//			System.exit(codigoRetorno);
//		}
    }
    
}