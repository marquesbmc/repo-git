package br.gov.caixa;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TesteData {

	public static void main(String[] args) {

		  String minhaData = "30/05/1980";
		  
		  
		  Date date = null;
		  
		  try {
			  java.util.Locale locale = new java.util.Locale("pt","BR");
			date = new SimpleDateFormat("dd/MM/yyyy", locale).parse(minhaData);
			
			System.out.println(new SimpleDateFormat("dd/MM/yyyy").format(date));
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  
		
	}
	
	
}
