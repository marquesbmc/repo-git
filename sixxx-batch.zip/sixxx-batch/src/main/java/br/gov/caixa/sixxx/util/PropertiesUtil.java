package br.gov.caixa.sixxx.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertiesUtil {
	
	private static Properties properties = new Properties();
	
	public static void loadProperties(String file) throws FileNotFoundException, IOException {
		properties.load(new FileInputStream(file));
	}
	
	public static String getProperty(String key) {
		return properties.getProperty(key);
	}
}
