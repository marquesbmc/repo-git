package br.gov.caixa.sixxx.exception;

public class BusinessException extends RuntimeException {

	private static final long serialVersionUID = 1554529508837720480L;

	public BusinessException(String message) {
        super(message);
    }
	
}
