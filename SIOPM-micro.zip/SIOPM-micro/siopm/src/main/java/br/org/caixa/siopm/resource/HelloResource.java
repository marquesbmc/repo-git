package br.org.caixa.siopm.resource;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.openapi.annotations.enums.SecuritySchemeType;
import org.eclipse.microprofile.openapi.annotations.security.OAuthFlow;
import org.eclipse.microprofile.openapi.annotations.security.OAuthFlows;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirements;
import org.eclipse.microprofile.openapi.annotations.security.SecurityScheme;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;


import io.quarkus.security.identity.SecurityIdentity;

@Path("/hello")
@Tag(name = "hello_test")
@SecurityScheme(securitySchemeName = "scheme", type = SecuritySchemeType.OAUTH2, flows = @OAuthFlows(password = @OAuthFlow(tokenUrl = "http://localhost:8180/auth/realms/intranet/protocol/openid-connect/token")))
public class HelloResource {

    @Inject
    SecurityIdentity identity;

    @GET
    @Path("publico")
    @Produces(MediaType.TEXT_PLAIN)
    public Response methodname() {
    	return Response.ok().entity("hello public").build();
    }
    
    @GET
    @Path("protegido")
    @Produces(MediaType.TEXT_PLAIN)
    @RolesAllowed("role1")
    @SecurityRequirements ( value  = { @SecurityRequirement ( name  =  " scheme " )})
   // @SecurityRequirement(name = "scheme")
    public Response hello() {
        return Response.ok().entity("hello user").build();
    }
    

  
}



/*
@Authenticated
public class HelloResource {

	@Inject
	SecurityIdentity identity;

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String hello() {
		return "Hello RESTEasy";
	}

	@GET
	@Path("/users")
	@RolesAllowed("user")
	@Produces(MediaType.TEXT_PLAIN)
	public String helloUsers() {
		return "Hello user";
	}

	@GET
	@Path("/users_admin")
	@RolesAllowed({ "user", "admin" })
	@Produces(MediaType.TEXT_PLAIN)
	public String helloUsersAdmins() {
		return "Hello user";
	}

	@GET
	@Path("/public")
	@PermitAll
	@Produces(MediaType.TEXT_PLAIN)
	public String helloPublic() {
		return "Hello public";
	}

	@GET
	//@Path("/uma_authorization")
	//@RolesAllowed({ "uma_authorization"})
	@Produces(MediaType.TEXT_PLAIN)
	public String helloUsersAdminsNome() {
		return "Hello uma_authorization " + identity.getPrincipal().getName();
	}
}*/