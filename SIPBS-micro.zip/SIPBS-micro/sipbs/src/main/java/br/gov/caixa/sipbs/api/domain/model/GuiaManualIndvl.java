package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO18_GUIA_MANUAL_INDVL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO18_GUIA_MANUAL_INDVL")
public class GuiaManualIndvl extends PanacheEntityBase {

	@Id
	@Column(name="NU_PBSO18")
	public Long nuPbso18;

	@Column(name="CO_BARRA_DIGITAL_GUIA_INDVL")
	public String coBarraDigitalGuiaIndvl;

	@Column(name="CO_BARRA_GUIA_INDIVIDUAL")
	public String coBarraGuiaIndividual;

	@Column(name="IC_SITUACAO_GUIA")
	public String icSituacaoGuia;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_GUIA_INDIVIDUAL")
	public Integer nuGuiaIndividual;

	@Column(name="NU_PBSO04")
	public Long nuPbso04;

	@Column(name="NU_PBSO17")
	public Long nuPbso17;

	@Column(name="TS_BAIXA_GUIA")
	public Timestamp tsBaixaGuia;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}