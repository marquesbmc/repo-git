package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO19_TIPO_PRODUTO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO19_TIPO_PRODUTO")
public class TipoProduto extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_TIPO_PRODUTO")
	public Short nuTipoProduto;

	@Column(name="NO_TIPO_PRODUTO")
	public String noTipoProduto;

	@Column(name="NU_TIPO_NATUREZA_PBSO20")
	public Short nuTipoNaturezaPbso20;
}