package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWF04_FOLHA_PROGRAMA_SOCIAL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWF04_FOLHA_PROGRAMA_SOCIAL")
public class FolhaProgramaSocial extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSF04")
	public Integer nuPbsf04;

	@Column(name="IC_BLOQUEIO_FOLHA")
	public String icBloqueioFolha;

	@Column(name="IC_QUEBRA_ESCALONAMENTO")
	public String icQuebraEscalonamento;

	@Column(name="NU_COMPETENCIA")
	public Integer nuCompetencia;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PBSB10")
	public Integer nuPbsb10;

	@Column(name="NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}