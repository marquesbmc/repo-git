package br.gov.caixa.sipbs.api.domain.dao;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.ArquivoFisico;
import br.gov.caixa.sipbs.api.utils.Constantes;

/**
 * 
 * @author SPREAD
 *
 */
@ApplicationScoped
public class ArquivoFisicoDAO extends GenericDAO<ArquivoFisico> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ArquivoFisicoDAO.class);

	@Override
	@SuppressWarnings("unchecked")
	public List<ArquivoFisico> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_LIST_PAG);
		try {
			int numeroPag = calcularNumeroPagina(pagina);
			int linhas;
			if(qtdPorPagina > 0) {
				linhas = qtdPorPagina + numeroPag;				
			} else {
				linhas = super.qtdPorPagina + numeroPag;
			}
						
			StringBuilder sql = new StringBuilder()
					.append(" SELECT NU_PBSD03, CO_SEGURANCA, DE_ERRO_GERACAO_ARQUIVO, IC_ARQUIVO, NO_ARQUIVO, NU_ARQUIVO_SISTEMA_PBSD04, NU_COMPETENCIA, NU_EVENTO_INCLUSAO_PBSA12, NU_EVENTO_PBSA12, NU_PRODUTO_PBSB02, NU_REMESSA, NU_SITUACAO_ARQUIVO_PBSD06, QT_ACATADO, QT_REJEITADO, QT_TOTAL_REGISTROS, TS_FIM_PROCESSAMENTO, TS_INICIO_PROCESSAMENTO ")
					.append(" FROM ( ")
					.append(" SELECT T.NU_PBSD03, T.CO_SEGURANCA, T.DE_ERRO_GERACAO_ARQUIVO, T.IC_ARQUIVO, T.NO_ARQUIVO, T.NU_ARQUIVO_SISTEMA_PBSD04, T.NU_COMPETENCIA, T.NU_EVENTO_INCLUSAO_PBSA12, T.NU_EVENTO_PBSA12, T.NU_PRODUTO_PBSB02, T.NU_REMESSA, T.NU_SITUACAO_ARQUIVO_PBSD06, T.QT_ACATADO, T.QT_REJEITADO, T.QT_TOTAL_REGISTROS, T.TS_FIM_PROCESSAMENTO, T.TS_INICIO_PROCESSAMENTO ")
					.append(", ROW_NUMBER() OVER () ROWNUMBER_ FROM ")
					.append(" {h-schema}PBSVWD03_ARQUIVO_FISICO ")
					.append(" T ")
					.append(" FETCH FIRST ")
					.append(linhas)
					.append(" ROWS ONLY ) AS INNER_ WHERE ROWNUMBER_ > ")
					.append(numeroPag)
					.append( " ORDER BY ROWNUMBER_");

			Query query = emDb2.createNativeQuery(sql.toString(), ArquivoFisico.class);
			return query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_LIST_PAG, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public List<ArquivoFisico> listAll() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArquivoFisico findById(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArquivoFisico create(ArquivoFisico request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArquivoFisico update(ArquivoFisico request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long count() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

}