package br.gov.caixa.sipbs.api.controllers;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import br.gov.caixa.sipbs.api.domain.service.PagamentoSituacaoService;
import br.gov.caixa.sipbs.api.dtos.PagamentoCanalDTO;
import br.gov.caixa.sipbs.api.dtos.FiltroRelatorioDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoParcelaSituacaoDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;

@Path("/api/pagamento-situacao/v2")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
@Transactional
@OpenAPIDefinition(info = @Info(description = "Conjunto de endpoints para consultas relacionadas ao relatório sintético de evolução das aprcelas por situação", title = "Relatório Sintético de avolução de parcelas por situação", version = "1.0"))
public class PagamentoSituacaoController extends Controller<PagamentoCanalDTO, ResponseEntity<?>> {

	@Autowired
	PagamentoSituacaoService pagamentoSituacaoService;

	@POST
	@Path("/consultar-lotes")
	@Timeout(3000)
	// @RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<List<Long>> consultarLotes(FiltroRelatorioDTO filtro) {
		try {
			LocalDate dtInicioPeriodo = LocalDate.parse(filtro.getDtInicioPeriodoString(), DateTimeFormatter.ISO_DATE);
			LocalDate dtFimPeriodo = LocalDate.parse(filtro.getDtFimPeriodoString(), DateTimeFormatter.ISO_DATE);

			List<Long> lotes = pagamentoSituacaoService.consultarLotes(filtro.getNuProdutoIcoo10(), dtInicioPeriodo, dtFimPeriodo);
			if (lotes != null) {
				return ResponseEntity.ok(lotes);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@POST
	@Path("/relatorio/sintetico-pagamento")
	@Timeout(3000)
	// @RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<RelatorioSinteticoParcelaSituacaoDTO> recuperarRelatorioSinteticoPagamentoCanal(FiltroRelatorioDTO filtro) {
		try {
			LocalDate dtInicioPeriodo = LocalDate.parse(filtro.getDtInicioPeriodoString(), DateTimeFormatter.ISO_DATE);
			LocalDate dtFimPeriodo = LocalDate.parse(filtro.getDtFimPeriodoString(), DateTimeFormatter.ISO_DATE);

			RelatorioSinteticoParcelaSituacaoDTO relatorioSinteticoParcelaSituacaoDTO = pagamentoSituacaoService
					.recuperarRelatorioSinteticoPagamentoSituacao(filtro.getNuProdutoIcoo10(), dtInicioPeriodo, dtFimPeriodo, filtro.getLotes());
			if (relatorioSinteticoParcelaSituacaoDTO != null) {
				return ResponseEntity.ok(relatorioSinteticoParcelaSituacaoDTO);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@POST
	@Path("/relatorio/sintetico-pagamento/exportar")
	@Produces("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	@Timeout(3000)
	// @RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<byte[]> exportarRelatorioSinteticoPagamento(FiltroRelatorioDTO filtro) {
		try {
			LocalDate dtInicioPeriodo = LocalDate.parse(filtro.getDtInicioPeriodoString(), DateTimeFormatter.ISO_DATE);
			LocalDate dtFimPeriodo = LocalDate.parse(filtro.getDtFimPeriodoString(), DateTimeFormatter.ISO_DATE);

			ByteArrayOutputStream arquivoxlsx = pagamentoSituacaoService
					.exportarRelatorioSinteticoPagamento(filtro.getNuProdutoIcoo10(), dtInicioPeriodo, dtFimPeriodo, filtro.getLotes());
			if (arquivoxlsx != null) {
				return ResponseEntity.ok()
						.header("Content-Disposition",
								String.format("attachment; filename=\"%s\"",
										"Relatório Sintético - Parcelas Pagas por Situação.xlsx"))
						.body(arquivoxlsx.toByteArray());
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}
	
	@POST
	@Path("/relatorio/sintetico-pagamento/exportarCSV")
	@Produces("text/csv")
	@Timeout(3000)
	// @RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<byte[]> exportarRelatorioSinteticoPagamentoCSV(FiltroRelatorioDTO filtro) {
		try {
			LocalDate dtInicioPeriodo = LocalDate.parse(filtro.getDtInicioPeriodoString(), DateTimeFormatter.ISO_DATE);
			LocalDate dtFimPeriodo = LocalDate.parse(filtro.getDtFimPeriodoString(), DateTimeFormatter.ISO_DATE);

			byte[] arquivoCSV = pagamentoSituacaoService
					.exportarRelatorioSinteticoPagamentoCSV(filtro.getNuProdutoIcoo10(), dtInicioPeriodo, dtFimPeriodo, filtro.getLotes());
			if (arquivoCSV != null) {
				return ResponseEntity.ok()
						.header("Content-Disposition",
								String.format("attachment; filename=\"%s\"",
										"Relatório Sintético - Parcelas Pagas por Situação.csv"))
						.body(arquivoCSV);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@Override
	public ResponseEntity<?> listAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> listPag(int pagina) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> listPag(int pagina, int qtdPorPagina) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> create(PagamentoCanalDTO request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> update(Long id, PagamentoCanalDTO request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> delete(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}