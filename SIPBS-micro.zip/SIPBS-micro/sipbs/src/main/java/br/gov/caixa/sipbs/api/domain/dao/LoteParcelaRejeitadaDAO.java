package br.gov.caixa.sipbs.api.domain.dao;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.LoteParcelaRejeitada;

@ApplicationScoped
public class LoteParcelaRejeitadaDAO extends GenericDAO<LoteParcelaRejeitada> {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoteParcelaRejeitadaDAO.class);

	@SuppressWarnings({"unchecked"})
	public List<LoteParcelaRejeitada> recuperarRelatorioSinteticoLoteParcelaRejeitada(Short nuProdutoIcoo10, Long nuRemessa,  LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException {

		LOGGER.info("Chamando método recuperarRelatorioSinteticoLoteParcelasRejeitadas com os parâmetros " + nuProdutoIcoo10
				+ " - " + dtInicioPeriodo + " - " + dtFimPeriodo);

		try {
			
			List<LoteParcelaRejeitada> lotesParcelaRejeitada;

			if( nuRemessa != null ) {


				StringBuilder queryLoteParcelasRejeitadas = new StringBuilder(" SELECT  LPR.NU_PBSR03 AS NU_PBSR03, LP.NU_PBSR02 AS NU_PBSR02, AF.NO_ARQUIVO AS NO_ARQUIVO, LP.NU_PRODUTO_ICOO10 AS NU_PRODUTO_ICOO10, LP.NU_REFERENCIA AS NU_REFERENCIA ")
						.append(" , LP.NU_REMESSA AS NU_REMESSA, LP.DT_PROCESSAMENTO AS DT_PROCESSAMENTO, TMR.DE_MOTIVO_REJEICAO_REGISTRO AS DE_MOTIVO_REJEICAO_REGISTRO, SUM(LPR.QT_PARCELAS_REJEITADAS) AS QT_PARCELAS_REJEITADAS, SUM(LPR.VR_TOTAL_PARCELAS_REJEITADAS) AS VR_TOTAL_PARCELAS_REJEITADAS ")
						.append(" FROM   {h-schema}PBSVWR02_LOTE_PARCELA LP ")
						.append("       ,{h-schema}PBSVWR03_LOTE_PARCELA_REJEITADA LPR ")
						.append("       ,{h-schema}PBSVWD13_TPO_MTVO_RJCAO_RGTO TMR ")
						.append("       ,{h-schema}PBSVWD03_ARQUIVO_FISICO AF ")
						.append(" WHERE   LP.NU_PBSR02 = LPR.NU_PBSR02 ")
						.append(" AND     LPR.NU_TIPO_MOTIVO_PBSD13 = TMR.NU_TIPO_MOTIVO_REGISTRO ")
						.append(" AND     LP.NU_PBSD03 = AF.NU_PBSD03 ")
						.append(" AND     LP.NU_PRODUTO_ICOO10 = :nuProdutoIcoo10 ");
				queryLoteParcelasRejeitadas.append(" AND LP.NU_REMESSA = :nuRemessa ");
				queryLoteParcelasRejeitadas.append(" GROUP BY LPR.NU_PBSR03, LP.NU_PBSR02, AF.NO_ARQUIVO, LP.NU_PRODUTO_ICOO10, LP.NU_REFERENCIA, LP.NU_REMESSA, LP.DT_PROCESSAMENTO, TMR.DE_MOTIVO_REJEICAO_REGISTRO ")
										   .append(" ORDER BY LPR.NU_PBSR03, LP.NU_PBSR02, AF.NO_ARQUIVO, LP.NU_PRODUTO_ICOO10, LP.NU_REFERENCIA, LP.NU_REMESSA, LP.DT_PROCESSAMENTO, TMR.DE_MOTIVO_REJEICAO_REGISTRO ");


				Query query = emDb2.createNativeQuery(queryLoteParcelasRejeitadas.toString(), LoteParcelaRejeitada.class );
				query.setParameter("nuProdutoIcoo10", nuProdutoIcoo10);
				query.setParameter("nuRemessa", nuRemessa);
	
				lotesParcelaRejeitada = query.getResultList();
				
			} else {
				
			
				StringBuilder queryLoteParcelasRejeitadas = new StringBuilder(" SELECT  LP.NU_PRODUTO_ICOO10 AS NU_PRODUTO_ICOO10, LP.NU_REFERENCIA AS NU_REFERENCIA ")
						.append(" , TMR.DE_MOTIVO_REJEICAO_REGISTRO AS DE_MOTIVO_REJEICAO_REGISTRO, SUM(LPR.QT_PARCELAS_REJEITADAS) AS QT_PARCELAS_REJEITADAS, SUM(LPR.VR_TOTAL_PARCELAS_REJEITADAS) AS VR_TOTAL_PARCELAS_REJEITADAS ")
						.append(" FROM   {h-schema}PBSVWR02_LOTE_PARCELA LP ")
						.append("       ,{h-schema}PBSVWR03_LOTE_PARCELA_REJEITADA LPR ")
						.append("       ,{h-schema}PBSVWD13_TPO_MTVO_RJCAO_RGTO TMR ")
						.append("       ,{h-schema}PBSVWD03_ARQUIVO_FISICO AF ")
						.append(" WHERE   LP.NU_PBSR02 = LPR.NU_PBSR02 ")
						.append(" AND     LPR.NU_TIPO_MOTIVO_PBSD13 = TMR.NU_TIPO_MOTIVO_REGISTRO ")
						.append(" AND     LP.NU_PBSD03 = AF.NU_PBSD03 ")
						.append(" AND     LP.NU_PRODUTO_ICOO10 = :nuProdutoIcoo10 ");
				queryLoteParcelasRejeitadas.append(" AND LP.DT_PROCESSAMENTO BETWEEN DATE('" + dtInicioPeriodo + "') AND DATE('" + dtFimPeriodo + "') ");
				queryLoteParcelasRejeitadas.append(" GROUP BY LP.NU_PRODUTO_ICOO10, LP.NU_REFERENCIA, TMR.DE_MOTIVO_REJEICAO_REGISTRO ")
										   .append(" ORDER BY LP.NU_PRODUTO_ICOO10, LP.NU_REFERENCIA, TMR.DE_MOTIVO_REJEICAO_REGISTRO ");

				Query query = emDb2.createNativeQuery(queryLoteParcelasRejeitadas.toString());
				query.setParameter("nuProdutoIcoo10", nuProdutoIcoo10);

				lotesParcelaRejeitada = new ArrayList<LoteParcelaRejeitada>();
				
				List<Object[]> result = query.getResultList();
				
				LoteParcelaRejeitada loteParcelaRejeitada;
				
				for (Object[] object : result) {
					int cont = 0;
					loteParcelaRejeitada = new LoteParcelaRejeitada();
					loteParcelaRejeitada.setNuProgramaSocial(Integer.valueOf(object[cont++] + ""));
					loteParcelaRejeitada.setNuReferencia(Integer.valueOf(object[cont++] + ""));
					loteParcelaRejeitada.setDeTipoMotivoRejeicao(object[cont++] + "");
					loteParcelaRejeitada.setQtParcelasRejeitadas(Long.valueOf(object[cont++] + ""));
					loteParcelaRejeitada.setVrTotalParcelasRejeitadas(BigDecimal.valueOf(Double.valueOf(object[cont++] + "")));
					
					lotesParcelaRejeitada.add(loteParcelaRejeitada);
				}


			}

			return lotesParcelaRejeitada;

		} catch (Exception e) {
			LOGGER.error("Erro em " + "Chamando método recuperarRelatorioSinteticoLoteParcelasRejeitadas com os parâmetros", e);
			e.printStackTrace();
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}



	@Override
	public List<LoteParcelaRejeitada> listAll() throws GeneralException {
		return null;
	}

	@Override
	public List<LoteParcelaRejeitada> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return null;
	}

	@Override
	public LoteParcelaRejeitada findById(Long id) throws GeneralException {
		return null;
	}

	@Override
	public LoteParcelaRejeitada create(LoteParcelaRejeitada request) throws GeneralException {
		return null;
	}

	@Override
	public LoteParcelaRejeitada update(LoteParcelaRejeitada request) throws GeneralException {
		return null;
	}

	@Override
	public void delete(Long id) throws GeneralException {

	}

	@Override
	public Long count() throws GeneralException {
		return null;
	}
}
