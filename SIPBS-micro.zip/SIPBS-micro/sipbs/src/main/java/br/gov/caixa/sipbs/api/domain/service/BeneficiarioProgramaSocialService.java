package br.gov.caixa.sipbs.api.domain.service;

import java.util.List;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.BeneficiarioProgramaSocialDTO;
import br.gov.caixa.sipbs.api.dtos.MarcasImpeditivasDTO;
import br.gov.caixa.sipbs.api.dtos.OposicaoTipoContaDTO;

public interface BeneficiarioProgramaSocialService {

	List<BeneficiarioProgramaSocialDTO> listAll();

	List<BeneficiarioProgramaSocialDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException;

	List<BeneficiarioProgramaSocialDTO> listFilter(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException;

	OposicaoTipoContaDTO findOposicaoCreditoConta(Long nuCpfBeneficiario, Short nuTipoConta, Short nuProdutoIcoo10);

	List<MarcasImpeditivasDTO> listMarcasImpeditivas(Short nuProdutoIcoo10, Long nuCpfBeneficiario, Integer nuPbsb06) throws GeneralException;

	BeneficiarioProgramaSocialDTO findById(Long id);

	BeneficiarioProgramaSocialDTO create(BeneficiarioProgramaSocialDTO request);

	BeneficiarioProgramaSocialDTO update(Long id, BeneficiarioProgramaSocialDTO request);

	void delete(Long id);

	Long count();
	
	BeneficiarioProgramaSocialDTO searchBeneficiario(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException;
}
