package br.gov.caixa.sipbs.api.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name = "PBSVWA12_EVENTO")
public class Evento extends PanacheEntityBase {

	@Id
	@Column(name = "NU_EVENTO")
	public Long id;

	@Column(name = "TS_INICIO")
	@JsonFormat(pattern = "dd/MM/yyyy")
	public Date inicio;

	@Column(name = "CO_IDENTIFICADOR")
	public String codigo;

	@Column(name = "CO_APLICACAO")
	public String codigoAplicacao;

	@Column(name = "NU_TAREFA")
	public Long idTarefa;

	@Column(name = "CO_PROGRAMA")
	public String codigoPrograma;

	@Column(name = "CO_TIPO_AMBIENTE")
	public String codigoTipoAmbiente;

	@Column(name = "TS_FIM")
	@JsonFormat(pattern = "dd/MM/yyyy")
	public Date fim;

	@Column(name = "NU_TIPO_CREDENCIAL")
	public Integer tipoCredencial;

	@Column(name = "CO_CREDENCIAL")
	public String codigoCredencial;

}