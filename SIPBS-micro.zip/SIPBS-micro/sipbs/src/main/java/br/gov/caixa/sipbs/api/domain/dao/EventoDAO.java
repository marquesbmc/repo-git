package br.gov.caixa.sipbs.api.domain.dao;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.EntidadeNaoEncontradaException;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.Evento;
import br.gov.caixa.sipbs.api.utils.Constantes;

/**
 * 
 * @author SPREAD
 *
 */
@ApplicationScoped
public class EventoDAO extends GenericDAO<Evento> {

	private static final Logger LOGGER = LoggerFactory.getLogger(EventoDAO.class);

	@Override
	@SuppressWarnings("unchecked")
	public List<Evento> listAll() throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_LIST_ALL);
		try {
			StringBuilder sql = new StringBuilder()
					.append(" SELECT NU_EVENTO, TS_INICIO, CO_IDENTIFICADOR, CO_APLICACAO, NU_TAREFA, CO_PROGRAMA, CO_TIPO_AMBIENTE, TS_FIM, NU_TIPO_CREDENCIAL, CO_CREDENCIAL FROM {h-schema}PBSVWA12_EVENTO ORDER BY NU_EVENTO DESC  FETCH FIRST 50 ROWS ONLY ");
			Query query = emDb2.createNativeQuery(sql.toString(), Evento.class);
			return query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_LIST_ALL, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Evento> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_LIST_PAG);
		try {
			int numeroPag = calcularNumeroPagina(pagina);
			int linhas;
			if(qtdPorPagina > 0) {
				linhas = qtdPorPagina + numeroPag;				
			} else {
				linhas = super.qtdPorPagina + numeroPag;
			}
			
			StringBuilder sql = new StringBuilder()
					.append(" SELECT NU_EVENTO, TS_INICIO, CO_IDENTIFICADOR, CO_APLICACAO, NU_TAREFA, CO_PROGRAMA, CO_TIPO_AMBIENTE, TS_FIM, NU_TIPO_CREDENCIAL, CO_CREDENCIAL ")
					.append(" FROM ( ")
					.append(" SELECT T.NU_EVENTO, T.TS_INICIO, T.CO_IDENTIFICADOR, T.CO_APLICACAO, T.NU_TAREFA, T.CO_PROGRAMA, T.CO_TIPO_AMBIENTE, T.TS_FIM, T.NU_TIPO_CREDENCIAL, T.CO_CREDENCIAL ")
					.append(", ROW_NUMBER() OVER () ROWNUMBER_ FROM ")
					.append(" {h-schema}PBSVWA12_EVENTO ")
					.append(" T ")
					.append(" FETCH FIRST ")
					.append(linhas)
					.append(" ROWS ONLY ) AS INNER_ WHERE ROWNUMBER_ > ")
					.append(numeroPag)
					.append( " ORDER BY ROWNUMBER_");

			Query query = emDb2.createNativeQuery(sql.toString(), Evento.class);
			return query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_LIST_PAG, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public Evento findById(Long id) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_READ);
		try {
			StringBuilder sql = new StringBuilder()
					.append(" SELECT NU_EVENTO, TS_INICIO, CO_IDENTIFICADOR, CO_APLICACAO, NU_TAREFA, CO_PROGRAMA, CO_TIPO_AMBIENTE, TS_FIM, NU_TIPO_CREDENCIAL, CO_CREDENCIAL ")
					.append(" FROM {h-schema}PBSVWA12_EVENTO WHERE NU_EVENTO = :id");
			Query query = emDb2.createNativeQuery(sql.toString(), Evento.class);
			query.setParameter("id", id);
			return (Evento) query.getSingleResult();
		} catch (NoResultException e) {
			throw new EntidadeNaoEncontradaException(EntidadeNaoEncontradaException.RESPONSE_CODE_ERROR_NO_ENTITY_FOUND, e);	
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_READ, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public Evento create(Evento request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Evento update(Evento request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long count() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}
}