package br.gov.caixa.sipbs.api.domain.repository.jpa;

import javax.enterprise.context.ApplicationScoped;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.sipbs.api.domain.model.Evento;

@ApplicationScoped
public interface EventoRepository extends JpaRepository<Evento, Long> {
}
