package br.gov.caixa.sipbs.api.dtos;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class EventoDTO {

	private Long id;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date inicio;
	private String codigo;
	private String codigoAplicacao;
	private Long idTarefa;
	private String codigoPrograma;
	private String codigoTipoAmbiente;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date fim;
	private Integer tipoCredencial;
	private String codigoCredencial;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getInicio() {
		return inicio;
	}

	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCodigoAplicacao() {
		return codigoAplicacao;
	}

	public void setCodigoAplicacao(String codigoAplicacao) {
		this.codigoAplicacao = codigoAplicacao;
	}

	public Long getIdTarefa() {
		return idTarefa;
	}

	public void setIdTarefa(Long idTarefa) {
		this.idTarefa = idTarefa;
	}

	public String getCodigoPrograma() {
		return codigoPrograma;
	}

	public void setCodigoPrograma(String codigoPrograma) {
		this.codigoPrograma = codigoPrograma;
	}

	public String getCodigoTipoAmbiente() {
		return codigoTipoAmbiente;
	}

	public void setCodigoTipoAmbiente(String codigoTipoAmbiente) {
		this.codigoTipoAmbiente = codigoTipoAmbiente;
	}

	public Date getFim() {
		return fim;
	}

	public void setFim(Date fim) {
		this.fim = fim;
	}

	public Integer getTipoCredencial() {
		return tipoCredencial;
	}

	public void setTipoCredencial(Integer tipoCredencial) {
		this.tipoCredencial = tipoCredencial;
	}

	public String getCodigoCredencial() {
		return codigoCredencial;
	}

	public void setCodigoCredencial(String codigoCredencial) {
		this.codigoCredencial = codigoCredencial;
	}
}