package br.gov.caixa.sipbs.api.dtos;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor

public class PropriedadeContaDTO {

	public short nuPropriedadeConta;
	public short nuPropriedadeProduto;
	public String dePropriedadeProduto;
	public TipoContaDTO tipoConta;
	public long nuEventoPbsa12;
}
