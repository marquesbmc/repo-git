package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntity;


/**
 * The persistent class for the PBSVWD04_ARQUIVO_SISTEMA database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWD04_ARQUIVO_SISTEMA")
public class ArquivoSistema extends PanacheEntity {

	@Column(name="CO_LEIAUTE_PBSD02")
	public String coLeiautePbsd02;

	@Column(name="NU_ARQUIVO_SISTEMA")
	public Long nuArquivoSistema;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PRODUTO_DESTINO_ICOO10")
	public Short nuProdutoDestinoIcoo10;

	@Column(name="NU_PRODUTO_ORIGEM_ICOO10")
	public Short nuProdutoOrigemIcoo10;

	@Column(name="NU_SEGMENTO_DESTINO_ICOS12")
	public Short nuSegmentoDestinoIcos12;

	@Column(name="NU_SEGMENTO_ORIGEM_ICOS12")
	public Short nuSegmentoOrigemIcos12;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;

}