package br.gov.caixa.sipbs.api.controllers;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Counted;
import org.eclipse.microprofile.metrics.annotation.Timed;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import br.gov.caixa.sipbs.api.domain.service.BeneficiarioProgramaSocialService;
import br.gov.caixa.sipbs.api.dtos.BeneficiarioProgramaSocialDTO;
import br.gov.caixa.sipbs.api.dtos.BeneficiarioSocialDTO;
import br.gov.caixa.sipbs.api.dtos.MarcasImpeditivasDTO;
import br.gov.caixa.sipbs.api.dtos.OposicaoTipoContaDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;

@Path("/api/beneficiario-programa-social/v2")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
@Transactional
@OpenAPIDefinition(info = @Info(description = "Conjunto de endpoints para consultas relacionadas à contas Beneficiário", title = "Contas Beneficiário", version = "1.0"))
public class BeneficiarioProgramaSocialController extends Controller<BeneficiarioProgramaSocialDTO, ResponseEntity<?>> {

	@Autowired
	BeneficiarioProgramaSocialService service;

	@GET
	@Path("/list/{icCpfNis}/{nuCpfNis}/{nuProdutoIcoo10}")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<List<BeneficiarioProgramaSocialDTO>> listFilter(@PathParam("icCpfNis") String icCpfNis,
	                                                                      @PathParam("nuCpfNis") Long nuCpfNis,
	                                                                      @PathParam("nuProdutoIcoo10") Short nuProdutoIcoo10) {
		try {
			List<BeneficiarioProgramaSocialDTO> lista = service.listFilter(icCpfNis, nuCpfNis, nuProdutoIcoo10);
			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/oposicao-credito/{nuCpfBeneficiario}/{nuTipoConta}/{nuProdutoIcoo10}")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<OposicaoTipoContaDTO> findOposicaoCreditoConta(@PathParam("nuCpfBeneficiario") Long nuCpfBeneficiario,
	                                                                     @PathParam("nuTipoConta") Short nuTipoConta,
	                                                                     @PathParam("nuProdutoIcoo10") Short nuProdutoIcoo10) {
		try {
			OposicaoTipoContaDTO oposicaoTipoContaDTO = service.findOposicaoCreditoConta(nuCpfBeneficiario, nuTipoConta, nuProdutoIcoo10);
			if (oposicaoTipoContaDTO != null) {
				return ResponseEntity.ok(oposicaoTipoContaDTO);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/marcas-impeditivas/{nuProdutoIcoo10}/{nuCpfBeneficiario}/{nuPbsb06}")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<List<MarcasImpeditivasDTO>> listMarcasImpeditivas(@PathParam("nuProdutoIcoo10") Short nuProdutoIcoo10,
	                                                                           @PathParam("nuCpfBeneficiario") Long nuCpfBeneficiario,
	                                                                           @PathParam("nuPbsb06") Integer nuPbsb06) {
		try {
			List<MarcasImpeditivasDTO> contaMarcadaMarcacaoDTOList = service.listMarcasImpeditivas(nuProdutoIcoo10, nuCpfBeneficiario, nuPbsb06);
			if (contaMarcadaMarcacaoDTOList != null) {
				return ResponseEntity.ok(contaMarcadaMarcacaoDTOList);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}




	@GET
	@Path("/list")
	@Timeout(3000)
	@Fallback(fallbackMethod = "listFallback")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<List<BeneficiarioProgramaSocialDTO>> list() {
		return null;
	}

	@GET
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.beneficiario-programa-social.listAll",
			displayName = "Tempo da listagem completa",
			description = "Tempo da listagem em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem", description = "Quantidade de listagem realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> listAll() {
		return null;
	}

	@GET
	@Path("/pagina/{pagina}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.beneficiario-programa-social.listPag",
			displayName = "Tempo da listagem paginada",
			description = "Tempo da listagem paginada em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem Paginada", description = "Quantidade de listagens paginadas realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?>listPag(@PathParam("pagina") int pagina) {
		return null;
	}

	public ResponseEntity<List<BeneficiarioProgramaSocialDTO>> listFallback() {
		try {
			List<BeneficiarioProgramaSocialDTO> lista = service.listPag(1, qtdPorPagina);

			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/pagina/{pagina}/{qtdPorPagina}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.beneficiario-programa-social.listPag",
			displayName = "Tempo da listagem paginada",
			description = "Tempo da listagem paginada em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem Paginada", description = "Quantidade de listagens paginadas realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> listPag(@PathParam("pagina") int pagina, @PathParam("qtdPorPagina") int qtdPorPagina) {
		return null;
	}

	@GET
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.beneficiario-programa-social.findById",
			displayName = "Tempo da consulta por ID",
			description = "Tempo da consulta por ID em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de consultas por ID", description = "Quantidade de consultas por ID realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> findById(@PathParam("id") Long id) {
		return null;
	}

	@POST
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.beneficiario-programa-social.create",
			displayName = "Tempo do cadastro",
			description = "Tempo do cadastro em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de cadastros", description = "Quantidade de cadastros realizados")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> create(BeneficiarioProgramaSocialDTO request) {
		return null;
	}

	@PUT
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.beneficiario-programa-social.update",
			displayName = "Tempo da atualizacao",
			description = "Tempo da atualizacao em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de atualizacoes", description = "Quantidade de atualizacoes realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> update(@PathParam("id") Long id, BeneficiarioProgramaSocialDTO request) {
		return null;
	}

	@DELETE
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.beneficiario-programa-social.delete",
			displayName = "Tempo da exclusao",
			description = "Tempo da exclusao em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de exclusoes", description = "Quantidade de exclusoes realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> delete(@PathParam("id") Long id) {
		return null;
	}
	
	@GET
	@Path("/searchBeneficiario/{icCpfNis}/{nuCpfNis}/{nuProdutoIcoo10}")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<BeneficiarioSocialDTO> searchBeneficiario(@PathParam("icCpfNis") String icCpfNis,
	                                                                      @PathParam("nuCpfNis") Long nuCpfNis,
	                                                                      @PathParam("nuProdutoIcoo10") Short nuProdutoIcoo10) {
		try {
			BeneficiarioProgramaSocialDTO beneficiario = service.searchBeneficiario(icCpfNis, nuCpfNis, nuProdutoIcoo10);
			if (beneficiario != null && beneficiario.getBeneficiarioSocial() != null) {
				return ResponseEntity.ok(beneficiario.getBeneficiarioSocial());
			}
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}
}
