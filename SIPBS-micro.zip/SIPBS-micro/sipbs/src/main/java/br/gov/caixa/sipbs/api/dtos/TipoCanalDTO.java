package br.gov.caixa.sipbs.api.dtos;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class TipoCanalDTO {

	private Short nuTipoCanal;
	private String deTipoCanal;
	private String coTipoCanal;
	private String sgSitemaPagamento;
}
