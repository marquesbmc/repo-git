package br.gov.caixa.sipbs.api.dtos;

import java.sql.Timestamp;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class BeneficiarioSocialDTO {

	public Integer nuPbsb05;
	public Long nuCpfBeneficiario;
	public Long nuNisBeneficiario;
	public String noBeneficiario;
	public Timestamp tsFimVigencia;
	public Timestamp tsIdVigencia;
	public Timestamp tsInicioVigencia;
	public Long nuEventoPbsa12;

}
