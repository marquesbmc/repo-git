package br.gov.caixa.sipbs.api.domain.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO14_CONVERSAO_PARCELA database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO14_CONVERSAO_PARCELA")
public class ConversaoParcela extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSO14")
	public Long nuPbso14;

	@Column(name="NU_CNPJ_RESPONSAVEL_BENEFICIO")
	public BigDecimal nuCnpjResponsavelBeneficio;

	@Column(name="NU_CPF_BENEFICIARIO")
	public BigDecimal nuCpfBeneficiario;

	@Column(name="NU_EVENTO_CONTABIL")
	public Short nuEventoContabil;

	@Column(name="NU_NIS_BENEFICIARIO")
	public BigDecimal nuNisBeneficiario;

	@Column(name="NU_NIS_DEPENDENTE")
	public BigDecimal nuNisDependente;

	@Column(name="NU_PRODUTO")
	public Short nuProduto;

	@Column(name="NU_REFERENCIA")
	public Integer nuReferencia;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}