package br.gov.caixa.sipbs.api.swagger;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {



}
