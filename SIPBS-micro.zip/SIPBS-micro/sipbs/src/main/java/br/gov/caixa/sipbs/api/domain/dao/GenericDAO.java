package br.gov.caixa.sipbs.api.domain.dao;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Value;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;

@ApplicationScoped
public abstract class GenericDAO<T> {

	@Value("${paginacao.qtd_por_pagina}")
	protected int qtdPorPagina;

	@Inject
	protected EntityManager emDb2;



	/**
	 * @Objetivo obter todos os registros da base
	 * @return lista completa de registros da base
	 * @throws GeneralException
	 */
	public abstract List<T> listAll() throws GeneralException;

	/**
	 * @Objetivo obter os registros paginados da base
	 * @param pagina número da página
	 * @param qtdPorPagina quantidade de linhas por página
	 * @return página de registros extraída da base
	 * @throws GeneralException
	 */
	public abstract List<T> listPag(int pagina, int qtdPorPagina) throws GeneralException;

	/**
	 * @Objetivo obter o registro da base
	 * @param id identificador usado para obter o registro
	 * @return registro encontrado na base
	 * @throws GeneralException
	 */
	public abstract T findById(Long id) throws GeneralException;

	/**
	 * @Objetivo O metodo create é utilizado para inserir o registro na base.
	 * @param request registro a ser persistido
	 * @param usuario usuário de criacão
	 * @return entity registro persistido
	 * @throws GeneralException
	 */
	public abstract T create(T request) throws GeneralException;

	/**
	 * @Objetivo O metodo update é utilizado para alterar o registro na base.
	 * @param request registro a ser alterado
	 * @param usuario usuário de alteralção
	 * @return registro alterado
	 * @throws GeneralException
	 */
	public abstract T update(T request) throws GeneralException;

	/**
	 * @Objetivo O metodo delete é utilizado para desativar o registro da base.
	 * @param id      do registro a ser desativado
	 * @param usuario usuário de alteralção
	 * @return registro alterado
	 * @throws GeneralException
	 */
	public abstract void delete(Long id) throws GeneralException;
	
	/**
	 * Obtém o total de registros
	 * 
	 * @return total de registros
	 * @throws GeneralException
	 */
	public abstract Long count() throws GeneralException;

	
	protected int calcularNumeroPagina(int pagina) {
		if(pagina < 1) {
			return 0;
		}
		return (pagina - 1) * qtdPorPagina;
	}
	
	protected int calcularNumeroPagina(int pagina, int qtdPorPagina) {
		if(qtdPorPagina > 0 ) {
			if(pagina < 1) {
				return 0;
			}
			return (pagina - 1) * qtdPorPagina;
		}
		return calcularNumeroPagina(pagina);
	}
}