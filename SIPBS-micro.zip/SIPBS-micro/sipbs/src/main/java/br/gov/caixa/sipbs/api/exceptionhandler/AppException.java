package br.gov.caixa.sipbs.api.exceptionhandler;

import javax.ws.rs.WebApplicationException;

import org.springframework.http.HttpStatus;

public class AppException extends WebApplicationException {

	private static final long serialVersionUID = -3903648795629920607L;

	private HttpStatus httpStatus;

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	/**
	 * 
	 * @param httpStatus
	 * @param message
	 */
	public AppException(HttpStatus httpStatus, String message) {
		super(message, httpStatus.value());
	}

	/**
	 * 
	 * @param httpStatus
	 * @param message
	 */
	public AppException(int code, String message) {
		super(message, code);
	}
}
