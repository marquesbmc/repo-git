package br.gov.caixa.sipbs.api.dtos;

import java.math.BigDecimal;
import java.util.List;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class RelatorioSinteticoParcelaSituacaoDTO {
	private Short idProduto;
	private String produto;
	private List<PagamentoParcelaSituacaoDTO> parcelas;
	private Long qtdTotalParcelas;
	private BigDecimal valorTotalParcelas;
}