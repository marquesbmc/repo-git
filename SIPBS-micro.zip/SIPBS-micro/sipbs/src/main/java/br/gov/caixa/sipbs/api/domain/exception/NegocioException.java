package br.gov.caixa.sipbs.api.domain.exception;

public class NegocioException extends RuntimeException {

	private static final long serialVersionUID = -709121761660758663L;

	public NegocioException(String message) {
		super(message);
	}
}
