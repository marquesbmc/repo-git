package br.gov.caixa.sipbs.api.domain.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the PBSVWB08_MARCACAO_DESMARCAO_CONTA database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB08_MARCACAO_DESMARCAO_CONTA")
public class MarcacaoDesmarcacaoConta extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSB08")
	public Long nuPbsb08;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_PRODUTO_PBSB02", referencedColumnName = "NU_PRODUTO_ICOO10")
	public ProgramaSocial programaSocial;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_PBSB06", referencedColumnName = "NU_PBSB06")
	public ContaCredito contaCredito;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_PBSB05", referencedColumnName = "NU_PBSB05")
	public BeneficiarioSocial beneficiarioSocial;

	@Column(name="NU_REFERENCIA")
	public Integer nuReferencia;

	@OneToOne
	@JoinColumn(name = "NU_CRITERIO_PRIORIZACAO_PBSB26", referencedColumnName = "NU_CRITERIO_PRIORIZACAO")
	public CriterioPriorizacaoSelecaoConta criterioPriorizacaoSelecaoConta;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ABERTURA_CONTA")
	public Date dtAberturaConta;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_FIM_VIGENCIA_CONTA_APTA")
	public Date dtFimVigenciaContaApta;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_INICIO_VIGENCIA_CONTA_APTA")
	public Date dtInicioVigenciaContaApta;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ULTMA_CNSLA_EXTRATO_SALDO")
	public Date dtUltmaCnslaExtratoSaldo;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ULTMA_MVMNO_ESPONTANEA")
	public Date dtUltmaMvmnoEspontanea;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ULTMA_MVMNO_ONLINE")
	public Date dtUltmaMvmnoOnline;

	@Column(name="IC_SALDO_POSITIVO")
	public Short icSaldoPositivo;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="TS_ULTIMA_ATUALIZACAO")
	public Timestamp tsUltimaAtualizacao;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_IDENTIFICACAO_CONTA")
	public Date dtIdentificacaoConta;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_SELECAO_CONTA")
	public Date dtSelecaoConta;

	@Column(name="IC_CRITERIO_CONTA_PROPRIEDADE")
	public Short icCriterioContaPropriedade;

	@Transient
	public String deCriterioContaPropriedade;

	@Transient
	public Boolean isContaSelecionada;
}
