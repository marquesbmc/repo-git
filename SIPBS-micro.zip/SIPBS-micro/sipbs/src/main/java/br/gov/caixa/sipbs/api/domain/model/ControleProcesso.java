package br.gov.caixa.sipbs.api.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWA01_CONTROLE_PROCESSO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWA01_CONTROLE_PROCESSO")
public class ControleProcesso extends PanacheEntityBase {

	@Id
	@Column(name="NU_CONTROLE_PROCESSO")
	public Short nuControleProcesso;

	@Column(name="CO_PROCESSO")
	public String coProcesso;

	@Column(name="DE_CONTROLE_PROCESSO")
	public String deControleProcesso;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_CONTROLE_PROCESSO")
	public Date dtControleProcesso;
}