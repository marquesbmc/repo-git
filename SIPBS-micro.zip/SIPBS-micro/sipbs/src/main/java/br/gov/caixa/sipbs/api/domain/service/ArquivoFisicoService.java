package br.gov.caixa.sipbs.api.domain.service;

import java.util.List;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.ArquivoFisicoDTO;


public interface ArquivoFisicoService {
		
	public List<ArquivoFisicoDTO> listAll();
	
	public List<ArquivoFisicoDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException;

	public ArquivoFisicoDTO findById(Long id);

	public ArquivoFisicoDTO create(ArquivoFisicoDTO request);

	public ArquivoFisicoDTO update(Long id, ArquivoFisicoDTO request);

	public void delete(Long id);

	public Long count();
}