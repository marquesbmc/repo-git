package br.gov.caixa.sipbs.api.dtos;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Entidade que representa a consulta da evolução da folha por situação
 * @author Spread
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class PagamentoParcelaSituacaoDTO implements Serializable{

	private static final long serialVersionUID = -4342464963629177948L;
	
	private String situacao;

	private Long qtdParcelas;
	
	private BigDecimal valorParcelas;
}