package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB23_CONTA_MARCADA_MARCACAO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB23_CONTA_MARCADA_MARCACAO")
public class ContaMarcadaMarcacao extends PanacheEntityBase {

	@Id
	@Column(name="NU_PBSB23")
	public Long nuPbsb23;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_PBSB08", referencedColumnName = "NU_PBSB08")
	public MarcacaoDesmarcacaoConta marcacaoDesmarcacaoConta;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_TIPO_PRPRE_CONTA_PBSB15", referencedColumnName = "NU_TIPO_PRPRE_CONTA")
	public TipoPropriedadeConta tipoPropriedadeConta;

}
