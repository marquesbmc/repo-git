package br.gov.caixa.sipbs.api.retorno;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author SIOGP
 *
 */
public class Retorno {
	private boolean temErro;
	private List<String> msgsErro = new ArrayList<String>();

	public boolean isTemErro() {
		return temErro;
	}

	public void setTemErro(boolean temErro) {
		this.temErro = temErro;
	}

	public List<String> getMsgsErro() {
		return msgsErro;
	}

	public void setMsgsErro(List<String> msgsErro) {
		this.msgsErro = msgsErro;
	}
}