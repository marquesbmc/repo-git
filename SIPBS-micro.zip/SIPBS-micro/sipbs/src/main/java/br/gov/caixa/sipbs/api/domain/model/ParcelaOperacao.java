package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO11_PARCELA_OPERACAO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO11_PARCELA_OPERACAO")
public class ParcelaOperacao extends PanacheEntityBase {

	@Id
	@Column(name="NU_PBSO11")
	public Long nuPbso11;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PBSO04")
	public Long nuPbso04;

	@Column(name="NU_PBSO12")
	public Long nuPbso12;

}