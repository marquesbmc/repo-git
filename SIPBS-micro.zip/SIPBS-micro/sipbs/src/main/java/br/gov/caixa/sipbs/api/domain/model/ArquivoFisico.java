package br.gov.caixa.sipbs.api.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

/**
 * The persistent class for the PBSVWD03_ARQUIVO_FISICO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name = "PBSVWD03_ARQUIVO_FISICO")
public class ArquivoFisico extends PanacheEntityBase {

	@Id
	@Column(name = "NU_PBSD03")
	public Long nuPbsd03;

	@Column(name = "CO_SEGURANCA")
	public String coSeguranca;

	@Column(name = "DE_ERRO_GERACAO_ARQUIVO")
	public String deErroGeracaoArquivo;

	@Column(name = "IC_ARQUIVO")
	public String icArquivo;

	@Column(name = "NO_ARQUIVO")
	public String noArquivo;

	@Column(name = "NU_ARQUIVO_SISTEMA_PBSD04")
	public Long nuArquivoSistemaPbsd04;

// FIXME: [allancr] A coluna estava mapeada na entidade mas não está presente no banco de dados.
//	@Column(name="NU_COMPETENCIA") 
	@Transient
	public Integer nuCompetencia;

	@Column(name = "NU_EVENTO_INCLUSAO_PBSA12")
	public Long nuEventoInclusaoPbsa12;

	@Column(name = "NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name = "NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name = "NU_REMESSA")
	public Integer nuRemessa;

	@Column(name = "NU_SITUACAO_ARQUIVO_PBSD06")
	public Short nuSituacaoArquivoPbsd06;

	@Column(name = "QT_ACATADO")
	public Integer qtAcatado;

	@Column(name = "QT_REJEITADO")
	public Integer qtRejeitado;

	@Column(name = "QT_TOTAL_REGISTROS")
	public Integer qtTotalRegistros;

	@Column(name = "TS_FIM_PROCESSAMENTO")
	public Date tsFimProcessamento;

	@Column(name = "TS_INICIO_PROCESSAMENTO")
	public Date tsInicioProcessamento = new Date();
}