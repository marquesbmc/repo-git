package br.gov.caixa.sipbs.api.dtos;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class ContaCreditoDTO {

	public Integer nuPbsb06;
	public Short nuAgencia;
	public Short nuBanco;
	public Integer nuReferencia;
	public Long nuConta;
	public Long nuCpfTitular;
	public Short nuDvAgencia;
	public Short nuDvConta;
	public Long nuEventoPbsa12;
	public PropriedadeContaDTO propriedadeConta;
}
