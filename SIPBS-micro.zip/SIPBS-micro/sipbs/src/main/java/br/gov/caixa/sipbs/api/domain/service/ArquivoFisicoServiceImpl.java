package br.gov.caixa.sipbs.api.domain.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.springframework.http.HttpStatus;

import br.gov.caixa.sipbs.api.domain.dao.ArquivoFisicoDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.ArquivoFisico;
import br.gov.caixa.sipbs.api.dtos.ArquivoFisicoDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;
import io.quarkus.panache.common.Sort;

@ApplicationScoped
public class ArquivoFisicoServiceImpl extends GenericService implements ArquivoFisicoService {

	
	@Inject
	ArquivoFisicoDAO dao;
	
	
	@Override
	public List<ArquivoFisicoDTO> listAll() {
		return ArquivoFisico.listAll(Sort.by("NU_PBSD03").descending()).stream().map(entity -> map(entity, ArquivoFisicoDTO.class))
				.collect(Collectors.toList());
	}
		
	@Override
	public List<ArquivoFisicoDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return dao.listPag(pagina, qtdPorPagina).stream().map(entity -> map(entity, ArquivoFisicoDTO.class))
		.collect(Collectors.toList());
	}

	@Override
	public ArquivoFisicoDTO findById(Long id) {
		ArquivoFisico entidade = ArquivoFisico.findById(id);
		if (entidade == null) {
			throw new AppException(HttpStatus.NOT_FOUND, "Registro com o id " + id + " não existe.");
		}
		return map(entidade, ArquivoFisicoDTO.class);
	}

	@Override
	public ArquivoFisicoDTO create(ArquivoFisicoDTO requisicao) {
		ArquivoFisico arquivo = map(requisicao, ArquivoFisico.class);
		arquivo.nuPbsd03 = 6896L;
		arquivo.nuCompetencia = 201801;
		arquivo.nuRemessa = 1;
		arquivo.nuEventoPbsa12 = 13L;
		arquivo.nuArquivoSistemaPbsd04 = 1L;
		arquivo.nuProdutoPbsb02 = 35;
		arquivo.icArquivo = "E";
		arquivo.qtTotalRegistros = 0;
		arquivo.coSeguranca = "6609";
		arquivo.tsInicioProcessamento = new Date();
		arquivo.tsFimProcessamento = new Date();
		arquivo.qtAcatado = 0;
		arquivo.qtRejeitado = 0;
		arquivo.nuEventoInclusaoPbsa12 = 16103L;
		arquivo.nuSituacaoArquivoPbsd06 = 1;
		arquivo.deErroGeracaoArquivo = "";
		arquivo.persist();
		return map(arquivo, ArquivoFisicoDTO.class);
	}

	@Override
	public ArquivoFisicoDTO update(Long id, ArquivoFisicoDTO requisicao) {
		ArquivoFisico entidade = ArquivoFisico.findById(id);

		if (entidade == null) {
			throw new AppException(HttpStatus.NOT_FOUND, "Registro com o id " + id + " não existe.");
		}
		entidade.noArquivo = requisicao.getNoArquivo();
		return map(entidade, ArquivoFisicoDTO.class);
	}

	@Override
	public void delete(Long id) {
		ArquivoFisico entidade = ArquivoFisico.findById(id);
		if (entidade == null) {
			throw new AppException(HttpStatus.NOT_FOUND, "Registro com o id " + id + " não existe.");
		}
		entidade.delete();
	}

	@Override
	public Long count() {
		return ArquivoFisico.count();
	}
}