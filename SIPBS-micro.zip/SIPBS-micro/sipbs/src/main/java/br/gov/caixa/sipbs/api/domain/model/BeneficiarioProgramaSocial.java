package br.gov.caixa.sipbs.api.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB04_BENEFICIARIO_PROGRAMA_SOCIAL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB04_BENEFICIARIO_PROGRAMA_SOCIAL")
public class BeneficiarioProgramaSocial extends PanacheEntityBase {

	@Id
	@Column(name="NU_PBSB04")
	public Long nuPbsb04;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NU_PBSB05", referencedColumnName = "NU_PBSB05")
	public BeneficiarioSocial beneficiarioSocial;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_PRODUTO_PBSB02", referencedColumnName = "NU_PRODUTO_ICOO10")
	public ProgramaSocial programaSocial;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_PBSB06", referencedColumnName = "NU_PBSB06")
	public ContaCredito contaCredito;

	@Column(name="IC_MSG_PROXIMO_PAGAMENTO")
	public String icMsgProximoPagamento;

	@Column(name="NU_BENEFICIARIO_EXTERNO")
	public Long nuBeneficiarioExterno;

	@Column(name="NU_REFERENCIA")
	public Integer nuReferencia;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Transient
	public MarcacaoDesmarcacaoConta marcacaoDesmarcacaoConta;

	@Transient
	public Date getDtSelecao() {
		return (this.getMarcacaoDesmarcacaoConta() != null && this.getMarcacaoDesmarcacaoConta().getDtSelecaoConta() != null) ? this.getMarcacaoDesmarcacaoConta().getDtSelecaoConta() : null;
	}

}
