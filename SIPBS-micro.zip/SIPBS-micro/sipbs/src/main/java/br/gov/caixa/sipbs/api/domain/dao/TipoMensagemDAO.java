package br.gov.caixa.sipbs.api.domain.dao;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.EntidadeNaoEncontradaException;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.TipoMensagem;
import br.gov.caixa.sipbs.api.utils.Constantes;

/**
 * 
 * @author SPREAD
 *
 */
@ApplicationScoped
public class TipoMensagemDAO extends GenericDAO<TipoMensagem> {

	private static final Logger LOGGER = LoggerFactory.getLogger(TipoMensagemDAO.class);

	@Override
	@SuppressWarnings("unchecked")
	public List<TipoMensagem> listAll() throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_LIST_ALL);
		try {
			StringBuilder sql = new StringBuilder()
					.append(" SELECT NU_TIPO_MENSAGEM, NO_TIPO_MENSAGEM, TS_INICIO_VIGENCIA, TS_FIM_VIGENCIA, ")
					.append(" TS_ID_VIGENCIA, NU_EVENTO_PBSA12 FROM {h-schema}PBSVWB12_TIPO_MENSAGEM  ORDER BY NU_TIPO_MENSAGEM ASC");
			Query query = emDb2.createNativeQuery(sql.toString(), TipoMensagem.class);
			return query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_LIST_ALL, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<TipoMensagem> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_LIST_PAG);
		try {
			int numeroPag = calcularNumeroPagina(pagina);
			int linhas;
			if(qtdPorPagina > 0) {
				linhas = qtdPorPagina + numeroPag;				
			} else {
				linhas = super.qtdPorPagina + numeroPag;
			}
			
			StringBuilder sql = new StringBuilder().append("SELECT NU_TIPO_MENSAGEM, NO_TIPO_MENSAGEM, TS_INICIO_VIGENCIA, TS_FIM_VIGENCIA, ")
					.append(" TS_ID_VIGENCIA, NU_EVENTO_PBSA12 FROM ( SELECT TIPO.NU_TIPO_MENSAGEM, TIPO.NU_EVENTO_PBSA12, TIPO.TS_FIM_VIGENCIA, ")
					.append(" TIPO.TS_ID_VIGENCIA, TIPO.TS_INICIO_VIGENCIA, TIPO.NO_TIPO_MENSAGEM, ROW_NUMBER() OVER () ROWNUMBER_ FROM {h-schema}PBSVWB12_TIPO_MENSAGEM TIPO ")
					.append(" FETCH FIRST ")
					.append(linhas)
					.append(" ROWS ONLY ) AS INNER_ WHERE ROWNUMBER_ > ")
					.append(numeroPag)
					.append( " ORDER BY ROWNUMBER_");

			Query query = emDb2.createNativeQuery(sql.toString(), TipoMensagem.class);
			return query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_LIST_PAG, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public TipoMensagem findById(Long id) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_READ);
		try {
			StringBuilder sql = new StringBuilder()
					.append(" SELECT NU_TIPO_MENSAGEM, NO_TIPO_MENSAGEM, TS_INICIO_VIGENCIA, TS_FIM_VIGENCIA, TS_ID_VIGENCIA, NU_EVENTO_PBSA12 ")
					.append(" FROM {h-schema}PBSVWB12_TIPO_MENSAGEM WHERE NU_TIPO_MENSAGEM = :id");
			Query query = emDb2.createNativeQuery(sql.toString(), TipoMensagem.class);
			query.setParameter("id", id);
			return (TipoMensagem) query.getSingleResult();
		} catch (NoResultException e) {
			throw new EntidadeNaoEncontradaException(EntidadeNaoEncontradaException.RESPONSE_CODE_ERROR_NO_ENTITY_FOUND, e);	
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_READ, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}
	
	public TipoMensagem findByName(String nome) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_READ);
		try {
			StringBuilder sql = new StringBuilder()
					.append(" SELECT NU_TIPO_MENSAGEM, NO_TIPO_MENSAGEM, TS_INICIO_VIGENCIA, TS_FIM_VIGENCIA, TS_ID_VIGENCIA, NU_EVENTO_PBSA12 ")
					.append(" FROM {h-schema}PBSVWB12_TIPO_MENSAGEM WHERE NO_TIPO_MENSAGEM = :nome");
			Query query = emDb2.createNativeQuery(sql.toString(), TipoMensagem.class);
			query.setParameter("nome", nome);
			return (TipoMensagem) query.getSingleResult();
		} catch (NoResultException e) {
			return null;		
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_READ, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public TipoMensagem create(TipoMensagem request) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_CREATE);
		try {
			StringBuilder sql = new StringBuilder()
					.append(" INSERT INTO {h-schema}PBSVWB12_TIPO_MENSAGEM ")
					.append(" (NU_TIPO_MENSAGEM, NO_TIPO_MENSAGEM) ")
					.append(" VALUES ((SELECT MAX(NU_TIPO_MENSAGEM) +1 FROM {h-schema}PBSVWB12_TIPO_MENSAGEM), :nome)");

			Query query = emDb2.createNativeQuery(sql.toString());
			query.setParameter("nome", request.nome);
			query.executeUpdate();
			return request;
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_CREATE, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public TipoMensagem update(TipoMensagem request) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_UPDATE);
		try {
			StringBuilder sql = new StringBuilder()
					.append(" UPDATE {h-schema}PBSVWB12_TIPO_MENSAGEM  ")
					.append(" SET NO_TIPO_MENSAGEM = :nome  ")
					.append(" WHERE NU_TIPO_MENSAGEM = :id ");

			Query query = emDb2.createNativeQuery(sql.toString());
			query.setParameter("id", request.id);
			query.setParameter("nome", request.nome);
			query.executeUpdate();
			return request;
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_UPDATE, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public void delete(Long id) throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_DELETE);
		try {
			StringBuilder sql = new StringBuilder()
					.append(" DELETE FROM {h-schema}PBSVWB12_TIPO_MENSAGEM  ")
					.append(" WHERE NU_TIPO_MENSAGEM = :id ");

			Query query = emDb2.createNativeQuery(sql.toString());
			query.setParameter("id", id);
			query.executeUpdate();
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_DELETE, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	public Long count() throws GeneralException {
		LOGGER.info(Constantes.INFO_CHAMANDO_METODO_COUNT);
		try {
			StringBuilder sql = new StringBuilder().append(" SELECT COUNT(NU_TIPO_MENSAGEM) FROM {h-schema}PBSVWB12_TIPO_MENSAGEM ");
			Query query = emDb2.createNativeQuery(sql.toString());
			return Long.valueOf((Integer) query.getSingleResult());
		} catch (Exception e) {
			LOGGER.error("Erro em " + Constantes.INFO_CHAMANDO_METODO_COUNT, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}
}