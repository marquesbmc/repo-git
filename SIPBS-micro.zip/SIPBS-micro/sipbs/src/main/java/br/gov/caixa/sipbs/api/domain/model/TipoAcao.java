package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO01_TIPO_ACAO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO01_TIPO_ACAO")
public class TipoAcao extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_TIPO_ACAO")
	public Short nuTipoAcao;

	@Column(name="DE_TIPO_ACAO")
	public String deTipoAcao;
}