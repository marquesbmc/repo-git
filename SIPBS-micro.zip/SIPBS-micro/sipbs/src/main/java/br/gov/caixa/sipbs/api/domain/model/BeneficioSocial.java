package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntity;


/**
 * The persistent class for the PBSVWB03_BENEFICIO_SOCIAL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB03_BENEFICIO_SOCIAL")
public class BeneficioSocial extends PanacheEntity {

	@Column(name="DE_DETALHADA")
	public String deDetalhada;

	@Column(name="DE_RESUMIDA")
	public String deResumida;

	@Column(name="IC_ATIVO")
	public Short icAtivo;

	@Column(name="NU_BENEFICIO_SOCIAL")
	public Short nuBeneficioSocial;

	@Column(name="NU_BENEFICIO_SOCIAL_EXTERNO")
	public Integer nuBeneficioSocialExterno;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;

}