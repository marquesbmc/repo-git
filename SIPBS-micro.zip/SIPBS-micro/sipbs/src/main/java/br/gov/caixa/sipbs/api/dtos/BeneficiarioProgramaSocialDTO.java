package br.gov.caixa.sipbs.api.dtos;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class BeneficiarioProgramaSocialDTO {

	private Long nuPbsb04;
	private BeneficiarioSocialDTO beneficiarioSocial;
	private ProgramaSocialDTO programaSocial;
	private ContaCreditoDTO contaCredito;
	private MarcacaoDesmarcacaoContaDTO marcacaoDesmarcacaoConta;
	private String icMsgProximoPagamento;
	private Long nuBeneficiarioExterno;
	private Integer nuReferencia;
	private Long nuEventoPbsa12;

}
