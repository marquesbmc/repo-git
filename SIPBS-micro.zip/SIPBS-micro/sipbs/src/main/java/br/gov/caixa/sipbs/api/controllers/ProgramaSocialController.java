package br.gov.caixa.sipbs.api.controllers;

import br.gov.caixa.sipbs.api.domain.service.ProgramaSocialService;
import br.gov.caixa.sipbs.api.dtos.ProgramaSocialDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Counted;
import org.eclipse.microprofile.metrics.annotation.Timed;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.jboss.resteasy.annotations.jaxrs.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.List;

@Path("/api/programa-social/v2")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
@Transactional
@OpenAPIDefinition(info = @Info(description = "Conjunto de endpoints para consultas relacionadas à contas Beneficiário", title = "Contas Beneficiário", version = "1.0"))
public class ProgramaSocialController extends Controller<ProgramaSocialDTO, ResponseEntity<?>>{

	@Autowired
	ProgramaSocialService service;

	@GET
	@Path("/list")
	@Timeout(3000)
	@Fallback(fallbackMethod = "listFallback")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<List<ProgramaSocialDTO>> list() {
		try {
			List<ProgramaSocialDTO> lista = service.listAll();
			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.programa-social.listAll",
			displayName = "Tempo da listagem completa",
			description = "Tempo da listagem em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem", description = "Quantidade de listagem realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> listAll() {
		try {

			List<ProgramaSocialDTO> lista = service.listAll();
			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/pagina/{pagina}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.programa-social.listPag",
			displayName = "Tempo da listagem paginada",
			description = "Tempo da listagem paginada em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem Paginada", description = "Quantidade de listagens paginadas realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?>listPag(@PathParam int pagina) {
		return null;
	}

	public ResponseEntity<List<ProgramaSocialDTO>> listFallback() {
		try {
			List<ProgramaSocialDTO> lista = service.listPag(1, qtdPorPagina);

			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/pagina/{pagina}/{qtdPorPagina}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.programa-social.listPag",
			displayName = "Tempo da listagem paginada",
			description = "Tempo da listagem paginada em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem Paginada", description = "Quantidade de listagens paginadas realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> listPag(@PathParam int pagina, @PathParam int qtdPorPagina) {
		return null;
	}

	@GET
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.programa-social.findById",
			displayName = "Tempo da consulta por ID",
			description = "Tempo da consulta por ID em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de consultas por ID", description = "Quantidade de consultas por ID realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> findById(@PathParam Long id) {
		return null;
	}

	@POST
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.programa-social.create",
			displayName = "Tempo do cadastro",
			description = "Tempo do cadastro em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de cadastros", description = "Quantidade de cadastros realizados")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> create(ProgramaSocialDTO request) {
		return null;
	}

	@PUT
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.programa-social.update",
			displayName = "Tempo da atualizacao",
			description = "Tempo da atualizacao em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de atualizacoes", description = "Quantidade de atualizacoes realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> update(@PathParam Long id, ProgramaSocialDTO request) {
		return null;
	}

	@DELETE
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.programa-social.delete",
			displayName = "Tempo da exclusao",
			description = "Tempo da exclusao em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de exclusoes", description = "Quantidade de exclusoes realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> delete(@PathParam Long id) {
		return null;
	}
}
