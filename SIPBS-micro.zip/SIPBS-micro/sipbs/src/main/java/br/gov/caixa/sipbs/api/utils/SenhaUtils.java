package br.gov.caixa.sipbs.api.utils;

import io.quarkus.elytron.security.common.BcryptUtil;

public class SenhaUtils {

	/**
	 * Gera um hash utilizando o BCrypt.
	 * 
	 * @param senha
	 * @return String
	 */
	public static String gerarBCrypt(String password) {
		if (password == null) {
			return password;
		}

		return BcryptUtil.bcryptHash(password);
		
	}

	/**
	 * Verifica se a senha é válida.
	 * 
	 * @param senha
	 * @param senhaEncoded
	 * @return boolean
	 */
	public static boolean senhaValida(String senha, String senhaEncoded) {
		return gerarBCrypt(senha).equals(senhaEncoded); 
	}

}
