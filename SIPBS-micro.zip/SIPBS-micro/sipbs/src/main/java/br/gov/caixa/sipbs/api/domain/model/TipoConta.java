package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB13_TIPO_CONTA database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table( name="PBSVWB13_TIPO_CONTA")
public class TipoConta extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_TIPO_CONTA")
	public Short nuTipoConta;

	@Column(name="DE_TIPO_CONTA")
	public String deTipoConta;

	@Column(name="NU_PRODUTO_ICOO10")
	public Short nuProdutoIcoo10;

	@Column(name="NU_PROPRIEDADE_TIPO_CONTA")
	public Short nuPropriedadeTipoConta;

	@Column(name="NU_SEGMENTO_ICOS12")
	public Short nuSegmentoIcos12;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;
}
