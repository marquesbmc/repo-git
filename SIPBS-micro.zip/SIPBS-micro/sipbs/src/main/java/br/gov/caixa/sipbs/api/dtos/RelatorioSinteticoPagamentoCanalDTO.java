package br.gov.caixa.sipbs.api.dtos;

import java.math.BigDecimal;
import java.util.List;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class RelatorioSinteticoPagamentoCanalDTO {

	private ProgramaSocialDTO programaSocial;
	private List<PagamentoCanalDTO> pagamentoCanalList;
	private Long qtTotalPagamento;
	private BigDecimal vrTotalPagamento;
}
