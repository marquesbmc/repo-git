package br.gov.caixa.sipbs.api.domain.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import br.gov.caixa.sipbs.api.domain.dao.ParcelaSituacaoDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.PagamentoParcelaSituacao;
import br.gov.caixa.sipbs.api.dtos.PagamentoParcelaSituacaoDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoParcelaSituacaoDTO;

@ApplicationScoped
public class PagamentoSituacaoServiceImpl extends GenericService implements PagamentoSituacaoService {

	@Inject 
	ParcelaSituacaoDAO parcelaSituacaoDAO;
	

    private static final String SEPARADOR=";";
    private static final String NOVA_LINHA="\r\n";

	@Override
	public RelatorioSinteticoParcelaSituacaoDTO recuperarRelatorioSinteticoPagamentoSituacao(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo, Long[] lotes) throws GeneralException {

		List<Long> lotesMock = Arrays.asList(lotes);
		List<PagamentoParcelaSituacao> pagamentoParcelaSituacaoList = parcelaSituacaoDAO.consultarParcelasPorSituacao(nuProdutoIcoo10, dtInicioPeriodo, dtFimPeriodo, lotesMock);
		PagamentoParcelaSituacaoDTO pagamentoParcelaSituacaoDTO;
		List<PagamentoParcelaSituacaoDTO> pagamentoParcelaSituacaoDTOList = new ArrayList<>();
		
		long qtdTotalParcelas = 0L;
		BigDecimal valorTotalParcelas = BigDecimal.ZERO;
		for (PagamentoParcelaSituacao pagamentoParcelaSituacao  : pagamentoParcelaSituacaoList) {
			pagamentoParcelaSituacaoDTO = new PagamentoParcelaSituacaoDTO();
			
			pagamentoParcelaSituacaoDTO.setSituacao(pagamentoParcelaSituacao.getSituacao());
			pagamentoParcelaSituacaoDTO.setQtdParcelas(pagamentoParcelaSituacao.getQtdParcelas());
			pagamentoParcelaSituacaoDTO.setValorParcelas(pagamentoParcelaSituacao.getValorParcelas());
			
			qtdTotalParcelas += pagamentoParcelaSituacao.getQtdParcelas();
			valorTotalParcelas = valorTotalParcelas.add(pagamentoParcelaSituacao.getValorParcelas());

			pagamentoParcelaSituacaoDTOList.add(pagamentoParcelaSituacaoDTO);
		}

		
		RelatorioSinteticoParcelaSituacaoDTO relatorioSinteticoParcelaSituacaoDTO = new RelatorioSinteticoParcelaSituacaoDTO();
		if (pagamentoParcelaSituacaoList != null && !pagamentoParcelaSituacaoList.isEmpty()) {
			relatorioSinteticoParcelaSituacaoDTO.setProduto(pagamentoParcelaSituacaoList.get(0).getProduto()); 
		}
		
		relatorioSinteticoParcelaSituacaoDTO.setIdProduto(nuProdutoIcoo10);
		relatorioSinteticoParcelaSituacaoDTO.setParcelas(pagamentoParcelaSituacaoDTOList);
		relatorioSinteticoParcelaSituacaoDTO.setQtdTotalParcelas(qtdTotalParcelas);
		relatorioSinteticoParcelaSituacaoDTO.setValorTotalParcelas(valorTotalParcelas);

		return relatorioSinteticoParcelaSituacaoDTO;
	}

	@Override
	public List<Long> consultarLotes(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo)
			throws GeneralException {
		return parcelaSituacaoDAO.listarLotes(nuProdutoIcoo10, dtInicioPeriodo, dtFimPeriodo);
	}

	@Override
	public ByteArrayOutputStream exportarRelatorioSinteticoPagamento(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo, Long[] lotes) throws GeneralException, IOException {

		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String dtInicio = dateFormatter.format(dtInicioPeriodo);
		String dtFim = dateFormatter.format(dtFimPeriodo);

		RelatorioSinteticoParcelaSituacaoDTO relatorioSinteticoPagamentoSituacaoDTO = recuperarRelatorioSinteticoPagamentoSituacao(nuProdutoIcoo10, dtInicioPeriodo, dtFimPeriodo, lotes);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Relatório Sintético");

		int contRow = 4;

		adicionarLogoCaixa(workbook, sheet);

		sheet.setDefaultColumnWidth(25);

		Font fontTamanho = workbook.createFont();
		fontTamanho.setFontHeight((short) 250);
		Font fontNegrito = workbook.createFont();
		fontNegrito.setBold(true);

		CellStyle styleCabecalho1 = workbook.createCellStyle();
		styleCabecalho1.setFont(fontTamanho);

		Row row = sheet.createRow(contRow++);
		Cell cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("CAIXA ECONÔMICA FEDERAL");
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("VICE-PRESIDÊNCIA DE GOVERNO - VIGOV");
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("SIPBS - RELATÓRIO SINTÉTICO DE PARCELAS PAGAS POR PERÍODO/SITUAÇÃO");

		CellStyle styleCabecalho2 = workbook.createCellStyle();
		styleCabecalho2.setFont(fontNegrito);

		row = sheet.createRow(contRow++).getSheet().createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		cellCabecalho.setCellValue("Produto: " + relatorioSinteticoPagamentoSituacaoDTO.getIdProduto() + " - " + relatorioSinteticoPagamentoSituacaoDTO.getProduto());

		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		cellCabecalho.setCellValue("Período: " + dtInicio + " - " + dtFim);

		Font fontBold = workbook.createFont();
		fontBold.setBold(true);
		fontBold.setFontHeight((short) 250);

		CellStyle styleTitulo = workbook.createCellStyle();
		styleTitulo.setAlignment(HorizontalAlignment.CENTER);
		styleTitulo.setFillForegroundColor(IndexedColors.GOLD.getIndex());
		styleTitulo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleTitulo);
		styleTitulo.setFont(fontBold);

		row = sheet.createRow(contRow++).getSheet().createRow(contRow++).getSheet().createRow(contRow++);
		Cell cellTitulo = row.createCell(0);
		cellTitulo.setCellValue("Situação");
		cellTitulo.setCellStyle(styleTitulo);
		cellTitulo = row.createCell(1);
		cellTitulo.setCellValue("Quantidade");
		cellTitulo.setCellStyle(styleTitulo);
		cellTitulo = row.createCell(2);
		cellTitulo.setCellValue("Valor (R$)");
		cellTitulo.setCellStyle(styleTitulo);

		NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
		row = sheet.createRow(contRow++);
		int contCell = 0;
		Cell cellConteudo;

		for (PagamentoParcelaSituacaoDTO dto : relatorioSinteticoPagamentoSituacaoDTO.getParcelas()) {
			CellStyle styleConteudoCanal = workbook.createCellStyle();
			CellStyle styleConteudoQtde = workbook.createCellStyle();
			CellStyle styleConteudoValor = workbook.createCellStyle();
			carregarbordarCelula(styleConteudoCanal);
			carregarbordarCelula(styleConteudoQtde);
			carregarbordarCelula(styleConteudoValor);
			if (contRow % 2 == 0) {
				styleConteudoCanal.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoQtde.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoValor.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			} else {
				styleConteudoCanal.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoQtde.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoValor.setFillForegroundColor(IndexedColors.WHITE.getIndex());
			}
			styleConteudoCanal.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoQtde.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoValor.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(dto.getSituacao());
			styleConteudoCanal.setAlignment(HorizontalAlignment.LEFT);
			cellConteudo.setCellStyle(styleConteudoCanal);

			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(dto.getQtdParcelas());
			styleConteudoQtde.setAlignment(HorizontalAlignment.RIGHT);
			cellConteudo.setCellStyle(styleConteudoQtde);

			cellConteudo = row.createCell(contCell);
			cellConteudo.setCellValue(numberFormat.format(dto.getValorParcelas()));
			styleConteudoValor.setAlignment(HorizontalAlignment.RIGHT);
			cellConteudo.setCellStyle(styleConteudoValor);

			row = sheet.createRow(contRow++);
			contCell = 0;
		}

		CellStyle styleRodapeRight = workbook.createCellStyle();
		styleRodapeRight.setFont(fontBold);
		styleRodapeRight.setAlignment(HorizontalAlignment.RIGHT);
		styleRodapeRight.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		styleRodapeRight.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleRodapeRight);

		Cell cellRodape = row.createCell(contCell++);
		cellRodape.setCellValue("Totais: ");
		cellRodape.setCellStyle(styleRodapeRight);

		cellRodape = row.createCell(contCell++);
		cellRodape.setCellValue(relatorioSinteticoPagamentoSituacaoDTO.getQtdTotalParcelas());
		cellRodape.setCellStyle(styleRodapeRight);

		cellRodape = row.createCell(contCell);
		cellRodape.setCellValue(numberFormat.format(relatorioSinteticoPagamentoSituacaoDTO.getValorTotalParcelas()));
		cellRodape.setCellStyle(styleRodapeRight);

		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

		row = sheet.createRow(contRow);
		Font fontItalic = workbook.createFont();
		fontItalic.setItalic(true);
		fontItalic.setBold(true);
		fontItalic.setFontHeight((short) 180);
		CellStyle styleDtRelatorio = workbook.createCellStyle();
		styleDtRelatorio.setFont(fontItalic);
		Cell cellDtRelatorio = row.createCell(0);
		cellDtRelatorio.setCellStyle(styleDtRelatorio);

		cellDtRelatorio.setCellValue("Date de geração do relatório: " + dateTimeFormatter.format(LocalDateTime.now()));

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		workbook.write(outputStream);
		workbook.close();
		return outputStream;
	}

	private void adicionarLogoCaixa(XSSFWorkbook workbook, XSSFSheet sheet) throws IOException {
		InputStream is = getClass().getResourceAsStream("/image/logo-caixa.jpeg");
		byte[] bytes = IOUtils.toByteArray(is);
		int pictureIdx = workbook.addPicture(bytes, Workbook.PICTURE_TYPE_JPEG);
		is.close();

		CreationHelper helper = workbook.getCreationHelper();
		Drawing<?> drawing = sheet.createDrawingPatriarch();
		ClientAnchor anchor = helper.createClientAnchor();

		anchor.setRow1(0);
		anchor.setCol1(0);
		Picture pict = drawing.createPicture(anchor, pictureIdx);
		pict.resize();
	}

	private void carregarbordarCelula(CellStyle cellStyle) {
		cellStyle.setBorderTop(BorderStyle.THIN);
		cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderBottom(BorderStyle.THIN);
		cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderLeft(BorderStyle.THIN);
		cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderRight(BorderStyle.THIN);
		cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
	}


	@Override
	public byte[] exportarRelatorioSinteticoPagamentoCSV(Short nuProdutoIcoo10,
			LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo, Long[] lotes) throws GeneralException {
		
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String dtInicio = dateFormatter.format(dtInicioPeriodo);
		String dtFim = dateFormatter.format(dtFimPeriodo);

		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		
		RelatorioSinteticoParcelaSituacaoDTO relatorioSinteticoPagamentoSituacaoDTO = recuperarRelatorioSinteticoPagamentoSituacao(nuProdutoIcoo10, dtInicioPeriodo, dtFimPeriodo, lotes);
		
		StringBuilder builderCSV = new StringBuilder();
		
		builderCSV.append("Produto: " + relatorioSinteticoPagamentoSituacaoDTO.getIdProduto() + " - " + relatorioSinteticoPagamentoSituacaoDTO.getProduto())
		.append(NOVA_LINHA)
		.append("Período: " + dtInicio + " - " + dtFim)
		.append(NOVA_LINHA)
		.append("Date de geração do relatório: " + dateTimeFormatter.format(LocalDateTime.now()))
		.append(NOVA_LINHA)
		.append("Situação").append(SEPARADOR).append("Quantidade").append(SEPARADOR).append("Valor (R$)");
		
		for (PagamentoParcelaSituacaoDTO dto : relatorioSinteticoPagamentoSituacaoDTO.getParcelas()) {
			builderCSV.append(NOVA_LINHA)
			.append(dto.getSituacao()).append(SEPARADOR).append(dto.getQtdParcelas()).append(SEPARADOR).append(dto.getValorParcelas());
		}
		builderCSV.append(NOVA_LINHA)
		.append("Totais: ").append(SEPARADOR).append(relatorioSinteticoPagamentoSituacaoDTO.getQtdTotalParcelas()).append(SEPARADOR).append(relatorioSinteticoPagamentoSituacaoDTO.getValorTotalParcelas());
		
		return builderCSV.toString().getBytes();
	}
}