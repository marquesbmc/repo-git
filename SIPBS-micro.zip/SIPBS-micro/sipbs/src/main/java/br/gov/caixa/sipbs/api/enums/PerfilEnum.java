package br.gov.caixa.sipbs.api.enums;

public enum PerfilEnum {
	ROLE_ADMIN,
	ROLE_USUARIO,
	ROLE_GERENTE,
	ROLE_SOCIO,
	ROLE_FUNCIONARIO;
}
