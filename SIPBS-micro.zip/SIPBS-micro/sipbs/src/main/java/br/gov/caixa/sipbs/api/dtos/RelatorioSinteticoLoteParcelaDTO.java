package br.gov.caixa.sipbs.api.dtos;

import java.util.Date;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class RelatorioSinteticoLoteParcelaDTO {

	
	private String dataConsulta;
	private String nuProgramaSocial;
	private String loteRemessa;
	private Date dtInicioPeriodo;
	private Date dtFimPeriodo;
	private String nomeArquivoFisico;
	private String dtProcessamento;
	
	private RelatorioSinteticoLoteParcelaAcatadaDTO relatorioSinteticoLoteParcelaAcatadaDTO;
	private RelatorioSinteticoLoteParcelaRejeitadaDTO relatorioSinteticoLoteParcelaRejeitadaDTO;
	
	
}
