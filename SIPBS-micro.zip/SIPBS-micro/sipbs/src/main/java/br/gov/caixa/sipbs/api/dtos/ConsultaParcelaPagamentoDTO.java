package br.gov.caixa.sipbs.api.dtos;

import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonFormat;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class ConsultaParcelaPagamentoDTO {

	public Integer anoBase;
	public Integer exercicio;
	public Short parcelaNuParcela;
	public String parcelaValor;
	public String parcelaSituacao;
	public String sentencaJudicial;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "UTC-03")
	public Date parcelaDataValidade;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "UTC-03")
	public Date pagamentoData;
	public String pagamentoCanal;
	public Short pagamentoAgencia;
	public Short pagamentoDvAgencia;
	public Short pagamentoProduto;
	public Short pagamentoPropriedadeProduto;
	public Long pagamentoConta;
	public Short pagamentoDvConta;
	public Long pagamentoNsuCanal;
	public List<String> motivoRejeicaoSIACC;
	public Boolean possuiHistoricoManutencao;
	public Long identificadorParcela;
	public Long codigoPagamento;
	public Long codigoConveniado;
	public Integer nuTerminal;
}
