package br.gov.caixa.sipbs.api.dtos;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class LoteParcelaRejeitadaDTO {

	private Long nuPbsr03;
	private Long nuPbsr02;
	private String nomeArquivoFisico;
	private Integer nuProgramaSocial;
	private Integer nuReferencia;
	private Integer nuRemessa;
	private Date dtProcessamento;
	private String motivoRejeicao;
	private Long quantidadeTotalParcelas;
	private BigDecimal valorTotalParcelas;

}
