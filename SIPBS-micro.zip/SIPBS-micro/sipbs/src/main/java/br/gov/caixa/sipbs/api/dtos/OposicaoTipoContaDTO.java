package br.gov.caixa.sipbs.api.dtos;

import java.sql.Timestamp;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor

public class OposicaoTipoContaDTO {

	public Long nuPbsb14;
	public Short nuProdutoPbsb02;
	public Long nuCpfBeneficiario;
	public Short nuPropriedadeContaPbsb21;
	public Timestamp tsFimVigencia;
	public Timestamp tsIdVigencia;
	public Timestamp tsInicioVigencia;
	public Long nuEventoPbsa12;
	public Boolean isPossuiOposicao;
}
