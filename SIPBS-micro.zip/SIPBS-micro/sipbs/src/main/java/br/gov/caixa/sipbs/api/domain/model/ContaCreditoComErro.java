package br.gov.caixa.sipbs.api.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB07_CONTA_CREDITO_COM_ERRO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB07_CONTA_CREDITO_COM_ERRO")
public class ContaCreditoComErro extends PanacheEntityBase {

	@Id
	@Column(name="NU_PBSB07")
	public Integer nuPbsb07;

	@Column(name="CO_MENSAGEM")
	public Short coMensagem;

	@Column(name="DE_MENSAGEM")
	public String deMensagem;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ABERTURA_CONTA")
	public Date dtAberturaConta;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ULTMA_CNSLA_EXTRATO_SALDO")
	public Date dtUltmaCnslaExtratoSaldo;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ULTMA_MVMNO_ESPONTANEA")
	public Date dtUltmaMvmnoEspontanea;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ULTMA_MVMNO_ONLINE")
	public Date dtUltmaMvmnoOnline;

	@Column(name="IC_SALDO_POSITIVO")
	public Short icSaldoPositivo;

	@Column(name="IC_TIPO_MENSAGEM")
	public String icTipoMensagem;

	@Column(name="NU_AGENCIA")
	public Short nuAgencia;

	@Column(name="NU_BANCO")
	public Short nuBanco;

	@Column(name="NU_COMPETENCIA")
	public Integer nuCompetencia;

	@Column(name="NU_CONTA")
	public Long nuConta;

	@Column(name="NU_CPF_RECEBIDO")
	public Long nuCpfRecebido;

	@Column(name="NU_DV_AGENCIA")
	public Short nuDvAgencia;

	@Column(name="NU_DV_CONTA")
	public Short nuDvConta;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_NIS_RECEBIDO")
	public Long nuNisRecebido;

	@Column(name="NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name="NU_PROPRIEDADE_CONTA_PBSB21")
	public Short nuPropriedadeContaPbsb21;
}