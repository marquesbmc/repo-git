package br.gov.caixa.sipbs.api.dtos;

import br.gov.caixa.sipbs.api.domain.model.BeneficiarioSocial;
import br.gov.caixa.sipbs.api.domain.model.ContaCredito;
import br.gov.caixa.sipbs.api.domain.model.ProgramaSocial;

import java.sql.Timestamp;
import java.util.Date;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class MarcacaoDesmarcacaoContaDTO {

	public Long nuPbsb08;
	public ProgramaSocial programaSocial;
	public ContaCredito contaCredito;
	public BeneficiarioSocial beneficiarioSocial;
	public Integer nuReferencia;
	public CriterioPriorizacaoSelecaoContaDTO criterioPriorizacaoSelecaoConta;
	public Date dtAberturaConta;
	public Date dtFimVigenciaContaApta;
	public Date dtInicioVigenciaContaApta;
	public Date dtUltmaCnslaExtratoSaldo;
	public Date dtUltmaMvmnoEspontanea;
	public Date dtUltmaMvmnoOnline;
	public Short icSaldoPositivo;
	public Long nuEventoPbsa12;
	public Timestamp tsUltimaAtualizacao;
	public Date dtIdentificacaoConta;
	public Date dtSelecaoConta;
	public Short icCriterioContaPropriedade;
	public String deCriterioContaPropriedade;
	public Boolean isContaSelecionada;
}
