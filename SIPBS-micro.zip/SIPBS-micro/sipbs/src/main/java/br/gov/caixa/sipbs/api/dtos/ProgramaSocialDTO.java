package br.gov.caixa.sipbs.api.dtos;

import java.math.BigDecimal;
import java.sql.Timestamp;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class ProgramaSocialDTO {

	private Short nuProdutoIcoo10;
	private String coServicoCartao;
	private String coTipoEntregaCartaoPbso22;
	private String icAtivo;
	private Short icBloqueioFolhaPrograma;
	private String icBloqueioPagamento;
	private String icExclusivoCreditoConta;
	private String icPagamentoCreditoConta;
	private String icPagamentoSemCartao;
	private String icRejeitaContaCrot;
	private String icSolicitaCartao;
	private Integer nuAcao;
	private Integer nuBloqueioFolhaPbsb10;
	private Integer nuBloqueioPgmnoPbsb10;
	private BigDecimal nuCnpjGestorProduto;
	private Short nuCodigoLancamento;
	private Integer nuEventoContabil;
	private Long nuEventoPbsa12;
	private Short nuGrupo;
	private Short nuModo;
	private Short nuPrioridade;
	private Short nuProdutoVinculadoPbsb02;
	private Short nuSegmentoIcos12;
	private Short nuSubgrupo;
	private Short nuSubtipo;
	private Short nuTd;
	private Short nuTipo;
	private Short nuTipoAbrangenciaPbso21;
	private Short nuTipoProdutoPbso19;
	private Short pzValidadeContaApta;
	private String sgProgramaSocial;
	private Timestamp tsFimVigencia;
	private Timestamp tsIdVigencia;
	private Timestamp tsInicioVigencia;
	private BigDecimal vrMaximoParcela;

}
