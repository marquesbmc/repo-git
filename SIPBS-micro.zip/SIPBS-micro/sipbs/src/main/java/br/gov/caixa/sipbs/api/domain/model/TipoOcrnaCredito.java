package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO09_TIPO_OCRNA_CREDITO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO09_TIPO_OCRNA_CREDITO")
public class TipoOcrnaCredito extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_TIPO_OCRNA_CREDITO")
	public Short nuTipoOcrnaCredito;

	@Column(name="DE_TIPO_OCORRENCIA_CREDITO")
	public String deTipoOcorrenciaCredito;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}