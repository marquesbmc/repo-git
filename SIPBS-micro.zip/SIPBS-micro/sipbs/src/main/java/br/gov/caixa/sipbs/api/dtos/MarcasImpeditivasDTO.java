package br.gov.caixa.sipbs.api.dtos;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor

public class MarcasImpeditivasDTO {

	public String marca;

	public String descricao;

}
