package br.gov.caixa.sipbs.api.domain.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList; 
import java.util.List;
import java.util.Locale;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import br.gov.caixa.sipbs.api.domain.dao.PagamentoCanalDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.PagamentoCanal;
import br.gov.caixa.sipbs.api.dtos.PagamentoCanalDTO;
import br.gov.caixa.sipbs.api.dtos.ProgramaSocialDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoPagamentoCanalDTO;
import br.gov.caixa.sipbs.api.dtos.TipoCanalDTO;

@ApplicationScoped
public class PagamentoCanalServiceImpl extends GenericService implements PagamentoCanalService {

	@Inject 
	PagamentoCanalDAO pagamentoCanalDAO;

	@Override
	public RelatorioSinteticoPagamentoCanalDTO recuperarRelatorioSinteticoPagamentoCanal(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException {

		List<PagamentoCanal> pagamentoCanalList = pagamentoCanalDAO.recuperarRelatorioSinteticoPagamentoCanal(nuProdutoIcoo10, dtInicioPeriodo, dtFimPeriodo);

		List<PagamentoCanalDTO> pagamentoCanalDTOList = new ArrayList<>();
		PagamentoCanalDTO pagamentoCanalDTO;
		long qtTotalPagamento = 0L;
		BigDecimal vrTotalPagamento = BigDecimal.ZERO;
		for (PagamentoCanal pagamentoCanal : pagamentoCanalList) {
			pagamentoCanalDTO = new PagamentoCanalDTO();
			pagamentoCanalDTO.setNuPbsr01(pagamentoCanal.getNuPbsr01());
			pagamentoCanalDTO.setProgramaSocial(new ProgramaSocialDTO());
			pagamentoCanalDTO.getProgramaSocial().setNuProdutoIcoo10(pagamentoCanal.getProgramaSocial().getNuProdutoIcoo10());
			pagamentoCanalDTO.setTipoCanal(new TipoCanalDTO());
			pagamentoCanalDTO.getTipoCanal().setNuTipoCanal(pagamentoCanal.getTipoCanal().getNuTipoCanal());
			pagamentoCanalDTO.getTipoCanal().setDeTipoCanal(pagamentoCanal.getTipoCanal().getDeTipoCanal());
			pagamentoCanalDTO.setQtTotalPagamentos(pagamentoCanal.getQtTotalPagamentos());
			pagamentoCanalDTO.setVrTotalPagamentos(pagamentoCanal.getVrTotalPagamentos());

			qtTotalPagamento = qtTotalPagamento + pagamentoCanal.getQtTotalPagamentos();
			vrTotalPagamento = vrTotalPagamento.add(pagamentoCanal.getVrTotalPagamentos());

			pagamentoCanalDTOList.add(pagamentoCanalDTO);
		}

		RelatorioSinteticoPagamentoCanalDTO relatorioSinteticoPagamentoCanalDTO = new RelatorioSinteticoPagamentoCanalDTO();
		relatorioSinteticoPagamentoCanalDTO.setProgramaSocial(pagamentoCanalDTOList.get(0).getProgramaSocial());
		relatorioSinteticoPagamentoCanalDTO.setPagamentoCanalList(pagamentoCanalDTOList);
		relatorioSinteticoPagamentoCanalDTO.setQtTotalPagamento(qtTotalPagamento);
		relatorioSinteticoPagamentoCanalDTO.setVrTotalPagamento(vrTotalPagamento);

		return relatorioSinteticoPagamentoCanalDTO;
	}

	public ByteArrayOutputStream exportarRelatorioSinteticoPagamento(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException, IOException {

		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String dtInicio = dateFormatter.format(dtInicioPeriodo);
		String dtFim = dateFormatter.format(dtFimPeriodo);

		RelatorioSinteticoPagamentoCanalDTO relatorioSinteticoPagamentoCanalDTO = recuperarRelatorioSinteticoPagamentoCanal(nuProdutoIcoo10, dtInicioPeriodo, dtFimPeriodo);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Relatório Sintético");

		int contRow = 4;

		adicionarLogoCaixa(workbook, sheet);

		sheet.setDefaultColumnWidth(25);

		Font fontTamanho = workbook.createFont();
		fontTamanho.setFontHeight((short) 250);
		Font fontNegrito = workbook.createFont();
		fontNegrito.setBold(true);

		CellStyle styleCabecalho1 = workbook.createCellStyle();
		styleCabecalho1.setFont(fontTamanho);

		Row row = sheet.createRow(contRow++);
		Cell cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("CAIXA ECONÔMICA FEDERAL");
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("VICE-PRESIDÊNCIA DE GOVERNO - VIGOV");
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("SIPBS - RELATÓRIO SINTÉTICO DE PARCELAS PAGAS POR PERÍODO/CANAL");

		CellStyle styleCabecalho2 = workbook.createCellStyle();
		styleCabecalho2.setFont(fontNegrito);

		row = sheet.createRow(contRow++).getSheet().createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		cellCabecalho.setCellValue("Produto: " + relatorioSinteticoPagamentoCanalDTO.getProgramaSocial().getNuProdutoIcoo10());

		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		cellCabecalho.setCellValue("Período: " + dtInicio + " - " + dtFim);

		Font fontBold = workbook.createFont();
		fontBold.setBold(true);
		fontBold.setFontHeight((short) 250);

		CellStyle styleTitulo = workbook.createCellStyle();
		styleTitulo.setAlignment(HorizontalAlignment.CENTER);
		styleTitulo.setFillForegroundColor(IndexedColors.GOLD.getIndex());
		styleTitulo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleTitulo);
		styleTitulo.setFont(fontBold);

		row = sheet.createRow(contRow++).getSheet().createRow(contRow++).getSheet().createRow(contRow++);
		Cell cellTitulo = row.createCell(0);
		cellTitulo.setCellValue("Canal");
		cellTitulo.setCellStyle(styleTitulo);
		cellTitulo = row.createCell(1);
		cellTitulo.setCellValue("Qtde");
		cellTitulo.setCellStyle(styleTitulo);
		cellTitulo = row.createCell(2);
		cellTitulo.setCellValue("Valor (R$)");
		cellTitulo.setCellStyle(styleTitulo);

		NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
		row = sheet.createRow(contRow++);
		int contCell = 0;
		Cell cellConteudo;

		for (PagamentoCanalDTO pagamentoCanalDTO : relatorioSinteticoPagamentoCanalDTO.getPagamentoCanalList()) {
			CellStyle styleConteudoCanal = workbook.createCellStyle();
			CellStyle styleConteudoQtde = workbook.createCellStyle();
			CellStyle styleConteudoValor = workbook.createCellStyle();
			carregarbordarCelula(styleConteudoCanal);
			carregarbordarCelula(styleConteudoQtde);
			carregarbordarCelula(styleConteudoValor);
			if (contRow % 2 == 0) {
				styleConteudoCanal.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoQtde.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoValor.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			} else {
				styleConteudoCanal.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoQtde.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoValor.setFillForegroundColor(IndexedColors.WHITE.getIndex());
			}
			styleConteudoCanal.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoQtde.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoValor.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(pagamentoCanalDTO.getTipoCanal().getDeTipoCanal() + " " + pagamentoCanalDTO.getTipoCanal().getSgSitemaPagamento());
			styleConteudoCanal.setAlignment(HorizontalAlignment.LEFT);
			cellConteudo.setCellStyle(styleConteudoCanal);

			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(pagamentoCanalDTO.getQtTotalPagamentos());
			styleConteudoQtde.setAlignment(HorizontalAlignment.RIGHT);
			cellConteudo.setCellStyle(styleConteudoQtde);

			cellConteudo = row.createCell(contCell);
			cellConteudo.setCellValue(numberFormat.format(pagamentoCanalDTO.getVrTotalPagamentos()));
			styleConteudoValor.setAlignment(HorizontalAlignment.RIGHT);
			cellConteudo.setCellStyle(styleConteudoValor);

			row = sheet.createRow(contRow++);
			contCell = 0;
		}

		CellStyle styleRodapeRight = workbook.createCellStyle();
		styleRodapeRight.setFont(fontBold);
		styleRodapeRight.setAlignment(HorizontalAlignment.RIGHT);
		styleRodapeRight.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		styleRodapeRight.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleRodapeRight);

		Cell cellRodape = row.createCell(contCell++);
		cellRodape.setCellValue("Totais: ");
		cellRodape.setCellStyle(styleRodapeRight);

		cellRodape = row.createCell(contCell++);
		cellRodape.setCellValue(relatorioSinteticoPagamentoCanalDTO.getQtTotalPagamento());
		cellRodape.setCellStyle(styleRodapeRight);

		cellRodape = row.createCell(contCell);
		cellRodape.setCellValue(numberFormat.format(relatorioSinteticoPagamentoCanalDTO.getVrTotalPagamento()));
		cellRodape.setCellStyle(styleRodapeRight);

		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

		row = sheet.createRow(contRow);
		Font fontItalic = workbook.createFont();
		fontItalic.setItalic(true);
		fontItalic.setBold(true);
		fontItalic.setFontHeight((short) 180);
		CellStyle styleDtRelatorio = workbook.createCellStyle();
		styleDtRelatorio.setFont(fontItalic);
		Cell cellDtRelatorio = row.createCell(0);
		cellDtRelatorio.setCellStyle(styleDtRelatorio);

		cellDtRelatorio.setCellValue("Date de geração do relatório: " + dateTimeFormatter.format(LocalDateTime.now()));

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		workbook.write(outputStream);
		workbook.close();
		return outputStream;
	}

	private void adicionarLogoCaixa(XSSFWorkbook workbook, XSSFSheet sheet) throws IOException {
		InputStream is = getClass().getResourceAsStream("/image/logo-caixa.jpeg");
		byte[] bytes = IOUtils.toByteArray(is);
		int pictureIdx = workbook.addPicture(bytes, Workbook.PICTURE_TYPE_JPEG);
		is.close();

		CreationHelper helper = workbook.getCreationHelper();
		Drawing<?> drawing = sheet.createDrawingPatriarch();
		ClientAnchor anchor = helper.createClientAnchor();

		anchor.setRow1(0);
		anchor.setCol1(0);
		Picture pict = drawing.createPicture(anchor, pictureIdx);
		pict.resize();
	}

	private void carregarbordarCelula(CellStyle cellStyle) {
		cellStyle.setBorderTop(BorderStyle.THIN);
		cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderBottom(BorderStyle.THIN);
		cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderLeft(BorderStyle.THIN);
		cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderRight(BorderStyle.THIN);
		cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
	}

	@Override
	public List<PagamentoCanalDTO> listAll() {
		return null;
	}

	@Override
	public List<PagamentoCanalDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return null;
	}

	@Override
	public PagamentoCanalDTO findById(Long id) {
		return null;
	}

	@Override
	public PagamentoCanalDTO create(PagamentoCanalDTO request) {
		return null;
	}

	@Override
	public PagamentoCanalDTO update(Long id, PagamentoCanalDTO request) {
		return null;
	}

	@Override
	public void delete(Long id) {

	}

	@Override
	public Long count() {
		return null;
	}

}
