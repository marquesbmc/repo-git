package br.gov.caixa.sipbs.api.dtos;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class LoteParcelaDTO {

	private Date dataConsulta;
	private ProgramaSocialDTO programaSocialDTO;
	private Integer loteRemessa;
	private LocalDate dtInicioPeriodo;
	private LocalDate dtInicioFim;
	private ArquivoFisicoDTO arquivoFisicoDTO;
	
	private List<LoteParcelaAcatadaDTO> loteParcelasAcatadasDTO;
	private List<LoteParcelaRejeitadaDTO> loteParcelasRejeitadasDTO;
}
