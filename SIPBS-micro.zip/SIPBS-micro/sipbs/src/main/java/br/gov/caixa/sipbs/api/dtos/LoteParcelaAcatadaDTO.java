package br.gov.caixa.sipbs.api.dtos;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class LoteParcelaAcatadaDTO {

    private Long nuPbsr04;
	private Long nuPbsr02;
	private String noOriginalArquivo;
	private Integer nuProduto;
	private Integer nuReferencia;
	private Integer nuRemessa;
	private Date dtProcessamento;
	private Integer anoBase;
	private Long quantidateTotalParcelas;
	private BigDecimal valorTotalParcelas;

}
