package br.gov.caixa.sipbs.api.domain.repository.panache;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.ContaMarcadaMarcacao;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class ContaMarcadaMarcacaoPanacheRepository implements PanacheRepository<ContaMarcadaMarcacao> {

	private static final Logger LOGGER = LoggerFactory.getLogger(BeneficiarioProgramaSocialPanacheRepository.class);

	public List<ContaMarcadaMarcacao> listMarcasImpeditivas(Short nuProdutoIcoo10, Long nuCpfBeneficiario, Integer nuPbsb06) throws GeneralException {


		LOGGER.info("Chamando método listFilter com os parâmetros" + nuProdutoIcoo10 + " - " + nuCpfBeneficiario + " - " + nuPbsb06);
		try {
			String sql = "SELECT contaMarcadaMarcacao " +
					"       FROM ContaMarcadaMarcacao contaMarcadaMarcacao" +
					"       JOIN FETCH contaMarcadaMarcacao.tipoPropriedadeConta tipoPropriedadeConta" +
					"       JOIN FETCH contaMarcadaMarcacao.marcacaoDesmarcacaoConta marcacaoDesmarcacaoConta" +
					"       JOIN FETCH marcacaoDesmarcacaoConta.programaSocial programaSocial" +
					"       JOIN FETCH marcacaoDesmarcacaoConta.contaCredito contaCredito" +
					"       JOIN FETCH marcacaoDesmarcacaoConta.beneficiarioSocial beneficiarioSocial" +
					"       JOIN FETCH contaCredito.propriedadeConta propriedadeConta" +
					"       JOIN FETCH propriedadeConta.tipoConta tipoConta" +
					"       WHERE contaMarcadaMarcacao.marcacaoDesmarcacaoConta.programaSocial.nuProdutoIcoo10 = ?1" +
					"       AND contaMarcadaMarcacao.marcacaoDesmarcacaoConta.beneficiarioSocial.nuCpfBeneficiario = ?2" +
					"       AND contaMarcadaMarcacao.marcacaoDesmarcacaoConta.contaCredito.nuPbsb06 = ?3";

			return ContaMarcadaMarcacao.list(sql, nuProdutoIcoo10, nuCpfBeneficiario, nuPbsb06);

		} catch (Exception e) {
			LOGGER.error("Erro em " + "Chamando método listFilter com os parâmetros", e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}
}
