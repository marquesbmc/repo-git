package br.gov.caixa.sipbs.api.domain.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import br.gov.caixa.sipbs.api.domain.dao.ParcelaPagamentoDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.repository.panache.ParcelaPagamentoRepository;
import br.gov.caixa.sipbs.api.dtos.ConsultaParcelaPagamentoDTO;
import br.gov.caixa.sipbs.api.dtos.HistoricoManutencaoDTO;

@ApplicationScoped
public class ParcelaPagamentoServiceImpl extends GenericService implements ParcelaPagamentoService {

	@Inject
	ParcelaPagamentoRepository parcelaPagamentoRepository;
	
	@Inject
	ParcelaPagamentoDAO parcelaPagamentoDao;

	@Override
	public List<ConsultaParcelaPagamentoDTO> searchParcelas(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10)
			throws GeneralException {
		List<ConsultaParcelaPagamentoDTO> listaParcelas = parcelaPagamentoDao.searchParcelas(icCpfNis, nuCpfNis, nuProdutoIcoo10);
		/*if(listaParcelas != null && listaParcelas.size() == 1) {
			ConsultaParcelaPagamentoDTO consultaParcelaPagamentoDTO = listaParcelas.get(0);
			for(int i = 0; i<21;i++) {
				listaParcelas.add(consultaParcelaPagamentoDTO);
			}
		}*/
		return listaParcelas;
	}

	@Override
	public List<HistoricoManutencaoDTO> historiccoManutencao(Long nuPbso12) throws GeneralException {
		List<HistoricoManutencaoDTO> lista = parcelaPagamentoDao.historiccoManutencao(nuPbso12);
		/*if(lista != null && lista.size() == 0) {
			HistoricoManutencaoDTO historicoManutencaoDTO = new HistoricoManutencaoDTO();
			historicoManutencaoDTO.setComando("Comando");
			historicoManutencaoDTO.setDataCadastroSistemaExterno(new Date());
			historicoManutencaoDTO.setDataProcessamento(new Timestamp(new Date().getTime()));
			historicoManutencaoDTO.setDetalheSituacao("Detalhe Situação");
			historicoManutencaoDTO.setLoteNuRemessa(1L);
			historicoManutencaoDTO.setMotivoExterno("MotivoExterno");
			historicoManutencaoDTO.setMotivoInterno("MotivoInterno");
			historicoManutencaoDTO.setNumContraOrdem(1L);

			for(int i = 0; i<27;i++) {
				lista.add(historicoManutencaoDTO);
			}
		}*/
		return lista;
	}

	@Override
	public ByteArrayOutputStream exportarRelatorio(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10, String nomeProduto, Boolean perfilGestor)
			throws GeneralException, IOException {
		List<ConsultaParcelaPagamentoDTO> listConsultaParcela = searchParcelas(icCpfNis, nuCpfNis, nuProdutoIcoo10);

		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("dd/MM/yyyy");
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Processamento de Parcelas");
		
		int contRow = 4;

		adicionarLogoCaixa(workbook, sheet);
		
		sheet.setDefaultColumnWidth(25);
		Font fontTamanho = workbook.createFont();
		fontTamanho.setFontHeight((short) 250);
		Font fontNegrito = workbook.createFont();
		fontNegrito.setBold(true);
		
		CellStyle styleCabecalho1 = workbook.createCellStyle();
		styleCabecalho1.setFont(fontTamanho);
		
		Row row = sheet.createRow(contRow++);
		Cell cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("CAIXA ECONÔMICA FEDERAL");
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("SIPBS - PROCESSAMENTO");
		
		CellStyle styleCabecalho2 = workbook.createCellStyle();
		styleCabecalho2.setFont(fontNegrito);
		
		row = sheet.createRow(contRow++).getSheet().createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		if(icCpfNis.equals("C")) {
			cellCabecalho.setCellValue("CPF: " + nuCpfNis);
		} else {
			cellCabecalho.setCellValue("NIS: " + nuCpfNis);
		}
		row = sheet.createRow(contRow++).getSheet().createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		cellCabecalho.setCellValue("Produto: " + nomeProduto);
		
		Instant instant = new Date().toInstant();
		LocalDateTime ldt = instant.atOffset(ZoneOffset.UTC).toLocalDateTime();
		
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		cellCabecalho.setCellValue("Data de Geração do Relatório: " + dateFormatter.format(ldt));
		
		Font fontBold = workbook.createFont();
		fontBold.setBold(true);
		fontBold.setFontHeight((short) 250);
		
		CellStyle styleTitulo = workbook.createCellStyle();
		styleTitulo.setAlignment(HorizontalAlignment.CENTER);
		styleTitulo.setFillForegroundColor(IndexedColors.GOLD.getIndex());
		styleTitulo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleTitulo);
		styleTitulo.setFont(fontBold);
		
		row = sheet.createRow(contRow++).getSheet().createRow(contRow++).getSheet().createRow(contRow++);
		Cell cellTituloLinha1 = row.createCell(0);
		cellTituloLinha1.setCellValue("Ano Base");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(1);
		cellTituloLinha1.setCellValue("Exercício");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(2);
		cellTituloLinha1.setCellValue("Código Pagamento");
		cellTituloLinha1.setCellStyle(styleTitulo);

		cellTituloLinha1 = row.createCell(3);
		cellTituloLinha1.setCellValue("Parcela");
		cellTituloLinha1.setCellStyle(styleTitulo);

		cellTituloLinha1 = row.createCell(4);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);

		cellTituloLinha1 = row.createCell(5);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);

		cellTituloLinha1 = row.createCell(6);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(7);
		cellTituloLinha1.setCellValue("Pagamento");
		cellTituloLinha1.setCellStyle(styleTitulo);

		cellTituloLinha1 = row.createCell(8);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(9);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(10);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(11);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(12);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(13);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(14);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(15);
		cellTituloLinha1.setCellValue("");
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1 = row.createCell(16);
		String texto = "Motivos de Rejeição pelo SIACC";
		sheet.setColumnWidth(0, texto.length() * 250);
		cellTituloLinha1.setCellValue(texto);
		cellTituloLinha1.setCellStyle(styleTitulo);
		
		cellTituloLinha1.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow-1, 3, 6));
		cellTituloLinha1.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow-1, 7, 15));
		cellTituloLinha1.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow, 0, 0));
		cellTituloLinha1.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow, 1, 1));
		cellTituloLinha1.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow, 2, 2));
		cellTituloLinha1.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow, 16, 16));

		row = sheet.createRow(contRow++);
		Cell cellTituloLinha2 = row.createCell(0);
		cellTituloLinha2.setCellStyle(styleTitulo);
		cellTituloLinha2.setCellValue("");

		cellTituloLinha2 = row.createCell(1);
		cellTituloLinha2.setCellValue("");
		cellTituloLinha2.setCellStyle(styleTitulo);
		
		cellTituloLinha2 = row.createCell(2);
		cellTituloLinha2.setCellValue("");
		cellTituloLinha2.setCellStyle(styleTitulo);
		
		cellTituloLinha2 = row.createCell(3);
		cellTituloLinha2.setCellValue("Nº");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(4);
		cellTituloLinha2.setCellValue("Valor (R$)");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(5);
		cellTituloLinha2.setCellValue("Situação");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(6);
		cellTituloLinha2.setCellValue("Validade");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(7);
		cellTituloLinha2.setCellValue("Data");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(8);
		cellTituloLinha2.setCellValue("Canal");
		cellTituloLinha2.setCellStyle(styleTitulo);
		
		cellTituloLinha2 = row.createCell(9);
		cellTituloLinha2.setCellValue("Agência");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(10);
		cellTituloLinha2.setCellValue("Produto(operação)");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(11);
		cellTituloLinha2.setCellValue("Propriedade");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(12);
		cellTituloLinha2.setCellValue("Conta");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(13);
		cellTituloLinha2.setCellValue("Código Conveniado");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(14);
		cellTituloLinha2.setCellValue("Terminal");
		cellTituloLinha2.setCellStyle(styleTitulo);

		cellTituloLinha2 = row.createCell(15);
		cellTituloLinha2.setCellValue("NSU do canal");
		cellTituloLinha2.setCellStyle(styleTitulo);

		row = sheet.createRow(contRow++);
		int contCell = 0;
		Cell cellConteudo;
		for (ConsultaParcelaPagamentoDTO consultaParcelaPagamentoDTO : listConsultaParcela) {
			CellStyle styleConteudoAnoBase = workbook.createCellStyle();
			CellStyle styleConteudoExercicio = workbook.createCellStyle();
			CellStyle styleConteudoCodPagmanto = workbook.createCellStyle();
			CellStyle styleConteudoParcelaNumero = workbook.createCellStyle();
			CellStyle styleConteudoParcelaValor = workbook.createCellStyle();
			CellStyle styleConteudoParcelaSituacao = workbook.createCellStyle();
			CellStyle styleConteudoParcelaValidade = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoData = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoCanal = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoAgencia = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoProduto = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoPropriedade = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoConta = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoCodigoConveniado = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoTerminal = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoNsuCanal = workbook.createCellStyle();
			CellStyle styleConteudoPagamentoMotivos = workbook.createCellStyle();
			carregarbordarCelula(styleConteudoAnoBase);
			carregarbordarCelula(styleConteudoExercicio);
			carregarbordarCelula(styleConteudoCodPagmanto);
			carregarbordarCelula(styleConteudoParcelaNumero);
			carregarbordarCelula(styleConteudoParcelaValor);
			carregarbordarCelula(styleConteudoParcelaSituacao);
			carregarbordarCelula(styleConteudoParcelaValidade);
			carregarbordarCelula(styleConteudoPagamentoData);
			carregarbordarCelula(styleConteudoPagamentoCanal);
			carregarbordarCelula(styleConteudoPagamentoAgencia);
			carregarbordarCelula(styleConteudoPagamentoProduto);
			carregarbordarCelula(styleConteudoPagamentoPropriedade);
			carregarbordarCelula(styleConteudoPagamentoConta);
			carregarbordarCelula(styleConteudoPagamentoCodigoConveniado);
			carregarbordarCelula(styleConteudoPagamentoTerminal);
			carregarbordarCelula(styleConteudoPagamentoNsuCanal);
			carregarbordarCelula(styleConteudoPagamentoMotivos);
			if (contRow % 2 == 0) {
				styleConteudoAnoBase.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoExercicio.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoCodPagmanto.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoParcelaNumero.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoParcelaValor.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoParcelaSituacao.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoParcelaValidade.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoData.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoCanal.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoAgencia.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoProduto.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoPropriedade.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoConta.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoCodigoConveniado.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoTerminal.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoNsuCanal.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoPagamentoMotivos.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			} else {
				styleConteudoAnoBase.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoExercicio.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoCodPagmanto.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoParcelaNumero.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoParcelaValor.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoParcelaSituacao.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoParcelaValidade.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoData.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoCanal.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoAgencia.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoProduto.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoPropriedade.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoConta.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoCodigoConveniado.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoTerminal.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoNsuCanal.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoPagamentoMotivos.setFillForegroundColor(IndexedColors.WHITE.getIndex());
			}
			styleConteudoAnoBase.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoExercicio.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoCodPagmanto.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoParcelaNumero.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoParcelaValor.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoParcelaSituacao.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoParcelaValidade.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoData.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoCanal.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoAgencia.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoProduto.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoPropriedade.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoConta.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoCodigoConveniado.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoTerminal.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoNsuCanal.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoPagamentoMotivos.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			//Ano Base
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getAnoBase() == null ? "" : consultaParcelaPagamentoDTO.getAnoBase().toString());
			styleConteudoAnoBase.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoAnoBase);
			
			//Exercicio
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getExercicio() == null ? "" : consultaParcelaPagamentoDTO.getExercicio().toString());
			styleConteudoExercicio.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoExercicio);
			
			//Codigo Pagamento
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getCodigoPagamento() == null ? "" : consultaParcelaPagamentoDTO.getCodigoPagamento().toString());
			styleConteudoCodPagmanto.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoCodPagmanto);
			
			//Num Parcela
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getParcelaNuParcela() == null ? "" : consultaParcelaPagamentoDTO.getParcelaNuParcela().toString());
			styleConteudoParcelaNumero.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoParcelaNumero);
			
			//Valor
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getParcelaValor() == null ? "R$0,00" : consultaParcelaPagamentoDTO.getParcelaValor());
			styleConteudoParcelaValor.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoParcelaValor);
			
			//situacao
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getParcelaSituacao() == null ? "" : consultaParcelaPagamentoDTO.getParcelaSituacao());
			styleConteudoParcelaSituacao.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoParcelaSituacao);
			
			//Validade
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getParcelaDataValidade() == null ? "" : simpleDateFormatter.format(consultaParcelaPagamentoDTO.getParcelaDataValidade()));
			styleConteudoParcelaValidade.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoParcelaValidade);
			
			//Data Pagamento
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getPagamentoData() == null ? "" :  simpleDateFormatter.format(consultaParcelaPagamentoDTO.getPagamentoData()));
			styleConteudoPagamentoData.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoPagamentoData);
			
			//Canal
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getPagamentoCanal() == null ? "" : consultaParcelaPagamentoDTO.getPagamentoCanal());
			styleConteudoPagamentoCanal.setAlignment(HorizontalAlignment.LEFT);
			cellConteudo.setCellStyle(styleConteudoPagamentoCanal);
			
			//Agência
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getPagamentoAgencia() == null ? "" : consultaParcelaPagamentoDTO.getPagamentoAgencia().toString());
			styleConteudoPagamentoAgencia.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoPagamentoAgencia);
			
			//Produto
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getPagamentoProduto() == null ? "" : consultaParcelaPagamentoDTO.getPagamentoProduto().toString());
			styleConteudoPagamentoProduto.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoPagamentoProduto);
			
			//Propriedade
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getPagamentoPropriedadeProduto() == null ? "" : consultaParcelaPagamentoDTO.getPagamentoPropriedadeProduto().toString());
			styleConteudoPagamentoPropriedade.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoPagamentoPropriedade);
			
			//Conta
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getPagamentoConta()== null ? "" : consultaParcelaPagamentoDTO.getPagamentoConta().toString());
			styleConteudoPagamentoConta.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoPagamentoPropriedade);
			
			//Codigo Conveniado
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getCodigoConveniado() == null ? "" : consultaParcelaPagamentoDTO.getCodigoConveniado().toString());
			styleConteudoPagamentoCodigoConveniado.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoPagamentoCodigoConveniado);
			
			//Terminal
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getNuTerminal() == null ? "" : consultaParcelaPagamentoDTO.getNuTerminal().toString());
			styleConteudoPagamentoTerminal.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoPagamentoTerminal);
			
			//NSU
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(consultaParcelaPagamentoDTO.getPagamentoNsuCanal() == null ? "" : consultaParcelaPagamentoDTO.getPagamentoNsuCanal().toString());
			styleConteudoPagamentoNsuCanal.setAlignment(HorizontalAlignment.CENTER);
			cellConteudo.setCellStyle(styleConteudoPagamentoNsuCanal);
			
			//Motivos
			StringBuilder motivos = new StringBuilder();
			int line = 1;
			for(String motivo : consultaParcelaPagamentoDTO.getMotivoRejeicaoSIACC()) {
				if(motivo != null) {
					motivos.append(line).append(". ");
					motivos.append(motivo);
					motivos.append("\n");
					line++;
				}
			}
			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(motivos.toString().trim());
			styleConteudoPagamentoMotivos.setWrapText(true);
			cellConteudo.setCellStyle(styleConteudoPagamentoMotivos);
			
			row.setHeight((short) 1000);
			row = sheet.createRow(contRow++);
			contCell = 0;
		}
		
		CellStyle styleRodapeRight = workbook.createCellStyle();
		styleRodapeRight.setFont(fontBold);
		styleRodapeRight.setAlignment(HorizontalAlignment.RIGHT);
		styleRodapeRight.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		styleRodapeRight.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleRodapeRight);

		Cell cellRodape = row.createCell(contCell++);
		cellRodape.setCellValue("Tota de linhas: ");
		cellRodape.setCellStyle(styleRodapeRight);
		
		cellRodape = row.createCell(contCell++);
		cellRodape.setCellValue(listConsultaParcela.size());
		cellRodape.setCellStyle(styleRodapeRight);

		row = sheet.createRow(contRow++);
		
		//Tabelas de históricos
		if(listConsultaParcela.size() > 0) {
			for(ConsultaParcelaPagamentoDTO consultaParcelaPagamentoDTO : listConsultaParcela) {
				List<HistoricoManutencaoDTO> listHistorico = historiccoManutencao(consultaParcelaPagamentoDTO.getIdentificadorParcela());

				if(listHistorico.size() > 0) {
					row = sheet.createRow(contRow++).getSheet().createRow(contRow++).getSheet().createRow(contRow++).getSheet().createRow(contRow++);
					Cell cellHistoricoTituloLinha1 = row.createCell(0);
					cellHistoricoTituloLinha1.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha1.setCellValue("Contra Ordem");
					
					cellHistoricoTituloLinha1 = row.createCell(1);
					cellHistoricoTituloLinha1.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha1.setCellValue("");
					
					cellHistoricoTituloLinha1 = row.createCell(2);
					cellHistoricoTituloLinha1.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha1.setCellValue("");
					
					cellHistoricoTituloLinha1 = row.createCell(3);
					cellHistoricoTituloLinha1.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha1.setCellValue("");
					
					cellHistoricoTituloLinha1 = row.createCell(4);
					cellHistoricoTituloLinha1.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha1.setCellValue("");
					
					cellHistoricoTituloLinha1 = row.createCell(5);
					cellHistoricoTituloLinha1.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha1.setCellValue("");
					
					cellHistoricoTituloLinha1 = row.createCell(6);
					cellHistoricoTituloLinha1.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha1.setCellValue("");
					
					cellHistoricoTituloLinha1 = row.createCell(7);
					cellHistoricoTituloLinha1.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha1.setCellValue("");
					
					cellHistoricoTituloLinha1.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow-1, 0, 6));
					
					row = sheet.createRow(contRow++);
					Cell cellHistoricoTituloLinha2 = row.createCell(0);
					String anoBaseHistorico = consultaParcelaPagamentoDTO.getAnoBase() == null ? "" : consultaParcelaPagamentoDTO.getAnoBase().toString();
					cellHistoricoTituloLinha2.setCellValue("Ano Base - " + anoBaseHistorico);
					cellHistoricoTituloLinha2.setCellStyle(styleTitulo);
					
					cellHistoricoTituloLinha2 = row.createCell(1);
					String exercicioHistorico = consultaParcelaPagamentoDTO.getExercicio() == null ? "" : consultaParcelaPagamentoDTO.getExercicio().toString();
					cellHistoricoTituloLinha2.setCellValue("Exercício - " + exercicioHistorico);
					cellHistoricoTituloLinha2.setCellStyle(styleTitulo);
					
					cellHistoricoTituloLinha2 = row.createCell(2);
					String codPagamentoHistorico = consultaParcelaPagamentoDTO.getCodigoPagamento() == null ? "" : consultaParcelaPagamentoDTO.getCodigoPagamento().toString();
					cellHistoricoTituloLinha2.setCellValue("Código de Pagamento - " + codPagamentoHistorico);
					cellHistoricoTituloLinha2.setCellStyle(styleTitulo);
					
					cellHistoricoTituloLinha2 = row.createCell(3);
					cellHistoricoTituloLinha2.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha2.setCellValue("");
					
					CellStyle styleParcela = workbook.createCellStyle();
					styleParcela.setAlignment(HorizontalAlignment.LEFT);
					styleParcela.setFillForegroundColor(IndexedColors.GOLD.getIndex());
					styleParcela.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					carregarbordarCelula(styleParcela);
					styleParcela.setFont(fontBold);
					
					cellHistoricoTituloLinha2 = row.createCell(4);
					String numParcelaHistorico = consultaParcelaPagamentoDTO.getParcelaNuParcela() == null ? "" : consultaParcelaPagamentoDTO.getParcelaNuParcela().toString();
					cellHistoricoTituloLinha2.setCellValue("Nº da Parcela - " + numParcelaHistorico);
					cellHistoricoTituloLinha2.setCellStyle(styleParcela);
					
					cellHistoricoTituloLinha2 = row.createCell(5);
					cellHistoricoTituloLinha2.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha2.setCellValue("");
					
					cellHistoricoTituloLinha2 = row.createCell(6);
					cellHistoricoTituloLinha2.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha2.setCellValue("");

					cellHistoricoTituloLinha2 = row.createCell(7);
					cellHistoricoTituloLinha2.setCellStyle(styleTitulo);
					cellHistoricoTituloLinha2.setCellValue("");

					cellHistoricoTituloLinha2.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow-1, 2, 3));
					cellHistoricoTituloLinha2.getSheet().addMergedRegion(new CellRangeAddress(contRow-1, contRow-1, 4, 7));

					row = sheet.createRow(contRow++);
					Cell cellHistoricoTituloLinha3 = row.createCell(0);
					cellHistoricoTituloLinha3.setCellValue("Lote");
					cellHistoricoTituloLinha3.setCellStyle(styleTitulo);
					
					cellHistoricoTituloLinha3 = row.createCell(1);
					cellHistoricoTituloLinha3.setCellValue("Nº da contraordem");
					cellHistoricoTituloLinha3.setCellStyle(styleTitulo);

					cellHistoricoTituloLinha3 = row.createCell(2);
					cellHistoricoTituloLinha3.setCellValue("Data de cadastro no sistema do ente externo");
					cellHistoricoTituloLinha3.setCellStyle(styleTitulo);

					cellHistoricoTituloLinha3 = row.createCell(3);
					cellHistoricoTituloLinha3.setCellValue("Data de processamento");
					cellHistoricoTituloLinha3.setCellStyle(styleTitulo);

					cellHistoricoTituloLinha3 = row.createCell(4);
					cellHistoricoTituloLinha3.setCellValue("Comando");
					cellHistoricoTituloLinha3.setCellStyle(styleTitulo);

					if(perfilGestor) {
						cellHistoricoTituloLinha3 = row.createCell(5);
						cellHistoricoTituloLinha3.setCellValue("Motivo Interno");
						cellHistoricoTituloLinha3.setCellStyle(styleTitulo);

						cellHistoricoTituloLinha3 = row.createCell(6);
						cellHistoricoTituloLinha3.setCellValue("Situação");
						cellHistoricoTituloLinha3.setCellStyle(styleTitulo);

						cellHistoricoTituloLinha3 = row.createCell(7);
						cellHistoricoTituloLinha3.setCellValue("Motivo Externo");
						cellHistoricoTituloLinha3.setCellStyle(styleTitulo);
					} else {
						cellHistoricoTituloLinha3 = row.createCell(5);
						cellHistoricoTituloLinha3.setCellValue("Situação");
						cellHistoricoTituloLinha3.setCellStyle(styleTitulo);

						cellHistoricoTituloLinha3 = row.createCell(6);
						cellHistoricoTituloLinha3.setCellValue("Motivo Externo");
						cellHistoricoTituloLinha3.setCellStyle(styleTitulo);
						
						cellHistoricoTituloLinha3 = row.createCell(7);
						cellHistoricoTituloLinha3.setCellValue("");
						cellHistoricoTituloLinha3.setCellStyle(styleTitulo);
					}

					row = sheet.createRow(contRow++);
					contCell = 0;
					Cell cellConteudoHistorico;
					for(HistoricoManutencaoDTO historicoManutencao : listHistorico) {
						CellStyle styleConteudoLote = workbook.createCellStyle();
						CellStyle styleConteudoNumContraOrdem = workbook.createCellStyle();
						CellStyle styleConteudoDataEnteExterno= workbook.createCellStyle();
						CellStyle styleConteudoDataProcessamento = workbook.createCellStyle();
						CellStyle styleConteudoComando = workbook.createCellStyle();
						CellStyle styleConteudoMotivoInterno = workbook.createCellStyle();
						CellStyle styleConteudoSituacao = workbook.createCellStyle();
						CellStyle styleConteudoMotivoExterno = workbook.createCellStyle();
						carregarbordarCelula(styleConteudoLote);
						carregarbordarCelula(styleConteudoNumContraOrdem);
						carregarbordarCelula(styleConteudoDataEnteExterno);
						carregarbordarCelula(styleConteudoDataProcessamento);
						carregarbordarCelula(styleConteudoComando);
						carregarbordarCelula(styleConteudoMotivoInterno);
						carregarbordarCelula(styleConteudoSituacao);
						carregarbordarCelula(styleConteudoMotivoExterno);
						if (contRow % 2 == 0) {
							styleConteudoLote.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
							styleConteudoNumContraOrdem.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
							styleConteudoDataEnteExterno.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
							styleConteudoDataProcessamento.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
							styleConteudoComando.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
							styleConteudoMotivoInterno.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
							styleConteudoSituacao.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
							styleConteudoMotivoExterno.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
						} else {
							styleConteudoLote.setFillForegroundColor(IndexedColors.WHITE.getIndex());
							styleConteudoNumContraOrdem.setFillForegroundColor(IndexedColors.WHITE.getIndex());
							styleConteudoDataEnteExterno.setFillForegroundColor(IndexedColors.WHITE.getIndex());
							styleConteudoDataProcessamento.setFillForegroundColor(IndexedColors.WHITE.getIndex());
							styleConteudoComando.setFillForegroundColor(IndexedColors.WHITE.getIndex());
							styleConteudoMotivoInterno.setFillForegroundColor(IndexedColors.WHITE.getIndex());
							styleConteudoSituacao.setFillForegroundColor(IndexedColors.WHITE.getIndex());
							styleConteudoMotivoExterno.setFillForegroundColor(IndexedColors.WHITE.getIndex());
						}
						styleConteudoLote.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						styleConteudoNumContraOrdem.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						styleConteudoDataEnteExterno.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						styleConteudoDataProcessamento.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						styleConteudoComando.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						styleConteudoMotivoInterno.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						styleConteudoSituacao.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						styleConteudoMotivoExterno.setFillPattern(FillPatternType.SOLID_FOREGROUND);

						//Lote
						cellConteudoHistorico = row.createCell(contCell++);
						cellConteudoHistorico.setCellValue(historicoManutencao.getLoteNuRemessa() == null ? "" : historicoManutencao.getLoteNuRemessa().toString());
						styleConteudoLote.setAlignment(HorizontalAlignment.CENTER);
						cellConteudoHistorico.setCellStyle(styleConteudoLote);
						
						//Num da ContraOrdem
						cellConteudoHistorico = row.createCell(contCell++);
						cellConteudoHistorico.setCellValue(historicoManutencao.getNumContraOrdem() == null ? "" : historicoManutencao.getNumContraOrdem().toString());
						styleConteudoNumContraOrdem.setAlignment(HorizontalAlignment.CENTER);
						cellConteudoHistorico.setCellStyle(styleConteudoNumContraOrdem);

						//Data de Cadastro de Sistema do Ente Externo
						cellConteudoHistorico = row.createCell(contCell++);
						cellConteudoHistorico.setCellValue(historicoManutencao.getDataCadastroSistemaExterno() == null ? "" : simpleDateFormatter.format(historicoManutencao.getDataCadastroSistemaExterno()));
						styleConteudoDataEnteExterno.setAlignment(HorizontalAlignment.CENTER);
						cellConteudoHistorico.setCellStyle(styleConteudoDataEnteExterno);

						//Data Processamento
						cellConteudoHistorico = row.createCell(contCell++);
						cellConteudoHistorico.setCellValue(historicoManutencao.getDataProcessamento() == null ? "" : simpleDateFormatter.format(historicoManutencao.getDataProcessamento()));
						styleConteudoDataProcessamento.setAlignment(HorizontalAlignment.CENTER);
						cellConteudoHistorico.setCellStyle(styleConteudoDataProcessamento);

						//Comando
						cellConteudoHistorico = row.createCell(contCell++);
						cellConteudoHistorico.setCellValue(historicoManutencao.getComando() == null ? "" : historicoManutencao.getComando());
						styleConteudoComando.setAlignment(HorizontalAlignment.CENTER);
						cellConteudoHistorico.setCellStyle(styleConteudoComando);
						
						if(perfilGestor) {
							//Motivo Interno
							cellConteudoHistorico = row.createCell(contCell++);
							cellConteudoHistorico.setCellValue(historicoManutencao.getMotivoInterno() == null ? "" : historicoManutencao.getMotivoInterno());
							styleConteudoMotivoInterno.setAlignment(HorizontalAlignment.CENTER);
							cellConteudoHistorico.setCellStyle(styleConteudoMotivoInterno);
						}
						
						//Situacao
						cellConteudoHistorico = row.createCell(contCell++);
						cellConteudoHistorico.setCellValue(historicoManutencao.getDetalheSituacao() == null ? "" : historicoManutencao.getDetalheSituacao());
						styleConteudoSituacao.setAlignment(HorizontalAlignment.CENTER);
						cellConteudoHistorico.setCellStyle(styleConteudoSituacao);

						if(historicoManutencao.getDetalheSituacao()!=null
								&& "REJEITADA".equalsIgnoreCase(historicoManutencao.getDetalheSituacao().trim())) {
							//Motivo Externo
							cellConteudoHistorico = row.createCell(contCell++);
							cellConteudoHistorico.setCellValue("");
							styleConteudoMotivoExterno.setAlignment(HorizontalAlignment.CENTER);
							cellConteudoHistorico.setCellStyle(styleConteudoMotivoExterno);
						} else {
							//Motivo Externo
							cellConteudoHistorico = row.createCell(contCell++);
							cellConteudoHistorico.setCellValue(historicoManutencao.getMotivoExterno() == null ? "" : historicoManutencao.getMotivoExterno());
							styleConteudoMotivoExterno.setAlignment(HorizontalAlignment.CENTER);
							cellConteudoHistorico.setCellStyle(styleConteudoMotivoExterno);
						}
						
						
						//Para manter o tamanho da linha quando não for perfil de gestor 
						if(!perfilGestor) {
							cellConteudoHistorico = row.createCell(contCell++);
							cellConteudoHistorico.setCellValue("");
							styleConteudoMotivoExterno.setAlignment(HorizontalAlignment.CENTER);
							cellConteudoHistorico.setCellStyle(styleConteudoMotivoExterno);
						}
						
						row.setHeight((short) 500);
						row = sheet.createRow(contRow++);
						contCell = 0;
					}
					
					CellStyle styleRodapeHistorico = workbook.createCellStyle();
					styleRodapeHistorico.setFont(fontBold);
					styleRodapeHistorico.setAlignment(HorizontalAlignment.RIGHT);
					styleRodapeHistorico.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
					styleRodapeHistorico.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					carregarbordarCelula(styleRodapeHistorico);

					Cell cellRodapeHistorico = row.createCell(contCell++);
					cellRodapeHistorico.setCellValue("Tota de linhas: ");
					cellRodapeHistorico.setCellStyle(styleRodapeHistorico);
					
					cellRodapeHistorico = row.createCell(contCell++);
					cellRodapeHistorico.setCellValue(listHistorico.size());
					cellRodapeHistorico.setCellStyle(styleRodapeHistorico);

					row = sheet.createRow(contRow++);
				}
			}
		}

		//Escrever a saida
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		workbook.write(outputStream);
		workbook.close();
		return outputStream;
	}
	
	private void adicionarLogoCaixa(XSSFWorkbook workbook, XSSFSheet sheet) throws IOException {
		InputStream is = getClass().getResourceAsStream("/image/logo-caixa.jpeg");
		byte[] bytes = IOUtils.toByteArray(is);
		int pictureIdx = workbook.addPicture(bytes, Workbook.PICTURE_TYPE_JPEG);
		is.close();

		CreationHelper helper = workbook.getCreationHelper();
		Drawing<?> drawing = sheet.createDrawingPatriarch();
		ClientAnchor anchor = helper.createClientAnchor();

		anchor.setRow1(0);
		anchor.setCol1(0);
		Picture pict = drawing.createPicture(anchor, pictureIdx);
		pict.resize();
	}
	
	private void carregarbordarCelula(CellStyle cellStyle) {
		cellStyle.setBorderTop(BorderStyle.THIN);
		cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderBottom(BorderStyle.THIN);
		cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderLeft(BorderStyle.THIN);
		cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderRight(BorderStyle.THIN);
		cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
	}
}
