package br.gov.caixa.sipbs.api.controllers;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/api/test/v1")
@Produces("application/json")
@Consumes("application/json")
@ApplicationScoped
public class TestHelloController {

    @GET
    @Path("/hello")
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
    	return "";
    }
}