package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO06_COMUNICACAO_CANAL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO06_COMUNICACAO_CANAL")
public class ComunicacaoCanal extends PanacheEntityBase {

	@Id
	@Column(name="NU_PBSO06")
	public Long nuPbso06;

	@Column(name="CO_PACOTE")
	public String coPacote;

	@Column(name="DE_CONTEUDO")
	public String deConteudo;

	@Column(name="NU_PBSO04")
	public Long nuPbso04;

}