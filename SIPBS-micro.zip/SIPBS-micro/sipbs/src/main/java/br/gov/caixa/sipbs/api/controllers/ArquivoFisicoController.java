package br.gov.caixa.sipbs.api.controllers;

import java.net.URI;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.jboss.resteasy.annotations.jaxrs.PathParam;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

import br.gov.caixa.sipbs.api.domain.exception.EntidadeNaoEncontradaException;
import br.gov.caixa.sipbs.api.domain.service.ArquivoFisicoService;
import br.gov.caixa.sipbs.api.dtos.ArquivoFisicoDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;
import br.gov.caixa.sipbs.api.retorno.RetornoPaginado;

@Path("/api/arquivoFisico/v1")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
@Transactional
@OpenAPIDefinition(info = @Info(description = "Conjunto de endpoints para manutenção dos arquivos", title = "Arquivo Físicos", version = "1.0"))
public class ArquivoFisicoController extends Controller<ArquivoFisicoDTO, ResponseEntity<?>> {

	@Inject
	ArquivoFisicoService service;

	@GET
//	@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> listAll() {
		try {
			List<ArquivoFisicoDTO> lista = service.listAll();
			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			ResponseEntity.badRequest();
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
//	@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	@Path("/pagina/{pagina}")
	public ResponseEntity<?> listPag(@PathParam int pagina) {
		try {
			List<ArquivoFisicoDTO> lista = service.listPag(pagina, qtdPorPagina);
			Long total = service.count();

			RetornoPaginado<ArquivoFisicoDTO> paginado = new RetornoPaginado<ArquivoFisicoDTO>(lista, total, pagina,
					qtdPorPagina);

			if (lista != null) {
				return ResponseEntity.ok(paginado);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
//	@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	@Path("/pagina/{pagina}/{qtdPorPagina}")
	public ResponseEntity<?> listPag(@PathParam int pagina, @PathParam int qtdPorPagina) {
		try {
			List<ArquivoFisicoDTO> lista = service.listPag(pagina, qtdPorPagina);
			Long total = service.count();

			RetornoPaginado<ArquivoFisicoDTO> paginado = new RetornoPaginado<ArquivoFisicoDTO>(lista, total, pagina,
					qtdPorPagina);

			if (lista != null) {
				return ResponseEntity.ok(paginado);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
//	@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	@Path("/{id}")
	public ResponseEntity<?> findById(@PathParam Long id) {
		try {
			ArquivoFisicoDTO dto = service.findById(id);
			if (dto != null) {
				return ResponseEntity.ok(dto);
			}
			throw new AppException(HttpStatus.NOT_FOUND, "Registro com o id " + id + " não existe.");

		} catch (EntidadeNaoEncontradaException e) {
			throw new AppException(e.getCode(), e.getMessage());
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	
	@POST
//	@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> create(ArquivoFisicoDTO request) {
		try {
//			if (request.getNuPbsd03() != 0) {
//				throw new AppException(HttpStatus.UNPROCESSABLE_ENTITY,
//						"Registro com o id definido de maneira incorreta");
//			}
			ArquivoFisicoDTO dto = service.create(request);
			return ResponseEntity.created(URI.create("/api/arquivoFisico/" + dto.getNuPbsd03())).build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@PUT
//	@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	@Path("/{id}")
	public ResponseEntity<?> update(@PathParam Long id, ArquivoFisicoDTO request) {
		try {
			if (StringUtils.isEmpty(request.getNuPbsd03())) {
				throw new AppException(HttpStatus.UNPROCESSABLE_ENTITY, "Registro com o atributo nome não informado.");
			}
			ArquivoFisicoDTO dto = service.update(id, request);
			return ResponseEntity.ok(dto);
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@DELETE
//	@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
//	@Path("/{id}")
	public ResponseEntity<?> delete(Long id) {
		try {
			service.delete(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}
}