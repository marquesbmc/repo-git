package br.gov.caixa.sipbs.api.domain.service;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TestHelloService {
		
	public String test(String nome) {
		return "Olá " + nome; 
	}
}