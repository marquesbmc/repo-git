package br.gov.caixa.sipbs.api.retorno;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.gov.caixa.sipbs.api.dtos.ArquivoDTO;

/**
 * @author SIOGP
 */
public class ArquivoRetorno extends Retorno {

  private List<ArquivoDTO> data;

  private List<String> tblcontent;

  private List<HashMap<String, String>> tbldata;

  /**
   * CONSTRUTOR PADRÃO
   */
  public ArquivoRetorno() {
    data = new ArrayList<ArquivoDTO>();
    tblcontent = new ArrayList<String>();
    tbldata = new ArrayList<HashMap<String, String>>();
  }

  public List<ArquivoDTO> getData() {
    return data;
  }

  public void setData(List<ArquivoDTO> data) {
    this.data = data;
  }

  public List<String> getTbl() {
    return tblcontent;
  }

  public void setTbl(final List<String> lista) {
    tblcontent = lista;
  }

  public List<HashMap<String, String>> getTblData() {
    return tbldata;
  }

  public void setTblData(final List<HashMap<String, String>> lista) {
    tbldata = lista;
  }
}