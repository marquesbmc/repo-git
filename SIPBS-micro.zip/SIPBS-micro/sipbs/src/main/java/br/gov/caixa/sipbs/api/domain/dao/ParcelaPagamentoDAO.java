package br.gov.caixa.sipbs.api.domain.dao;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.ConsultaParcelaPagamentoDTO;
import br.gov.caixa.sipbs.api.dtos.HistoricoManutencaoDTO;

@ApplicationScoped
public class ParcelaPagamentoDAO extends GenericDAO<ConsultaParcelaPagamentoDTO> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ParcelaPagamentoDAO.class);

	@Override
	public List<ConsultaParcelaPagamentoDTO> listAll() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ConsultaParcelaPagamentoDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ConsultaParcelaPagamentoDTO findById(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ConsultaParcelaPagamentoDTO create(ConsultaParcelaPagamentoDTO request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ConsultaParcelaPagamentoDTO update(ConsultaParcelaPagamentoDTO request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long count() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public List<ConsultaParcelaPagamentoDTO> searchParcelas(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException {

		LOGGER.info("Chamando método searchParcelas2 com os parâmetros -> " + icCpfNis + " - " + nuCpfNis + " - " + nuProdutoIcoo10);
		try {
			List<ConsultaParcelaPagamentoDTO> parcelas = new ArrayList<>();

			String sql = " SELECT vwo12.NU_COMPETENCIA_PARCELA AS anoBase, vwo12.NU_REFERENCIA AS exercicio, vwo12.NU_PARCELA AS parcela, vwo12.VR_PARCELA AS vlr_parcela, vwo13.DE_SITUACAO_PARCELA AS situacao_parcela, vwo12.DT_FIM_VALIDADE_PARCELA AS dataValidade, vwo12.DT_EFETIVACAO_PARCELA AS dataPagamento, vwo12.NU_EXTERNO_PRCLA_PGMNO AS cod_pag, vwo12.NU_CONVENIADO AS cod_conveniado, vwo12.NU_TERMINAL AS terminal, "
					+ " vwc02.DE_TIPO_CANAL AS canal, "
					+ " vwb06.NU_AGENCIA AS agencia, vwb06.NU_DV_AGENCIA AS dv_Agencia, vwb06.NU_CONTA AS conta, vwb06.NU_DV_CONTA AS dv_conta, "
					+ " vwb13.NU_PRODUTO_ICOO10 AS codigoProduto, "
					+ " vwb21.NU_PROPRIEDADE_PRODUTO AS nu_propriedade_conta, "
					+ " vwo12.NU_NSU_PAGAMENTO_CANAL AS NSU_canal, "
					+ " vwo12.NU_PBSO12 as pk_vwo12, "
					+ " vwo12.CO_SENTENCA_JUDICIAL"
					+ " FROM {h-schema}PBSVWO12_PARCELA_PAGAMENTO vwo12 "
					+ " LEFT JOIN {h-schema}PBSVWB05_BENEFICIARIO_SOCIAL vwb05 ON vwb05.NU_PBSB05 = vwo12.NU_PBSB05 "
					+ " LEFT JOIN {h-schema}PBSVWB04_BENEFICIARIO_PROGRAMA_SOCIAL vwb04 ON vwb04.NU_PBSB05 = vwb05.NU_PBSB05 "
					+ " LEFT JOIN {h-schema}PBSVWB06_CONTA_CREDITO vwb06 on vwb06.NU_PBSB06 = vwb04.NU_PBSB06 "
					+ " LEFT JOIN {h-schema}PBSVWB21_PROPRIEDADE_CONTA vwb21 on vwb21.NU_PROPRIEDADE_CONTA = vwb06.NU_PROPRIEDADE_CONTA_PBSB21 "
					+ " LEFT JOIN {h-schema}PBSVWB13_TIPO_CONTA vwb13 on vwb13.NU_TIPO_CONTA = vwb21.NU_TIPO_CONTA_PBSB13 "
					+ " LEFT JOIN {h-schema}PBSVWC02_TIPO_CANAL vwc02 ON vwc02.NU_TIPO_CANAL = vwo12.NU_TIPO_CANAL_PBSC02 "
					+ " LEFT JOIN {h-schema}PBSVWO13_SITUACAO_PARCELA vwo13 ON vwo13.NU_SITUACAO_PARCELA = vwo12.NU_SITUACAO_PARCELA_PBSO13 "
					+ " WHERE vwb04.NU_PRODUTO_PBSB02 = :nuProduto ";
			if (icCpfNis.equals("C")) {
				sql = sql + "   AND vwb05.NU_CPF_BENEFICIARIO = :nuDocumento  ";
			} else {
				sql = sql + "   AND vwb05.NU_NIS_BENEFICIARIO = :nuDocumento  ";
			}
			sql = sql + " ORDER BY vwo12.NU_COMPETENCIA_PARCELA desc, vwo12.NU_REFERENCIA desc, vwo12.NU_PARCELA ";

			Query query = emDb2.createNativeQuery(sql.toString());
			query.setParameter("nuProduto", nuProdutoIcoo10);
			query.setParameter("nuDocumento", nuCpfNis);

			@SuppressWarnings("unchecked")
			List<Object[]> resultList = query.getResultList();
			
			ConsultaParcelaPagamentoDTO consultarParcelamentoDTO;
			for ( Object[] object : resultList) {
				consultarParcelamentoDTO = new ConsultaParcelaPagamentoDTO();
				consultarParcelamentoDTO.setAnoBase(object[0]==null? null : Integer.valueOf(object[0] + ""));
				consultarParcelamentoDTO.setExercicio(object[1]==null? null : Integer.valueOf(object[1] + ""));
				consultarParcelamentoDTO.setParcelaNuParcela(object[2]==null? null : Short.valueOf(object[2] + ""));
				consultarParcelamentoDTO.setParcelaValor(object[3]==null? null : NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format((BigDecimal) object[3]));
				consultarParcelamentoDTO.setParcelaSituacao(object[4]==null? null : object[4] + "");
				consultarParcelamentoDTO.setParcelaDataValidade(object[5]==null? null : Date.valueOf(object[5] + ""));
				consultarParcelamentoDTO.setPagamentoData(object[6]==null? null : Date.valueOf(object[6] + ""));
				consultarParcelamentoDTO.setCodigoPagamento(object[7]==null? null : Long.valueOf(object[7] + ""));
				consultarParcelamentoDTO.setCodigoConveniado(object[8]==null? null : Long.valueOf(object[8] + ""));
				consultarParcelamentoDTO.setNuTerminal(object[9]==null? null : Integer.valueOf(object[9] + ""));
				consultarParcelamentoDTO.setPagamentoCanal(object[10]==null? null : object[10] + "");
				consultarParcelamentoDTO.setPagamentoAgencia(object[11]==null? null : Short.valueOf(object[11] + ""));
				consultarParcelamentoDTO.setPagamentoDvAgencia(object[12]==null? null : Short.valueOf(object[12] + ""));
				consultarParcelamentoDTO.setPagamentoConta(object[13]==null? null : Long.valueOf(object[13] + ""));
				consultarParcelamentoDTO.setPagamentoDvConta(object[14]==null? null : Short.valueOf(object[14] + ""));
				consultarParcelamentoDTO.setPagamentoProduto(object[15]==null? null : Short.valueOf(object[15] + ""));
				consultarParcelamentoDTO.setPagamentoPropriedadeProduto(object[16]==null? null : Short.valueOf(object[16] + ""));
				consultarParcelamentoDTO.setPagamentoNsuCanal(object[17]==null? null : Long.valueOf(object[17] + ""));
				consultarParcelamentoDTO.setMotivoRejeicaoSIACC(object[18]==null? null : searchMotivorejeicaoiSIACC(Long.valueOf(object[18] + "")));
				consultarParcelamentoDTO.setIdentificadorParcela(object[18]==null? null : Long.valueOf(object[18] + ""));
				consultarParcelamentoDTO.setSentencaJudicial(object[19]==null? null : String.valueOf(object[19] + ""));
				if(object[18]==null) {
					consultarParcelamentoDTO.setPossuiHistoricoManutencao(Boolean.FALSE);
				} else {
					List<HistoricoManutencaoDTO> historicoManutencaoDTOs = historiccoManutencao(Long.valueOf(object[18] + ""));
					consultarParcelamentoDTO.setPossuiHistoricoManutencao(historicoManutencaoDTOs.size() == 0? Boolean.FALSE : Boolean.TRUE);
				}
				
//				if (consultarParcelamentoDTO.getPagamentoData() != null) {
//					Calendar c = Calendar.getInstance(); 
//					c.setTime(consultarParcelamentoDTO.getPagamentoData()); 
//					c.add(Calendar.DATE, 1);
//					consultarParcelamentoDTO.setPagamentoData(c.getTime());
//				}
//				
//				if (consultarParcelamentoDTO.getParcelaDataValidade() != null) {
//					Calendar c = Calendar.getInstance(); 
//					c.setTime(consultarParcelamentoDTO.getParcelaDataValidade()); 
//					c.add(Calendar.DATE, 1);
//					consultarParcelamentoDTO.setParcelaDataValidade(c.getTime());
//				}

				parcelas.add(consultarParcelamentoDTO);
			}
			return parcelas;
		} catch (Exception eXception) {
			LOGGER.error("Erro no Chamando do método 'searchParcelas' com os parâmetros ->" + icCpfNis + " - " + nuCpfNis + " - " + nuProdutoIcoo10, eXception);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, eXception);
		}
	}
	
	public List<String> searchMotivorejeicaoiSIACC(Long identificador) throws GeneralException {

		LOGGER.info("Chamando método searchMotivorejeicaoiSIACC com o parâmetro -> " + identificador);
		try {
			List<String> descricoes = new ArrayList<>();

			String sql = " SELECT vwo26.DE_OBSERVACAO "
					+ " FROM {h-schema}PBSVWO12_PARCELA_PAGAMENTO vwo12 "
					+ " INNER JOIN {h-schema}PBSVWO13_SITUACAO_PARCELA vwo13 ON vwo13.NU_SITUACAO_PARCELA = vwo12.NU_SITUACAO_PARCELA_PBSO13 "
					+ " INNER JOIN {h-schema}PBSVWO26_TIPO_MOTIVO_PARCELA vwo26 ON vwo26.NU_SITUACAO_PARCELA_PBSO13 = vwo13.NU_SITUACAO_PARCELA "
					+ " WHERE vwo13.NU_SITUACAO_PARCELA IN (17, 18) "
					+ "   AND vwo12.NU_PBSO12 = :nuIdentificador  ";

			Query query = emDb2.createNativeQuery(sql.toString());
			query.setParameter("nuIdentificador", identificador);

			@SuppressWarnings("unchecked")
			List<Object> resultList = query.getResultList();

			for ( Object object : resultList) {
				if(object != null) {
					descricoes.add(object + "");
				}
			}

			return descricoes;
		} catch (Exception eXception) {
			LOGGER.error("Erro em " + "Chamando método recuperarRelatorioSinteticoPagamentoCanal com os parâmetros", eXception);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, eXception);
		}
	}
	
	public List<HistoricoManutencaoDTO> historiccoManutencao(Long nuPbso12) throws GeneralException {
		LOGGER.info("Chamando método historiccoManutencao com o parâmetro -> " + nuPbso12);
		try {
			Set<HistoricoManutencaoDTO> listaHistorico = new HashSet<>();

			String sql = new StringBuilder()
					.append(" SELECT vwd03.NU_REMESSA AS lote, ") 
					.append(" vwo29.DE_TIPO_MOTIVO_EXTERNO AS motivoExterno, ")
					.append(" vwo25.DE_TIPO_MOTIVO AS motivoInterno, ") 
					.append(" vwo15.DT_CADASTRO AS dataCadastroSistemaExterno, ")
					.append(" vwo15.TS_SITUACAO AS DataProcessamento, ")
					.append(" vwo15.NU_EXTERNO_CONTRA_ORDEM AS numContraOrdem, ")
					.append(" vwo16.NO_ACAO AS Comando, ")
					.append(" vwo32.DE_SITUACAO_CONTRA AS situacao ")
					.append(" FROM PBSVWO12_PARCELA_PAGAMENTO vwo12 ")
					.append(" LEFT JOIN PBSVWD03_ARQUIVO_FISICO vwd03 ON vwd03.NU_PBSD03 = vwo12.NU_PBSD03 ")
					.append(" LEFT JOIN PBSVWO15_CONTRA_ORDEM_PARCELA vwo15 ON vwo15.NU_PBSO12 = vwo12.NU_PBSO12 ")
					.append(" LEFT JOIN PBSVWO02_ITEM_HISTORICO_PARCELA vwo02 ON vwo02.NU_PBSO15 = vwo15.NU_PBSO15 ") 
					.append(" LEFT JOIN PBSVWO16_ACAO_CONTRA_ORDEM vwo16 ON vwo16.NU_ACAO = vwo15.NU_ACAO_PBSO16 ")
					.append(" LEFT JOIN PBSVWO25_TIPO_MOTIVO vwo25 ON vwo25.NU_TIPO_MOTIVO = vwo02.NU_TIPO_MOTIVO_PBSO25 ")
					.append(" LEFT JOIN PBSVWO30_MOTIVO_EXTERNO vwo30 ON vwo30.NU_TIPO_MOTIVO_PBSO25 = vwo25.NU_TIPO_MOTIVO ") 
					.append(" LEFT JOIN PBSVWO29_TIPO_MOTIVO_EXTERNO vwo29 ON vwo29.NU_TIPO_MOTIVO_EXTERNO = vwo30.NU_TIPO_MOTIVO_EXTERNO_PBSO29 ")
					.append(" LEFT JOIN PBSVWO32_SITUACAO_CONTRA_ORDEM vwo32 ON vwo32.NU_SITUACAO_CONTRA = vwo15.NU_SITUACAO_CONTRA_PBSO32 ")
					.append(" WHERE vwo12.NU_PBSO12  = :nuPBSO12 ") 
					.append(" ORDER BY vwo02.NU_PBSO02 FETCH FIRST 1 ROW ONLY ").toString();

			Query query = emDb2.createNativeQuery(sql.toString());
			query.setParameter("nuPBSO12", nuPbso12);

			@SuppressWarnings("unchecked")
			List<Object[]> resultList = query.getResultList();
			
			HistoricoManutencaoDTO consultarParcelamentoDTO;
			for ( Object[] object : resultList) {
				consultarParcelamentoDTO = new HistoricoManutencaoDTO();
				consultarParcelamentoDTO.setLoteNuRemessa(object[0]==null? null : Long.valueOf(object[0] + ""));
				consultarParcelamentoDTO.setMotivoExterno(object[1]==null? null : object[1] + "");
				consultarParcelamentoDTO.setMotivoInterno(object[2]==null? null : object[2] + "");
				consultarParcelamentoDTO.setDataCadastroSistemaExterno(object[3]==null? null : Date.valueOf(object[3] + ""));
				consultarParcelamentoDTO.setDataProcessamento(object[4]==null? null : Timestamp.valueOf(object[4] + ""));
				consultarParcelamentoDTO.setNumContraOrdem(object[5]==null? null : Long.valueOf(object[5] + ""));
				consultarParcelamentoDTO.setComando(object[6]==null? null : object[6] + "");
				consultarParcelamentoDTO.setDetalheSituacao(object[7]==null? null : object[7] + "");

				listaHistorico.add(consultarParcelamentoDTO);
			}
			return new ArrayList<HistoricoManutencaoDTO>(listaHistorico);
		} catch (Exception eXception) {
			LOGGER.error("Erro no Chamando do método 'historiccoManutencao' com o parâmetro ->" + nuPbso12, eXception);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, eXception);
		}
	}
}
