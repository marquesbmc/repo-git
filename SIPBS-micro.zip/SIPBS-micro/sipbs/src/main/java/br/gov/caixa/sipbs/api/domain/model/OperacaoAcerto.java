package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntity;


/**
 * The persistent class for the PBSVWO05_OPERACAO_ACERTO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO05_OPERACAO_ACERTO")
public class OperacaoAcerto extends PanacheEntity {

	@Temporal(TemporalType.DATE)
	@Column(name="DT_LIMITE_TRATAMENTO")
	public Date dtLimiteTratamento;

	@Column(name="IC_SITUACAO")
	public String icSituacao;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PBSO03")
	public Short nuPbso03;

	@Column(name="NU_PBSO04")
	public Long nuPbso04;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INCLUSAO")
	public Timestamp tsInclusao;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;

	@Column(name="TS_RESOLUCAO")
	public Timestamp tsResolucao;
}