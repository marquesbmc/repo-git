package br.gov.caixa.sipbs.api.controllers;

import javax.ws.rs.core.Application;

import org.springframework.beans.factory.annotation.Value;

/**
 * 
 * @author Spread
 *
 * @param <E> Entidade de resuisição
 * @param <R> Response
 */
public abstract class Controller<E, R> extends Application {

	@Value("${paginacao.qtd_por_pagina}")
	int qtdPorPagina;
	
	public abstract R listAll();
	
	public abstract R listPag(int pagina);
	
	public abstract R listPag(int pagina, int qtdPorPagina);
	
	public abstract R findById(Long id);

	public abstract R create(E request);

	public abstract R update(Long id, E request);

	public abstract R delete(Long id);

}
