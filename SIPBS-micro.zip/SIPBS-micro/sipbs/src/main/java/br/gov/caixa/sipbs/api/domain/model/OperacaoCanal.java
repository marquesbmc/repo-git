package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWC03_OPERACAO_CANAL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWC03_OPERACAO_CANAL")
public class OperacaoCanal extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSC03")
	public Long nuPbsc03;

	@Column(name="CO_ESTACAO")
	public String coEstacao;

	@Column(name="CO_OPERADOR")
	public String coOperador;

	@Column(name="CO_REDE_RECEPTORA")
	public String coRedeReceptora;

	@Column(name="CO_SYSID")
	public String coSysid;

	@Column(name="CO_TERMINAL")
	public String coTerminal;

	@Column(name="CO_TIPO_CARTAO_CID010")
	public String coTipoCartaoCid010;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_MOVIMENTO")
	public Date dtMovimento;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_LOCALIDADE_ICOL08")
	public Integer nuLocalidadeIcol08;

	@Column(name="NU_NATURAL_ICOU24")
	public Integer nuNaturalIcou24;

	@Column(name="NU_NSU_CANAL")
	public Long nuNsuCanal;

	@Column(name="NU_NSU_MULTICANAL")
	public Long nuNsuMulticanal;

	@Column(name="NU_REDE_TRANSMISSORA_ANTERIOR")
	public Short nuRedeTransmissoraAnterior;

	@Column(name="NU_SEGMENTO_ICOS12")
	public Short nuSegmentoIcos12;

	@Column(name="NU_TERMINAL")
	public Integer nuTerminal;

	@Column(name="NU_TIPO_AUTENTICACAO_PBSC01")
	public Short nuTipoAutenticacaoPbsc01;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}