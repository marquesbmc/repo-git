package br.gov.caixa.sipbs.api.dtos;

import java.sql.Timestamp;
import java.util.Date;

import lombok.EqualsAndHashCode;

@lombok.Getter
@lombok.Setter
@EqualsAndHashCode
@lombok.NoArgsConstructor
public class HistoricoManutencaoDTO {

	public Long loteNuRemessa;
	public String motivoExterno;
	public String motivoInterno;
	public Date dataCadastroSistemaExterno;
	public Timestamp dataProcessamento;
	public Long numContraOrdem;
	public String comando;
	public String detalheSituacao;
}
