package br.gov.caixa.sipbs.api.dtos;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Entidade que representa o filtro de pesquisa do relatório sintético de evolução da folha por situação.
 * @author Spread
 *
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class FiltroRelatorioDTO implements Serializable{
	private static final long serialVersionUID = -8844224122386863546L;

	private Short nuProdutoIcoo10;
	private String dtInicioPeriodoString;
	private String dtFimPeriodoString;
	private Long[] lotes;
}