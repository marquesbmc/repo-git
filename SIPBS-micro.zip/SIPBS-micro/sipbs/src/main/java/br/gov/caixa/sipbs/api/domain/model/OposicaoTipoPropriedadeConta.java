package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB18_OPOSICAO_TIPO_PROPRIEDADE_CONTA database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB18_OPOSICAO_TIPO_PROPRIEDADE_CONTA")
public class OposicaoTipoPropriedadeConta extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_OPOSICAO_TIPO_PRPRE_CONTA")
	public Integer nuOposicaoTipoPrpreConta;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;


	@Column(name="NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name="NU_TIPO_PRPRE_CONTA_PBSB15")
	public Short nuTipoPrpreContaPbsb15;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}