package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVW999_MENSAGEM_DB2 database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVW999_MENSAGEM_DB2")
public class MensagemDb2 extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBS999")
	public Integer nuPbs999;

	@Column(name="DE_DB2_MESSAGE_TEXT")
	public String deDb2MessageText;

	@Column(name="NO_CHAMADOR")
	public String noChamador;

	@Column(name="NO_STORED_PROCEDURE")
	public String noStoredProcedure;

	@Column(name="NU_DB2_LINE_NUMBER")
	public Integer nuDb2LineNumber;

	@Column(name="NU_DB2_REASON_CODE")
	public Integer nuDb2ReasonCode;

	@Column(name="NU_DB2_SQLCODE")
	public Integer nuDb2Sqlcode;

	@Column(name="NU_DB2_SQLSTATE")
	public String nuDb2Sqlstate;

	@Column(name="TS_MENSAGEM")
	public Timestamp tsMensagem;
}