package br.gov.caixa.sipbs.api.domain.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Entidade que representa o relatório sintético das parcelas por situação.
 * @author Spread
 *
 */
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(of = {"id"})
@Entity
public class PagamentoParcelaSituacao implements Serializable{

	private static final long serialVersionUID = -4342464963629177948L;

	@Id
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "NOME_PRODUTO")
	private String produto;
	
	@Column(name = "DE_SITUACAO_PARCELA")
	private String situacao;

	@Column(name = "QTD_PARCELAS")
	private Long qtdParcelas;

	@Column(name = "VALOR_PARCELAS")
	private BigDecimal valorParcelas;
	
}