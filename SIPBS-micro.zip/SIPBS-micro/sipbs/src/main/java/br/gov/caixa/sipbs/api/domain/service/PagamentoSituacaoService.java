package br.gov.caixa.sipbs.api.domain.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoParcelaSituacaoDTO;

public interface PagamentoSituacaoService {

	List<Long> consultarLotes(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo)
			throws GeneralException;

	RelatorioSinteticoParcelaSituacaoDTO recuperarRelatorioSinteticoPagamentoSituacao(Short nuProdutoIcoo10,
			LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo, Long[] lotes) throws GeneralException;

	ByteArrayOutputStream exportarRelatorioSinteticoPagamento(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo,
			LocalDate dtFimPeriodo, Long[] lotes) throws GeneralException, IOException;

	byte[] exportarRelatorioSinteticoPagamentoCSV(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo,
			LocalDate dtFimPeriodo, Long[] lotes) throws GeneralException;

}