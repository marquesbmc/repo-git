package br.gov.caixa.sipbs.api.domain.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO02_PARCELA_HISTORICO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO02_PARCELA_HISTORICO")
public class ParcelaHistorico extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSO02")
	public Integer nuPbso02;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_FIM_VALIDADE_PARCELA")
	public Date dtFimValidadeParcela;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_INICIO_VALIDADE_PARCELA")
	public Date dtInicioValidadeParcela;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_LOCALIDADE_ICOL08")
	public Integer nuLocalidadeIcol08;

	@Column(name="NU_PBSB05")
	public Integer nuPbsb05;

	@Column(name="NU_PBSB10")
	public Integer nuPbsb10;

	@Column(name="NU_PBSD03")
	public Long nuPbsd03;

	@Column(name="NU_PBSO12")
	public Long nuPbso12;

	@Column(name="NU_REFERENCIA")
	public Integer nuReferencia;

	@Column(name="NU_SITUACAO_PARCELA_PBSO13")
	public Short nuSituacaoParcelaPbso13;

	@Column(name="NU_TIPO_ACAO_PBSO01")
	public Short nuTipoAcaoPbso01;

	@Column(name="TS_ALTERACAO")
	public Timestamp tsAlteracao;

	@Column(name="TS_INCLUSAO")
	public Timestamp tsInclusao;

	@Column(name="VR_PARCELA")
	public BigDecimal vrParcela;

}