package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB23_CONTA_MARCADA_MARCACAO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
public class MarcasImpeditivas extends PanacheEntityBase {

	@Id
	@Column(name="ID")
	public Long id;
	
	@Column(name="MARCA")
	public String marca;

	@Column(name="DESCRICAO")
	public String descricao;

}