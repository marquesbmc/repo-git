package br.gov.caixa.sipbs.api.dtos;

import java.util.Date;

public class ArquivoFisicoDTO {

	private String coSeguranca;
	private String deErroGeracaoArquivo;
	private String icArquivo;
	private String noArquivo;
	private long nuArquivoSistemaPbsd04;
	private int nuCompetencia;
	private long nuEventoInclusaoPbsa12;
	private long nuEventoPbsa12;
	private long nuPbsd03;
	private short nuProdutoPbsb02;
	private int nuRemessa;
	private short nuSituacaoArquivoPbsd06;
	private int qtAcatado;
	private int qtRejeitado;
	private int qtTotalRegistros;
	private Date tsFimProcessamento;
	private Date tsInicioProcessamento;

	public String getCoSeguranca() {
		return coSeguranca;
	}

	public void setCoSeguranca(String coSeguranca) {
		this.coSeguranca = coSeguranca;
	}

	public String getDeErroGeracaoArquivo() {
		return deErroGeracaoArquivo;
	}

	public void setDeErroGeracaoArquivo(String deErroGeracaoArquivo) {
		this.deErroGeracaoArquivo = deErroGeracaoArquivo;
	}

	public String getIcArquivo() {
		return icArquivo;
	}

	public void setIcArquivo(String icArquivo) {
		this.icArquivo = icArquivo;
	}

	public String getNoArquivo() {
		return noArquivo;
	}

	public void setNoArquivo(String noArquivo) {
		this.noArquivo = noArquivo;
	}

	public long getNuArquivoSistemaPbsd04() {
		return nuArquivoSistemaPbsd04;
	}

	public void setNuArquivoSistemaPbsd04(long nuArquivoSistemaPbsd04) {
		this.nuArquivoSistemaPbsd04 = nuArquivoSistemaPbsd04;
	}

	public int getNuCompetencia() {
		return nuCompetencia;
	}

	public void setNuCompetencia(int nuCompetencia) {
		this.nuCompetencia = nuCompetencia;
	}

	public long getNuEventoInclusaoPbsa12() {
		return nuEventoInclusaoPbsa12;
	}

	public void setNuEventoInclusaoPbsa12(long nuEventoInclusaoPbsa12) {
		this.nuEventoInclusaoPbsa12 = nuEventoInclusaoPbsa12;
	}

	public long getNuEventoPbsa12() {
		return nuEventoPbsa12;
	}

	public void setNuEventoPbsa12(long nuEventoPbsa12) {
		this.nuEventoPbsa12 = nuEventoPbsa12;
	}

	public long getNuPbsd03() {
		return nuPbsd03;
	}

	public void setNuPbsd03(long nuPbsd03) {
		this.nuPbsd03 = nuPbsd03;
	}

	public short getNuProdutoPbsb02() {
		return nuProdutoPbsb02;
	}

	public void setNuProdutoPbsb02(short nuProdutoPbsb02) {
		this.nuProdutoPbsb02 = nuProdutoPbsb02;
	}

	public int getNuRemessa() {
		return nuRemessa;
	}

	public void setNuRemessa(int nuRemessa) {
		this.nuRemessa = nuRemessa;
	}

	public short getNuSituacaoArquivoPbsd06() {
		return nuSituacaoArquivoPbsd06;
	}

	public void setNuSituacaoArquivoPbsd06(short nuSituacaoArquivoPbsd06) {
		this.nuSituacaoArquivoPbsd06 = nuSituacaoArquivoPbsd06;
	}

	public int getQtAcatado() {
		return qtAcatado;
	}

	public void setQtAcatado(int qtAcatado) {
		this.qtAcatado = qtAcatado;
	}

	public int getQtRejeitado() {
		return qtRejeitado;
	}

	public void setQtRejeitado(int qtRejeitado) {
		this.qtRejeitado = qtRejeitado;
	}

	public int getQtTotalRegistros() {
		return qtTotalRegistros;
	}

	public void setQtTotalRegistros(int qtTotalRegistros) {
		this.qtTotalRegistros = qtTotalRegistros;
	}

	public Date getTsFimProcessamento() {
		return tsFimProcessamento;
	}

	public void setTsFimProcessamento(Date tsFimProcessamento) {
		this.tsFimProcessamento = tsFimProcessamento;
	}

	public Date getTsInicioProcessamento() {
		return tsInicioProcessamento;
	}

	public void setTsInicioProcessamento(Date tsInicioProcessamento) {
		this.tsInicioProcessamento = tsInicioProcessamento;
	}
}