package br.gov.caixa.sipbs.api.dtos;

import java.sql.Timestamp;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor

public class TipoContaDTO {

	public short nuTipoConta;
	public String deTipoConta;
	public short nuProdutoIcoo10;
	public short nuPropriedadeTipoConta;
	public short nuSegmentoIcos12;
	public Timestamp tsFimVigencia;
	public Timestamp tsIdVigencia;
	public Timestamp tsInicioVigencia;
	public long nuEventoPbsa12;
}
