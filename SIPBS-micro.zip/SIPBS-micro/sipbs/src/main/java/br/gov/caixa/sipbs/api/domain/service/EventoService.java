package br.gov.caixa.sipbs.api.domain.service;

import java.util.List;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.EventoDTO;


public interface EventoService {
	
	public List<EventoDTO> findAllRepository();

	public List<EventoDTO> findAllNative();
	
	public List<EventoDTO> findAllPanache();
	
	public List<EventoDTO> listAll() throws GeneralException;
	
	public List<EventoDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException;

	public EventoDTO findById(Long id);

	public EventoDTO create(EventoDTO request);

	public EventoDTO update(Long id, EventoDTO request);

	public void delete(Long id);

	public Long count();
}