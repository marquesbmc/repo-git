package br.gov.caixa.sipbs.api.domain.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the PBSVWC02_TIPO_CANAL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWC02_TIPO_CANAL")
public class TipoCanal extends PanacheEntityBase {

	@Id
	@Column(name="NU_TIPO_CANAL")
	private Short nuTipoCanal;

	@Column(name="DE_TIPO_CANAL")
	private String deTipoCanal;

	@Column(name="CO_TIPO_CANAL")
	private String coTipoCanal;

	@Column(name="SG_SISTEMA_PAGAMENTO")
	private String sgSitemaPagamento;
}
