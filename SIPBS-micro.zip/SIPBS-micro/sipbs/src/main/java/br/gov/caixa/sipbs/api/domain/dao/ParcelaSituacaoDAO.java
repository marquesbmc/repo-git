package br.gov.caixa.sipbs.api.domain.dao;

import java.time.LocalDate;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.PagamentoParcelaSituacao;

@ApplicationScoped
public class ParcelaSituacaoDAO extends GenericDAO<PagamentoParcelaSituacao> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ParcelaSituacaoDAO.class);

	private static final String QRY_LOTES = new StringBuilder(" SELECT ")
			.append( "        DISTINCT AF.NU_REMESSA ")
			.append( "        FROM  {h-schema}PBSVWF04_FOLHA_PROGRAMA_SOCIAL FPS   ")
			.append( "        INNER JOIN {h-schema}PBSVWB03_BENEFICIO_SOCIAL BS  ON FPS.NU_PRODUTO_PBSB02 = BS.NU_PRODUTO_PBSB02    ")
			.append( "        LEFT JOIN {h-schema}PBSVWB02_PROGRAMA_SOCIAL PS ON BS.NU_BENEFICIO_SOCIAL = PS.NU_PRODUTO_ICOO10    ")
			.append( "        LEFT JOIN {h-schema}PBSVWF02_ESCALONAMENTO E ON PS.NU_PRODUTO_ICOO10 = E.NU_PRODUTO_PBSB02    ")
			.append( "        INNER JOIN {h-schema}PBSVWO12_PARCELA_PAGAMENTO PP ON FPS.NU_PBSF04 = PP.NU_PBSF04 ")
			.append( "        INNER JOIN {h-schema}PBSVWO13_SITUACAO_PARCELA SP ON PP.NU_SITUACAO_PARCELA_PBSO13 = SP.NU_SITUACAO_PARCELA    ")
			.append( "        INNER JOIN {h-schema}PBSVWF01_FOLHA_ARQUIVO FA ON FA.NU_PBSF04 = FPS.NU_PBSF04 ")
			.append( "        INNER JOIN {h-schema}PBSVWD03_ARQUIVO_FISICO AF ON AF.NU_PBSD03 = FA.NU_PBSD03 ")
			.append( "        WHERE  ")
			.append( "        PP.DT_EFETIVACAO_PARCELA between :dtIni and :dtFim ")
			.append( "        AND PP.NU_PRODUTO_PBSB02 = :idProduto").toString();
	
	
	private static final String QRY_REL_SINTETICO =  new StringBuilder(" SELECT ROW_NUMBER() OVER() ID, BS.DE_RESUMIDA AS NOME_PRODUTO, ")
			.append("        SP.DE_SITUACAO_PARCELA, ")
			.append("        COUNT(PP.NU_PBSO12) QTD_PARCELAS, ")
			.append("        SUM(VR_PARCELA) VALOR_PARCELAS ") 
			.append("        FROM  {h-schema}PBSVWF04_FOLHA_PROGRAMA_SOCIAL FPS  ")
			.append("        INNER JOIN {h-schema}PBSVWB03_BENEFICIO_SOCIAL BS  ON FPS.NU_PRODUTO_PBSB02 = BS.NU_PRODUTO_PBSB02   ")
			.append("        LEFT JOIN {h-schema}PBSVWB02_PROGRAMA_SOCIAL PS ON BS.NU_BENEFICIO_SOCIAL = PS.NU_PRODUTO_ICOO10   ")
			.append("        LEFT JOIN {h-schema}PBSVWF02_ESCALONAMENTO E ON PS.NU_PRODUTO_ICOO10 = E.NU_PRODUTO_PBSB02   ")
			.append("        INNER JOIN {h-schema}PBSVWO12_PARCELA_PAGAMENTO PP ON FPS.NU_PBSF04 = PP.NU_PBSF04")
			.append("        INNER JOIN {h-schema}PBSVWO13_SITUACAO_PARCELA SP ON PP.NU_SITUACAO_PARCELA_PBSO13 = SP.NU_SITUACAO_PARCELA   ")
			.append("        INNER JOIN {h-schema}PBSVWF01_FOLHA_ARQUIVO FA ON FA.NU_PBSF04 = FPS.NU_PBSF04 ")
			.append("        INNER JOIN {h-schema}PBSVWD03_ARQUIVO_FISICO AF ON AF.NU_PBSD03 = FA.NU_PBSD03 ")
			.append("        WHERE ")
			.append("        PP.DT_EFETIVACAO_PARCELA between :dtIni and :dtFim ")
			.append("        AND PP.NU_PRODUTO_PBSB02 = :idProduto ")
			.append("        AND AF.NU_REMESSA IN (:lotes) ")
			.append(" GROUP BY SP.DE_SITUACAO_PARCELA, BS.DE_RESUMIDA ").toString();
	
		
	public List<Long> listarLotes(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException {
		LOGGER.info("Chamando método listarLotes com os parâmetros -> " + nuProdutoIcoo10 + " - " + dtInicioPeriodo + " - " + dtFimPeriodo);
		try {
			Query query = emDb2.createNativeQuery(QRY_LOTES);
			query.setParameter("idProduto", nuProdutoIcoo10);
			query.setParameter("dtIni", dtInicioPeriodo);
			query.setParameter("dtFim", dtFimPeriodo);
			return query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Erro no método listarLotes com os parâmetros -> " + nuProdutoIcoo10 + " - " + dtInicioPeriodo + " - " + dtFimPeriodo, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}
	
	public List<PagamentoParcelaSituacao> consultarParcelasPorSituacao(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo, List<Long> lotes ) throws GeneralException {
		LOGGER.info("Chamando método consultarParcelasPorSituacao com os parâmetros -> " + nuProdutoIcoo10 + " - " + dtInicioPeriodo + " - " + dtFimPeriodo);
		try {
			Query query = emDb2.createNativeQuery(QRY_REL_SINTETICO, PagamentoParcelaSituacao.class);
			query.setParameter("idProduto", nuProdutoIcoo10);
			query.setParameter("dtIni", dtInicioPeriodo);
			query.setParameter("dtFim", dtFimPeriodo);
			query.setParameter("lotes", lotes);
			return query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Erro no método consultarParcelasPorSituacao com os parâmetros -> " + nuProdutoIcoo10 + " - " + dtInicioPeriodo + " - " + dtFimPeriodo, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public List<PagamentoParcelaSituacao> listAll() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PagamentoParcelaSituacao> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PagamentoParcelaSituacao findById(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PagamentoParcelaSituacao create(PagamentoParcelaSituacao request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PagamentoParcelaSituacao update(PagamentoParcelaSituacao request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Long count() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}
}
