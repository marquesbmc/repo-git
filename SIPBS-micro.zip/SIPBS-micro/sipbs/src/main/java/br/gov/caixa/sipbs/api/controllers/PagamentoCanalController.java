package br.gov.caixa.sipbs.api.controllers;

import br.gov.caixa.sipbs.api.domain.service.PagamentoCanalService;
import br.gov.caixa.sipbs.api.dtos.PagamentoCanalDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoPagamentoCanalDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Counted;
import org.eclipse.microprofile.metrics.annotation.Timed;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

@Path("/api/pagamento-canal/v2")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
@Transactional
@OpenAPIDefinition(info = @Info(description = "Conjunto de endpoints para consultas relacionadas à contas Beneficiário", title = "Contas Beneficiário", version = "1.0"))
public class PagamentoCanalController extends Controller<PagamentoCanalDTO, ResponseEntity<?>>{

	@Autowired
	PagamentoCanalService pagamentoCanalService;

	@GET
	@Path("/relatorio/sintetico-pagamento/{nuProdutoIcoo10}/{dtInicioPeriodoString}/{dtFimPeriodoString}")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<RelatorioSinteticoPagamentoCanalDTO> recuperarRelatorioSinteticoPagamentoCanal(@PathParam("nuProdutoIcoo10") Short nuProdutoIcoo10,
	                                                                                                     @PathParam("dtInicioPeriodoString") String dtInicioPeriodoString,
	                                                                                                     @PathParam("dtFimPeriodoString") String dtFimPeriodoString) {
		try {
			LocalDate dtInicioPeriodo = LocalDate.parse(dtInicioPeriodoString, DateTimeFormatter.ISO_DATE);
			LocalDate dtFimPeriodo = LocalDate.parse(dtFimPeriodoString, DateTimeFormatter.ISO_DATE);

			RelatorioSinteticoPagamentoCanalDTO relatorioSinteticoPagamentoCanal = pagamentoCanalService.recuperarRelatorioSinteticoPagamentoCanal(nuProdutoIcoo10, dtInicioPeriodo, dtFimPeriodo);
			if (relatorioSinteticoPagamentoCanal != null) {
				return ResponseEntity.ok(relatorioSinteticoPagamentoCanal);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			e.printStackTrace();
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/relatorio/sintetico-pagamento/exportar/{nuProdutoIcoo10}/{dtInicioPeriodoString}/{dtFimPeriodoString}")
	@Produces("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<byte[]> exportarRelatorioSinteticoPagamento(@PathParam("nuProdutoIcoo10") Short nuProdutoIcoo10,
	                                                                  @PathParam("dtInicioPeriodoString") String dtInicioPeriodoString,
	                                                                  @PathParam("dtFimPeriodoString") String dtFimPeriodoString) {
		try {
			LocalDate dtInicioPeriodo = LocalDate.parse(dtInicioPeriodoString, DateTimeFormatter.ISO_DATE);
			LocalDate dtFimPeriodo = LocalDate.parse(dtFimPeriodoString, DateTimeFormatter.ISO_DATE);

			ByteArrayOutputStream arquivoxlsx = pagamentoCanalService.exportarRelatorioSinteticoPagamento(nuProdutoIcoo10, dtInicioPeriodo, dtFimPeriodo);
			if (arquivoxlsx != null) {
				return ResponseEntity.ok().header("Content-Disposition", String.format("attachment; filename=\"%s\"", "Relatório Sintético - Parcelas Pagas por Canal.xlsx")).body(arquivoxlsx.toByteArray());
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			e.printStackTrace();
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/list")
	@Timeout(3000)
	@Fallback(fallbackMethod = "listFallback")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<List<PagamentoCanalDTO>> list() {
		return null;
	}

	@GET
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.pagamento-canal.listAll",
			displayName = "Tempo da listagem completa",
			description = "Tempo da listagem em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem", description = "Quantidade de listagem realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> listAll() {
		return null;
	}

	@GET
	@Path("/pagina/{pagina}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.pagamento-canal.listPag",
			displayName = "Tempo da listagem paginada",
			description = "Tempo da listagem paginada em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem Paginada", description = "Quantidade de listagens paginadas realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?>listPag(@PathParam("pagina") int pagina) {
		return null;
	}

	public ResponseEntity<List<PagamentoCanalDTO>> listFallback() {
		try {
			List<PagamentoCanalDTO> lista = pagamentoCanalService.listPag(1, qtdPorPagina);

			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/pagina/{pagina}/{qtdPorPagina}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.pagamento-canal.listPag",
			displayName = "Tempo da listagem paginada",
			description = "Tempo da listagem paginada em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de listagem Paginada", description = "Quantidade de listagens paginadas realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> listPag(@PathParam("pagina") int pagina, @PathParam("qtdPorPagina") int qtdPorPagina) {
		return null;
	}

	@GET
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.pagamento-canal.findById",
			displayName = "Tempo da consulta por ID",
			description = "Tempo da consulta por ID em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de consultas por ID", description = "Quantidade de consultas por ID realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> findById(@PathParam("id") Long id) {
		return null;
	}

	@POST
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.pagamento-canal.create",
			displayName = "Tempo do cadastro",
			description = "Tempo do cadastro em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de cadastros", description = "Quantidade de cadastros realizados")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> create(PagamentoCanalDTO request) {
		return null;
	}

	@PUT
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.pagamento-canal.update",
			displayName = "Tempo da atualizacao",
			description = "Tempo da atualizacao em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de atualizacoes", description = "Quantidade de atualizacoes realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> update(@PathParam("id") Long id, PagamentoCanalDTO request) {
		return null;
	}

	@DELETE
	@Path("/{id}")
	@Timeout(3000)
	@Retry(maxRetries = 3)
	@Timed(absolute = true,
			name = "api.pagamento-canal.delete",
			displayName = "Tempo da exclusao",
			description = "Tempo da exclusao em Milissegundos",
			unit = MetricUnits.MILLISECONDS)
	@Counted(name = "Quantidade de exclusoes", description = "Quantidade de exclusoes realizadas")
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<?> delete(@PathParam("id") Long id) {
		return null;
	}
}
