package br.gov.caixa.sipbs.api.domain.repository.panache;

import br.gov.caixa.sipbs.api.domain.dao.GenericDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.MarcacaoDesmarcacaoConta;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class MarcacaoDesmarcacaoContaPanacheRepository extends GenericDAO<MarcacaoDesmarcacaoConta> {

	private static final Logger LOGGER = LoggerFactory.getLogger(MarcacaoDesmarcacaoContaPanacheRepository.class);

	public List<MarcacaoDesmarcacaoConta> listFilter(Short nuProdutoIcoo10, Integer nuPbsb06, Integer nuPbsb05) throws GeneralException {

		LOGGER.info("Chamando método listFilter com os parâmetros" + nuProdutoIcoo10 + " - " + nuPbsb06 + " - " + nuPbsb05);
		try {
			String sql = "SELECT marcacaoDesmarcacaoConta " +
					"       FROM MarcacaoDesmarcacaoConta  marcacaoDesmarcacaoConta " +
					"       WHERE marcacaoDesmarcacaoConta.programaSocial.nuProdutoIcoo10 = ?1" +
					"       AND marcacaoDesmarcacaoConta.contaCredito.nuPbsb06 = ?2" +
					"       AND marcacaoDesmarcacaoConta.beneficiarioSocial.nuPbsb05 = ?3" +
					"       ORDER BY marcacaoDesmarcacaoConta.nuReferencia DESC";

			return MarcacaoDesmarcacaoConta.list(sql, nuProdutoIcoo10, nuPbsb06, nuPbsb05);

		} catch (Exception e) {
			LOGGER.error("Erro em " + "Chamando método listFilter com os parâmetros", e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public List<MarcacaoDesmarcacaoConta> listAll() throws GeneralException {
		return null;
	}

	@Override
	public List<MarcacaoDesmarcacaoConta> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return null;
	}

	@Override
	public MarcacaoDesmarcacaoConta findById(Long id) throws GeneralException {
		return null;
	}

	@Override
	public MarcacaoDesmarcacaoConta create(MarcacaoDesmarcacaoConta request) throws GeneralException {
		return null;
	}

	@Override
	public MarcacaoDesmarcacaoConta update(MarcacaoDesmarcacaoConta request) throws GeneralException {
		return null;
	}

	@Override
	public void delete(Long id) throws GeneralException {

	}

	@Override
	public Long count() throws GeneralException {
		return null;
	}
}
