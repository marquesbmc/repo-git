package br.gov.caixa.sipbs.api.domain.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWR01_PAGAMENTO_CANAL")
public class PagamentoCanal extends PanacheEntityBase {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="pagamento_sequence")
	@SequenceGenerator(name="pagamento_sequence", sequenceName="PBSSQR01")
	@Column(name = "NU_PBSR01")
	private Integer nuPbsr01;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_PRODUTO_ICOO10", referencedColumnName = "NU_PRODUTO_ICOO10")
	private ProgramaSocial programaSocial;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_TIPO_CANAL_PBSC02", referencedColumnName = "NU_TIPO_CANAL")
	private TipoCanal tipoCanal;

	@Temporal(TemporalType.DATE)
	@Column(name = "DT_PAGAMENTO")
	private Date dtPagamento;

	@Column(name = "QT_TOTAL_PAGAMENTOS")
	private Long qtTotalPagamentos;

	@Column(name = "VR_TOTAL_PAGAMENTOS")
	private BigDecimal vrTotalPagamentos;

	@Column(name="TS_INCLUSAO_PAGAMENTO")
	private Timestamp tsInicioVigencia;
}
