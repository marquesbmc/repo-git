package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB19_CONTA_PROGRAMA_SOCIAL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB19_CONTA_PROGRAMA_SOCIAL")
public class ContaProgramaSocial extends PanacheEntityBase {

	@Id
	@Column(name="NU_CONTA_PROGRAMA_SOCIAL")
	public Integer nuContaProgramaSocial;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PRIORIDADE_TIPO_CONTA")
	public Short nuPrioridadeTipoConta;

	@Column(name="NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name="NU_PROPRIEDADE_CONTA_PBSB21")
	public Short nuPropriedadeContaPbsb21;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
	
}