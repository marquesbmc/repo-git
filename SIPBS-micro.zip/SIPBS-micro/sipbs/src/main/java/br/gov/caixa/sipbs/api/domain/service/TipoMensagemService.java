package br.gov.caixa.sipbs.api.domain.service;

import java.util.List;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.TipoMensagemDTO;


public interface TipoMensagemService {

	public List<TipoMensagemDTO> findAllRepository();

	public List<TipoMensagemDTO> findAllPanache();

	public List<TipoMensagemDTO> listAll() throws GeneralException;

	public List<TipoMensagemDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException;

	public TipoMensagemDTO findById(Long id) throws GeneralException;

	public TipoMensagemDTO create(TipoMensagemDTO request) throws GeneralException;

	public TipoMensagemDTO update(Long id, TipoMensagemDTO request) throws GeneralException;

	public void delete(Long id) throws GeneralException;
	
	public Long count() throws GeneralException;

}