package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntity;


/**
 * The persistent class for the PBSVWD02_ARQUIVO_LOGICO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWD02_ARQUIVO_LOGICO")
public class ArquivoLogico extends PanacheEntity {
	
	@Column(name="CO_ETAPA_PBSD01")
	public String coEtapaPbsd01;

	@Column(name="CO_LEIAUTE")
	public String coLeiaute;

	@Column(name="DE_ARQUIVO")
	public String deArquivo;

	@Column(name="IC_COMPETENCIA_ARQUIVO")
	public String icCompetenciaArquivo;

	@Column(name="IC_SEGURANCA")
	public String icSeguranca;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}