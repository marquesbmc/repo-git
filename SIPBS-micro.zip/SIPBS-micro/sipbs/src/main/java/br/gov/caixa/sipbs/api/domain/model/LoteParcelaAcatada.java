package br.gov.caixa.sipbs.api.domain.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWR04_LOTE_PARCELA_ACATADA")
public class LoteParcelaAcatada extends PanacheEntityBase {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="lote_parcela_acatada_sequence")
	@SequenceGenerator(name="lote_parcela_acatada_sequence", sequenceName="PBSSQR04")
	@Column(name = "NU_PBSR04")
	private Long nuPbsr04;
	
	@Column(name = "NU_PBSR02")
	private Long nuPbsr02;
	
	@Column(name="NO_ARQUIVO")
	private String nomeArquivoFisico;

	@Column(name="NU_PRODUTO_ICOO10")
	private Integer nuProgramaSocial;

	@Column(name = "NU_REFERENCIA")
	private Integer nuReferencia;

	@Column(name = "NU_REMESSA")
	private Integer nuRemessa;

	@Column(name = "DT_PROCESSAMENTO")
	private Date dtProcessamento;

	@Column(name = "NU_COMPETENCIA")
	private Integer nuCompetencia;

	@Column(name = "QT_PARCELAS_ACATADAS")
	private Long qtParcelasAcatadas;

	@Column(name="VR_TOTAL_PARCELAS_ACATADAS")
	private BigDecimal vrTotalParcelasAcatadas;

}
