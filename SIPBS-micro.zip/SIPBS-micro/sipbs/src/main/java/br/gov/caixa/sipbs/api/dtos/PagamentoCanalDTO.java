package br.gov.caixa.sipbs.api.dtos;

import java.math.BigDecimal;
import java.util.Date;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class PagamentoCanalDTO {

	private Integer nuPbsr01;
	private ProgramaSocialDTO programaSocial;
	private TipoCanalDTO tipoCanal;
	private Date dtPagamento;
	private Long qtTotalPagamentos;
	private BigDecimal vrTotalPagamentos;
}
