package br.gov.caixa.sipbs.api.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name = "PBSVWB12_TIPO_MENSAGEM")
@NamedQuery(name = "TipoMensagens.findAll", query = "from TipoMensagem")
public class TipoMensagem extends PanacheEntityBase {
	
	@Id
	@Column(name = "NU_TIPO_MENSAGEM")
	public Long id;

	@Column(name = "NO_TIPO_MENSAGEM")
	public String nome;

	@JsonFormat(pattern = "dd/MM/yyyy")
	@Column(name = "TS_INICIO_VIGENCIA")
	public Date inicioVigencia;

	@JsonFormat(pattern = "dd/MM/yyyy")
	@Column(name = "TS_FIM_VIGENCIA")
	public Date fimVigencia;

	@JsonFormat(pattern = "dd/MM/yyyy")
	@Column(name = "TS_ID_VIGENCIA")
	public Date idVigencia;

	@Column(name = "NU_EVENTO_PBSA12")
	public Integer evento;
	
}