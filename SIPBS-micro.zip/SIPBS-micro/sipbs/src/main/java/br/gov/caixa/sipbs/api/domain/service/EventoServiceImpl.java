package br.gov.caixa.sipbs.api.domain.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.Query;

import org.springframework.http.HttpStatus;

import br.gov.caixa.sipbs.api.domain.dao.EventoDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.Evento;
import br.gov.caixa.sipbs.api.domain.repository.jpa.EventoRepository;
import br.gov.caixa.sipbs.api.dtos.EventoDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;

@ApplicationScoped
public class EventoServiceImpl extends GenericService implements EventoService {

	@Inject
	EventoRepository eventoRepository;
	
	@Inject
	EventoDAO dao;
	

	public List<EventoDTO> findAllRepository() {
		return eventoRepository.findAll().stream().map(entity -> map(entity, EventoDTO.class))
				.collect(Collectors.toList());
	}

	@SuppressWarnings("unchecked")
	public List<EventoDTO> findAllNative() {
		Query query = emDb2.createNativeQuery("SELECT NU_EVENTO, TS_INICIO, CO_IDENTIFICADOR, CO_APLICACAO, NU_TAREFA, "
				+ "CO_PROGRAMA, CO_TIPO_AMBIENTE, TS_FIM, NU_TIPO_CREDENCIAL, "
				+ "CO_CREDENCIAL FROM {h-schema}PBSVWA12_EVENTO", Evento.class);
		return (List<EventoDTO>)  query.getResultStream().map(entity -> map(entity, EventoDTO.class))
				.collect(Collectors.toList());
	}

	public List<EventoDTO> findAllPanache() {
		return Evento.findAll().stream().map(entity -> map(entity, EventoDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<EventoDTO> listAll() throws GeneralException {
		return dao.listAll().stream()
				.map(entity -> map(entity, EventoDTO.class)).collect(Collectors.toList());
	}

	@Override
	public List<EventoDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return dao.listPag(pagina, qtdPorPagina).stream()
				.map(entity -> map(entity, EventoDTO.class)).collect(Collectors.toList());
	}

	@Override
	public EventoDTO findById(Long id) {
		Evento tabela = Evento.findById(id);
		if (tabela == null) {
			throw new AppException(HttpStatus.NOT_FOUND, "Registro com o id " + id + " não existe.");
		}
		return map(tabela, EventoDTO.class);
	}

	@Override
	public EventoDTO create(EventoDTO requisicao) {
		Evento evento = map(requisicao, Evento.class);
		
		evento.persist();
		return map(evento, EventoDTO.class);
	}

	@Override
	public EventoDTO update(Long id, EventoDTO evento) {
		Evento entidade = Evento.findById(id);

		if (entidade == null) {
			throw new AppException(HttpStatus.NOT_FOUND, "Registro com o id " + id + " não existe.");
		}
		entidade.codigo = evento.getCodigo();
		entidade.codigoAplicacao = evento.getCodigoAplicacao();
		entidade.idTarefa = evento.getIdTarefa();
		entidade.codigoPrograma = evento.getCodigoPrograma();
		entidade.codigoTipoAmbiente = evento.getCodigoTipoAmbiente();
		
		return map(entidade, EventoDTO.class);
	}

	@Override
	public void delete(Long id) {
		Evento entidade = Evento.findById(id);
		if (entidade == null) {
			throw new AppException(HttpStatus.NOT_FOUND, "Registro com o id " + id + " não existe.");
		}
		entidade.delete();
	}

	@Override
	public Long count() {
		return Evento.count();
	}
}