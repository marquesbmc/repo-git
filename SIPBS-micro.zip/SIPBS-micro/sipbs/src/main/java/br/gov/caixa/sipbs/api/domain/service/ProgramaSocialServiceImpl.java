package br.gov.caixa.sipbs.api.domain.service;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.ProgramaSocial;
import br.gov.caixa.sipbs.api.dtos.ProgramaSocialDTO;
import io.quarkus.panache.common.Sort;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class ProgramaSocialServiceImpl extends GenericService implements ProgramaSocialService {

	@Override
	public List<ProgramaSocialDTO> listAll() {
		return ProgramaSocial.listAll(Sort.by("NU_PRODUTO_ICOO10")).stream().map(entity -> map(entity, ProgramaSocialDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<ProgramaSocialDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return null;
	}

	@Override
	public ProgramaSocialDTO findById(Long id) {
		return null;
	}

	@Override
	public ProgramaSocialDTO create(ProgramaSocialDTO request) {
		return null;
	}

	@Override
	public ProgramaSocialDTO update(Long id, ProgramaSocialDTO request) {
		return null;
	}

	@Override
	public void delete(Long id) {

	}

	@Override
	public Long count() {
		return null;
	}
}
