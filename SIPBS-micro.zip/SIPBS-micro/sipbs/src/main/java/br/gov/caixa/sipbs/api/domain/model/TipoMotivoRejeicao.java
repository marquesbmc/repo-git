package br.gov.caixa.sipbs.api.domain.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the PBSVWD13_TPO_MTVO_RJCAO_RGTO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWD13_TPO_MTVO_RJCAO_RGTO")
public class TipoMotivoRejeicao extends PanacheEntityBase {

	@Id
	@Column(name="NU_TIPO_MOTIVO_REGISTRO")
	private Short nuTipoMotivoRejeicao;

	@Column(name="NU_MOTIVO_EXTERNO_REGISTRO")
	private Short nuMotivoExterno;

	@Column(name="DE_MOTIVO_REJEICAO_REGISTRO")
	private String deMotivoRejeicao;

}
