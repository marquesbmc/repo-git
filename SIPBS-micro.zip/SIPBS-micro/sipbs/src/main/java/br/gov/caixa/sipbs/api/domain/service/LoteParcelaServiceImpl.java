package br.gov.caixa.sipbs.api.domain.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import br.gov.caixa.sipbs.api.domain.dao.LoteParcelaAcatadaDAO;
import br.gov.caixa.sipbs.api.domain.dao.LoteParcelaRejeitadaDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.LoteParcelaAcatada;
import br.gov.caixa.sipbs.api.domain.model.LoteParcelaRejeitada;
import br.gov.caixa.sipbs.api.dtos.LoteParcelaAcatadaDTO;
import br.gov.caixa.sipbs.api.dtos.LoteParcelaRejeitadaDTO;
import br.gov.caixa.sipbs.api.dtos.PagamentoCanalDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoLoteParcelaAcatadaDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoLoteParcelaDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoLoteParcelaRejeitadaDTO;

@ApplicationScoped
public class LoteParcelaServiceImpl extends GenericService implements LoteParcelaService{

	@Inject
	LoteParcelaAcatadaDAO loteParcelaAcatadaDAO;
	
	@Inject
	LoteParcelaRejeitadaDAO loteParcelaRejeitadaDAO;

	@Override
	public RelatorioSinteticoLoteParcelaDTO recuperarRelatorioSinteticoLoteParcela(Short nuProdutoIcoo10, Long nuRemessa, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException {
		
		String dataConsulta = "";
		String nuProgramaSocial = "";
		String loteRemessa = "";
		String nomeArquivoFisico = "";
		Date dtProcessamento = null;

		List<LoteParcelaAcatada> loteParcelaAcatadaList = loteParcelaAcatadaDAO.recuperarRelatorioSinteticoLoteParcelaAcatada(nuProdutoIcoo10, nuRemessa, dtInicioPeriodo, dtFimPeriodo);
		
		List<LoteParcelaRejeitada> loteParcelaRejeitadaList = loteParcelaRejeitadaDAO.recuperarRelatorioSinteticoLoteParcelaRejeitada(nuProdutoIcoo10, nuRemessa, dtInicioPeriodo, dtFimPeriodo);

		List<LoteParcelaAcatadaDTO> loteParcelaAcatadaDTOList = new ArrayList<>();
		LoteParcelaAcatadaDTO loteParcelaAcatadaDTO;
		long qtTotalLoteParcelasAcatadas = 0L;
		BigDecimal vrTotalLoteParcelasAcatadas = BigDecimal.ZERO;
		for (LoteParcelaAcatada loteParcelaAcatada : loteParcelaAcatadaList) {
			
			nuProgramaSocial = String.valueOf(loteParcelaAcatada.getNuProgramaSocial());
			loteRemessa = String.valueOf(loteParcelaAcatada.getNuPbsr02());
			nomeArquivoFisico = loteParcelaAcatada.getNomeArquivoFisico();
			dtProcessamento = loteParcelaAcatada.getDtProcessamento();
					
			loteParcelaAcatadaDTO = new LoteParcelaAcatadaDTO();
			loteParcelaAcatadaDTO.setNuPbsr04(loteParcelaAcatada.getNuPbsr04());
			loteParcelaAcatadaDTO.setNuPbsr02(loteParcelaAcatada.getNuPbsr02());
			loteParcelaAcatadaDTO.setNoOriginalArquivo(loteParcelaAcatada.getNomeArquivoFisico());
			loteParcelaAcatadaDTO.setNuProduto(loteParcelaAcatada.getNuProgramaSocial());
			loteParcelaAcatadaDTO.setNuReferencia(loteParcelaAcatada.getNuReferencia());
			loteParcelaAcatadaDTO.setNuRemessa(loteParcelaAcatada.getNuRemessa());
			if ( loteParcelaAcatada.getDtProcessamento() != null ) {
				loteParcelaAcatadaDTO.setDtProcessamento(loteParcelaAcatada.getDtProcessamento());
			}
			loteParcelaAcatadaDTO.setAnoBase(loteParcelaAcatada.getNuCompetencia());
			loteParcelaAcatadaDTO.setQuantidateTotalParcelas(loteParcelaAcatada.getQtParcelasAcatadas());
			loteParcelaAcatadaDTO.setValorTotalParcelas(loteParcelaAcatada.getVrTotalParcelasAcatadas());

			qtTotalLoteParcelasAcatadas = qtTotalLoteParcelasAcatadas + loteParcelaAcatada.getQtParcelasAcatadas();
			vrTotalLoteParcelasAcatadas = vrTotalLoteParcelasAcatadas.add(loteParcelaAcatada.getVrTotalParcelasAcatadas());

			loteParcelaAcatadaDTOList.add(loteParcelaAcatadaDTO);
		}

		RelatorioSinteticoLoteParcelaAcatadaDTO relatorioSinteticoLoteParcelaAcatadaDTO = new RelatorioSinteticoLoteParcelaAcatadaDTO();
		relatorioSinteticoLoteParcelaAcatadaDTO.setLoteParcelaAcatadaDTOList(loteParcelaAcatadaDTOList);
		relatorioSinteticoLoteParcelaAcatadaDTO.setQtTotalParcela(qtTotalLoteParcelasAcatadas);
		relatorioSinteticoLoteParcelaAcatadaDTO.setVrTotalParcela(vrTotalLoteParcelasAcatadas);

		List<LoteParcelaRejeitadaDTO> loteParcelaRejeitadaDTOList = new ArrayList<>();
		LoteParcelaRejeitadaDTO loteParcelaRejeitadaDTO;
		long qtTotalLoteParcelasRejeitadas = 0L;
		BigDecimal vrTotalLoteParcelasRejeitadas = BigDecimal.ZERO;
		for (LoteParcelaRejeitada loteParcelaRejeitada : loteParcelaRejeitadaList) {
			loteParcelaRejeitadaDTO = new LoteParcelaRejeitadaDTO();
			loteParcelaRejeitadaDTO.setNuPbsr03(loteParcelaRejeitada.getNuPbsr03());
			loteParcelaRejeitadaDTO.setNuPbsr02(loteParcelaRejeitada.getNuPbsr02());
			loteParcelaRejeitadaDTO.setNomeArquivoFisico(loteParcelaRejeitada.getNomeArquivoFisico());
			loteParcelaRejeitadaDTO.setNuProgramaSocial(loteParcelaRejeitada.getNuProgramaSocial());
			loteParcelaRejeitadaDTO.setNuReferencia(loteParcelaRejeitada.getNuReferencia());
			loteParcelaRejeitadaDTO.setNuRemessa(loteParcelaRejeitada.getNuRemessa());
			loteParcelaRejeitadaDTO.setMotivoRejeicao(loteParcelaRejeitada.getDeTipoMotivoRejeicao());
			loteParcelaRejeitadaDTO.setQuantidadeTotalParcelas(loteParcelaRejeitada.getQtParcelasRejeitadas());
			loteParcelaRejeitadaDTO.setValorTotalParcelas(loteParcelaRejeitada.getVrTotalParcelasRejeitadas());

			qtTotalLoteParcelasRejeitadas = qtTotalLoteParcelasRejeitadas + loteParcelaRejeitada.getQtParcelasRejeitadas();
			vrTotalLoteParcelasRejeitadas = vrTotalLoteParcelasRejeitadas.add(loteParcelaRejeitada.getVrTotalParcelasRejeitadas());

			loteParcelaRejeitadaDTOList.add(loteParcelaRejeitadaDTO);
		}

		RelatorioSinteticoLoteParcelaRejeitadaDTO relatorioSinteticoLoteParcelaRejeitadaDTO = new RelatorioSinteticoLoteParcelaRejeitadaDTO();
		relatorioSinteticoLoteParcelaRejeitadaDTO.setLoteParcelaRejeitadaDTOList(loteParcelaRejeitadaDTOList);
		relatorioSinteticoLoteParcelaRejeitadaDTO.setQtTotalParcela(qtTotalLoteParcelasRejeitadas);
		relatorioSinteticoLoteParcelaRejeitadaDTO.setVrTotalParcela(vrTotalLoteParcelasRejeitadas);

		Date date = new Date();
		SimpleDateFormat sm = new SimpleDateFormat("dd-MM-yyyy");
		String strDate = sm.format(date);

		dataConsulta = strDate;


		//String dataInicio = dateFormatter.format(dtInicioPeriodo);
		//String dataFim = dateFormatter.format(dtFimPeriodo);

		RelatorioSinteticoLoteParcelaDTO relatorioSinteticoLoteParcelaDTO = new RelatorioSinteticoLoteParcelaDTO(); 
		relatorioSinteticoLoteParcelaDTO.setDataConsulta(dataConsulta);
		relatorioSinteticoLoteParcelaDTO.setNuProgramaSocial(nuProgramaSocial);
		if( loteRemessa != null ) {
			relatorioSinteticoLoteParcelaDTO.setLoteRemessa(loteRemessa);
		} else {	
			relatorioSinteticoLoteParcelaDTO.setDtInicioPeriodo(Date.from(dtInicioPeriodo.atStartOfDay(ZoneId.systemDefault()).toInstant()));
			relatorioSinteticoLoteParcelaDTO.setDtFimPeriodo(Date.from(dtFimPeriodo.atStartOfDay(ZoneId.systemDefault()).toInstant()));
		}
		relatorioSinteticoLoteParcelaDTO.setNomeArquivoFisico(nomeArquivoFisico);

		if( dtProcessamento != null ) {
			relatorioSinteticoLoteParcelaDTO.setDtProcessamento(sm.format(dtProcessamento));
		}

		relatorioSinteticoLoteParcelaDTO.setRelatorioSinteticoLoteParcelaAcatadaDTO(relatorioSinteticoLoteParcelaAcatadaDTO);
		relatorioSinteticoLoteParcelaDTO.setRelatorioSinteticoLoteParcelaRejeitadaDTO(relatorioSinteticoLoteParcelaRejeitadaDTO);

		return relatorioSinteticoLoteParcelaDTO;

	}
	
	public ByteArrayOutputStream exportarRelatorioSinteticoLoteParcela(Short nuProdutoIcoo10, Long nuRemessa, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException, IOException {

		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		String dtInicio = "";
		String dtFim = ""; 
				
		if(dtInicioPeriodo!= null) {
			dtInicio = dateFormatter.format(dtInicioPeriodo);
			dtFim = dateFormatter.format(dtFimPeriodo);
		} 

		RelatorioSinteticoLoteParcelaDTO relatorioSinteticoLoteParcelaDTO = recuperarRelatorioSinteticoLoteParcela(nuProdutoIcoo10, nuRemessa, dtInicioPeriodo, dtFimPeriodo);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Processamento de Folha – Sintético");

		int contRow = 4;

		adicionarLogoCaixa(workbook, sheet);

		sheet.setDefaultColumnWidth(25);

		Font fontTamanho = workbook.createFont();
		fontTamanho.setFontHeight((short) 250);
		Font fontNegrito = workbook.createFont();
		fontNegrito.setBold(true);

		CellStyle styleCabecalho1 = workbook.createCellStyle();
		styleCabecalho1.setFont(fontTamanho);

		Row row = sheet.createRow(contRow++);
		Cell cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("CAIXA ECONÔMICA FEDERAL");
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("VICE-PRESIDÊNCIA DE GOVERNO - VIGOV");
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho1);
		cellCabecalho.setCellValue("SIPBS - PROCESSAMENTO FOLHA - SINTÉTICO");

		CellStyle styleCabecalho2 = workbook.createCellStyle();
		styleCabecalho2.setFont(fontNegrito);

		row = sheet.createRow(contRow++).getSheet().createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		cellCabecalho.setCellValue("Produto: " + relatorioSinteticoLoteParcelaDTO.getNuProgramaSocial());

		if(dtInicioPeriodo!= null) {
			
			row = sheet.createRow(contRow++);
			cellCabecalho = row.createCell(0);
			cellCabecalho.setCellStyle(styleCabecalho2);
			cellCabecalho.setCellValue("Período: " + dtInicio + " - " + dtFim);
			
		} else {
			
			row = sheet.createRow(contRow++);
			cellCabecalho = row.createCell(0);
			cellCabecalho.setCellStyle(styleCabecalho2);
			cellCabecalho.setCellValue("Lote: " + nuRemessa );
			
			row = sheet.createRow(contRow++);
			cellCabecalho = row.createCell(0);
			cellCabecalho.setCellStyle(styleCabecalho2);
			String nomeArquivo = relatorioSinteticoLoteParcelaDTO.getNomeArquivoFisico() == null ? "" : relatorioSinteticoLoteParcelaDTO.getNomeArquivoFisico();
			cellCabecalho.setCellValue("Nome de Arquivo: " + nomeArquivo );
			
			row = sheet.createRow(contRow++);
			cellCabecalho = row.createCell(0);
			cellCabecalho.setCellStyle(styleCabecalho2);
		
			cellCabecalho.setCellValue("Data de Processamento: " + relatorioSinteticoLoteParcelaDTO.getDtProcessamento() );
			
		}
		
		row = sheet.createRow(contRow++);
		cellCabecalho = row.createCell(0);
		cellCabecalho.setCellStyle(styleCabecalho2);
		cellCabecalho.setCellValue("Data de Geração do Relatório: " + relatorioSinteticoLoteParcelaDTO.getDataConsulta());

		

		Font fontBold = workbook.createFont();
		fontBold.setBold(true);
		fontBold.setFontHeight((short) 250);

		CellStyle styleTitulo = workbook.createCellStyle();
		styleTitulo.setAlignment(HorizontalAlignment.CENTER);
		styleTitulo.setFillForegroundColor(IndexedColors.GOLD.getIndex());
		styleTitulo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleTitulo);
		styleTitulo.setFont(fontBold);

		row = sheet.createRow(contRow++).getSheet().createRow(contRow++).getSheet().createRow(contRow++);
		Cell cellTitulo = row.createCell(0);
		cellTitulo.setCellValue("Ano Base");
		cellTitulo.setCellStyle(styleTitulo);
		cellTitulo = row.createCell(1);
		cellTitulo.setCellValue("Qtde");
		cellTitulo.setCellStyle(styleTitulo);
		cellTitulo = row.createCell(2);
		cellTitulo.setCellValue("Valor (R$)");
		cellTitulo.setCellStyle(styleTitulo);

		NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
		row = sheet.createRow(contRow++);
		int contCell = 0;
		Cell cellConteudo;

		for (LoteParcelaAcatadaDTO loteParcelaAcatadaDTO : relatorioSinteticoLoteParcelaDTO.getRelatorioSinteticoLoteParcelaAcatadaDTO().getLoteParcelaAcatadaDTOList()) {
			CellStyle styleConteudoCanal = workbook.createCellStyle();
			CellStyle styleConteudoQtde = workbook.createCellStyle();
			CellStyle styleConteudoValor = workbook.createCellStyle();
			carregarbordarCelula(styleConteudoCanal);
			carregarbordarCelula(styleConteudoQtde);
			carregarbordarCelula(styleConteudoValor);
			if (contRow % 2 == 0) {
				styleConteudoCanal.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoQtde.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoValor.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			} else {
				styleConteudoCanal.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoQtde.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoValor.setFillForegroundColor(IndexedColors.WHITE.getIndex());
			}
			styleConteudoCanal.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoQtde.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoValor.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(loteParcelaAcatadaDTO.getAnoBase());
			styleConteudoCanal.setAlignment(HorizontalAlignment.LEFT);
			cellConteudo.setCellStyle(styleConteudoCanal);

			cellConteudo = row.createCell(contCell++);
			cellConteudo.setCellValue(loteParcelaAcatadaDTO.getQuantidateTotalParcelas());
			styleConteudoQtde.setAlignment(HorizontalAlignment.RIGHT);
			cellConteudo.setCellStyle(styleConteudoQtde);

			cellConteudo = row.createCell(contCell);
			cellConteudo.setCellValue(numberFormat.format(loteParcelaAcatadaDTO.getValorTotalParcelas()));
			styleConteudoValor.setAlignment(HorizontalAlignment.RIGHT);
			cellConteudo.setCellStyle(styleConteudoValor);

			row = sheet.createRow(contRow++);
			contCell = 0;
		}

		CellStyle styleRodapeRight = workbook.createCellStyle();
		styleRodapeRight.setFont(fontBold);
		styleRodapeRight.setAlignment(HorizontalAlignment.RIGHT);
		styleRodapeRight.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		styleRodapeRight.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleRodapeRight);

		Cell cellRodape = row.createCell(contCell++);
		cellRodape.setCellValue("Totais: ");
		cellRodape.setCellStyle(styleRodapeRight);

		cellRodape = row.createCell(contCell++);
		cellRodape.setCellValue(relatorioSinteticoLoteParcelaDTO.getRelatorioSinteticoLoteParcelaAcatadaDTO().getQtTotalParcela());
		cellRodape.setCellStyle(styleRodapeRight);

		cellRodape = row.createCell(contCell);
		cellRodape.setCellValue(numberFormat.format(relatorioSinteticoLoteParcelaDTO.getRelatorioSinteticoLoteParcelaAcatadaDTO().getVrTotalParcela()));
		cellRodape.setCellStyle(styleRodapeRight);
		
		
		
		Font fontBoldRejeitada = workbook.createFont();
		fontBoldRejeitada.setBold(true);
		fontBoldRejeitada.setFontHeight((short) 250);

		CellStyle styleTituloRejeitada = workbook.createCellStyle();
		styleTituloRejeitada.setAlignment(HorizontalAlignment.CENTER);
		styleTituloRejeitada.setFillForegroundColor(IndexedColors.GOLD.getIndex());
		styleTituloRejeitada.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleTituloRejeitada);
		styleTituloRejeitada.setFont(fontBoldRejeitada);

		row = sheet.createRow(contRow++).getSheet().createRow(contRow++).getSheet().createRow(contRow++);
		Cell cellTituloRejeitada = row.createCell(0);
		cellTituloRejeitada.setCellValue("Motivo Rejeição");
		cellTituloRejeitada.setCellStyle(styleTituloRejeitada);
		cellTituloRejeitada = row.createCell(1);
		cellTituloRejeitada.setCellValue("Qtde");
		cellTituloRejeitada.setCellStyle(styleTituloRejeitada);
		cellTituloRejeitada = row.createCell(2);
		cellTituloRejeitada.setCellValue("Valor (R$)");
		cellTituloRejeitada.setCellStyle(styleTituloRejeitada);

		NumberFormat numberFormatRejeitada = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
		row = sheet.createRow(contRow++);
		int contCellRejeitada = 0;
		Cell cellConteudoRejeitada;

		for (LoteParcelaRejeitadaDTO loteParcelaRejeitadaDTO : relatorioSinteticoLoteParcelaDTO.getRelatorioSinteticoLoteParcelaRejeitadaDTO().getLoteParcelaRejeitadaDTOList()) {
			CellStyle styleConteudoCanal = workbook.createCellStyle();
			CellStyle styleConteudoQtde = workbook.createCellStyle();
			CellStyle styleConteudoValor = workbook.createCellStyle();
			carregarbordarCelula(styleConteudoCanal);
			carregarbordarCelula(styleConteudoQtde);
			carregarbordarCelula(styleConteudoValor);
			if (contRow % 2 == 0) {
				styleConteudoCanal.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoQtde.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				styleConteudoValor.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			} else {
				styleConteudoCanal.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoQtde.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				styleConteudoValor.setFillForegroundColor(IndexedColors.WHITE.getIndex());
			}
			styleConteudoCanal.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoQtde.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleConteudoValor.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			cellConteudoRejeitada = row.createCell(contCellRejeitada++);
			cellConteudoRejeitada.setCellValue(loteParcelaRejeitadaDTO.getMotivoRejeicao());
			styleConteudoCanal.setAlignment(HorizontalAlignment.LEFT);
			cellConteudoRejeitada.setCellStyle(styleConteudoCanal);

			cellConteudoRejeitada = row.createCell(contCellRejeitada++);
			cellConteudoRejeitada.setCellValue(loteParcelaRejeitadaDTO.getQuantidadeTotalParcelas());
			styleConteudoQtde.setAlignment(HorizontalAlignment.RIGHT);
			cellConteudoRejeitada.setCellStyle(styleConteudoQtde);

			cellConteudoRejeitada = row.createCell(contCellRejeitada);
			cellConteudoRejeitada.setCellValue(numberFormat.format(loteParcelaRejeitadaDTO.getValorTotalParcelas()));
			styleConteudoValor.setAlignment(HorizontalAlignment.RIGHT);
			cellConteudoRejeitada.setCellStyle(styleConteudoValor);

			row = sheet.createRow(contRow++);
			contCellRejeitada = 0;
		}

		CellStyle styleRodapeRightRejeitada = workbook.createCellStyle();
		styleRodapeRightRejeitada.setFont(fontBoldRejeitada);
		styleRodapeRightRejeitada.setAlignment(HorizontalAlignment.RIGHT);
		styleRodapeRightRejeitada.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		styleRodapeRightRejeitada.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		carregarbordarCelula(styleRodapeRightRejeitada);

		Cell cellRodapeRejeitada = row.createCell(contCellRejeitada++);
		cellRodapeRejeitada.setCellValue("Totais: ");
		cellRodapeRejeitada.setCellStyle(styleRodapeRightRejeitada);

		cellRodapeRejeitada = row.createCell(contCellRejeitada++);
		cellRodapeRejeitada.setCellValue(relatorioSinteticoLoteParcelaDTO.getRelatorioSinteticoLoteParcelaRejeitadaDTO().getQtTotalParcela());
		cellRodapeRejeitada.setCellStyle(styleRodapeRightRejeitada);

		cellRodapeRejeitada = row.createCell(contCellRejeitada);
		cellRodapeRejeitada.setCellValue(numberFormat.format(relatorioSinteticoLoteParcelaDTO.getRelatorioSinteticoLoteParcelaRejeitadaDTO().getVrTotalParcela()));
		cellRodapeRejeitada.setCellStyle(styleRodapeRightRejeitada);

		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

		row = sheet.createRow(contRow);
		Font fontItalic = workbook.createFont();
		fontItalic.setItalic(true);
		fontItalic.setBold(true);
		fontItalic.setFontHeight((short) 180);
		CellStyle styleDtRelatorio = workbook.createCellStyle();
		styleDtRelatorio.setFont(fontItalic);
		Cell cellDtRelatorio = row.createCell(0);
		cellDtRelatorio.setCellStyle(styleDtRelatorio);

		cellDtRelatorio.setCellValue("Date de geração do relatório: " + dateTimeFormatter.format(LocalDateTime.now()));

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		workbook.write(outputStream);
		workbook.close();
		return outputStream;
	}

	private void adicionarLogoCaixa(XSSFWorkbook workbook, XSSFSheet sheet) throws IOException {
		InputStream is = getClass().getResourceAsStream("/image/logo-caixa.jpeg");
		byte[] bytes = IOUtils.toByteArray(is);
		int pictureIdx = workbook.addPicture(bytes, Workbook.PICTURE_TYPE_JPEG);
		is.close();

		CreationHelper helper = workbook.getCreationHelper();
		Drawing<?> drawing = sheet.createDrawingPatriarch();
		ClientAnchor anchor = helper.createClientAnchor();

		anchor.setRow1(0);
		anchor.setCol1(0);
		Picture pict = drawing.createPicture(anchor, pictureIdx);
		pict.resize();
	}

	private void carregarbordarCelula(CellStyle cellStyle) {
		cellStyle.setBorderTop(BorderStyle.THIN);
		cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderBottom(BorderStyle.THIN);
		cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderLeft(BorderStyle.THIN);
		cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderRight(BorderStyle.THIN);
		cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
	}

	@Override
	public List<PagamentoCanalDTO> listAll() {
		return null;
	}

	@Override
	public List<PagamentoCanalDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return null;
	}

	@Override
	public PagamentoCanalDTO findById(Long id) {
		return null;
	}

	@Override
	public PagamentoCanalDTO create(PagamentoCanalDTO request) {
		return null;
	}

	@Override
	public PagamentoCanalDTO update(Long id, PagamentoCanalDTO request) {
		return null;
	}

	@Override
	public void delete(Long id) {

	}

	@Override
	public Long count() {
		return null;
	}
}
