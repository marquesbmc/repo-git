package br.gov.caixa.sipbs.api.retorno;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ListReturn<T> extends Retorno implements Serializable {
	
	private static final long serialVersionUID = -8750373068316976842L;
	
	private List<T> data = new ArrayList<T>();

	public ListReturn(List<T> data) {
		super();
		this.data = data;
	}

	public ListReturn() {
		super();
	}

	public List<T> getData() {
		if (data == null) {
			data = new ArrayList<T>();			
		}
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}
}