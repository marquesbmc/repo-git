package br.gov.caixa.sipbs.api.enums;

public enum CriterioContaPropriedadeEnum {
	DATA_ABERTURA_CONTA(1, "Data da Abertura da Conta"),
	DATA_ULTIMA_MOVIMENTACAO(2, "Data da Última Movimentação");

	private Integer codigo;
	private String nome;

	CriterioContaPropriedadeEnum(Integer codigo, String nome) {
		this.codigo = codigo;
		this.nome = nome;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public static CriterioContaPropriedadeEnum consultarPorCodigo(Integer codigo){
		if (codigo != null) {
			for (CriterioContaPropriedadeEnum criterioContaPropriedadeEnum : values()) {
				if (criterioContaPropriedadeEnum.getCodigo().compareTo(codigo) == 0) {
					return criterioContaPropriedadeEnum;
				}
			}
		}
		return null;
	}
}
