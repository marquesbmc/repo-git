package br.gov.caixa.sipbs.api.domain.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.sql.Timestamp;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB05_BENEFICIARIO_SOCIAL")
public class BeneficiarioSocial extends PanacheEntityBase {

	@Id
	@Column(name="NU_PBSB05")
	public Integer nuPbsb05;

	@Column(name="NU_CPF_BENEFICIARIO")
	public Long nuCpfBeneficiario;

	@Column(name="NU_NIS_BENEFICIARIO")
	public Long nuNisBeneficiario;

	@Column(name="NO_BENEFICIARIO")
	public String noBeneficiario;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;
}
