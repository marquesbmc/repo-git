package br.gov.caixa.sipbs.api.domain.service;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.PagamentoCanalDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoPagamentoCanalDTO;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public interface PagamentoCanalService {

	RelatorioSinteticoPagamentoCanalDTO recuperarRelatorioSinteticoPagamentoCanal(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException;

	ByteArrayOutputStream exportarRelatorioSinteticoPagamento(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException, IOException;

	List<PagamentoCanalDTO> listAll();

	List<PagamentoCanalDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException;

	PagamentoCanalDTO findById(Long id);

	PagamentoCanalDTO create(PagamentoCanalDTO request);

	PagamentoCanalDTO update(Long id, PagamentoCanalDTO request);

	void delete(Long id);

	Long count();
}
