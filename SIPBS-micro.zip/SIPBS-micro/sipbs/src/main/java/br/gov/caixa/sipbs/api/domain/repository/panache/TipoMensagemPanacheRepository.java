package br.gov.caixa.sipbs.api.domain.repository.panache;

import javax.enterprise.context.ApplicationScoped;

import br.gov.caixa.sipbs.api.domain.model.TipoMensagem;
import io.quarkus.hibernate.orm.panache.PanacheRepository;



@ApplicationScoped
public class TipoMensagemPanacheRepository implements PanacheRepository<TipoMensagem> {
}
