package br.gov.caixa.sipbs.api.domain.dao;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.LoteParcelaAcatada;

@ApplicationScoped
public class LoteParcelaAcatadaDAO extends GenericDAO<LoteParcelaAcatada> {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoteParcelaAcatadaDAO.class);


	@SuppressWarnings({"unchecked"})
	public List<LoteParcelaAcatada> recuperarRelatorioSinteticoLoteParcelaAcatada(Short nuProdutoIcoo10, Long nuRemessa, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException {

		LOGGER.info("Chamando método recuperarRelatorioSinteticoLoteParcelasAcatadas com os parâmetros " + nuProdutoIcoo10 + " - " + nuRemessa  
				+ " - " + dtInicioPeriodo + " - " + dtFimPeriodo);

		try {
			
			List<LoteParcelaAcatada> lotesParcelaAcatada;

			if( nuRemessa != null ) {
				
				StringBuilder queryLoteParcelasAcatadas = new StringBuilder(" SELECT  LPA.NU_PBSR04 AS NU_PBSR04, LP.NU_PBSR02 AS NU_PBSR02, AF.NO_ARQUIVO AS NO_ARQUIVO, LP.NU_PRODUTO_ICOO10 AS NU_PRODUTO_ICOO10, LP.NU_REFERENCIA AS NU_REFERENCIA")
						.append(", LP.NU_REMESSA AS NU_REMESSA, LP.DT_PROCESSAMENTO AS DT_PROCESSAMENTO, LPA.NU_COMPETENCIA AS NU_COMPETENCIA, SUM(LPA.QT_PARCELAS_ACATADAS) AS QT_PARCELAS_ACATADAS, SUM(LPA.VR_TOTAL_PARCELAS_ACATADAS) AS VR_TOTAL_PARCELAS_ACATADAS ")	
						.append(" FROM   {h-schema}PBSVWR02_LOTE_PARCELA LP ")
						.append("  		,{h-schema}PBSVWR04_LOTE_PARCELA_ACATADA LPA ")
						.append("  		,{h-schema}PBSVWD03_ARQUIVO_FISICO AF ")
						.append(" WHERE   LP.NU_PBSR02 = LPA.NU_PBSR02 ")
						.append(" AND     LP.NU_PBSD03 = AF.NU_PBSD03 ")
						.append(" AND     LP.NU_PRODUTO_ICOO10 = :nuProdutoIcoo10 ");
				queryLoteParcelasAcatadas.append(" AND LP.NU_REMESSA = :nuRemessa ");
				queryLoteParcelasAcatadas.append(" GROUP BY LPA.NU_PBSR04, LP.NU_PBSR02, AF.NO_ARQUIVO, LP.NU_PRODUTO_ICOO10, LP.NU_REFERENCIA, LP.NU_REMESSA, LP.DT_PROCESSAMENTO, LPA.NU_COMPETENCIA ")
										 .append(" ORDER BY LPA.NU_PBSR04, LP.NU_PBSR02, AF.NO_ARQUIVO, LP.NU_PRODUTO_ICOO10, LP.NU_REFERENCIA, LP.NU_REMESSA, LP.DT_PROCESSAMENTO, LPA.NU_COMPETENCIA ");
	
				Query query = emDb2.createNativeQuery(queryLoteParcelasAcatadas.toString(), LoteParcelaAcatada.class);
				query.setParameter("nuProdutoIcoo10", nuProdutoIcoo10);
				query.setParameter("nuRemessa", nuRemessa);
				
				lotesParcelaAcatada = query.getResultList();
				
			} else {
				
				StringBuilder queryLoteParcelasAcatadas = new StringBuilder(" SELECT  LP.NU_PRODUTO_ICOO10 AS NU_PRODUTO_ICOO10, LP.NU_REFERENCIA AS NU_REFERENCIA") 
						.append(", LPA.NU_COMPETENCIA AS NU_COMPETENCIA, SUM(LPA.QT_PARCELAS_ACATADAS) AS QT_PARCELAS_ACATADAS, SUM(LPA.VR_TOTAL_PARCELAS_ACATADAS) AS VR_TOTAL_PARCELAS_ACATADAS ")	
						.append(" FROM   {h-schema}PBSVWR02_LOTE_PARCELA LP ")
						.append("  		,{h-schema}PBSVWR04_LOTE_PARCELA_ACATADA LPA ")
						.append("  		,{h-schema}PBSVWD03_ARQUIVO_FISICO AF ")
						.append(" WHERE   LP.NU_PBSR02 = LPA.NU_PBSR02 ")
						.append(" AND     LP.NU_PBSD03 = AF.NU_PBSD03 ")
						.append(" AND     LP.NU_PRODUTO_ICOO10 = :nuProdutoIcoo10 ");
				queryLoteParcelasAcatadas.append(" AND LP.DT_PROCESSAMENTO BETWEEN DATE('" + dtInicioPeriodo + "') AND DATE('" + dtFimPeriodo + "') ");
				queryLoteParcelasAcatadas.append(" GROUP BY LP.NU_PRODUTO_ICOO10, LP.NU_REFERENCIA, LPA.NU_COMPETENCIA ")
				 .append(" ORDER BY LP.NU_PRODUTO_ICOO10, LP.NU_REFERENCIA, LPA.NU_COMPETENCIA ");
				
				Query query = emDb2.createNativeQuery(queryLoteParcelasAcatadas.toString());
				query.setParameter("nuProdutoIcoo10", nuProdutoIcoo10);
				
				lotesParcelaAcatada = new ArrayList<LoteParcelaAcatada>();
				
				List<Object[]> result = query.getResultList();
				
				LoteParcelaAcatada loteParcelaAcatada;
				
				for (Object[] object : result) {
					int cont = 0;
					loteParcelaAcatada = new LoteParcelaAcatada();
					loteParcelaAcatada.setNuProgramaSocial(Integer.valueOf(object[cont++] + ""));
					loteParcelaAcatada.setNuReferencia(Integer.valueOf(object[cont++] + ""));
					loteParcelaAcatada.setNuCompetencia(Integer.valueOf(object[cont++] + ""));
					loteParcelaAcatada.setQtParcelasAcatadas(Long.valueOf(object[cont++] + ""));
					loteParcelaAcatada.setVrTotalParcelasAcatadas(BigDecimal.valueOf(Double.valueOf(object[cont++] + "")));

					lotesParcelaAcatada.add(loteParcelaAcatada);
					
				}

				
			}
			
			return lotesParcelaAcatada;
			
		} catch (Exception e) {
			LOGGER.error("Erro em " + "Chamando método recuperarRelatorioSinteticoLoteParcelasAcatadas com os parâmetros", e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}


	@Override
	public List<LoteParcelaAcatada> listAll() throws GeneralException {
		return null;
	}

	@Override
	public List<LoteParcelaAcatada> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return null;
	}

	@Override
	public LoteParcelaAcatada findById(Long id) throws GeneralException {
		return null;
	}

	@Override
	public LoteParcelaAcatada create(LoteParcelaAcatada request) throws GeneralException {
		return null;
	}

	@Override
	public LoteParcelaAcatada update(LoteParcelaAcatada request) throws GeneralException {
		return null;
	}

	@Override
	public void delete(Long id) throws GeneralException {

	}

	@Override
	public Long count() throws GeneralException {
		return null;
	}
}
