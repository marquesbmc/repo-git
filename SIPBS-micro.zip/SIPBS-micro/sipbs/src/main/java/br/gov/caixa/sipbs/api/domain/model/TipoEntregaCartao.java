package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntity;


/**
 * The persistent class for the PBSVWO22_TIPO_ENTREGA_CARTAO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO22_TIPO_ENTREGA_CARTAO")
public class TipoEntregaCartao extends PanacheEntity {

	@Column(name="CO_TIPO_ENTREGA_CARTAO")
	public String coTipoEntregaCartao;

	@Column(name="DE_TIPO_ENTREGA_CARTAO")
	public String deTipoEntregaCartao;
}