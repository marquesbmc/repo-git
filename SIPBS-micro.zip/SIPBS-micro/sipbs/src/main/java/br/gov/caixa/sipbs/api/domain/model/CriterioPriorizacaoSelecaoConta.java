package br.gov.caixa.sipbs.api.domain.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name = "PBSVWB26_CRITERIO_PRIORIZACAO_SELECAO_CONTA")
public class CriterioPriorizacaoSelecaoConta extends PanacheEntityBase {

	@Id
	@Column(name = "NU_CRITERIO_PRIORIZACAO")
	public Short nuCriterioPriorizacao;

	@Column(name = "NO_CRITERIO_PRIORIZACAO")
	public String noCriterioPriorizacao;
}
