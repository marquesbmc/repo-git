package br.gov.caixa.sipbs.api.controllers;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import br.gov.caixa.sipbs.api.domain.service.ParcelaPagamentoService;
import br.gov.caixa.sipbs.api.dtos.ConsultaParcelaPagamentoDTO;
import br.gov.caixa.sipbs.api.dtos.HistoricoManutencaoDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;

@Path("/api/parcela-pagamento/v2")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
@Transactional
@OpenAPIDefinition(info = @Info(description = "Conjunto de endpoints para consultas relacionadas à contas Beneficiário", title = "Contas Beneficiário", version = "1.0"))
public class ParcelaPagamentoController extends Controller<ConsultaParcelaPagamentoDTO, ResponseEntity<?>> {

	@Autowired
	ParcelaPagamentoService service;

	@GET
	@Path("/listarParcelas/{icCpfNis}/{nuCpfNis}/{nuProdutoIcoo10}")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<List<ConsultaParcelaPagamentoDTO>> listarParcelas(@PathParam("icCpfNis") String icCpfNis,
	                                                                      @PathParam("nuCpfNis") Long nuCpfNis,
	                                                                      @PathParam("nuProdutoIcoo10") Short nuProdutoIcoo10) {
		try {
			List<ConsultaParcelaPagamentoDTO> lista = service.searchParcelas(icCpfNis, nuCpfNis, nuProdutoIcoo10);
			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}
	
	@GET
	@Path("/historiccoManutencao/{nuPbso12}")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<List<HistoricoManutencaoDTO>> historiccoManutencao(@PathParam("nuPbso12") Long nuPbso12) {
		try {
			List<HistoricoManutencaoDTO> lista = service.historiccoManutencao(nuPbso12);
			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}
	
	@GET
	@Path("/relatorio/exportar/{icCpfNis}/{nuCpfNis}/{nuProdutoIcoo10}/{nomeProduto}/{perfiGestor}")
	@Produces("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	@Timeout(3000)
	//@RolesAllowed({ "PPBS0001", "PPBS0002", "PPBS0003" })
	public ResponseEntity<byte[]> exportarRelatorioSinteticoPagamento(@PathParam("icCpfNis") String icCpfNis,
															          @PathParam("nuCpfNis") Long nuCpfNis,
															          @PathParam("nuProdutoIcoo10") Short nuProdutoIcoo10,
															          @PathParam("nomeProduto") String nomeProduto,
                                                                      @PathParam("perfiGestor") Boolean perfilGestor) {
		try {

			ByteArrayOutputStream arquivoxlsx = service.exportarRelatorio(icCpfNis, nuCpfNis, nuProdutoIcoo10, nomeProduto, perfilGestor);
			if (arquivoxlsx != null) {
				return ResponseEntity.ok().header("Content-Disposition", String.format("attachment; filename=\"%s\"", "Relatório Parcelas - Processamento da consulta das Parcelas.xlsx")).body(arquivoxlsx.toByteArray());
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			e.printStackTrace();
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@Override
	public ResponseEntity<?> listAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> listPag(int pagina) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> listPag(int pagina, int qtdPorPagina) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> create(ConsultaParcelaPagamentoDTO request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> update(Long id, ConsultaParcelaPagamentoDTO request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> delete(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}
