package br.gov.caixa.sipbs.api.domain.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.ConsultaParcelaPagamentoDTO;
import br.gov.caixa.sipbs.api.dtos.HistoricoManutencaoDTO;

public interface ParcelaPagamentoService {

	List<ConsultaParcelaPagamentoDTO> searchParcelas(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException;
	List<HistoricoManutencaoDTO> historiccoManutencao(Long nuPbso12) throws GeneralException;
	ByteArrayOutputStream exportarRelatorio(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10, String nomeProduto, Boolean perfilGestor) throws GeneralException, IOException;
}
