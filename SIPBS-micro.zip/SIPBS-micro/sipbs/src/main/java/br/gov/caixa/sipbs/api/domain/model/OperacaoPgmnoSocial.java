package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO04_OPERACAO_PGMNO_SOCIAL database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO04_OPERACAO_PGMNO_SOCIAL")
public class OperacaoPgmnoSocial extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSO04")
	public Long nuPbso04;

	@Column(name="CO_CONFIRMACAO")
	public String coConfirmacao;

	@Column(name="CO_RESPOSTA_SOLICITACAO")
	public String coRespostaSolicitacao;

	@Column(name="CO_SOLICITACAO")
	public String coSolicitacao;

	@Column(name="CO_TIPO_CANAL_PBSC02")
	public String coTipoCanalPbsc02;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_OPERACAO_PAGAMENTO")
	public Date dtOperacaoPagamento;

	@Column(name="NU_ESTORNA_PBSO04")
	public Long nuEstornaPbso04;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_NATURAL_NIS_ATIVO")
	public Long nuNaturalNisAtivo;

	@Column(name="NU_NATURAL_NIS_ENTRADA")
	public Long nuNaturalNisEntrada;

	@Column(name="NU_NIS_ATIVO")
	public Long nuNisAtivo;

	@Column(name="NU_NIS_ENTRADA")
	public Long nuNisEntrada;

	@Column(name="NU_NSU_CANAL")
	public Long nuNsuCanal;

	@Column(name="NU_PBSB06")
	public Integer nuPbsb06;

	@Column(name="NU_PBSC03")
	public Long nuPbsc03;

	@Column(name="NU_PBSD03")
	public Long nuPbsd03;

	@Column(name="NU_SEQUENCIAL_UNICO")
	public Integer nuSequencialUnico;

	@Column(name="NU_SITUACAO_NIS_ENTRADA")
	public Short nuSituacaoNisEntrada;

	@Column(name="NU_TIPO_OCRNA_CREDITO_PBSO09")
	public Short nuTipoOcrnaCreditoPbso09;

	@Column(name="NU_TIPO_OPERACAO_PBSO10")
	public Short nuTipoOperacaoPbso10;

	@Column(name="TS_CONFIRMACAO")
	public Timestamp tsConfirmacao;

	@Column(name="TS_RESPOSTA_SOLICITACAO")
	public Timestamp tsRespostaSolicitacao;

	@Column(name="TS_SOLICITACAO")
	public Timestamp tsSolicitacao;
}