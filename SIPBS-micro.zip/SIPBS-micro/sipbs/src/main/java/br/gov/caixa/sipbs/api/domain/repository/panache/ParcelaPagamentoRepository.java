package br.gov.caixa.sipbs.api.domain.repository.panache;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.ParcelaPagamento;
import io.quarkus.hibernate.orm.panache.PanacheRepository;

@ApplicationScoped
public class ParcelaPagamentoRepository implements PanacheRepository<ParcelaPagamento> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ParcelaPagamentoRepository.class);

	public List<ParcelaPagamento> searchParcelas(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException {

		LOGGER.info("Chamando método searchParcelas com os parâmetros" + icCpfNis + " - " + nuCpfNis + " - " + nuProdutoIcoo10);
		try {
			String sql = "SELECT parcelapagamento " +
					"       FROM ParcelaPagamento parcelaPagamento " +
					"           JOIN FETCH parcelaPagamento.beneficiarioSocial beneficiarioSocial  " +
					"           LEFT JOIN BeneficiarioProgramaSocial.bSocial on bSocial.beneficiarioSocial = parcelapagamento.nuPbsb05 = parcelapagamento.beneficiarioSocial.nuPbsb05" +
					"           JOIN FETCH bSocial.contaCredito contaCredito  " +
					"           JOIN FETCH contaCredito.propriedadeConta propriedadeConta  " +
					"           JOIN FETCH propriedadeConta.tipoConta tipoConta  " +
					"       WHERE 0 = 0  " +
					"       AND beneficiarioPrograma.programaSocial.nuProdutoIcoo10 = ?1";
			if (icCpfNis.equals("C")) {
				sql = sql + "   AND beneficiarioSocial.nuCpfBeneficiario = ?2  ";
			} else {
				sql = sql + "   AND beneficiarioSocial.nuNisBeneficiario = ?2  ";
			}
			return ParcelaPagamento.list(sql, nuProdutoIcoo10, nuCpfNis);
		} catch (Exception eXception) {
			LOGGER.error("Erro em " + "Chamando método listFilter com os parâmetros", eXception);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, eXception);
		}
	}
}
