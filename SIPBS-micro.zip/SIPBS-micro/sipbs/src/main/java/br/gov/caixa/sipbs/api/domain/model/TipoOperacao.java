package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO10_TIPO_OPERACAO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO10_TIPO_OPERACAO")
public class TipoOperacao extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_TIPO_OPERACAO")
	public Short nuTipoOperacao;

	@Column(name="NO_TIPO_OPERACAO")
	public String noTipoOperacao;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}