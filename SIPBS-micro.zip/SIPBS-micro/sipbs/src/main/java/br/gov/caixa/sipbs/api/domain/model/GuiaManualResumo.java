package br.gov.caixa.sipbs.api.domain.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO17_GUIA_MANUAL_RESUMO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO17_GUIA_MANUAL_RESUMO")
public class GuiaManualResumo extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSO17")
	public Long nuPbso17;

	@Column(name="CO_BARRA_DIGITAL_GUIA_RESUMO")
	public String coBarraDigitalGuiaResumo;

	@Column(name="CO_BARRA_GUIA_RESUMO")
	public String coBarraGuiaResumo;

	@Column(name="CO_USUARIO_RSPNL_ATRZO")
	public String coUsuarioRspnlAtrzo;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_FIM_VALIDADE_GUIA")
	public Date dtFimValidadeGuia;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_INICIO_VALIDADE_GUIA")
	public Date dtInicioValidadeGuia;

	@Column(name="IC_SITUACAO_GUIA")
	public String icSituacaoGuia;

	@Column(name="NU_AUTENTICACAO")
	public Integer nuAutenticacao;

	@Column(name="NU_CNPJ_PREFEITURA")
	public BigDecimal nuCnpjPrefeitura;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_EXTERNO_GUIA_MUNICIPIO")
	public Integer nuExternoGuiaMunicipio;

	@Column(name="NU_IBGE_PREFEITURA")
	public Integer nuIbgePrefeitura;

	@Column(name="NU_LOCALIDADE_ICOL10")
	public Integer nuLocalidadeIcol10;

	@Column(name="NU_PBSO04")
	public Long nuPbso04;

	@Column(name="TS_AUTORIZACAO_SAIDA")
	public Timestamp tsAutorizacaoSaida;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}