package br.gov.caixa.sipbs.api.domain.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.sql.Timestamp;


@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB02_PROGRAMA_SOCIAL")
public class ProgramaSocial extends PanacheEntityBase {

	@Id
	@Column(name="NU_PRODUTO_ICOO10")
	private Short nuProdutoIcoo10;

	@Column(name="CO_SERVICO_CARTAO")
	private String coServicoCartao;

	@Column(name="CO_TIPO_ENTREGA_CARTAO_PBSO22")
	private String coTipoEntregaCartaoPbso22;

	@Column(name="IC_ATIVO")
	private String icAtivo;

	@Column(name="IC_BLOQUEIO_FOLHA_PROGRAMA")
	private Short icBloqueioFolhaPrograma;

	@Column(name="IC_BLOQUEIO_PAGAMENTO")
	private String icBloqueioPagamento;

	@Column(name="IC_EXCLUSIVO_CREDITO_CONTA")
	private String icExclusivoCreditoConta;

	@Column(name="IC_PAGAMENTO_CREDITO_CONTA")
	private String icPagamentoCreditoConta;

	@Column(name="IC_PAGAMENTO_SEM_CARTAO")
	private String icPagamentoSemCartao;

	@Column(name="IC_REJEITA_CONTA_CROT")
	private String icRejeitaContaCrot;

	@Column(name="IC_SOLICITA_CARTAO")
	private String icSolicitaCartao;

	@Column(name="NU_ACAO")
	private Integer nuAcao;

	@Column(name="NU_BLOQUEIO_FOLHA_PBSB10")
	private Integer nuBloqueioFolhaPbsb10;

	@Column(name="NU_BLOQUEIO_PGMNO_PBSB10")
	private Integer nuBloqueioPgmnoPbsb10;

	@Column(name="NU_CNPJ_GESTOR_PRODUTO")
	private BigDecimal nuCnpjGestorProduto;

	@Column(name="NU_CODIGO_LANCAMENTO")
	private Short nuCodigoLancamento;

	@Column(name="NU_EVENTO_CONTABIL")
	private Integer nuEventoContabil;

	@Column(name="NU_EVENTO_PBSA12")
	private Long nuEventoPbsa12;

	@Column(name="NU_GRUPO")
	private Short nuGrupo;

	@Column(name="NU_MODO")
	private Short nuModo;

	@Column(name="NU_PRIORIDADE")
	private Short nuPrioridade;

	@Column(name="NU_PRODUTO_VINCULADO_PBSB02")
	private Short nuProdutoVinculadoPbsb02;

	@Column(name="NU_SEGMENTO_ICOS12")
	private Short nuSegmentoIcos12;

	@Column(name="NU_SUBGRUPO")
	private Short nuSubgrupo;

	@Column(name="NU_SUBTIPO")
	private Short nuSubtipo;

	@Column(name="NU_TD")
	private Short nuTd;

	@Column(name="NU_TIPO")
	private Short nuTipo;

	@Column(name="NU_TIPO_ABRANGENCIA_PBSO21")
	private Short nuTipoAbrangenciaPbso21;

	@Column(name="NU_TIPO_PRODUTO_PBSO23")
	private Short nuTipoProdutoPbso23;

	@Column(name="PZ_VALIDADE_CONTA_APTA")
	private Short pzValidadeContaApta;

	@Column(name="SG_PROGRAMA_SOCIAL")
	private String sgProgramaSocial;

	@Column(name="TS_FIM_VIGENCIA")
	private Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	private Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	private Timestamp tsInicioVigencia;

	@Column(name="VR_MAXIMO_PARCELA")
	private BigDecimal vrMaximoParcela;
}
