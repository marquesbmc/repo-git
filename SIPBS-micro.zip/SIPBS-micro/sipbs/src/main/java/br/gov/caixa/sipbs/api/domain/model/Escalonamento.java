package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWF02_ESCALONAMENTO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWF02_ESCALONAMENTO")
public class Escalonamento extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSF02")
	public Integer nuPbsf02;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_ESCALONAMENTO")
	public Date dtEscalonamento;

	@Column(name="NU_COMPETENCIA")
	public Integer nuCompetencia;

	@Column(name="NU_DV_NIS")
	public Short nuDvNis;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;

}