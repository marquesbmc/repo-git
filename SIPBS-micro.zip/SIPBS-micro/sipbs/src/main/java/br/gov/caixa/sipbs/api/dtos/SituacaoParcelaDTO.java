package br.gov.caixa.sipbs.api.dtos;

import java.sql.Timestamp;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class SituacaoParcelaDTO {

	public String deSituacaoParcela;
	public String icImpeditivoSaque;
	public Long nuEventoPbsa12;
	public Short nuSituacaoParcela;
	public Timestamp tsFimVigencia;
	public Timestamp tsIdVigencia;
	public Timestamp tsInicioVigencia;

}
