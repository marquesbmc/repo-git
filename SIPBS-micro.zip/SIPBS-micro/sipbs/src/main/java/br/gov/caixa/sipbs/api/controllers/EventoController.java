package br.gov.caixa.sipbs.api.controllers;

import java.net.URI;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.jboss.resteasy.annotations.jaxrs.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import br.gov.caixa.sipbs.api.domain.exception.EntidadeNaoEncontradaException;
import br.gov.caixa.sipbs.api.domain.service.EventoService;
import br.gov.caixa.sipbs.api.dtos.EventoDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;
import br.gov.caixa.sipbs.api.retorno.RetornoPaginado;

@Path("/api/evento/v1")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
@Transactional
@OpenAPIDefinition(info = @Info(description = "Conjunto de endpoints para manutenção dos eventos", title = "Eventos", version="1.0"))
public class EventoController extends Controller<EventoDTO, ResponseEntity<?>> {

	@Autowired
	EventoService service;
	
	@GET
	public ResponseEntity<?> listAll() {
		try {
			List<EventoDTO> lista = service.listAll();
			if (lista != null) {
				return ResponseEntity.ok(lista);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}
	
	@GET
	@Path("/pagina/{pagina}")
	public ResponseEntity<?>listPag(@PathParam int pagina) {
		try {
			List<EventoDTO> lista = service.listPag(pagina, qtdPorPagina);
			Long total = service.count();
			
			RetornoPaginado<EventoDTO> paginado = new RetornoPaginado<EventoDTO>(lista, total, pagina, qtdPorPagina);
			
			if (lista != null) {
				return ResponseEntity.ok(paginado);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@GET
	@Path("/pagina/{pagina}/{qtdPorPagina}")
	public ResponseEntity<?> listPag(@PathParam int pagina, @PathParam int qtdPorPagina) {
		try {
			List<EventoDTO> lista = service.listPag(pagina, qtdPorPagina);
			Long total = service.count();
			
			RetornoPaginado<EventoDTO> paginado = new RetornoPaginado<EventoDTO>(lista, total, pagina, qtdPorPagina);
			
			if (lista != null) {
				return ResponseEntity.ok(paginado);
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}
	
	@GET
	@Path("/{id}")
	public ResponseEntity<?> findById(@PathParam Long id) {
		try {
			EventoDTO dto = service.findById(id);
			if (dto != null) {
				return ResponseEntity.ok(dto);
			}
			throw new AppException(HttpStatus.NOT_FOUND, "Registro com o id " + id + " não existe.");
		} catch (EntidadeNaoEncontradaException e) {
			throw new AppException(e.getCode(), e.getMessage());
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@POST
	public ResponseEntity<?> create(EventoDTO request) {
		try {
			EventoDTO dto = service.create(request);
			return ResponseEntity.created(URI.create("/api/evento/" + dto.getId())).build();			
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@PUT
	@Path("/{id}")
	public ResponseEntity<?> update(@PathParam Long id, EventoDTO request) {
		try {
			EventoDTO dto = service.update(id, request);
			return ResponseEntity.ok(dto);		
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

	@DELETE
	@Path("/{id}")
	public ResponseEntity<?> delete(@PathParam Long id) {
		try {
			service.delete(id);
			return ResponseEntity.noContent().build();			
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

}