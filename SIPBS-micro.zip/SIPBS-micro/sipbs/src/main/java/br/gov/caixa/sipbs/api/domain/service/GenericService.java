package br.gov.caixa.sipbs.api.domain.service;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.persistence.EntityManager;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Value;

@ApplicationScoped
public class GenericService {

	@Value("${paginacao.qtd_por_pagina}")
	int qtdPorPagina;

	@Inject
	EntityManager emDb2;

	private static ModelMapper modelMapper = new ModelMapper();

	static {
		modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
	}

	/**
	 * Responsavel por fazer um parse de um objeto de acordo com o tipo especificado
	 * 
	 * @param <D>        tipo de objeto de resultante
	 * @param <T>        tipo de objeto de origem
	 * @param objEntrada objeto de entrada para conversão
	 * @param tipoSaida  tido de saída
	 * @return objeto gerado a partir do tipo especificado.
	 */
	public static <D, T> D map(final T objEntrada, Class<D> tipoSaida) {
		return modelMapper.map(objEntrada, tipoSaida);
	}

	/**
	 * Responsável por fazer um parse de uma lista de acordo com o tipo especificado
	 *
	 *
	 * @param lista     a ser mapeadas
	 * @param tipoSaida tido de saída
	 * @param <D>       tipo da lista resultante
	 * @param <T>       tipo da lista de entrada
	 **/
	public static <D, T> List<D> mapAll(final Collection<T> lista, Class<D> tipoSaida) {
		return lista.stream().map(entity -> map(entity, tipoSaida)).collect(Collectors.toList());
	}

	/**
	 * Mapeia {@code source} para {@code destination}.
	 *
	 * Objeto de origem @param para mapear objeto de destino @param para mapear
	 */
	public static <S, D> D map(final S origem, D destino) {
		modelMapper.map(origem, destino);
		return destino;
	}

	@Provider
	public static class ErrorMapper implements ExceptionMapper<Exception> {
		@Override
		public Response toResponse(Exception exception) {
			int code = 500;
			if (exception instanceof WebApplicationException) {
				code = ((WebApplicationException) exception).getResponse().getStatus();
			}
			return Response.status(code)
					.entity(Json.createObjectBuilder().add("error", exception.getMessage()).add("code", code).build())
					.build();
		}
	}

	protected int calcularNumeroPagina(int pagina) {
		if (pagina < 1) {
			return 0;
		}
		return (pagina - 1) * qtdPorPagina;
	}
}
