package br.gov.caixa.sipbs.api.domain.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB06_CONTA_CREDITO")
public class ContaCredito extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSB06")
	public Integer nuPbsb06;

	@Column(name="NU_AGENCIA")
	public Short nuAgencia;

	@Column(name="NU_BANCO")
	public Short nuBanco;

	@Column(name="NU_REFERENCIA")
	public Integer nuReferencia;

	@Column(name="NU_CONTA")
	public Long nuConta;

	@Column(name="NU_CPF_TITULAR")
	public Long nuCpfTitular;

	@Column(name="NU_DV_AGENCIA")
	public Short nuDvAgencia;

	@Column(name="NU_DV_CONTA")
	public Short nuDvConta;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_PROPRIEDADE_CONTA_PBSB21", referencedColumnName = "NU_PROPRIEDADE_CONTA")
	public PropriedadeConta propriedadeConta;
}
