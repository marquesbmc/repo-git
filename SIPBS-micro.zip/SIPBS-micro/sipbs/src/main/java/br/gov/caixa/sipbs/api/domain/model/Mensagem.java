package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB10_MENSAGEM database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB10_MENSAGEM")
public class Mensagem extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSB10")
	public Integer nuPbsb10;

	@Column(name="DE_MENSAGEM")
	public String deMensagem;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_FIM_IMPRESSAO")
	public Date dtFimImpressao;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_INICIO_IMPRESSAO")
	public Date dtInicioImpressao;

	@Column(name="IC_SITUACAO")
	public String icSituacao;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PRIORIDADE")
	public Short nuPrioridade;

	@Column(name="NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name="NU_TIPO_MENSAGEM_PBSB12")
	public Short nuTipoMensagemPbsb12;

	@Column(name="QT_MAXIMA_IMPRESSAO")
	public Short qtMaximaImpressao;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;

}