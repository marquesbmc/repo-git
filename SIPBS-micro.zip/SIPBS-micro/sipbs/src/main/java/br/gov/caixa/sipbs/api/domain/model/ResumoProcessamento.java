package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWD05_RESUMO_PROCESSAMENTO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWD05_RESUMO_PROCESSAMENTO")
public class ResumoProcessamento extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSD05")
	public Long nuPbsd05;

	@Column(name="CONTEUDO_LINHA")
	public String conteudoLinha;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_LINHA")
	public Integer nuLinha;

	@Column(name="NU_PBSD03")
	public Long nuPbsd03;

}