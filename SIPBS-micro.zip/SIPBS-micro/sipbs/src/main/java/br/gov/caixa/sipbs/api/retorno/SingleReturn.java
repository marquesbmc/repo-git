package br.gov.caixa.sipbs.api.retorno;

public class SingleReturn<T> extends Retorno {

	private T data;

	public SingleReturn(T data) {
		super();
		this.data = data;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
}