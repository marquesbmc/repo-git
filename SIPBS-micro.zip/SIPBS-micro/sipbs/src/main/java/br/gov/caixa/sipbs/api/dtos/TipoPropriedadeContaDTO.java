package br.gov.caixa.sipbs.api.dtos;

import java.sql.Timestamp;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor

public class TipoPropriedadeContaDTO {

	public Short nuTipoPrpreConta;
	public String sgTipoPropriedadeConta;
	public String deTipoPropriedadeConta;
	public String coCifAtivacao;
	public String coCifDesativacao;
	public Long nuEventoPbsa12;
	public Short nuPropriedadeContaSegmento;
	public Short nuSegmentoIcos12;
	public Timestamp tsFimVigencia;
	public Timestamp tsIdVigencia;
	public Timestamp tsInicioVigencia;
}
