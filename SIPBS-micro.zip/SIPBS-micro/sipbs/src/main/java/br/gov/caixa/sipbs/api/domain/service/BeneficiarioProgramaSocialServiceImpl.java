package br.gov.caixa.sipbs.api.domain.service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import br.gov.caixa.sipbs.api.domain.dao.MarcasImpeditivasDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.BeneficiarioProgramaSocial;
import br.gov.caixa.sipbs.api.domain.model.MarcacaoDesmarcacaoConta;
import br.gov.caixa.sipbs.api.domain.model.MarcasImpeditivas;
import br.gov.caixa.sipbs.api.domain.model.OposicaoTipoConta;
import br.gov.caixa.sipbs.api.domain.repository.panache.BeneficiarioProgramaSocialPanacheRepository;
import br.gov.caixa.sipbs.api.domain.repository.panache.MarcacaoDesmarcacaoContaPanacheRepository;
import br.gov.caixa.sipbs.api.dtos.BeneficiarioProgramaSocialDTO;
import br.gov.caixa.sipbs.api.dtos.MarcasImpeditivasDTO;
import br.gov.caixa.sipbs.api.dtos.OposicaoTipoContaDTO;
import br.gov.caixa.sipbs.api.enums.CriterioContaPropriedadeEnum;

@ApplicationScoped
public class BeneficiarioProgramaSocialServiceImpl extends GenericService implements BeneficiarioProgramaSocialService {

	@Inject
	BeneficiarioProgramaSocialPanacheRepository beneficiarioProgramaSocialPanacheRepository;

	@Inject
	MarcacaoDesmarcacaoContaPanacheRepository marcacaoDesmarcacaoContaPanacheRepository;

	@Inject
	MarcasImpeditivasDAO marcasImpeditivasDAO;


	@Override
	public List<BeneficiarioProgramaSocialDTO> listFilter(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException {
		List<BeneficiarioProgramaSocial> beneficiarioProgramaSocialList = beneficiarioProgramaSocialPanacheRepository.listFilter(icCpfNis, nuCpfNis, nuProdutoIcoo10);

		for (BeneficiarioProgramaSocial beneficiarioProgramaSocial : beneficiarioProgramaSocialList) {

			List<MarcacaoDesmarcacaoConta> marcacaoDesmarcacaoContaList = marcacaoDesmarcacaoContaPanacheRepository.listFilter(
					beneficiarioProgramaSocial.getProgramaSocial().getNuProdutoIcoo10(),beneficiarioProgramaSocial.getContaCredito().getNuPbsb06(),
					beneficiarioProgramaSocial.getBeneficiarioSocial().getNuPbsb05());

			if (!marcacaoDesmarcacaoContaList.isEmpty()) {
				MarcacaoDesmarcacaoConta _marcacaoDesmarcacaoConta = marcacaoDesmarcacaoContaList.get(0);
				if (_marcacaoDesmarcacaoConta.getIcCriterioContaPropriedade() != null) {
					CriterioContaPropriedadeEnum criterioContaPropriedadeEnum = CriterioContaPropriedadeEnum.consultarPorCodigo(Integer.valueOf(_marcacaoDesmarcacaoConta.getIcCriterioContaPropriedade()));

					_marcacaoDesmarcacaoConta.setDeCriterioContaPropriedade(criterioContaPropriedadeEnum.getNome());
				}
				beneficiarioProgramaSocial.setMarcacaoDesmarcacaoConta(_marcacaoDesmarcacaoConta);
				beneficiarioProgramaSocial.getMarcacaoDesmarcacaoConta().setIsContaSelecionada(Boolean.FALSE);
			}
		}
		if(beneficiarioProgramaSocialList.size() > 0) {
			beneficiarioProgramaSocialList.sort(Comparator.comparing(BeneficiarioProgramaSocial::getDtSelecao, Comparator.nullsLast(Comparator.reverseOrder())));
			beneficiarioProgramaSocialList.get(0).getMarcacaoDesmarcacaoConta().setIsContaSelecionada(Boolean.TRUE);
		}
		return beneficiarioProgramaSocialList.stream().map(entity -> map(
				entity, BeneficiarioProgramaSocialDTO.class)).collect(Collectors.toList());
	}

	@Override
	public OposicaoTipoContaDTO findOposicaoCreditoConta(Long nuCpfBeneficiario, Short nuTipoConta, Short nuProdutoIcoo10) {
		List<OposicaoTipoConta> _oposicaoTipoContaList =  OposicaoTipoConta.list(
				"nuCpfBeneficiario = ?1 AND nuPropriedadeContaPbsb21 = ?2 AND nuProdutoPbsb02 = ?3",
				nuCpfBeneficiario, nuTipoConta, nuProdutoIcoo10);

		OposicaoTipoConta oposicaoTipoConta;
		if (_oposicaoTipoContaList.isEmpty()) {
			oposicaoTipoConta = new OposicaoTipoConta();
			oposicaoTipoConta.setIsPossuiOposicao(false);
		} else {
			oposicaoTipoConta = _oposicaoTipoContaList.get(0);
		}
		return map(oposicaoTipoConta, OposicaoTipoContaDTO.class);
	}

	@Override
	public List<MarcasImpeditivasDTO> listMarcasImpeditivas(Short nuProdutoIcoo10, Long nuCpfBeneficiario, Integer nuPbsb06) throws GeneralException {
		List<MarcasImpeditivas> marcasImpeditivas = marcasImpeditivasDAO.listarMarcasImpeditivas(nuProdutoIcoo10, nuCpfBeneficiario, nuPbsb06);

		return marcasImpeditivas.stream().map(entity -> map(entity, MarcasImpeditivasDTO.class)).collect(Collectors.toList());
	}

	@Override
	public List<BeneficiarioProgramaSocialDTO> listAll() {
		return null;
	}

	@Override
	public List<BeneficiarioProgramaSocialDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return null;
	}

	@Override
	public BeneficiarioProgramaSocialDTO findById(Long id) {
		return null;
	}

	@Override
	public BeneficiarioProgramaSocialDTO create(BeneficiarioProgramaSocialDTO request) {
		return null;
	}

	@Override
	public BeneficiarioProgramaSocialDTO update(Long id, BeneficiarioProgramaSocialDTO request) {
		return null;
	}

	@Override
	public void delete(Long id) {

	}

	@Override
	public Long count() {
		return null;
	}

	@Override
	public BeneficiarioProgramaSocialDTO searchBeneficiario(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException{
		List<BeneficiarioProgramaSocial> lista = beneficiarioProgramaSocialPanacheRepository.searchBeneficiario(icCpfNis, nuCpfNis, nuProdutoIcoo10);
		if(lista.size() > 0) {
			return map(lista.get(0), BeneficiarioProgramaSocialDTO.class);
		} else {
			return null;
		}
	}
}
