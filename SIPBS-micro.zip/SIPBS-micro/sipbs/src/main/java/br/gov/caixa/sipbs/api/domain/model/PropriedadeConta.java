package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB21_PROPRIEDADE_CONTA database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB21_PROPRIEDADE_CONTA")
public class PropriedadeConta extends PanacheEntityBase {

	@Id
	@Column(name="NU_PROPRIEDADE_CONTA")
	public Short nuPropriedadeConta;

	@Column(name="DE_PROPRIEDADE_PRODUTO")
	public String dePropriedadeProduto;

	@Column(name="NU_PROPRIEDADE_PRODUTO")
	public Short nuPropriedadeProduto;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NU_TIPO_CONTA_PBSB13", referencedColumnName = "NU_TIPO_CONTA")
	public TipoConta tipoConta;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;
}
