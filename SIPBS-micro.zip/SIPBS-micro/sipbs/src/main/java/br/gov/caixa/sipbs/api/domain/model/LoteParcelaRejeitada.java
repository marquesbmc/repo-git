package br.gov.caixa.sipbs.api.domain.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWR03_LOTE_PARCELA_REJEITADA")
public class LoteParcelaRejeitada extends PanacheEntityBase {

	@Id
	@Column(name = "NU_PBSR03")
	private Long nuPbsr03;

	@Column(name = "NU_PBSR02")
	private Long nuPbsr02;
	
	@Column(name="NO_ARQUIVO")
	private String nomeArquivoFisico;

	@Column(name="NU_PRODUTO_ICOO10")
	private Integer nuProgramaSocial;

	@Column(name = "NU_REFERENCIA")
	private Integer nuReferencia;

	@Column(name = "NU_REMESSA")
	private Integer nuRemessa;

	@Temporal(TemporalType.DATE)
	@Column(name = "DT_PROCESSAMENTO")
	private Date dtProcessamento;
	
	@Column(name="DE_MOTIVO_REJEICAO_REGISTRO")
	private String deTipoMotivoRejeicao;
	
	@Column(name = "QT_PARCELAS_REJEITADAS")
	private Long qtParcelasRejeitadas;

	@Column(name="VR_TOTAL_PARCELAS_REJEITADAS")
	private BigDecimal vrTotalParcelasRejeitadas;

}
