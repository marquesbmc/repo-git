package br.gov.caixa.sipbs.api.domain.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWO12_PARCELA_PAGAMENTO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWO12_PARCELA_PAGAMENTO")
public class ParcelaPagamento extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_FIM_VALIDADE_PARCELA")
	public Date dtFimValidadeParcela;

	@Temporal(TemporalType.DATE)
	@Column(name="DT_INICIO_VALIDADE_PARCELA")
	public Date dtInicioValidadeParcela;

	@Column(name="IC_CREDITO_CONTA")
	public String icCreditoConta;

	@Column(name="IC_GUIA_MUNICIPIO")
	public String icGuiaMunicipio;

	@Column(name="IC_SAQUE_CARTAO")
	public String icSaqueCartao;

	@Column(name="NU_BENEFICIO_SOCIAL_PBSB03")
	public Short nuBeneficioSocialPbsb03;

	@Column(name="NU_CNPJ")
	public BigDecimal nuCnpj;

	@Column(name="NU_COMPETENCIA_PARCELA")
	public Integer nuCompetenciaParcela;

	@Column(name="NU_EXTERNO_PRCLA_PGMNO")
	public Long nuExternoPrclaPgmno;

	@Column(name="NU_FAMILIA")
	public Long nuFamilia;

	@Column(name="NU_LOCALIDADE_ICOL08")
	public Integer nuLocalidadeIcol08;

	@Column(name="NU_NIS_DEPENDENTE")
	public Long nuNisDependente;

	@Column(name="NU_PBSB04")
	public Long nuPbsb04;

	@Column(name="NU_PBSB05")
	public Integer nuPbsb05;

	@Column(name="NU_PBSB10")
	public Integer nuPbsb10;

	@Column(name="NU_PBSD03")
	public Long nuPbsd03;

	@Column(name="NU_PBSO12")
	public Long nuPbso12;

	@Column(name="NU_PRODUTO_PBSB02")
	public Short nuProdutoPbsb02;

	@Column(name="NU_PROPRIEDADE_CONTA_PBSTBB21")
	public Short nuPropriedadeContaPbstbb21;

	@Column(name="NU_REFERENCIA")
	public Integer nuReferencia;

	@Column(name="NU_SITUACAO_PARCELA_PBSO13")
	public Short nuSituacaoParcelaPbso13;

	@Column(name="TS_ATUALIZACAO")
	public Timestamp tsAtualizacao;

	@Column(name="VR_PARCELA")
	public BigDecimal vrParcela;

}