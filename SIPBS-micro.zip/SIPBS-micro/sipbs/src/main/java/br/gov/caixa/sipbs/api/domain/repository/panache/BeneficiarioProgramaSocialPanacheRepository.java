package br.gov.caixa.sipbs.api.domain.repository.panache;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.BeneficiarioProgramaSocial;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class BeneficiarioProgramaSocialPanacheRepository implements PanacheRepository<BeneficiarioProgramaSocial> {

	private static final Logger LOGGER = LoggerFactory.getLogger(BeneficiarioProgramaSocialPanacheRepository.class);

	public List<BeneficiarioProgramaSocial> listFilter(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException {

		LOGGER.info("Chamando método listFilter com os parâmetros" + icCpfNis + " - " + nuCpfNis + " - " + nuProdutoIcoo10);
		try {
			String sql = "SELECT beneficiarioPrograma " +
					"       FROM BeneficiarioProgramaSocial  beneficiarioPrograma " +
					"           JOIN FETCH beneficiarioPrograma.beneficiarioSocial beneficiarioSocial  " +
					"           JOIN FETCH beneficiarioPrograma.contaCredito contaCredito  " +
					"           JOIN FETCH contaCredito.propriedadeConta propriedadeConta  " +
					"           JOIN FETCH propriedadeConta.tipoConta tipoConta  " +
					"       WHERE 0 = 0  " +
					"       AND beneficiarioPrograma.programaSocial.nuProdutoIcoo10 = ?1";
			if (icCpfNis.equals("C")) {
				sql = sql + "   AND beneficiarioSocial.nuCpfBeneficiario = ?2  ";
			} else {
				sql = sql + "   AND beneficiarioSocial.nuNisBeneficiario = ?2  ";
			}
			return BeneficiarioProgramaSocial.list(sql, nuProdutoIcoo10, nuCpfNis);
		} catch (Exception e) {
			LOGGER.error("Erro em " + "Chamando método listFilter com os parâmetros", e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}
	
	public List<BeneficiarioProgramaSocial> searchBeneficiario(String icCpfNis, Long nuCpfNis, Short nuProdutoIcoo10) throws GeneralException{
		LOGGER.info("Chamando método searchBeneficiario com os parâmetros" + icCpfNis + " - " + nuCpfNis + " - " + nuProdutoIcoo10);
		try {
			String sql = "SELECT beneficiarioPrograma " +
					"       FROM BeneficiarioProgramaSocial  beneficiarioPrograma " +
					"           JOIN FETCH beneficiarioPrograma.beneficiarioSocial beneficiarioSocial  " +
					"       WHERE 0 = 0 " +
					" 		AND beneficiarioPrograma.programaSocial.nuProdutoIcoo10 = ?1";
			if (icCpfNis.equals("C")) {
				sql = sql + "   AND beneficiarioSocial.nuCpfBeneficiario = ?2  ";
			} else {
				sql = sql + "   AND beneficiarioSocial.nuNisBeneficiario = ?2  ";
			}
			return BeneficiarioProgramaSocial.list(sql, nuProdutoIcoo10, nuCpfNis);
		}
		catch (Exception e) {
			LOGGER.error("Erro em " + "Chamando método searchBeneficiario com os parâmetros", e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}
}
