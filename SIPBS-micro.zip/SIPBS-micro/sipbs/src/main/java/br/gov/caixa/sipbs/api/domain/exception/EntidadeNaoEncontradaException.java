package br.gov.caixa.sipbs.api.domain.exception;

public class EntidadeNaoEncontradaException extends RuntimeException {

	private static final long serialVersionUID = 2305139830782243945L;

	private final transient String message;
	private final transient int code;
	private transient Exception error;

	public static final EntidadeNaoEncontradaException RESPONSE_CODE_ERROR_NO_ENTITY_FOUND = new EntidadeNaoEncontradaException(350, "Não foi possível encontrar o registro através do indentificador informado");

	/**
	 * @param code
	 * @param message
	 */
	public EntidadeNaoEncontradaException(int code, String message) {
		super();
		this.message = message;
		this.code = code;
	}

	/**
	 * @param code
	 * @param message
	 * @param error
	 */
	public EntidadeNaoEncontradaException(int code, String message, Exception error) {
		super();
		this.message = message;
		this.code = code;
		this.error = error;
	}

	/**
	 * @param general
	 * @param args
	 */
	public EntidadeNaoEncontradaException(EntidadeNaoEncontradaException general, String[] args) {
		super();
		this.message = String.format(general.getMessage(), (Object[]) args);
		this.code = general.getCode();
	}

	/**
	 * @param general
	 * @param args
	 * @param cause
	 */
	public EntidadeNaoEncontradaException(EntidadeNaoEncontradaException general, String[] args, Exception cause) {
		super(cause);
		this.message = String.format(general.getMessage(), (Object[]) args);
		this.code = general.getCode();
	}

	/**
	 * @param general
	 * @param arg
	 */
	public EntidadeNaoEncontradaException(EntidadeNaoEncontradaException general, String arg) {
		super();
		this.message = String.format(general.getMessage(), arg);
		this.code = general.getCode();
	}

	/**
	 * @param general
	 * @param arg
	 * @param cause
	 */
	public EntidadeNaoEncontradaException(EntidadeNaoEncontradaException general, String arg, Exception cause) {
		super(cause);
		this.message = String.format(general.getMessage(), arg);
		this.code = general.getCode();
	}

	/**
	 * @param general
	 */
	public EntidadeNaoEncontradaException(EntidadeNaoEncontradaException general) {
		super();
		this.message = general.getMessage();
		this.code = general.getCode();
	}

	/**
	 * @param general
	 * @param cause
	 */
	public EntidadeNaoEncontradaException(EntidadeNaoEncontradaException general, Exception cause) {
		super(cause);
		this.message = general.getMessage();
		this.code = general.getCode();
	}

	public String getMessage() {
		return message;
	}

	public int getCode() {
		return code;
	}

	public Exception getError() {
		return error;
	}

}
