package br.gov.caixa.sipbs.api.domain.service;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.ProgramaSocialDTO;

import java.util.List;

public interface ProgramaSocialService {

	List<ProgramaSocialDTO> listAll();

	List<ProgramaSocialDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException;

	ProgramaSocialDTO findById(Long id);

	ProgramaSocialDTO create(ProgramaSocialDTO request);

	ProgramaSocialDTO update(Long id, ProgramaSocialDTO request);

	void delete(Long id);

	Long count();
}
