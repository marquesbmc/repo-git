package br.gov.caixa.sipbs.api.dtos;

@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
public class CriterioPriorizacaoSelecaoContaDTO {

	public Short nuCriterioPriorizacao;
	public String noCriterioPriorizacao;
}
