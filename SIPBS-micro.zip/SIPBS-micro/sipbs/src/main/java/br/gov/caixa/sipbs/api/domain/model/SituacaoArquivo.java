package br.gov.caixa.sipbs.api.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWD06_SITUACAO_ARQUIVO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWD06_SITUACAO_ARQUIVO")
public class SituacaoArquivo extends PanacheEntityBase {

	@Id
	@Column(name="NU_SITUACAO_ARQUIVO")
	public Short nuSituacaoArquivo;

	@Column(name="DE_SITUACAO_ARQUIVO")
	public String deSituacaoArquivo;

}