package br.gov.caixa.sipbs.api.domain.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.dtos.PagamentoCanalDTO;
import br.gov.caixa.sipbs.api.dtos.RelatorioSinteticoLoteParcelaDTO;

public interface LoteParcelaService {

	List<PagamentoCanalDTO> listAll();

	List<PagamentoCanalDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException;

	RelatorioSinteticoLoteParcelaDTO recuperarRelatorioSinteticoLoteParcela(Short nuProdutoIcoo10, Long nuPbsr02, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException;
	
	ByteArrayOutputStream exportarRelatorioSinteticoLoteParcela(Short nuProdutoIcoo10, Long nuPbsr02, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException, IOException;

	PagamentoCanalDTO findById(Long id);

	PagamentoCanalDTO create(PagamentoCanalDTO request);

	PagamentoCanalDTO update(Long id, PagamentoCanalDTO request);

	void delete(Long id);

	Long count();
}
