package br.gov.caixa.sipbs.api.domain.dao;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.PagamentoCanal;
import br.gov.caixa.sipbs.api.domain.model.ProgramaSocial;
import br.gov.caixa.sipbs.api.domain.model.TipoCanal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class PagamentoCanalDAO extends GenericDAO<PagamentoCanal> {

	private static final Logger LOGGER = LoggerFactory.getLogger(PagamentoCanalDAO.class);

	@SuppressWarnings({"unchecked"})
	public List<PagamentoCanal> recuperarRelatorioSinteticoPagamentoCanal(Short nuProdutoIcoo10, LocalDate dtInicioPeriodo, LocalDate dtFimPeriodo) throws GeneralException {

		LOGGER.info("Chamando método recuperarRelatorioSinteticoPagamentoCanal com os parâmetros " + nuProdutoIcoo10
				+ " - " + dtInicioPeriodo + " - " + dtFimPeriodo);

		try {
			List<PagamentoCanal> pagamentoCanalList = new ArrayList<>();

			String sql = "SELECT pagamentoCanal.programaSocial.nuProdutoIcoo10," +
					"               pagamentoCanal.tipoCanal.nuTipoCanal," +
					"               pagamentoCanal.tipoCanal.deTipoCanal," +
					"               SUM(pagamentoCanal.qtTotalPagamentos)," +
					"               SUM(pagamentoCanal.vrTotalPagamentos)" +
					"       FROM PagamentoCanal pagamentoCanal" +
					"       WHERE pagamentoCanal.programaSocial.nuProdutoIcoo10 = :nuProdutoIcoo10" +
					"           AND pagamentoCanal.dtPagamento BETWEEN DATE('"+ dtInicioPeriodo + "') AND DATE('" + dtFimPeriodo + "')" +
					"       GROUP BY pagamentoCanal.programaSocial.nuProdutoIcoo10," +
					"                pagamentoCanal.tipoCanal.nuTipoCanal,"  +
					"                pagamentoCanal.tipoCanal.deTipoCanal";

			Query query = emDb2.createQuery(sql);
			query.setParameter("nuProdutoIcoo10", nuProdutoIcoo10);

			List<Object[]> resultList = query.getResultList();

			PagamentoCanal pagamentoCanal;
			for ( Object[] object : resultList) {
				int cont = 0;
				pagamentoCanal = new PagamentoCanal();
				pagamentoCanal.setProgramaSocial(new ProgramaSocial());
				pagamentoCanal.getProgramaSocial().setNuProdutoIcoo10(Short.valueOf(object[cont++] + ""));
				pagamentoCanal.setTipoCanal(new TipoCanal());
				pagamentoCanal.getTipoCanal().setNuTipoCanal(Short.valueOf(object[cont++] + ""));
				pagamentoCanal.getTipoCanal().setDeTipoCanal(object[cont++] + "");
				pagamentoCanal.setQtTotalPagamentos(Long.valueOf(object[cont++] + ""));
				pagamentoCanal.setVrTotalPagamentos((BigDecimal) object[cont]);

				pagamentoCanalList.add(pagamentoCanal);

			}
			return pagamentoCanalList;
		} catch (Exception e) {
			LOGGER.error("Erro em " + "Chamando método recuperarRelatorioSinteticoPagamentoCanal com os parâmetros", e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}


	@Override
	public List<PagamentoCanal> listAll() throws GeneralException {
		return null;
	}

	@Override
	public List<PagamentoCanal> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return null;
	}

	@Override
	public PagamentoCanal findById(Long id) throws GeneralException {
		return null;
	}

	@Override
	public PagamentoCanal create(PagamentoCanal request) throws GeneralException {
		return null;
	}

	@Override
	public PagamentoCanal update(PagamentoCanal request) throws GeneralException {
		return null;
	}

	@Override
	public void delete(Long id) throws GeneralException {

	}

	@Override
	public Long count() throws GeneralException {
		return null;
	}
}
