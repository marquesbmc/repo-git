package br.gov.caixa.sipbs.api.dtos;

import java.util.Date;

public class ArquivoDTO {

	private Long id;
	private String nome;
	private Date inicio;
	private Date fim;
	private Long idSiacc;
	private Long idNsgd;
	private Long idTipoInterface;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getInicio() {
		return inicio;
	}

	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}

	public Date getFim() {
		return fim;
	}

	public void setFim(Date fim) {
		this.fim = fim;
	}

	public Long getIdSiacc() {
		return idSiacc;
	}

	public void setIdSiacc(Long idSiacc) {
		this.idSiacc = idSiacc;
	}

	public Long getIdNsgd() {
		return idNsgd;
	}

	public void setIdNsgd(Long idNsgd) {
		this.idNsgd = idNsgd;
	}

	public Long getIdTipoInterface() {
		return idTipoInterface;
	}

	public void setIdTipoInterface(Long idTipoInterface) {
		this.idTipoInterface = idTipoInterface;
	}
	
}