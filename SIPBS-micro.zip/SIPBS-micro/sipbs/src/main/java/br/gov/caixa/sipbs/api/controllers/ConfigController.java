package br.gov.caixa.sipbs.api.controllers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import br.gov.caixa.sipbs.api.exceptionhandler.AppException;
import io.vertx.core.json.JsonObject;

@Path("/api/config")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
@Transactional
@OpenAPIDefinition(info = @Info(description = "Responsável por disponibilizar o endpoint que fornece as configurações da aplicação", title = "Configurações da Aplicação", version = "1.0"))
public class ConfigController {

	@GET
	public ResponseEntity<?> listAll() {
		try {
			JsonObject jsonProperties = new JsonObject();
			Iterable<String> propertyNames = ConfigProvider.getConfig().getPropertyNames();
			List<String> propriedades = new ArrayList<String>();
			propertyNames.forEach(propriedades::add);
			Collections.sort(propriedades);
			for (String chave : propriedades) {
				Optional<String> valor = ConfigProvider.getConfig().getOptionalValue(chave, String.class);
				jsonProperties.put(chave, valor.orElse("Não se aplica"));
			}

			return ResponseEntity.ok(jsonProperties);
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}
}