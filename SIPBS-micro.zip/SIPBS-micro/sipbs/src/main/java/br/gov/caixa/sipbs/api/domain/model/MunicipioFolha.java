package br.gov.caixa.sipbs.api.domain.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWF06_MUNICIPIO_FOLHA database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWF06_MUNICIPIO_FOLHA")
public class MunicipioFolha extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSF06")
	public Integer nuPbsf06;

	@Column(name="IC_BLOQUEIO_FOLHA")
	public String icBloqueioFolha;

	@Column(name="NU_CNPJ")
	public BigDecimal nuCnpj;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_LOCALIDADE_ICOL08")
	public Integer nuLocalidadeIcol08;

	@Column(name="NU_PBSB10")
	public Integer nuPbsb10;

	@Column(name="NU_PBSF04")
	public Integer nuPbsf04;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}