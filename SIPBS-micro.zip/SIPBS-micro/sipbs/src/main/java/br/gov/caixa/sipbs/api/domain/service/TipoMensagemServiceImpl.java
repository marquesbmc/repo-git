package br.gov.caixa.sipbs.api.domain.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.springframework.http.HttpStatus;

import br.gov.caixa.sipbs.api.domain.dao.TipoMensagemDAO;
import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.TipoMensagem;
import br.gov.caixa.sipbs.api.domain.repository.panache.TipoMensagemPanacheRepository;
import br.gov.caixa.sipbs.api.dtos.TipoMensagemDTO;
import br.gov.caixa.sipbs.api.exceptionhandler.AppException;

@ApplicationScoped
public class TipoMensagemServiceImpl extends GenericService implements TipoMensagemService {

	@Inject
	TipoMensagemPanacheRepository repository;

	@Inject
	TipoMensagemDAO dao;	

	public List<TipoMensagemDTO> findAllRepository() {
		return repository.findAll().stream().map(entity -> map(entity, TipoMensagemDTO.class))
				.collect(Collectors.toList());
	}

	public List<TipoMensagemDTO> findAllPanache() {
		return TipoMensagem.<TipoMensagem>streamAll().map(entity -> map(entity, TipoMensagemDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<TipoMensagemDTO> listAll() throws GeneralException {
		return dao.listAll().stream().map(entity -> map(entity, TipoMensagemDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<TipoMensagemDTO> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		return dao.listPag(pagina, qtdPorPagina).stream().map(entity -> map(entity, TipoMensagemDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public TipoMensagemDTO findById(Long id) throws GeneralException {
		TipoMensagem tipoMensagem = dao.findById(id);
		if (tipoMensagem == null) {
			throw new AppException(HttpStatus.NOT_FOUND, "TipoMensagem com o id " + id + " não existe.");
		}
		return map(tipoMensagem, TipoMensagemDTO.class);
	}

	@Override
	public TipoMensagemDTO create(TipoMensagemDTO request) throws GeneralException {
		TipoMensagem tipoMensagem = dao.findByName(request.getNome());
		if (tipoMensagem != null) {
			throw new AppException(HttpStatus.UNPROCESSABLE_ENTITY,
					"Já existe um tipoMensagem com o nome " + request.getNome() + " na base.");
		}
		TipoMensagem novoTipoMensagem = dao.create(map(request, TipoMensagem.class));
		return map(novoTipoMensagem, TipoMensagemDTO.class);
	}

	@Override
	public TipoMensagemDTO update(Long id, TipoMensagemDTO request) throws GeneralException {
		TipoMensagem tipoMensagemAtualizado = dao.update(map(request, TipoMensagem.class));
		return map(tipoMensagemAtualizado, TipoMensagemDTO.class);
	}

	@Override
	public void delete(Long id) throws GeneralException {
		dao.delete(id);
	}

	@Override
	public Long count() throws GeneralException {
		return dao.count();
	}
}