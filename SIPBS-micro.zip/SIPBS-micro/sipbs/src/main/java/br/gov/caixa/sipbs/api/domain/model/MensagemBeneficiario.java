package br.gov.caixa.sipbs.api.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;


/**
 * The persistent class for the PBSVWB09_MENSAGEM_BENEFICIARIO database table.
 * 
 */
@lombok.Getter
@lombok.Setter
@lombok.NoArgsConstructor
@Entity
@Table(name="PBSVWB09_MENSAGEM_BENEFICIARIO")
public class MensagemBeneficiario extends PanacheEntityBase {
	
	@Id
	@Column(name="NU_PBSB09")
	public Long nuPbsb09;

	@Column(name="IC_ASSOCIACAO_ARQUIVO")
	public String icAssociacaoArquivo;

	@Column(name="IC_ATIVO")
	public String icAtivo;

	@Column(name="NU_EVENTO_PBSA12")
	public Long nuEventoPbsa12;

	@Column(name="NU_PBSB05")
	public Integer nuPbsb05;

	@Column(name="NU_PBSB10")
	public Integer nuPbsb10;

	@Column(name="QT_MENSAGEM")
	public Short qtMensagem;

	@Column(name="TS_FIM_VIGENCIA")
	public Timestamp tsFimVigencia;

	@Column(name="TS_ID_VIGENCIA")
	public Timestamp tsIdVigencia;

	@Column(name="TS_INICIO_VIGENCIA")
	public Timestamp tsInicioVigencia;
}