package br.gov.caixa.sipbs.api.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import javax.ws.rs.OPTIONS;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.retorno.Retorno;

/**
 * @author SIOGP
 */
public class Resource {
	
    private static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";

    private static final String ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";

    private static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

    @Context
    protected HttpHeaders header;
    
    private static final Logger LOGGER = LoggerFactory.getLogger(Resource.class);

    static ValidatorFactory factory;
    
    @Context
    protected HttpServletRequest request;
    
    @Context
    protected HttpSession session;
    
    @Context
    protected HttpSessionEvent event;
    
    static {
        factory = Validation.buildDefaultValidatorFactory();
    }
	
	protected static final String CREDENCIAL = "credencial";
	protected static final String TOKENACESSO = "tokenAcesso";
	protected static final String TOKENRENOVACAO = "tokenRenovacao";
	
	protected static final String NEW_CREDENCIAL = "new_credencial";
	protected static final String NEW_TOKENACESSO = "new_tokenAcesso";
	protected static final String NEW_TOKENRENOVACAO = "new_tokenRenovacao";
	

    protected String tokenJson;

	
    @OPTIONS
	@Path("{path : .*}")
	public Response options() {
		LOGGER.debug("options()");
	    return Response.ok("")
	            .header(ACCESS_CONTROL_ALLOW_ORIGIN, "*")
	            .header(ACCESS_CONTROL_ALLOW_HEADERS, "origin, content-type, accept, authorization")
	            .header(ACCESS_CONTROL_ALLOW_CREDENTIALS, "true")
	            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
	            .header("Access-Control-Max-Age", "1209600")
	            .build();
	}

	protected Response build(Status status, Object object) {
		return Response.status(status)
				.entity(object)
				.header(ACCESS_CONTROL_ALLOW_ORIGIN, "*" )
				.header(ACCESS_CONTROL_ALLOW_CREDENTIALS, "true")
				.header(ACCESS_CONTROL_ALLOW_HEADERS, "Origin, X-Request-Width, Content-Type, Accept")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
				.header("Access-Control-Max-Age", "1209600")
//				.header("Cache-Control", "no-cache, no-store, must-revalidate")
//				.header("Expires", 0)
//				.header("Pragma", "no-cache")
//				.header("X-Frame-Options", "DENY")
//				.header("X-XSS-Protection", "1")
                .build();
	}
	
	protected Response buildFile(Status status, Object object, String nomeArquivo) {
		return Response.status(status)
				.entity(object)
				.header(ACCESS_CONTROL_ALLOW_ORIGIN, "*")
				.header(ACCESS_CONTROL_ALLOW_CREDENTIALS, "true")
				.header(ACCESS_CONTROL_ALLOW_HEADERS, "Origin, X-Request-Width, Content-Type, Accept")
				.header("Content-Type", "application/pdf")
				.header("Content-Disposition", "attachment; filename="+ nomeArquivo +".pdf")
				.build();
	}
	
	protected Retorno getMensagemErro(final String msg){
		 Retorno retorno = new Retorno();

		 List<String> msgs = new ArrayList<String>();
		 msgs.add(msg);
		 retorno.setMsgsErro(msgs);
		 
		 return retorno;
	}
	
	protected Retorno montarRetorno(final String mensagem, Boolean temErro) {
		Retorno retorno = new Retorno();
		List<String> msgErro = new ArrayList<String>();

		msgErro.add(mensagem);
		retorno.setTemErro(temErro);
		retorno.setMsgsErro(msgErro);

		return retorno;
	}
	
}