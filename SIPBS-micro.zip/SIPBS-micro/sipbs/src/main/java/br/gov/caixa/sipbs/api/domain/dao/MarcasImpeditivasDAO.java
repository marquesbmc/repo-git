package br.gov.caixa.sipbs.api.domain.dao;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.caixa.sipbs.api.domain.exception.GeneralException;
import br.gov.caixa.sipbs.api.domain.model.MarcasImpeditivas;

@ApplicationScoped
public class MarcasImpeditivasDAO extends GenericDAO<MarcasImpeditivas> {

	private static final Logger LOGGER = LoggerFactory.getLogger(MarcasImpeditivasDAO.class);

	private static final String QRY_MARCACOES = new StringBuilder()
					.append( "    SELECT DISTINCT ")
					.append( "    B15.NU_PROPRIEDADE_CONTA_SEGMENTO AS ID, ")
					.append( "    B15.SG_TIPO_PROPRIEDADE_CONTA AS MARCA, ")
					.append( "    B15.DE_TIPO_PROPRIEDADE_CONTA AS DESCRICAO ")
					.append( " FROM PBSVWB18_OPOSICAO_TIPO_PROPRIEDADE_CONTA B18 ")
					.append( " INNER JOIN PBSVWB15_TIPO_PROPRIEDADE_CONTA B15 ON B15.NU_TIPO_PRPRE_CONTA = B18.NU_TIPO_PRPRE_CONTA_PBSB15 ")
					.append( " INNER JOIN PBSVWB16_PROPRIEDADE_CONTA_CREDITO B16 ON B16.NU_TIPO_PRPRE_CONTA_PBSB15 = B18.NU_TIPO_PRPRE_CONTA_PBSB15 ")
					.append( " INNER JOIN PBSVWB06_CONTA_CREDITO B06 ON B06.NU_PBSB06 = B16.NU_PBSB06 ")
					.append( " INNER JOIN PBSVWB02_PROGRAMA_SOCIAL B02 ON B02.NU_PRODUTO_ICOO10 = B18.NU_PRODUTO_PBSB02 ")
					.append( " INNER JOIN PBSVWB08_MARCACAO_DESMARCAO_CONTA B08 ON B08.NU_PRODUTO_PBSB02 = B02.NU_PRODUTO_ICOO10  ")
					.append( " INNER JOIN PBSVWB05_BENEFICIARIO_SOCIAL B05 ON B05.NU_PBSB05 = B08.NU_PBSB05 ")
					.append( " WHERE  ")
					.append( " B06.NU_PBSB06 = B08.NU_PBSB06 ")
					.append( " AND B18.NU_PRODUTO_PBSB02 = :idProduto ")
					.append( " AND B06.NU_PBSB06 = :idConta ")
					.append( " AND B05.NU_CPF_BENEFICIARIO = :cpf").toString();
		
	public List<MarcasImpeditivas> listarMarcasImpeditivas(Short nuProdutoIcoo10,
            Long nuCpfBeneficiario,
            Integer nuPbsb06) throws GeneralException {
		LOGGER.info("Chamando método consultarMarcasImpeditivas com os parâmetros -> " + nuProdutoIcoo10 + " - " + nuCpfBeneficiario + " - " + nuPbsb06);
		try {
			Query query = emDb2.createNativeQuery(QRY_MARCACOES, MarcasImpeditivas.class);
			query.setParameter("idProduto", nuProdutoIcoo10);
			query.setParameter("cpf", nuCpfBeneficiario);
			query.setParameter("idConta", nuPbsb06);
			return query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Erro no método consultarMarcasImpeditivas com os parâmetros -> " + nuProdutoIcoo10 + " - " + nuCpfBeneficiario + " - " + nuPbsb06, e);
			throw new GeneralException(GeneralException.RESPONSE_CODE_ERROR_FILEIO_FAIL, e);
		}
	}

	@Override
	public List<MarcasImpeditivas> listAll() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public List<MarcasImpeditivas> listPag(int pagina, int qtdPorPagina) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public MarcasImpeditivas findById(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public MarcasImpeditivas create(MarcasImpeditivas request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public MarcasImpeditivas update(MarcasImpeditivas request) throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void delete(Long id) throws GeneralException {
		// TODO Auto-generated method stub
		
	}



	@Override
	public Long count() throws GeneralException {
		// TODO Auto-generated method stub
		return null;
	}
}
