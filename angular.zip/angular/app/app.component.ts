import { HelloService } from './services/web-service/hello.service';
import { Component, OnInit, Inject } from '@angular/core';
import { LogService } from "./services/log/log.service";
import { NativeInterfaceService } from "./services/native-interface/native-interface.service";
import { ProfileService } from './services/profile/profile.service';
import { CentralCaixaService } from "./services/central/central-caixa.service";
import { ApplicationService } from './services/application/application.service';
import { WebServiceService } from './services/web-service/web-service.service';
import { Config } from "../environments/config";
import { Project } from "../environments/project";
import { CurrentView } from "../environments/currentview";
import { DOCUMENT } from '@angular/common';

let APP_NAME: string = Config.APP_NAME;
let CENTRAL_ID: string = Config.CENTRAL_ID;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {

  project = Project;
  theme = this.project.theme;

  constructor(@Inject(DOCUMENT) private document: any, private helloService: HelloService) { }

  ngOnInit() {
    this.document.getElementById('theme').setAttribute('href', './assets/css/' + this.theme.value );    	 

    //Teste de chamada a servico
    console.log('Chamando Serviço Hello...');
    this.helloService.hello().subscribe((retorno: any) => {
      console.log('Serviço Hello chamado com sucesso.');
      console.log(retorno);
    }, error => {
      console.log('Serviço Hello chamado com erro.');
      console.log(error);
    });
  }
}