import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/observable/from';
import { Config } from "../environments/config";

import { KeycloakService, KeycloakAuthGuard, KeycloakAngularModule } from 'keycloak-angular';


@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor(protected keycloak: KeycloakService) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        const token: string = localStorage.getItem('token');

        console.log('adding heder to request');

        console.log(token); 

        const headers: HttpHeaders = request.headers;

        console.log('URL====>'+request.url)
        
        console.log(request.url.includes(Config.ENDPOINT))
        

        if(!request.url.includes('http') || !request.url.includes('https')){
           const hedersWithAuthorization: HttpHeaders = headers.append('Authorization', 'Bearer ' + token);
           const requestWithAuthorizationHeader = request.clone({ headers: hedersWithAuthorization });
           return next.handle(requestWithAuthorizationHeader);
        } else {
          return next.handle(request);
        }
 
         
      }
}