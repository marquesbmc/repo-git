import { Component, OnInit } from '@angular/core';
import {NgbModal, NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-modal-input',
  templateUrl: './modal-input.component.html',
  styleUrls: ['./modal-input.component.css']
})
export class ModalInputComponent implements OnInit {
  required: boolean = false;
  title: string = null;
  message: string = null;
  inputValue: string = null;

  constructor(public activeModal: NgbActiveModal) {}

  ngOnInit() {
  }

}
