import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import {NgbModal, NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import { FeedbackService } from './../../services/feedback/feedback.service';
import { AlertService } from "../../services/alert/alert.service";

@Component({
  selector: 'app-modal-share',
  templateUrl: './modal-share.component.html',
  styleUrls: ['./modal-share.component.css']
})
export class ModalShareComponent implements OnInit {

  public onClose: Subject<boolean>;
  public onDismiss: Subject<boolean>;
  users;

  constructor(
    public activeModal: NgbActiveModal,
    private alertService: AlertService,
    private feedback: FeedbackService,
    private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    var vm = this;
    this.onClose = new Subject();
    this.onDismiss = new Subject();

    this.loadUsers();
  }

  loadUsers(onsuccess: Function = null, onfail: Function = null) {
    var vm = this;
    vm.users = [
      { 
        nome: 'Juca Fugi',
        email: 'jucaSssss@sdfsd.com'
      },
      { 
        nome: 'Juca Luja',
        email: 'jucaTtttt@sdfsd.com'
      },
      { 
        nome: 'Juca Gico',
        email: 'jucaGggggg@sdfsd.com'
      },
      { 
        nome: 'Juca Capi',
        email: 'jucaasdd@sdfsd.com'
      }
    ]
    /*function success(data) {
      vm.users = data;
      if (onsuccess) onsuccess(data);
    }
    function fail(message, code) {
      vm.alertService.showMessage("Atenção", code + " - " + message);
      if (onfail) onfail(message);
    }*/
  }

  setShare(user) {
    var vm = this;

    user.check = !user.check;
    /*if (user.compartilhado) {
      var sharedId = user.compartilhado;
    } else {
      var temEquipe = false;
      if (temEquipe){
      } else {
        vm.alertService.showMessage("Atenção", "Vincule uma equipe ao quadro para ativar o compartilhamento");
        user.compartilhado=false;
      }
    }*/
  }
}