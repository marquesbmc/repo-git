import { KeycloakService, KeycloakAuthGuard } from 'keycloak-angular';
import { WebServiceService } from './services/web-service/web-service.service';
import { environment } from '../environments/environment';

var token;

export function initializer(keycloak: KeycloakService, webservice: WebServiceService): () => Promise<any> {
  
  return (): Promise<any> => {
    return new Promise(async (resolve, reject) => {
      try {


          var url = environment.sso;
          var realm;

          realm = 'intranet';

          await keycloak.init({
            config: {
            url: url,
            realm: realm,
            clientId: 'cli-web-pbs-x'
          },
          initOptions: {
            onLoad: 'login-required',
            checkLoginIframe: false,
            flow: 'standard',
            responseMode: 'query',
          },
          loadUserProfileAtStartUp: false,
          bearerExcludedUrls: []
        });
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  };
}