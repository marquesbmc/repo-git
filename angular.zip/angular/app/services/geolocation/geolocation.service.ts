import { Injectable } from '@angular/core';
import { LogService } from "../../services/log/log.service";
//import {} from '@types/googlemaps';

const VERSION: string = '2.0.0';
declare var $ :any;

@Injectable()
export class GeolocationService {

  constructor(private log: LogService) { }

  version(): string {
    return VERSION;
  }

  localmap: any = null;
  infowindow: any = null;
  markers: any[] = [];
  scope: any = null;
  userlocation: any = null;
  path: any = null;

  private _getTitle(location) {
    var title = "";
    if (location.nome) title += "<strong>" + location.nome + "</strong>";
    if (location.data) title += "<br>Data: <strong>" + location.data + "</strong>"
    if (location.perimetro) title += "<br>Perímetro: <strong>" + location.perimetro + " metros</strong>"
    if (location.precisao) title += "<br>Precisão: <strong>" + location.precisao + " metros</strong>"
    if (location.distancia) title += "<br>Distância: <strong>" + location.distancia + " km</strong>"
    return title;
  }

  private _getId(location) {
    var id = "";
    if (location.id != null) id += location.id;
    if (location.nome) id += location.nome;
    if (location.nomeobra) id += location.nomeobra;
    if (id == "") {
      this.log.warning("get(): id is null for this location");
    }
    return id;
  }

  private _getMarker(id) {
    for (var j = 0; j < this.markers.length; j++) {
      var marker = this.markers[j];
      if (marker.id == id) return marker;
    }
    return null;
  }

  directDistance(lat1, lon1, lat2, lon2) {
    var radlat1 = Math.PI * lat1 / 180
    var radlat2 = Math.PI * lat2 / 180
    var radlon1 = Math.PI * lon1 / 180
    var radlon2 = Math.PI * lon2 / 180
    var theta = lon1 - lon2
    var radtheta = Math.PI * theta / 180
    var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
    dist = Math.acos(dist)
    dist = dist * 180 / Math.PI
    dist = dist * 60 * 1.1515
    dist = dist * 1.609344;
    return dist
  }

  setUserLocation(location) {
    this.userlocation = location;
  }
  getUserLocation() {
    return this.userlocation;
  }
  resetMap() {
    //this.clearMarkers();
    this.localmap = null;
    this.path = null;
  }

  loadMap(mapname) {
    this.log.debug("Geolocation.loadMap(" + mapname + ")");
    var perimeter = null;
    if (this.localmap) this.resetMap();

   var userLocation = this.getUserLocation();
    if (userLocation) {
      var lat = userLocation.latitude;
      var lng = userLocation.longitude;
      //var location = new google.maps.LatLng(lat, lng);
      //localmap.setCenter(location);
      this.localmap.panTo(location);
      this.localmap.setZoom(12);
    }
    return this.localmap;
  }
}