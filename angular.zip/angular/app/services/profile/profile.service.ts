import { Injectable } from '@angular/core';
import { WebServiceService } from "../web-service/web-service.service";
import { LogService } from "../log/log.service";
import { environment } from "../../../environments/environment";

const ENDPOINT_PROFILE = "ws/login/profile/";
const VERSION: string = '1.0.5';

@Injectable()
export class ProfileService {

  constructor(private log: LogService, private webservice: WebServiceService) { }

  private endpoint: string = environment.endpoint;

  private projectKey: string = null;
  private token: string = null;
  private environmentVar: string = null;
  private profile: string = null;
  private preferences = null;

  setProfile(profile: string) {
    this.profile = profile;
  }

  getProfile() {
    return this.profile;
  }

  public getPreference(name: string, onsuccess, onfail = null, environmentVar = null) {
    return this.getProfilePreference(this.profile, name, onsuccess, onfail, environmentVar)
  }

  public getProfilePreference(profile: string, name: string, onsuccess, onfail = null, environmentVar = null) {
    var vm = this;
    function success(res) {
      if (vm.preferences != null && res != null) {
        vm.preferences[name] = res.value;
      }

      if (onsuccess) onsuccess(res);
    }

    function fail(message, status) {
      if (onfail) onfail(message, status);
    }

    var thisEnvironment = vm.environmentVar;
    if (environmentVar != null) {
      thisEnvironment = environmentVar;
    }

    this.webservice.read(ENDPOINT_PROFILE + profile, success,fail);    
  }

  public setPreference(name: string, value, onsuccess = null, onfail = null, environmentVar = null) {
    return this.setProfilePreference(this.profile, name, value, onsuccess, onfail, environmentVar);
  }

  public setProfilePreference(profile: string, name: string, value, onsuccess = null, onfail = null, environmentVar = null) {
    var vm = this;
    if (vm.preferences != null) {
      vm.preferences[name] = value;
    }

    function success(res) {
      if (onsuccess) onsuccess(res);
    }

    function fail(message, status) {
      if (onfail) onfail(message, status);
    }

    var content = {
      profile: this.profile,
      name: name,
      value: value
    };

    var thisEnvironment = vm.environmentVar;
    if (environmentVar != null) {
      thisEnvironment = environmentVar;
    }

    this.webservice.create(ENDPOINT_PROFILE, content , success,fail);    
  }
}