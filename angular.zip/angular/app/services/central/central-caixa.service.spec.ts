import { TestBed, inject } from '@angular/core/testing';

import { CentralCaixaService } from './central-caixa.service';

describe('CentralCaixaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CentralCaixaService]
    });
  });

  it('should be created', inject([CentralCaixaService], (service: CentralCaixaService) => {
    expect(service).toBeTruthy();
  }));
});
