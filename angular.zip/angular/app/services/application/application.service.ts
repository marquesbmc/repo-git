import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Config } from "../../../environments/config";
import { AlertService }  from "../alert/alert.service";
import { Project } from "../../../environments/project";

const NAME: string = 'SIPBS';
const TITLE: string = 'Sistema Pagamento Beneficios';
const VERSION: string = '1.0.0';

@Injectable()
export class ApplicationService {

  app: any = null;
  project = Project;
  
  constructor(private router: Router, private route: ActivatedRoute, private alertService: AlertService) { }

  getParam(name: string, success) {
    this.route
      .queryParams
      .subscribe(params => {
        var result = params[name] || null;
        if (success) success(result);
      });      
  }

  getCurrentState = function(state) {
    if (!this.project || !this.project.views) return;

    for (var i in this.project.views) {
        var view = this.project.views[i];
        if (view.id == state.replace("/", "")) {
            return view;
        }
    }
    return {};
  }

  getState(): string {
      return this.router.url;
  }

  version(): string {
    return VERSION;
  }

  getTitle(): string {
    return TITLE;
  }

  getName(): string {
    return NAME;
  }

  getVersion(): string {
    return VERSION;
  }

  setApp(data) { 
    this.app = data;
  }
  getApp(): string {
    return this.app;
  }
  
  goHome() {
    this.openPage("/");
  }

  goAuth() {
    this.router.navigate(["auth"]);
  }  

  openPage(page,data = null) {
    console.log("openPage('" + page + "," + data +  "')");

    if (Config.authCode == null) {
      this.goAuth();
      return;
  	}
  
    if (data) {
      this.router.navigate([page, data]);
    } else {
      this.router.navigate([page]);
    }
  }
}