import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders,HttpParams,HttpErrorResponse } from '@angular/common/http';
import { LogService } from "../../services/log/log.service";
import { AlertService } from '../../services/alert/alert.service';
import { ApplicationService } from '../../services/application/application.service';
import { Config } from "../../../environments/config";
import { environment } from "../../../environments/environment";

const VERSION: string = '2.1.0';

@Injectable()
export class WebServiceService {

  constructor(private http: HttpClient, private log: LogService, private alertService: AlertService, private applicationService: ApplicationService) { }

  version(): string {
    return VERSION;
  }

  get(request: string, options, success, fail) {

    const headers = new HttpHeaders().set("authCode", Config.authCode);
    
    this.http.get(`${environment.endpoint}${request}`, {headers})
      .subscribe(data => {
        if (success) success(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          this.log.error(err.error.message, "Client-side error occured.");
          if (fail) fail(err.error.message);
        } else {
          this.log.error(err.message, "Server-side error occured.");
          if (fail) fail(err.message, err.status);
        }
      });
  }
  getAnalytics(request: string, options, success, fail) {

    this.http.get(`${request}`, options ? options : { headers: new HttpHeaders().set("authCode", Config.authCode) })
      .subscribe(data => {
        if (success) success(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          this.log.error(err.error.message, "Client-side error occured.");
          if (fail) fail(err.error.message);
        } else {
          this.log.error(err.message, "Server-side error occured.");
          if (fail) fail(err.message, err.status);
        }
      });
  }

  params() {    
    return new HttpParams();
  }

  post(request: string, body, params, success, fail) {
    this.http.post(`${environment.endpoint}${request}`, body,  params)
      .subscribe(data => {
        if (data && data['code'] == 603) {
          this.alertService.showWarning("Atenção","Sessão expirada. Reiniciando...");
          this.applicationService.openPage("/");
          return;
        }

        if (success) success(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          this.log.error(err.error.message, "Client-side error occured.");
          if (fail) fail(err.error.message);
        } else {
          this.log.error(err.message, "Server-side error occured.");
          if (fail) fail(err.message, err.status);
        }

      });
  }
  postAnalytics(request: string, body, params, success, fail) {
    this.http.post(`${request}`, body,  params)
      .subscribe(data => {
        if (data && data['code'] == 603) {
          this.alertService.showWarning("Atenção","Sessão expirada. Reiniciando...");
          this.applicationService.openPage("/");
          return;
        }

        if (success) success(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          this.log.error(err.error.message, "Client-side error occured.");
          if (fail) fail(err.error.message);
        } else {
          this.log.error(err.message, "Server-side error occured.");
          if (fail) fail(err.message, err.status);
        }

      });
  }

  put(request: string, body, options, success, fail) {
    this.http.put(`${environment.endpoint}${request}`, body, options)
      .subscribe(data => {
        if (success) success(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          this.log.error(err.error.message, "Client-side error occured.");
          if (fail) fail(err.error.message);
        } else {
          this.log.error(err.message, "Server-side error occured.");
          if (fail) fail(err.message, err.status);
        }

      });
  }

  delete(request: string, options, success, fail) {
    this.http.delete(`${environment.endpoint}${request}`, options)
      .subscribe(data => {
        if (success) success(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          this.log.error(err.error.message, "Client-side error occured.");
          if (fail) fail(err.error.message);
        } else {
          this.log.error(err.message, "Server-side error occured.");
          if (fail) fail(err.message, err.status);
        }

      });
  }

  read(request: string,  success, fail) {
    this.get(request, {}, success, fail);
  }
  create(request: string, body, success, fail) {
  	const headers = new HttpHeaders().set("authCode", Config.authCode);
  	
    this.http.post(`${environment.endpoint}${request}`, body, {headers})
      .subscribe(data => {
        if (success) success(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          this.log.error(err.error.message, "Client-side error occured.");
          if (fail) fail(err.error.message);
        } else {
          this.log.error(err.message, "Server-side error occured.");
          if (fail) fail(err.message, err.status);
        }

      });
  }
  update(request: string, body, options, success, fail) {
    this.put(request, body, options, success, fail)
  }
  deleta(request: string, body, options, success, fail) {
    this.delete(request, options, success, fail)
  }

  headers() {
    var header = new HttpHeaders();
    header = header.append('Cache-Control','no-cache');  
    header = header.append('Cache-Control','no-store');  
    header = header.append('Pragma','no-cache');  
    header = header.append('Expires','Sat, 01 Jan 2000 00:00:00 GMT'); 
    //header = header.append('timeout','600000'); 
    return header;
  }

  getURLServices(success){
    this.http.get(`${environment.endpoint}ws/analyticres/url`)
        .subscribe(data => {
        if (success) success(data);
      },
	  (err: HttpErrorResponse) => {
	    this.log.error(err.message, "Client-side error occured.");
	});
  }
}