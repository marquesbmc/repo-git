import { Injectable } from '@angular/core';
import { ErrorService } from "../../services/error/error.service";
import { LogService } from "../../services/log/log.service";
import { WebServiceService } from "../web-service/web-service.service";
import { Config } from "../../../environments/config";

const VERSION: string = '2.0.2';
const INIT_EVENT = "INIT";
const INIT_AGENT = "AGENT";
const NOTE = "NOTE";
const ISP = "ISP";
const SESSION_EVENT = "SESSION";
const PAGE = "page";
const ERROR = "error";
const WARN = "warn";
const TIMEOUT = 120000;

@Injectable()
export class AnalyticsService {
  evaluationRate: number = null;
  userFeedback: number = null;
  userAgent: string = null;
  token: string = null;
  provedor: string = null;
  session: number = null;
  category: string = "";
  enabled: boolean = true;

  constructor(private log: LogService, private errorService: ErrorService, private webservice: WebServiceService) {
    var vm = this;
    if (window && window.navigator && window.navigator.userAgent) {
      vm.userAgent = window.navigator.userAgent;
    }
  }

  version(): string {
    return VERSION;
  }

  private getEvaluationRest() {
    var vm = this;

    function success(res) {
      if (!res.temErro) {
        var response = res;
        vm.evaluationRate = JSON.parse(response.message);
      } else if (res.temErro) {
        console.error(res.msgsErro[0]);
      }
    }
    function fail(xhr, message) {
      console.error("Ocorreu um erro ao obter o json Evaluation: " + xhr.responseText);
    }

    var headers = this.webservice.headers();
    this.webservice.getAnalytics(Config.URL_CAIXA_ANALYTICS + "ws/json/listarEvaluationUserFeedback?json=evaluationRate", {headers: headers}, success, fail);
  }


  private getUserFeedbackRest() {
    var vm = this;

    function success(res) {
      if (!res.temErro) {
        var response = res;
        vm.userFeedback = JSON.parse(response.message);
      } else if (res.temErro) {
        console.error(res.msgsErro[0]);
      }
    }
    function fail(xhr, message) {
      console.error("Ocorreu um erro ao obter o json UserFeedback: " + xhr.responseText);
    }

    var headers = this.webservice.headers();
    this.webservice.getAnalytics(Config.URL_CAIXA_ANALYTICS + "ws/json/listarEvaluationUserFeedback?json=userFeedback", {headers: headers}, success, fail);
  }

  private getStamp(name) {
    var result = null;
    try {
      result = window.localStorage.getItem(name);
      if (result == "" || result == "null") {
        result = null;
      }
    } catch (ignore) {
    }
    return result;
  }
  private setStamp(name, value) {
    try {
      window.localStorage.setItem(name, value);
    } catch (ignore) {
    }
  }
  montarJson(key, session, category, action, label, value, device) {
    var vm = this;

    var json = {
      chave: null,
      sessao: "",
      categoria: null,
      acao: null,
      etiqueta: null,
      valor: "",
      nomeSistemaOperacional: "",
      versaoSistemaOperacional: "",
      nomeNavegador: "",
      versaoNavegador: "",
      dispositivo: "",
      userAgent: null,
      token: ""
    };
    json.chave = key;

    
    if (session) {
      json.sessao = session + "";
    }
    json.categoria = category;
    json.acao = action;
    json.etiqueta = label;
    if (value) {
      json.valor = value;
    }

    if (device != null && device["soname"]) {
      json.nomeSistemaOperacional = device["soname"];
    }

    if (device != null && device["sover"]) {
      json.versaoSistemaOperacional = device["sover"];
    }

    if (device != null && device["navname"]) {
      json.nomeNavegador = device["navname"];
    }

    if (device != null && device["navver"]) {
      json.versaoNavegador = device["navver"];
    }

    if (device != null && device["devname"]) {
      json.dispositivo = device["devname"];
    }

    json.userAgent = vm.userAgent;

    if (vm.token != null) {
      json.token = vm.token;
    }
    return json;
  }

  enviarEventoRest(json) {
    var url = null;
    var vm = this;

    if (vm.token == null) {
      url = Config.URL_CAIXA_ANALYTICS + "ws/evento/registrar";
    } else {
      url = Config.URL_CAIXA_ANALYTICS + "ws/evento/registrarAutenticado";
    }


    function success(res) {
      if (!res.temErro) {
        //console.info(res.msgsErro[0]);
      } else if (res.temErro) {
        console.error(res.msgsErro[0] + ": " + json);
      }
    }
    function fail(xhr, message) {
      console.error("Ocorreu um erro ao enviar o evento: " + xhr.statusText);
    }

    var headers = this.webservice.headers();
    headers = headers.append('Content-Type', 'application/json');
    this.webservice.postAnalytics(url, json, {headers: headers}, success, fail);

  }

  private registerEvent(category, action, label, value) {
    var vm = this;

    var json = vm.montarJson(Config.ANALYTICS_ID, vm.session, category, action, label, value, null);    
    var jsontext = JSON.stringify(json);

    vm.enviarEventoRest(jsontext);
  }

  private configs(id, newcategory) {
    var vm = this;
    vm.getEvaluationRest();
    vm.getUserFeedbackRest();

    if (!id) return;
    if (newcategory) vm.category = newcategory;
    vm.session = vm.makeid();
    var lastsession = vm.getStamp(vm.category);

    vm.enabled = true;

    vm.trackEvent(INIT_EVENT, lastsession);

    if (vm.userAgent != null) {
      vm.trackEvent(INIT_AGENT, vm.userAgent);
    }

    vm.setStamp(vm.category, vm.session);

    vm.registrarProvedor();

  }

  private getISPService() {
    var vm = this;
    function success(data) {
      try {
        if (data) {
          vm.provedor = data.org;
          if (!vm.provedor) {
            vm.provedor = data.isp;
          }
          vm.trackEvent("ISP", vm.provedor);
        }
      } catch (ignore) {
      }
    }
    function fail(data) {
      console.error("Não foi possível obter as informações do provedor");
    }

    var headers = this.webservice.headers();
    this.webservice.getAnalytics("https://extreme-ip-lookup.com/json/", {headers: null}, success, fail);
  }

  private registrarProvedor() {
    var vm = this;
    
    function success(res) {
      if (!res.temErro) {
        var response = res;
        vm.provedor = response.message;
        vm.trackEvent("ISP", vm.provedor);
      } else if (res.temErro) {

        vm.getISPService();
      }      
    }
    function fail(xhr, message) {
      console.error("Ocorreu um erro ao verificar se o provedor já está cadastrado: " + xhr.responseText);
    }

    var headers = this.webservice.headers();
    this.webservice.getAnalytics(Config.URL_CAIXA_ANALYTICS + "ws/json/checarProvedor", {headers: headers}, success, fail);
  }


  private makeid() {
    return this.getRandom(1, 2147483647);
  }
  private getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }


  init(id, newcategory) {
    this.configs(id, newcategory);
  }

  initAuth(user, pass, id, newcategory, devmode) {
    this.auth(user, pass, id, newcategory, devmode);
  }

  auth(user, pass, id, newcategory, devmode) {
    var vm = this;
    var json = { usuario: user, senha: pass };


    function success(res) {
      if (!res.temErro) {
        vm.token = res.user.token;
      } else if (res.temErro) {
        console.error(res.message + ": " + json);
      }
    }
    function fail(xhr, message) {
      var cause = null;
      if (xhr != null && xhr.responseText) cause = xhr.responseText
      if (cause == null && xhr != null && xhr.statusText) cause = xhr.statusText;
      console.error("Ocorreu um erro ao se autenticar " + xhr.responseText);
    }

    var headers = this.webservice.headers();
    headers = headers.append('Content-Type', 'application/json');
    this.webservice.postAnalytics(Config.URL_CAIXA_ANALYTICS + "ws/autenticacao/autenticarInterface", JSON.stringify(json), {headers: headers}, success, fail);    

    vm.configs(id, newcategory);
  }

  setEnable(value) {
    this.enabled = value;
  }
  setSession(id) {
    this.session = id;
  }
  setCategory(id) {
    this.category = id;
  }
  isEnabled() {
    return this.enabled;
  }
  trackWarn(label, value = null) {
    if (!this.enabled) return;
    if (!Config.ANALYTICS_ID) return;

    this.registerEvent(this.category, WARN, label, value);
  }
  trackException(label, value = null) {
    if (!this.enabled) return;
    if (!Config.ANALYTICS_ID) return;

    this.registerEvent(this.category, ERROR, label, value);
  }
  trackEvent(action, label = null, value = null) {
    if (!this.enabled) return;
    if (!Config.ANALYTICS_ID) return;

    this.registerEvent(this.category, action, label, value);
  }
  trackPage(page, value) {
    if (!this.enabled) return;
    if (!Config.ANALYTICS_ID) return;

    this.registerEvent(this.category, PAGE, page, value);
  }
  getEvaluationRate() {
    return this.evaluationRate;
  }
  getUserFeedback() {
    return this.userFeedback;
  }
  isFeedbackReady() {
    return this.userFeedback != null && this.evaluationRate != null;
  }
}