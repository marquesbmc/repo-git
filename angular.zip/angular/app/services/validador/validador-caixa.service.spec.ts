import { TestBed, inject } from '@angular/core/testing';

import { ValidadorCaixaService } from './validador-caixa.service';

describe('ValidadorCaixaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ValidadorCaixaService]
    });
  });

  it('should be created', inject([ValidadorCaixaService], (service: ValidadorCaixaService) => {
    expect(service).toBeTruthy();
  }));
});
