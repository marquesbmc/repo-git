import { TestBed, inject } from '@angular/core/testing';

import { NativeInterfaceService } from './native-interface.service';

describe('NativeInterfaceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NativeInterfaceService]
    });
  });

  it('should be created', inject([NativeInterfaceService], (service: NativeInterfaceService) => {
    expect(service).toBeTruthy();
  }));
});
