import { HelloService } from './services/web-service/hello.service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule, ErrorHandler, APP_INITIALIZER } from '@angular/core';
import { KeycloakService, KeycloakAngularModule } from 'keycloak-angular';
import { initializer } from './app-init';
import { TokenInterceptor } from './token-interceptor';
import { AgmCoreModule } from '@agm/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from "@angular/router";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputMaskModule } from 'primeng/inputmask';
import { CalendarModule } from 'primeng/calendar';
import { AppComponent } from './app.component';
import { ModalShareComponent } from './resources/modal-share/modal-share.component';
import { ModalAlertComponent } from './resources/modal-alert/modal-alert.component';
import { ModalConfirmComponent } from './resources/modal-confirm/modal-confirm.component';
import { ModalInputComponent } from './resources/modal-input/modal-input.component';
import { ModalWarningComponent } from './resources/modal-warning/modal-warning.component';
import { ModalErrorComponent } from './resources/modal-error/modal-error.component';
import { MenuPrincipalComponent } from './components/menu/menu-principal/menu-principal.component';
import { CabecalhoPrincipalComponent } from './components/cabecalho/cabecalho-principal/cabecalho-principal.component';
import { RodapePrincipalComponent } from './components/rodape/rodape-principal/rodape-principal.component';
import { AcessibilidadeComponent } from './components/acessibilidade/acessibilidade.component';
import { AlertService } from './services/alert/alert.service';
import { ApplicationService } from './services/application/application.service';
import { EndpointService } from './services/endpoint/endpoint.service';
import { ProfileService } from './services/profile/profile.service';
import { ErrorService } from './services/error/error.service';
import { GeneralErrorHandler } from './services/error/error.handler';
import { FeedbackService } from './services/feedback/feedback.service';
import { GeolocationService } from './services/geolocation/geolocation.service';
import { LogService } from './services/log/log.service';
import { NativeInterfaceService } from './services/native-interface/native-interface.service';
import { UtilsService } from './services/utils/utils.service';
import { WebServiceService } from './services/web-service/web-service.service';
import { ValidadorCaixaService } from './services/validador/validador-caixa.service';
import { CentralCaixaService } from './services/central/central-caixa.service';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { InitializeDirective } from './directives/initialize/initialize.directive';
import { HighchartsChartModule } from 'highcharts-angular';
import { AnuncioDireitaComponent } from './components/anuncios/anuncio-direita/anuncio-direita.component';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SplashComponent } from './components/splash/splash.component';
import { PrincipalComponent } from './components/principal/principal.component';
import { LabelErrorComponent } from "./resources/label-error/label-error.component";
import { TreeModule } from 'angular-tree-component';
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { QRCodeModule } from 'angularx-qrcode';

const routes: Routes = [
  
    { path: '', redirectTo: 'splash', pathMatch: 'full' },
  	{ path: 'splash', component: SplashComponent, data: { label:'Splash'}  },
  	{ path: 'principal', component: PrincipalComponent, data: { label:'Principal'}  },
  	{ path: '**', component: SplashComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    SplashComponent,
    PrincipalComponent,
    ModalShareComponent,
    ModalAlertComponent,
    ModalConfirmComponent,
    ModalInputComponent,
    LabelErrorComponent,
    ModalWarningComponent,
    ModalErrorComponent,
    MenuPrincipalComponent,
    CabecalhoPrincipalComponent,
    RodapePrincipalComponent,
    AcessibilidadeComponent,
    BreadcrumbComponent,
    InitializeDirective,
    AnuncioDireitaComponent
  ],
  imports: [
  	AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAodeT4jHIkwFbLQKietXG8mcXx6FIDtQc'
    }),
    BrowserAnimationsModule, NgbModule.forRoot(), BrowserModule,
    RouterModule.forRoot(routes, {
      useHash: true,
      anchorScrolling: 'enabled',
      onSameUrlNavigation: 'reload',
      scrollPositionRestoration: 'enabled'
    }),
    FormsModule, HttpClientModule, QRCodeModule,
    HighchartsChartModule, ReactiveFormsModule, InputMaskModule, TreeModule.forRoot(), AngularDualListBoxModule, CalendarModule, KeycloakAngularModule,
    TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [HttpClient]
        }
    })
  ],
  entryComponents: [ModalShareComponent,ModalAlertComponent, ModalConfirmComponent, ModalInputComponent, ModalWarningComponent, ModalErrorComponent, LabelErrorComponent],
  providers: [ProfileService, AlertService, ApplicationService, EndpointService, ErrorService, FeedbackService,
    GeolocationService, LogService, NativeInterfaceService, UtilsService, WebServiceService, ValidadorCaixaService, KeycloakService, HelloService,
    {
      provide: APP_INITIALIZER,
      useFactory: initializer,
      multi: true,
      deps: [KeycloakService, HttpClient]
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },
    CentralCaixaService, { provide: ErrorHandler, useClass: GeneralErrorHandler }],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}