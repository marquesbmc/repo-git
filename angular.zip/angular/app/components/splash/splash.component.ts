import { Component, OnInit } from '@angular/core';
import { LogService } from "../../services/log/log.service";
import { Config } from "../../../environments/config";
import { CurrentView } from "../../../environments/currentview";
import { ApplicationService } from '../../services/application/application.service';
import { WebServiceService } from '../../services/web-service/web-service.service';
import { GeolocationService } from '../../services/geolocation/geolocation.service';
import { AlertService }  from "../../services/alert/alert.service";
import { FormBuilder, FormGroup, Validators} from "@angular/forms";
import { ModalShareComponent } from "../../resources/modal-share/modal-share.component";
import { UtilsService } from "../../services/utils/utils.service";
import { CentralCaixaService } from "../../services/central/central-caixa.service";

@Component({
  selector: 'app-splash',
  templateUrl: './splash.component.html',
  styleUrls: ['./splash.component.css']
})
export class SplashComponent implements OnInit {

  constructor(private log: LogService, private formBuilder: FormBuilder, 
      private appService: ApplicationService, private webservice: WebServiceService, private central: CentralCaixaService,
      private alertService: AlertService, private geolocation: GeolocationService, private utilsService: UtilsService) { }

  currentview = CurrentView; 
  public myPage;
  myForm: FormGroup;

  hasCentral = '[null]' == Config.CENTRAL_ID ? false : true;
 
  timer = null;
  
  ngOnInit() {

    this.log.info("SplashComponent.init()");

    this.currentview.locked = false;
    this.currentview.menu = true;
    this.myForm = this.formBuilder.group({
      btiicon013primosiogpinvertedverysmallpng2: [ null , []],
      imagem: [ null , []],
      timer: [ null , []],
      timer2: [ null , []],
      link: [ null , []],
      id: [null]
    });

    this.myPage = "";
	
  }


  iterate(obj) {
    return Object.keys(obj).map((key)=>{ return obj[key]});
  }


  initDate(data) {
  	return "";
  }

  openViewDelayed(id,event=null,message=null) {
    var vm = this;
    vm.log.info("AppComponent.openViewDelayed(" + id + ")");

    if (id == null || id.length <= 1) {
    	if( message == null) message = "Procedimento executado com sucesso";
      vm.alertService.showWarning("Atenção", message);
      return;
    }

    vm.appService.openPage(id); 
  }
  
  getPlatforms(platforms) {
    return "";
  }
  
  confirmDelete() {
    var vr = this;
    function confirm() {
      vr.alertService.showMessage("Atenção","Exclusão confirmada pelo usuário");
    }
    function deny() {
      vr.alertService.showMessage("Atenção","Exclusão cancelada pelo usuário");
    }
    this.alertService.showConfirm("Atenção","Confirma a exclusão deste item?",confirm,deny);
  }
  
  populaDadosForm(dados) {
    this.myForm.patchValue({
      btiicon013primosiogpinvertedverysmallpng2: dados.btiicon013primosiogpinvertedverysmallpng2,
      imagem: dados.imagem,
      timer: dados.timer,
      timer2: dados.timer2,
      link: dados.link,
      id: [null]
    });
      
  }
  
  clickPill(page) {
    this.myPage = page;
  }
  
  doShare() {
    this.alertService.showTemplate(ModalShareComponent, null);
  }
}