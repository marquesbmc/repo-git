import { Component, OnInit } from '@angular/core';
import { LogService } from "../../services/log/log.service";
import { Config } from "../../../environments/config";
import { CurrentView } from "../../../environments/currentview";
import { ApplicationService } from '../../services/application/application.service';
import { WebServiceService } from '../../services/web-service/web-service.service';
import { AlertService }  from "../../services/alert/alert.service";
import { FormBuilder, FormGroup} from "@angular/forms";
import { ModalShareComponent } from "../../resources/modal-share/modal-share.component";

@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']
})
export class PrincipalComponent implements OnInit {

  constructor(private log: LogService, 
              private formBuilder: FormBuilder,
              private appService: ApplicationService,
              private webservice: WebServiceService,
              private alertService: AlertService) { }

  currentview = CurrentView; 
  public myPage;
  myForm: FormGroup;

  hasCentral = '[null]' == Config.CENTRAL_ID ? false : true;
 
  timer = null;
  
  ngOnInit() {
    this.log.info("PrincipalComponent.init()");

    this.currentview.locked = true;
    this.currentview.menu = true;
    this.myForm = this.formBuilder.group({
      imagem: [ null , []],
      id: [null]
    });
    
    this.myPage = "";
    this.listar();
  }


  iterate(obj) {
    return Object.keys(obj).map((key)=>{ return obj[key]});
  }

  inclusao(paginaDestino) {
    var vm = this;
    

    function success(res) {
      
      if(!res.temErro) {
        vm.appService.openPage(paginaDestino);
      } else if(res.temErro) {
        this.log.error("Ocorreu um erro ao incluir lista",res.msgsErro[0]);
      }
    }

    function fail(xhr, status, err) {
        var message = "Falha ao incluir PrincipalController";
        if (xhr && xhr.responseText) {
          try {
            var response = JSON.parse(xhr.responseText);
            if (response && response.msgsErro && response.msgsErro.length > 0) {
              message = response.msgsErro[0];
            }	        					
          } catch(ignore) {
          }
        }
        this.log.error(message);      
    }    
    
    this.webservice.create("ws/principal/principal", vm.myForm.value, success, fail);
  };        
  
  listar() {
    var vm = this;
    

    function success(res) {      
      
      if(!res.temErro) {      
      	if (res.data)
			vm.populaDadosForm(res.data);
      } else if(res.temErro) {	      		
        vm.log.error(res.msgsErro[0]);
      }
    }

    function fail(xhr, status, err) {
      
      
      var message = "Falha ao listar PrincipalController";
      if (xhr && xhr.responseText) {
        try {
          var response = JSON.parse(xhr.responseText);
          if (response && response.msgsErro && response.msgsErro.length > 0) {
            message = response.msgsErro[0];
          }	        					
        } catch(ignore) {
        }
      }
      vm.log.error(message, err);
      if (xhr.status == 502 || err == 401) {
          this.application.goAuth();
      } 
    }    
  
    this.webservice.read("ws/principal/principal", success,fail);
  };

  initDate(data) {
  	return "";
  }

  openViewDelayed(id,event=null,message=null) {
    var vm = this;
    vm.log.info("AppComponent.openViewDelayed(" + id + ")");

    if (id == null || id.length <= 1) {
    	if( message == null) message = "Procedimento executado com sucesso";
      vm.alertService.showWarning("Atenção", message);
      return;
    }

    vm.appService.openPage(id); 
  }
  
  getPlatforms(platforms) {
    return "";
  }
  
  confirmDelete() {
    var vr = this;
    function confirm() {
      vr.alertService.showMessage("Atenção","Exclusão confirmada pelo usuário");
    }
    function deny() {
      vr.alertService.showMessage("Atenção","Exclusão cancelada pelo usuário");
    }
    this.alertService.showConfirm("Atenção","Confirma a exclusão deste item?",confirm,deny);
  }
  
  populaDadosForm(dados) {
    this.myForm.patchValue({
      imagem: dados.imagem,
      id: [null]
    });
      
  }
  
  clickPill(page) {
    this.myPage = page;
  }
  
  doShare() {
    this.alertService.showTemplate(ModalShareComponent, null);
  }

}