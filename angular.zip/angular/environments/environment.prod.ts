export const environment = {
  production: false,
  endpoint: 'https://sipbs-micro-des-esteiras.nprd2.caixa',
  sso: 'https://login.des.caixa/auth'
};