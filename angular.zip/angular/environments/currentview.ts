export const CurrentView = {
  menu: true,
  locked: true    
}
