export const Project = {
    "analytics": true,
    "anuncios": true,
    "artefatos": [],
    "build": null,
    "builderNotes": [],
    "builderfullname": "Ramon Muniz",
    "builderid": 4939,
    "buildername": "F718588@caixa.gov.br",
    "code": 1472,
    "comapk": false,
    "comments": true,
    "contact": "F718588@caixa.gov.br",
    "context": "/app/",
    "contraste": {
        "content": "/*---------- fontes */\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN45__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: 500;\r\n\tfont-style: normal;\r\n}\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN85__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: bold;\r\n\tfont-style: normal;\r\n}\r\n\r\n/*---------- fontes */\r\n\r\n.theme-app {\r\n\tbackground-color: #fff;\r\n}\r\n\r\n.theme-header {\r\n\tbackground-color: #296fa7;\r\n\tborder-bottom: 3px solid #F39A00!important;\r\n}\r\n.theme-app.tabbed .theme-header {\r\n\tborder-bottom: none!important;\r\n}\r\n\r\n.theme-header-tabs {\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-header-right > .navbar-brand {\r\n\tcolor: #fff;\r\n\tpadding-right: 5px;\r\n}\r\n.theme-header-left > .navbar-brand {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-header-middle.navbar-brand{\r\n\tcolor: #fff;\r\n}\r\n.theme-header-tabs {\r\n\t    background-color: #fff;\r\n}\r\n\r\n.theme-header-tabs > li.active > a {\r\n\tbackground-color: #296fa7;\r\n\tcolor: #fff;\r\n}\r\n.theme-footer {\r\n\tbackground-color: #296fa7;\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-footer-right {\r\n\tpadding-right: 10px;\r\n}\r\n.theme-footer-middle {\r\n\r\n}\r\n.theme-footer-left {\r\n\tpadding-left: 10px;\r\n}\r\n\r\n.theme-header-left > a {\r\n\tbackground: url(../imgs/theme-padrao/caixab.png) no-repeat!important;\r\n\twidth: 112px;\r\n\theight: 24px;\r\n\tmargin-top: 20px!important;\r\n\tmargin-left: 10px!important;\r\n}\r\n\r\n.theme-header-left-caption {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.theme-header-title {\r\n\theight: 63px;\r\n}\r\n\r\n.form-group{\r\n\t/* top:20px; */\r\n}\r\n\r\n.theme-header-acessibilidade{\r\n\theight: 25px;\r\n\tbackground-color: #2ca5fe;\r\n}\r\n\r\n.theme-link-acessibilidade{\r\n\tposition: relative;\r\n\ttop: 3px;\r\n\tleft: 10px;\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-app.tabbed .theme-menu-container {\r\n    margin-top: 120px!important;\r\n}\r\n.theme-app .theme-menu-container {\r\n    margin-top: 80px!important;\r\n}\r\n\r\n.theme-app.collapse.in .theme-submenu-item > a {\r\n\tpadding-left: 20px;\r\n}\r\n\r\n.theme-app .theme-main-container {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 70px 0 50px 0px;\r\n}\r\n\r\n.theme-app.menu .theme-main-container {\r\n\tmargin: 10px 0 50px 0px;\r\n}\r\n\t\r\n@media (min-width: 768px) {\r\n\t.theme-app.tabbed .theme-menu-container {\r\n\t    margin-top: 20px!important;\r\n\t}\r\n\t.theme-app .theme-menu-container {\r\n\t    margin-top: 0px!important;\r\n\t}\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 15px!important;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tposition: fixed;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-header-right {\r\n\t\tpadding-right: 15px;\r\n\t}\r\n\t\t\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 10px!important;\r\n\t}\r\n\r\n\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 0 70px!important;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 0px!important;\r\n\t}\r\n\r\n\t.theme-main-container {\r\n\t\tmargin: 67px 0 0 70px;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tmargin-top: 3px!important;\r\n\t}\r\n}\r\n\r\n\r\n.sidebar-nav > .nav li > a.active {\r\n    margin: 0;\r\n    border-left: 4px solid #ffa100;\r\n    border-left-width: 4px;\r\n    border-left-style: solid;\r\n    border-left-color: #ffa100;\r\n    border-top: 1px solid #d9d9d9;\r\n    border-top-width: 1px;\r\n    border-top-style: solid;\r\n    border-top-color: rgb(217, 217, 217);\r\n    border-bottom: 1px solid #d9d9d9;\r\n    border-bottom-width: 1px;\r\n    border-bottom-style: solid;\r\n    border-bottom-color: rgb(217, 217, 217);\r\n    background-color: #f5f7f7;\r\n}\r\n\r\n.theme-header .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n.theme-footer .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n\r\nbutton {\r\n\tmargin-right: 5px;\r\n}\r\n\r\n.table-responsive{\r\n\ttop:20px;\r\n}\r\n\r\n/* texto */\r\n.text-primary {\r\n\tcolor: #296fa7;\r\n}\r\n.text-primary-important {\r\n\tcolor: #296fa7!important;\r\n}\r\n.text-warning {\r\n\tcolor: #ffa100;\r\n}\r\n.text-warning-important {\r\n\tcolor: #ffa100!important;\r\n}\r\n.text-success {\r\n\tcolor: #3c763d;\r\n}\r\n.text-success-important {\r\n\tcolor: #3c763d!important;\r\n}\r\n.text-black {\r\n\tcolor: #464646;\r\n\tfont-weight: 100;\r\n}\r\n.text-purple {\r\n\tcolor: #494d62;\r\n\tfont-weight: 100;\r\n}\r\n.text-laranja {\r\n\tcolor: #ffa100;\r\n\tfont-weight: 100;\r\n}\r\n.text-info {\r\n\tcolor: #c0b723;\r\n\tfont-weight: 100;\r\n}\r\n.text-danger {\r\n\tcolor: #920A04;\r\n\tfont-weight: 100;\r\n}\r\n\r\n/* Botoes */\r\n.btn-outline {\r\n\tcolor: inherit;\r\n\tbackground-color: transparent;\r\n\ttransition: all .5s;\r\n}\r\n\r\n.btn-primary.btn-outline {\r\n\tcolor: #428bca;\r\n}\r\n\r\n.btn-success.btn-outline {\r\n\tcolor: #5cb85c;\r\n}\r\n\r\n.btn-info.btn-outline {\r\n\tcolor: #5bc0de;\r\n}\r\n\r\n.btn-warning.btn-outline {\r\n\tcolor: #f0ad4e;\r\n}\r\n\r\n.btn-danger.btn-outline {\r\n\tcolor: #d9534f;\r\n}\r\n\r\n.btn-primary.btn-outline:hover,\r\n.btn-success.btn-outline:hover,\r\n.btn-info.btn-outline:hover,\r\n.btn-warning.btn-outline:hover,\r\n.btn-danger.btn-outline:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-menu-container {\r\n\tborder-right: 1px solid #ADADAD;\r\n\theight: 100%;\r\n\tbackground: #fff;\r\n}\r\n\r\n.theme-main-container.menu {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 0px 0 50px 0px;\r\n}\r\n\r\n.theme-app.tabbed .page-wrapper {\r\n\tmargin-top: 110px;\r\n}\r\n\r\n\r\n.theme-menu-item {\r\n\tborder-bottom: 0px!important;\r\n}\r\n\r\n.table-bordered{\r\n\tborder: none;\r\n}\r\n\r\n.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, \r\n.table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, \r\n.table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th{\r\n\tborder-top: 1px solid #ccc;\r\n}\r\n\r\n/* Material Design Switch */\r\n.material-switch-contraste-contraste {\r\n\tmargin-top: 5px;\r\n}\r\n.material-switch-contraste > input[type=\"checkbox\"] {\r\n\tdisplay: none;\r\n}\r\n\r\n.material-switch-contraste > label {\r\n\tcursor: pointer;\r\n\theight: 0px;\r\n\tposition: relative;\r\n\twidth: 40px;\r\n\ttop: -20px;\r\n}\r\n\r\n.material-switch-contraste > label::before {\r\n\tleft: 0px;\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\tborder-radius: 8px;\r\n\tcontent: '';\r\n\theight: 13px;\r\n\tposition:absolute;\r\n\topacity: 0.3;\r\n\ttransition: all 0.4s ease-in-out;\r\n\twidth: 34px;\r\n\ttop: 14px;\r\n}\r\n.material-switch-contraste > label::after {\r\n\tbackground: rgb(255, 255, 255);\r\n\tborder-radius: 16px;\r\n\tbox-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);\r\n\tcontent: '';\r\n\theight: 20px;\r\n\tleft: 0px;\r\n\tposition: absolute;\r\n\ttop: 11px;\r\n\ttransition: all 0.3s ease-in-out;\r\n\twidth: 20px;\r\n}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::before {\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\topacity: 0.1;\r\n}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::after {\r\n\tbackground: inherit;\r\n\tbox-shadow: 0px 0px 5px rgba(255, 255, 255, 0.5);\r\n\tleft: 20px;\r\n}\r\n\r\n.breadcrumb{\r\n\tmargin-top: 10px;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n}\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none!important;\r\n}\r\n\r\n\r\n\r\n\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n/*---------------------------------------------- TEMPLATE INTRANET 2018 -------------------------------------------------*/\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n\r\n\r\n/*-----geral-----*/\r\n\r\n.theme-header-acessibilidade {background-color: #3A4859;}\r\n\r\n.theme-header-acessibilidade a {color: #C2DC26;}\r\n\r\n.theme-app {background-color: black;}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::before {\r\n    background: #EFF5F6;\r\n    box-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n}\r\n\r\n/*-----cabecalho-----*/\r\n\r\n.theme-header {\r\n\tborder-bottom: 3px solid white !important;\r\n\tbackground-image: none;\r\n\tbackground-color: black;\r\n\twidth: 100%;\r\n\tbox-sizing: border-box !important;\r\n}\r\n\r\n.theme-header-right-title {\r\n\tmargin-top: 5px;\r\n\tmargin-right: 25px;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.navbar-left.theme-header-left {\r\n\theight: 63px !important;\r\n\tbackground-image: url(../imgs/theme-intranet/logo_caixa.png) !important;\r\n\tbackground-repeat: no-repeat !important;\r\n\tbackground-position: center left !important;\r\n\tmargin: 0 !important;\r\n\tpadding: 0 !important;\r\n\tmargin-left: 15% !important;\r\n}\r\n\r\n.theme-header-left a {background: none !important;}\r\n\r\n.navbar-brand  {padding-right: inherit !important;}\r\n\r\n.navbar-brand[title^=\"Avalia��o\"]  {padding-right: inherit !important;}\r\n\r\n.navbar-toggle {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n\tborder: none;\r\n}\r\n\t\r\n.navbar-toggle i {\r\n\twidth: 20px;\r\n\theight: 20px;\r\n\tmargin-right: 36px;\r\n}\r\n\r\n.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:active, \r\n.navbar-default .navbar-toggle:focus, .nav li a:hover, .nav li a:active, .nav li a:focus {background: none;}\r\n\r\n/*-----rodape-----*/\r\n\r\n.theme-footer {\r\n\tborder-top: 3px solid white !important;\r\n\tbackground-color: black !important;\r\n\tbackground-image: none;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n/*-----menu horizontal-----*/\r\n\r\nul[ng-hide=\"currentview.telainicial\"] {\r\n\theight: 43px;\r\n\tborder-top: 3px solid white !important;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px;\r\n\tborder-bottom: 1px solid white;\r\n\tbackground-color: black;\r\n\tbox-sizing: border-box !important;\r\n}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li {\r\n\t/display: inline-block !important;\r\n\tpadding-top: 10px;\r\n\tpadding-bottom: 10px;\r\n\theight: 100%;\r\n}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li a {\r\n\tcolor: white;\r\n\tborder-right: 1px solid white !important;\r\n\tborder-radius: 0;\r\n\tdisplay: inline-block !important;\r\n\tpadding-top: 0 !important;\r\n\theight: 16px !important;\r\n\tline-height: 1 !important;\r\n}\r\n\r\n.nav .open>a, .nav .open>a:focus,.nav .open>a:hover {\r\n\tbackground: none;\r\n\tborder: none;\r\n}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li a:hover{\r\n\tcolor: #C2DC26;\r\n\tborder-color: black;\r\n\tborder-right: 1px solid white !important;\r\n\tborder-radius: 0;\r\n\tdisplay: inline-block !important;\r\n\tbox-sizing: border-box;\r\n\tpadding-top: 0 !important;\r\n\theight: 16px !important;\r\n\tline-height: 1 !important;\r\n}\r\n\r\nul.theme-header-tabs > li:last-child a {border: none !important;}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li a i {display: none;}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li ul {\r\n\tbackground-color: black;\r\n\tborder: 1px solid white;\r\n}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li ul li a {\r\n\tborder: none !important;\r\n\tcolor: white;\r\n}\r\n\r\n/*-----menu vertical-----*/\r\n\r\n.sidebar-nav .nav li a.active {\r\n\tborder: none;\r\n\tcolor: black;\r\n\tfont-size: 13px;\r\n\tbackground: #EFF5F6;\r\n\tbackground: -moz-linear-gradient(left, #EFF5F6 1%, #B3C7CB 100%);\r\n\tbackground: -webkit-linear-gradient(left, #EFF5F6 1%, #B3C7CB 100%);\r\n\tbackground: linear-gradient(to right, #EFF5F6 1%, #B3C7CB 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#EFF5F6', endColorstr='#B3C7CB',GradientType=1 );\r\n}\r\n\r\n.sidebar, .sidebar-nav {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-weight: bold;\r\n\tbackground-color: black;\r\n\twidth: 217px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li {padding:0;}\r\n\r\n.sidebar-nav .nav li a {\r\n\tcolor: white;\r\n\tfont-size: 14px;\r\n\tdisplay: block;\r\n\tpadding-left: 16px;\r\n\tline-height: 23.5px;\r\n\tmin-height: 47px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li a:hover {color: #C2DC26;}\r\n\r\n.sidebar-nav .nav li a.active:hover {color: black;}\r\n\r\n.sidebar-nav .nav li a i {display: none;}\r\n\r\n.sidebar-nav .nav li.open > a {background-color: #F4F4F4; display: block;}\r\n\r\n.sidebar-nav .nav li > a[aria-expanded=\"true\"] {\r\n\tcolor: white;\r\n\tfont-size: 13px;\r\n\tbackground-color: #3A4859;\r\n}\r\n\r\n.sidebar-nav .nav li > a[aria-expanded=\"true\"]:hover {color:#C2DC26;}\r\n\r\n.sidebar-nav .nav li ul li a {\r\n\tbackground-image: none !important;\r\n\tbackground-color: black !important;\r\n\tcolor: white !important;\r\n\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tpadding-left: 28px;\r\n\tline-height: 16px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li ul li a:hover {color:#C2DC26 !important;}\r\n\r\n.sidebar-nav .nav li ul li a.active {\r\n\tfont-size: 12px;\r\n\tbackground-color: #B3C7CB !important;\r\n\tcolor: black !important;\r\n}\r\n\r\n.sidebar-nav .nav li ul li a.active span {\r\n\tposition:relative;\r\n\tleft: -4px;\r\n}\r\n\r\n/*-----carrossel-----*/\r\n\r\n.carousel {margin: 16px 16px 0 0;}\r\n\r\n.carousel-indicators li, .carousel-indicators .active {\r\n\tmargin: 16px 9px;\r\n\tborder-color: #9aacaf;\r\n\tbackground-color: #9aacaf;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.carousel-indicators .active {\r\n\tborder-color: #C2DC26;\r\n\tbackground-color: #C2DC26;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nol.carousel-indicators {\r\n\tposition: static;\r\n\tlist-style: none;\r\n\tmargin: 0 auto;\r\n}\r\n\r\n.carousel-caption {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tbackground: none;\r\n\tmargin-bottom: 28px;\r\n\tmargin-left: 31px;\r\n\tpadding: 0;\r\n\ttext-shadow: none;\r\n\tcolor: black;\r\n}\r\n\r\n.carousel-control {display: none;}\r\n\r\n.carousel-caption h4 {font-weight: bold; margin-bottom: 6px;}\r\n\r\n.carousel-caption p {margin-left: 16px; margin-bottom: 0;}\r\n\r\n.carousel-caption h4:before {\r\n\tcontent:'\\0025E3';\r\n\tfont-size: 12px;\r\n\tmargin-right: 6px;\r\n\tcolor: #C2DC26;\r\n}\r\n\r\n/*-----texto-----*/\r\n\r\n.text-primary, .text-primary-important, .text-warning,\r\n.text-warning-important, .text-success, .text-success-important,\r\n.text-default, .text-black, .text-purple, .text-laranja, .text-info,\r\n.text-danger {\r\n\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\tcolor: white !important;\r\n\tfont-weight: 100;\r\n}\r\n\r\ndiv.theme-main-list label,\r\nh5.theme-main-push-status {\r\n\tcolor: white;\r\n\tfont-weight: normal;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\tpadding: 0;\r\n\tmargin: 0 0 5px 0;\r\n}\r\n\r\nh5.theme-main-h4, h6.theme-main-h6 {\r\n\tfont-weight: bold;\r\n\tline-height: 1;\r\n\tcolor: white;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 20px !important;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tmargin-top: 0;\r\n}\r\n\r\nh5.theme-main-h4 {\r\n\tborder-bottom: 1px solid white;\r\n\tpadding-bottom: 6px;\r\n\tmargin-bottom: 30px;\r\n}\r\n\r\nh6.theme-main-h6 {\r\n\tfont-size: 14px !important;\r\n\tmargin-bottom: 12px;\r\n}\r\n\r\n/*-----tabelas-----*/\r\n\r\nthead tr th {\r\n\tbackground-color: black;\r\n\tcolor: white;\r\n\tfont-size: 13px !important;\r\n\tborder-top: none !important;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tvertical-align: bottom;\r\n    border-bottom: 2px solid white !important;\r\n\theight: 35px;\r\n\tfont-size: 14px;\r\n\tpadding: 8px !important;\r\n\tline-height: 13px !important;\r\n}\r\n\r\ntbody tr td {\r\n\tcolor: white;\r\n\tline-height: 1.428571429;\r\n\tvertical-align: top;\r\n\tborder-top: 1px solid white;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tborder-bottom: none !important;\r\n\theight: 35px !important;\r\n\tfont-size: 13px;\r\n\tpadding: 8px !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ntbody tr:nth-child(odd),\r\ntbody tr:nth-child(odd):hover {background-color: #3A4859 !important;}\r\n\r\ntbody tr:nth-child(even),\r\ntbody tr:nth-child(even):hover {background-color: black;}\r\n\r\ntd button {\r\n\tbackground: none;\r\n\tmargin:0 !important;\r\n\tpadding:0!important;\r\n}\r\n\r\ntd button:hover {\r\n\tcolor: white !important;\r\n}\r\n\r\n/*-----inputs-----*/\r\n\r\ndiv.form-group {\r\n\tpadding: 0;\r\n\tmargin-bottom: 20px !important;\r\n\tdisplay: inline-block;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.form-control {\r\n\tbox-shadow:none;\r\n}\r\n\r\ndiv.form-group label {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tline-height: 16px;\r\n\tcolor: white;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 0;\r\n\tline-height: 1;\r\n}\r\n\r\ndiv.input-group {\r\n\twidth: inherit;\r\n\theight: 34px;\r\n\tmin-width: 100%;\r\n    padding-right: 30px;\r\n}\r\n\r\ndiv.input-group input:focus {\r\n\tborder-color: white;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.input-group input {\r\n\tbackground-color: transparent;\r\n\tcolor: white;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid white;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding: 13px 0 5px 0 !important;\r\n}\r\n\r\ndiv.input-group input[type=\"file\"] {\r\n\tcolor:black;\r\n}\r\n\r\ndiv.theme-main-input-radio label  {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tcolor: white;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 2px;\r\n}\r\n\r\ndiv.input-group input::-webkit-input-placeholder {color: #9aacaf;}\r\ndiv.input-group input:-moz-placeholder {color: #9aacaf;}\r\ndiv.input-group input::-moz-placeholder {color: #9aacaf;}\r\ndiv.input-group input:-ms-input-placeholder {color: #9aacaf;}\r\ndiv.input-group input::-ms-input-placeholder {color: #9aacaf;}\r\n\r\nspan.input-group-addon {display: none;}\r\n\r\n.form-control[disabled],\r\n.form-control[readonly],\r\nfieldset[disabled] .form-control,\r\n.form-control[disabled]:active,\r\n.form-control[readonly]:active,\r\nfieldset[disabled] .form-control:active,\r\n.form-control[disabled]:focus,\r\n.form-control[readonly]:focus,\r\nfieldset[disabled] .form-control:focus\r\n {\r\n\tbackground-color: rgba(0,0,0,0);\r\n\tcolor: #9aacaf !important;\r\n\tborder-bottom-color: #9aacaf;\r\n}\r\n\r\n.form-control[disabled] > label.label-mobilidade,\r\n.form-control[readonly] > label.label-mobilidade,\r\nfieldset[disabled] .form-control > label.label-mobilidade {\r\n\tcolor: #9aacaf !important;\r\n}\r\n\r\n/*-----combo box-----*/\r\n\r\n.theme-main-input-select label {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tfont-weight: normal !important;\r\n\tcolor: #B3C7CB;\r\n\tmargin-bottom: 2px !important;\r\n}\r\n\r\n.input-group select {\r\n\t-webkit-appearance: none;\r\n\t-moz-appearance: none;\r\n\tappearance: none;\r\n\tbackground: url('../imgs/theme-intranet/seta-combox-intranetpreto.png') no-repeat top right;\r\n\tborder-radius: 0;\r\n\tborder-top: none;\r\n\tborder-right: none;\r\n\tborder-bottom: 1px solid white;\r\n\tborder-left: none;\r\n\tpadding: 0 0 10px 0;\r\n\theight: 26px;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 6px !important;\r\n\tbox-sizing: border-box;\r\n\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tline-height: 12px;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.input-group select:focus {border-color: white; box-shadow: none;}\r\n\r\n.input-group select::placeholder {color: white !important;}\r\n\r\n/*-----transicao labels-----*/\r\n\r\ninput.form-control ~ label {\r\n\tmargin-top:0;\r\n\tposition:absolute;\r\n\ttop:-5px;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\tfont-size:12px !important;\r\n\tcolor: white;\r\n}\r\n\r\ninput.form-control {\r\n    margin-top:0px !important;\r\n    transition:0.3s;\r\n    color: white !important;\r\n}\r\n\r\ninput.form-control:placeholder-shown ~ label{\r\n    transition:0.3s;\r\n    top:5px;\r\n\tfont-size:14px!important;\r\n}\r\n\r\ninput.form-control:placeholder{\r\n    opacity:0;\r\n    color:transparent;\r\n}\r\n\r\nlabel{\r\n\tfont-size:12px !important;\r\n\ttransition:0.3s;\r\n}\r\n\r\n.form-control::-webkit-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n.form-control::-moz-placeholder {opacity:0;\r\n    color:transparent;}\r\n.form-control:-ms-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n\r\n\r\n.form-group label:nth-child(1) {\r\n   display: none;\r\n}\r\n.form-group .theme-main-input-select label:nth-child(1),\r\n.form-group.pick-list label:nth-child(1),\r\n.form-group.theme-main-input-select label:nth-child(1),\r\n.form-group.theme-main-text-area label:nth-child(1),\r\n.form-group.theme-main-input-check label:nth-child(1) {\r\n\tdisplay: block;\r\n}\r\n.theme-main-input-radio label:nth-child(1),\r\n#uplEscolhaoarquivo label {\r\n\tdisplay:block;\r\n}\r\n\r\n/*-----caixa de texto-----*/\r\n\r\ndiv.input-group textarea {\r\n\twidth: inherit;\r\n\tcolor: white;\r\n\tbackground-color: transparent;\r\n\tfont-size: 12px !important;\r\n\tborder-top, border-left, border-right: none;\r\n\tborder-bottom: 1px solid white;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.input-group textarea:focus {\r\n\tborder-color: white;\r\n\tbox-shadow: none;\r\n}\r\n\r\n\r\n.side-menubar {\r\n    display:none;\r\n}\r\n\r\n/*-----botoes-----*/\r\n\r\n.theme-main-button {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tmargin: 15px 26px 0 0 !important;\r\n}\r\n\r\n.btn-primary, .btn-warning {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white;\r\n\tcolor: black;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\n.btn-default, .btn-danger {\r\n\tbackground-color:black;\r\n\tborder: 1px solid white;\r\n\tcolor: white;\r\n\tfont-weight: normal;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.btn-primary:hover,\r\n.btn-warning:hover,\r\n.btn-primary:active,\r\n.btn-warning:active,\r\n.btn-primary:focus,\r\n.btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:black !important;\r\n\tcolor:white!important;\r\n\tborder: 1px solid white !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 24px !important;\r\n\t/margin-left: 2px !important;\r\n}\t\r\n\r\n.theme-main-button[disabled=\"disabled\"],\r\n.theme-main-button[disabled=\"disabled\"]:hover,\r\n.theme-main-button[disabled=\"disabled\"]:focus {\r\n\tbackground-color:#d0e0e3 !important;\r\n\tborder-color:#d0e0e3 !important;\r\n\tcolor:white; opacity:1 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton#optOpces {background-color: white;}\r\nbutton#optOpces.active {color:#48586C;}\r\n\r\nbutton.btn-default,\r\nbutton.theme-main-button-subscribe,\r\nbutton.theme-main-button-unsubscribe {\r\n\tbox-sizing: border-box;\r\n\tcolor:white;\r\n\tbackground-color: black;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tmargin-left: 0 !important;\r\n\tmargin-right: 26px !important;\r\n\tborder: 1px solid white;\r\n}\r\n\r\nbutton.btn-default:hover,\r\nbutton.theme-main-button-subscribe:hover,\r\nbutton.theme-main-button-unsubscribe:hover,\r\nbutton.btn-default:active,\r\nbutton.theme-main-button-subscribe:active,\r\nbutton.theme-main-button-unsubscribe:active,\r\nbutton.btn-default:focus,\r\nbutton.theme-main-button-subscribe:focus,\r\nbutton.theme-main-button-unsubscribe:focus {\r\n\tcolor: black !important;\r\n\tbackground-color: #9aacaf !important;\r\n\tborder: 1px solid #9aacaf !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 26px !important;\r\n\tmargin-left: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton.theme-main-button-subscribe:first-child {\r\n\tmargin-left:0;\r\n}\r\n\r\nbutton#btnEnviar {\r\n\tfont-size:0.5em;\r\n}\r\n\r\n#btnEnviar:hover, #btnEnviar:active, #btnEnviar:focus {\r\n\tdisplay: block !important;\r\n\tmargin-right: auto !important;\r\n\tmargin-left: auto !important;\r\n\tmargin-bottom: 0 !important;\r\n\tbox-sizing: border-box;\r\n\theight: 38px;\r\n}\r\n\r\n/*-----botao imagem-----*/\r\n\r\na.theme-main-img-button {\r\n\tmargin-bottom: 0;\r\n}\r\n\r\nspan.theme-main-img-button-label {\r\n\tcolor: #C2DC26;\r\n}\r\n\r\nspan.theme-main-img-button-label:hover,\r\na.theme-main-img-button:hover {\r\n\tcolor: #C2DC26;\r\n\ttext-decoration: underline !important;\r\n}\r\n\r\n/*-----radio-----*/\r\n\r\ndiv.theme-main-input-radio {\r\n\tpadding: 0;\r\n}\r\n\r\ndiv.theme-main-input-radio button {\r\n\tcolor: white;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 11px !important;\r\n\tborder: 1px solid white;\r\n\topacity: 1 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n\tborder-radius: 3px;\r\n\tpadding: 0 9px;\r\n\r\n}\r\n\r\ndiv.theme-main-input-radio button:hover {\r\n\tbackground-color: #9aacaf !important;\r\n\tborder: 1px solid #9aacaf !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active,\r\ndiv.theme-main-input-radio button.active:active,\r\ndiv.theme-main-input-radio button.active:focus {\r\n\tcolor: black !important;\r\n\tbackground-color: white !important;\r\n\tborder: 1px solid white !important;\r\n\tbox-shadow: none;\r\n\tfont-weight: normal;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active:hover {\r\n\tbackground-color: black !important;\r\n\tborder: 1px solid white !important;\r\n\tcolor: white !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\t\r\n/*-----checkbox-----*/\r\n\t\r\n.input-group {margin-bottom: 0px;}\r\n\r\n.input-group > label {\r\n\tdisplay: block;\r\n\t/color: #48586C;\r\n\t/height: 20px;\r\n\t/margin: 0 14px 5px 0;\r\n}\r\n\r\n.theme-main-input-check div.input-group label {\r\n\tcolor:white;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*-----breadcrumb-----*/\r\n\r\nol.breadcrumb {\r\n\tbackground-color: black;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\nol.breadcrumb li a {color: #C2DC26; text-decoration: underline;}\r\n\r\nol.breadcrumb:before {\r\n\tcontent: 'Voc\\00ea  est\\00e1  em';\r\n\tfont-weight: bold;\r\n\tpadding-right: 8px;\r\n}\r\n\r\nol.breadcrumb li:before {content:''; padding-left:0 !important;}\r\n\r\nol.breadcrumb li:after {content:'\\0023F5'; padding-left:1ch;}\r\n\r\nol.breadcrumb li:last-child:after {content:'';}\r\n\r\nol.breadcrumb li span {color: #9aacaf;}\r\n\r\n/*-----navbar-----*/\r\n\r\n.navbar-brand-middle {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 18px;\r\n\tpadding-top: 22px;\r\n}\r\n\r\n/*-----links-----*/\r\n\r\n.theme-main-link a {\r\n\tcolor: #C2DC26;\r\n\tfont-size: 11px;\r\n\ttext-decoration: none !important;\r\n}\r\n\r\n.theme-main-link a:hover {\r\n\ttext-decoration: underline !important;\r\n}\r\n\r\n/*-----listagem-----*/\r\n\r\ndiv.theme-main-list {margin-top: 2em;}\r\n\r\ndiv.theme-main-list,\r\ndiv.theme-main-list div.text-left,\r\ndiv.theme-main-list div.text-right {padding: 0;}\r\n\r\n/*-----timer-----*/\r\n\r\n.theme-main-timer button,\r\n.theme-main-timer button:hover,\r\n.theme-main-timer button:active,\r\n.theme-main-timer button:focus {\r\n\tcolor:#B3C7CB;\r\n\tborder: 1px solid #B3C7CB;\r\n\tbackground-color: black;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n\r\n*:focus {outline: none !important;}\r\n\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n\tborder: none;\r\n\tmargin-bottom: 35px;\r\n}\r\n\r\n.rodape-atm{\r\n\tdisplay: none;\r\n}\r\n\r\n.caixa-azul{\r\n\tdisplay: none;\r\n}\r\n\r\n.theme-header-ATM{\r\n\tdisplay: none;\r\n}\r\n\r\n.side-menubar{\r\n    display:none;\r\n}\r\n\r\n/*-----abas-----*/\r\n\r\n.tabs-nav a {background: black; color: white;}\r\n\r\n.tabs-nav .active {\r\n\tbackground-color: #B3C7CB !important;\r\n\tborder: 1px solid white;\r\n\tcolor: black;\r\n}\r\n\r\nul.tabs-nav {\r\n\tborder-bottom: 2px solid white;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tpadding-bottom: 12px;\r\n}\r\n\r\nul.tabs-nav li {\r\n\tmargin: 0 20px -1px;\r\n}\r\n\r\n.tabs-nav li:first-child {\r\n    margin-left: 0 !important;\r\n}\r\n\r\nul.tabs-nav li a {\r\n\tbackground-color: black;\r\n\tborder: 1px solid white !important;\r\n\tborder-radius: 0;\r\n    /border: none !important;\r\n\tcolor: white !important;\r\n\tfont-size: 16px;\r\n\tfont-weight: bold;\r\n\tpadding: 9px 29px;\r\n\ttext-transform: uppercase;\r\n\tbox-sizing: border-box !important;\r\n    /height: 30px;\r\n}\r\n\r\nul.tabs-nav li a:hover {\r\n\tbackground-color: #9aacaf;\r\n\tcolor: black !important;\r\n\tborder: 1px solid #9aacaf !important;\r\n}\r\n\r\nul.tabs-nav li a.active {\r\n\tbackground-color: white !important;\r\n    border-radius: 0;\r\n    border: none !important;\r\n    color: black !important;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    padding: 10px 30px;\r\n    text-transform: uppercase;\r\n}\r\n\r\nul.tabs-nav li a.active:hover {\r\n\tcursor: default;\r\n}\r\n\r\ndiv.theme-main-tab .tab-content {\r\n\tmargin-top: 15px;\r\n}\r\n\r\n/*-----graficos-----*/\r\n\r\n.theme-main-chart label {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tcolor: white;\r\n\tfont-size: 18px !important;\r\n\tdisplay: block;\r\n\ttext-align: left;\r\n}\r\n\r\n.theme-main-chart text {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n[fill=\"#f0ad4e\"] {fill: #F39200;}\r\n[fill=\"#3c763d\"] {fill: #0E7639;}\r\n[fill=\"#277db6\"] {fill: #005CA9;}\r\n[fill=\"#5cb85c\"] {fill: #29C0B3;}\r\n[fill=\"#f1ca3a\"] {fill: #F9B000;}\r\n[text-anchor=\"start\"] {\r\n\tfont-weight: normal !important;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*-----paineis-----*/\r\n\r\n.theme-main-detail-panel {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary {border-color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-heading {\r\n\tbackground-color: #005CA9;\r\n\tborder-color: #005CA9;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-footer {color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-warning {border-color: #F9B000;}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-heading {\r\n\tbackground-color: #F9B000;\r\n\tborder-color: #F9B000;\r\n}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-footer {\r\n\tbackground-color: #EFF5F6;\r\n\tcolor: #F39200;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default {border-color: #B3C7CB;}\r\n\r\n.theme-main-detail-panel .panel-default .panel-heading {\r\n\tbackground-color: #EFF5F6;\r\n\tborder-color: #B3C7CB;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default .panel-footer {\r\n\tbackground-color: white;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger {border-color: #F51C1F;}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-heading {\r\n\tbackground-color: #F51C1F;\r\n\tborder-color: #F51C1F;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-footer {\r\n\tcolor: #F51C1F;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\n\r\n@media (min-width: 768px) {\r\n\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 26px;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    margin-right: 106px;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: white;\r\n    text-decoration: none;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid #76bad1;\r\n    padding: 3px 18px;\r\n    font-weight: bold;\r\n    box-sizing: border-box;\r\n    width: 80px;\r\n    height: 24px;\r\n}\r\n\r\n.item-sair-intranet a:hover {\r\n    text-decoration: underline;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.menu-item-intranet ul li a span {\r\n\tcolor: transparent;\r\n}\r\n\r\n.menu-item-intranet ul li.item-calendario-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/calendario_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-pesquisa-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/pesquisa_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-config-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/config_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: normal;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n    font-size: 13px !important;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n    position: absolute;\r\n    right: 18px;\r\n    border: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    width: 265px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n\tfont-size: 13px;\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #656565;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 15px;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 16px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 16px;\r\n    padding: 0 15px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 19px;\r\n}\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 24px !important;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    /margin-right: 106px;\r\n    margin-right: 2%;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: aliceblue;\r\n    text-decoration: none;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid white;\r\n    padding: 3px 18px;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: 400;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n\tposition: absolute;\r\n\tright: 15%;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\twidth: 265px;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #3A4859;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n    font-size: 13px !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 14px !important;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 18px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 14px;\r\n    padding: 0 14px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 16px;\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n\r\n\r\n/*-----componente calendario-----*/\r\n\r\n .hasDatepicker .ui-datepicker-inline {\r\n  background: transparent;\r\n  border: none;\r\n  /padding: 1px;\r\n  width: auto;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header {\r\n  background-color: white;\r\n  border: none;\r\n  padding-top: 8px;\r\n  padding-bottom: 8px;\r\n  border-bottom: 1px solid #d2d2d2;\r\n  margin-bottom: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background-position: 50%;\r\n  background-repeat: no-repeat;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next .ui-icon,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev .ui-icon {\r\n  display: none;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background: url(../imgs/theme-intranet/bt_anteriorMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-left: 16px;\r\n  padding: 0;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next {\r\n  background: url(../imgs/theme-intranet/bt_proximoMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-right: 16px;\r\n  padding: 0;\r\n  float: right;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-title {\r\n  display: inline-block;\r\n  width: calc(100% - 56px);\r\n  margin: 0 auto !important;\r\n  margin-top: 0 !important;\r\n  color: #3A4859;\r\n  font-weight: 400;\r\n  text-transform: uppercase;\r\n  text-align: center;\r\n  vertical-align: top;\r\n  font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n  font-size: 14px;\r\n  line-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar thead tr th {\r\n  background-color: #EFF5F6;\r\n  color: #3A4859;\r\n  font-size: 13px !important;\r\n  font-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n  border-bottom: none !important;\r\n  vertical-align: middle;\r\n  text-align: center;\r\n  max-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td {\r\n  background-color: white;\r\n  border: none !important;\r\n  text-align: center;\r\n  vertical-align: middle;\r\n  padding: 0 !important;\r\n  height: 2em !important;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td a {\r\n  background-color: white;\r\n  border: none;\r\n  color: #3A4859;\r\n  font-size: 13px;\r\n  font-weight: 400;\r\n  text-align: center;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td.ui-datepicker-current-day a {\r\n  background-color: #54BBAB;\r\n  color: #fff;\r\n  /padding: .2em;\r\n  padding: 4px .35em;\r\n  font-weight: 700;\r\n}\r\n\r\n.calendario-intranet.sub-item {\r\n\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\tpadding: 0;\r\n\tpadding-bottom: 12px;\r\n\twidth: 236px;\r\n\tposition: absolute;\r\n\tright: 13%;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\ntd.ui-datepicker-week-end {\r\n    border: none !important;\r\n}\r\n\r\n.evento-intranet h5 {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tborder-top: 1px solid #d2d2d2;\r\n\tborder-bottom: 1px solid #d2d2d2;\r\n\ttext-align: center;\r\n\tpadding: 9px 0;\r\n\ttext-transform: uppercase;\r\n\tvertical-align: middle !important;\r\n}\r\n\r\n.conteudo-intranet {\r\n    box-sizing: content-box;\r\n    padding: 0 12px;\r\n}\r\n\r\n.evento-intranet a.verMais {\r\n    color: #54BBAB;\r\n    font-size: 11px;\r\n    font-weight: 700;\r\n    padding-left: 10px;\r\n    position: relative;\r\n}\r\n\r\n.evento-intranet a.verMais:before {\r\n    border-top: 3px solid transparent;\r\n    border-bottom: 3px solid transparent;\r\n    border-left: 4px solid #54BBAB;\r\n    content: \" \";\r\n    left: 0;\r\n    position: absolute;\r\n    top: 3px;\r\n}\r\n\r\n.ui-datepicker-calendar {\r\n\twidth: calc(100% - 32px);\r\n\tmargin: 0 auto;\r\n}\r\n\r\n/*-----titulo-----*/\r\n\r\ndiv.theme-header-title span.navbar-brand {\r\n\tdisplay: none;\r\n}\r\n\r\n/*-----header botoes a direita-----*/\r\n\r\n.theme-header-right {\r\n\tdisplay: block !important;\r\n}\r\n\r\n/*-----picklist-----*/\r\n\r\nselect[data-picklist-src], select[data-picklist-dest] {\r\n\tpadding: 2px 1px 1px 6px;\r\n\tbackground-color: transparent;\r\n\tbox-shadow: none;\r\n\tborder-radius: 0;\r\n\tcolor: #3A4859;\r\n    font-size: 12px !important;\r\n    background-color: white;\r\n}\r\n\r\nselect[data-picklist-src]:focus, select[data-picklist-dest]:focus {\r\n\tbox-shadow: none;\r\n\tborder-color: transparent;\r\n}\r\n\r\n/*-----mensagem push-----*/\r\n\r\ndiv.analytics-wizard-container .form-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-top, border-left, border-right: none;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.analytics-wizard-container .form-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .input-group-addon {\r\n\tdisplay: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary,\r\ndiv.analytics-wizard-container .btn-warning {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tbox-sizing: border-box;\r\n\tbackground-color:#F9B000;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary:hover,\r\ndiv.analytics-wizard-container .btn-warning:hover,\r\ndiv.analytics-wizard-container .btn-primary:active,\r\ndiv.analytics-wizard-container .btn-warning:active,\r\ndiv.analytics-wizard-container .btn-primary:focus,\r\ndiv.analytics-wizard-container .btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white !important;\r\n\tcolor:#F9B000 !important;\r\n\tborder: 1px solid #F9B000 !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 5px !important;\r\n}\r\n\r\n/*-----switcher-----*/\r\n\r\n.switch-box .switch-box-input ~ .switch-box-label {\r\n\tcolor: white !important;\r\n}\r\n\r\n.switch-box .switch-box-input:checked ~ .switch-box-label {\r\n    color: #1abc9c !important;\r\n}\r\n\r\n/*-----fieldset-----*/\r\n\r\np.fieldset-title-atm {color: white;}\r\n\r\n/*-----form group-----*/\r\n\r\nlabel.form-group {\r\n\tcolor: white;\r\n}\r\n\r\n/*-----modal------*/\r\n\r\n.modal-footer button {\r\n\tborder-radius: 4px;\r\n\tborder: 1px solid;\r\n\tbox-sizing: border-box;\r\n\tmargin: initial;\r\n}\r\n\r\n.modal-footer button:hover {\r\n\tbox-sizing: border-box !important;\r\n\tmargin: initial !important;\r\n\tborder: 1px solid black !important;\r\n}",
        "contraste": 28,
        "icon": "fa-file-image-o",
        "id": 28,
        "name": "Intranet Preto",
        "preview_mode": [
            {
                "check": true,
                "icon": "fa fa-list-alt",
                "id": "preview",
                "name": "Preview"
            },
            {
                "check": false,
                "icon": "fa fa-desktop",
                "id": "desktop",
                "name": "Desktop"
            },
            {
                "check": false,
                "icon": "glyphicon glyphicon-globe",
                "id": "mobile",
                "name": "Browser Mobile"
            },
            {
                "check": false,
                "icon": "fa fa-mobile",
                "id": "nativo",
                "name": "App Mobile"
            },
            {
                "check": false,
                "icon": "fa fa-android",
                "id": "android",
                "name": "Android"
            },
            {
                "check": false,
                "icon": "fa fa-apple",
                "id": "ios",
                "name": "IOS"
            },
            {
                "check": false,
                "icon": "fa fa-windows",
                "id": "winphone",
                "name": "WinPhone"
            },
            {
                "check": false,
                "icon": "fa fa-print",
                "id": "printer",
                "name": "Impressão"
            }
        ],
        "tema": 11,
        "value": "preto-theme-intranet.css"
    },
    "description": "Modelo de Aplicação do PRIMO",
    "footer": {
        "left": "Caixa Econômica Federal",
        "right": "12-01-2021"
    },
    "fullbuild": true,
    "groups": [
        {"name": "Splash"},
        {"name": "Principal"},
        {"name": "Arquivo"},
        {"name": "Sobre"},
        {"name": "Login"}
    ],
    "grupos": [],
    "hash": "338ff86d2516604c6db82aad2657d302e61281dd",
    "header": {
        "help": "SIPBS - Sistema de Pagamento Social",
        "subtitle": "v1.0",
        "title": "SIPBS"
    },
    "home": "splash",
    "icon": "fa-ils",
    "id": "SIPBS",
    "label_list": [
        {
            "key": "label.",
            "value": ""
        },
        {
            "key": "label..",
            "value": " "
        },
        {
            "key": "label.boto",
            "value": "Botão"
        },
        {
            "key": "label.boto.imagem",
            "value": "Botão Imagem"
        },
        {
            "key": "label.cadastrar",
            "value": "Cadastrar"
        },
        {
            "key": "label.caixa.de.texto",
            "value": "Caixa de Texto"
        },
        {
            "key": "label.cancelar.emails",
            "value": "Cancelar Email's"
        },
        {
            "key": "label.cancelar.notificaes",
            "value": "Cancelar Notificações"
        },
        {
            "key": "label.cargo.do.funcionrio",
            "value": "Cargo do Funcionário"
        },
        {
            "key": "label.carregando..",
            "value": "Carregando..."
        },
        {
            "key": "label.cedesrj.-.caixa.econmica.federal",
            "value": "CEDESRJ - Caixa Econômica Federal"
        },
        {
            "key": "label.clique.aqui.para.no.receber.emails",
            "value": "Clique aqui para NÃO receber email's"
        },
        {
            "key": "label.clique.aqui.para.no.receber.notificaes",
            "value": "Clique aqui para NÃO receber notificações"
        },
        {
            "key": "label.clique.aqui.para.receber.emails",
            "value": "Clique aqui para receber Email's"
        },
        {
            "key": "label.clique.aqui.para.receber.notificaes",
            "value": "Clique aqui para receber notificações"
        },
        {
            "key": "label.clique.para.cadastrar",
            "value": "Clique para cadastrar"
        },
        {
            "key": "label.clique.para.cadastrar.nova.senha",
            "value": "Clique para cadastrar nova senha"
        },
        {
            "key": "label.clique.para.cadastrar.um.novo.usurio",
            "value": "Clique para cadastrar um novo usuário"
        },
        {
            "key": "label.clique.para.deslogar",
            "value": "Clique para deslogar"
        },
        {
            "key": "label.clique.para.enviar.nova.senha",
            "value": "Clique para enviar nova senha"
        },
        {
            "key": "label.clique.para.instalar.a.verso.mobile",
            "value": "Clique para instalar a versão Mobile"
        },
        {
            "key": "label.clique.para.logar",
            "value": "Clique para logar"
        },
        {
            "key": "label.clique.para.retornar",
            "value": "Clique para retornar"
        },
        {
            "key": "label.clique.para.trocar.a.senha",
            "value": "Clique para trocar a Senha"
        },
        {
            "key": "label.confirmar.a.senha",
            "value": "Confirmar a senha"
        },
        {
            "key": "label.data.de.cadastramento",
            "value": "Data de Cadastramento"
        },
        {
            "key": "label.descrio.da.atividade",
            "value": "Descrição da Atividade"
        },
        {
            "key": "label.deslogar",
            "value": "Deslogar"
        },
        {
            "key": "label.email.do.usurio",
            "value": "Email do usuário"
        },
        {
            "key": "label.entrada.de.combo",
            "value": "Entrada de Combo"
        },
        {
            "key": "label.entrada.de.data.(calendrio)",
            "value": "Entrada de Data (calendário)"
        },
        {
            "key": "label.entrada.de.email",
            "value": "Entrada de Email"
        },
        {
            "key": "label.entrada.de.senha",
            "value": "Entrada de Senha"
        },
        {
            "key": "label.entrada.de.texto",
            "value": "Entrada de Texto"
        },
        {
            "key": "label.entrar",
            "value": "Entrar"
        },
        {
            "key": "label.enviar.nova.senha",
            "value": "Enviar nova senha"
        },
        {
            "key": "label.esqueci.a.senha",
            "value": "Esqueci a senha"
        },
        {
            "key": "label.esqueci.minha.senha",
            "value": "ESQUECI MINHA SENHA"
        },
        {
            "key": "label.exibe.a.situao.atual.da.assinatura.de.notificaes",
            "value": "Exibe a situação atual da assinatura de notificações"
        },
        {
            "key": "label.informe.a.senha",
            "value": "Informe a senha"
        },
        {
            "key": "label.informe.o.email",
            "value": "Informe o email"
        },
        {
            "key": "label.informe.o.email.cadastrado",
            "value": "Informe o email cadastrado"
        },
        {
            "key": "label.informe.o.nome.completo",
            "value": "Informe o nome completo"
        },
        {
            "key": "label.layout.-.sistema.genrico",
            "value": "SIPBS - Sistema de Pagamento Social"
        },
        {
            "key": "label.link",
            "value": "Link"
        },
        {
            "key": "label.listagem",
            "value": "Listagem"
        },
        {
            "key": "label.login",
            "value": "LOGIN"
        },
        {
            "key": "label.modelo.de.aplicao.do.primo",
            "value": "Modelo de Aplicação do PRIMO"
        },
        {
            "key": "label.nome",
            "value": "Nome"
        },
        {
            "key": "label.novo.usurio",
            "value": "Novo usuário"
        },
        {
            "key": "label.perfil",
            "value": "PERFIL"
        },
        {
            "key": "label.perfil.do.usurio",
            "value": "Perfil do Usuário"
        },
        {
            "key": "label.por.favor.informe.seu.login",
            "value": "Por favor informe seu login"
        },
        {
            "key": "label.primo/siogp",
            "value": "PRIMO/SIOGP"
        },
        {
            "key": "label.principal",
            "value": "PRINCIPAL"
        },
        {
            "key": "label.prototipado.no.primo,.suportado.pelo.siogp",
            "value": "prototipado no PRIMO, suportado pelo SIOGP"
        },
        {
            "key": "label.quebra.de.linha.(br)",
            "value": "Quebra de linha (br)"
        },
        {
            "key": "label.quero.me.cadastrar",
            "value": "QUERO ME CADASTRAR"
        },
        {
            "key": "label.receber.emails",
            "value": "Receber Email's"
        },
        {
            "key": "label.receber.notificaes",
            "value": "Receber Notificações"
        },
        {
            "key": "label.retornar",
            "value": "retornar"
        },
        {
            "key": "label.separador.(hr)",
            "value": "Separador (hr)"
        },
        {
            "key": "label.sistema.genrico",
            "value": "Sistema Genérico"
        },
        {
            "key": "label.situao.das.notificaes",
            "value": "Situação das Notificações"
        },
        {
            "key": "label.sobre",
            "value": "SOBRE"
        },
        {
            "key": "label.splash",
            "value": "SPLASH"
        },
        {
            "key": "label.sub-ttulo",
            "value": "Sub-título"
        },
        {
            "key": "label.tela.de.cadastramento",
            "value": "Tela de Cadastramento"
        },
        {
            "key": "label.tela.de.login",
            "value": "Tela de Login"
        },
        {
            "key": "label.tela.de.perfil.do.usurio",
            "value": "Tela de Perfil do Usuário"
        },
        {
            "key": "label.tela.de.recuperao.de.senha",
            "value": "Tela de recuperação de senha"
        },
        {
            "key": "label.tela.de.splash",
            "value": "Tela de Splash"
        },
        {
            "key": "label.tela.principal",
            "value": "Tela Principal"
        },
        {
            "key": "label.texto",
            "value": "Texto"
        },
        {
            "key": "label.timer",
            "value": "Timer"
        },
        {
            "key": "label.trocar.a.senha",
            "value": "Trocar a Senha"
        },
        {
            "key": "label.ttulo",
            "value": "Título"
        },
        {
            "key": "label.v1.0",
            "value": "v1.0"
        }
    ],
    "lastchange": "12/01/2021 16:01:07",
    "logs": [],
    "menuHorizontal": false,
    "menuVertical": true,
    "menus": [{
        "itensMenu": [
            {
                "description": "Tela Principal",
                "icon": "fa-home",
                "locked": true,
                "target": "principal",
                "title": "Principal1"
            },
            {
                "description": "Tela Manter Arquivo",
                "icon": "fa-home",
                "locked": true,
                "target": "arquivo",
                "title": "Arquivo"
            },
            {
                "description": "Tela Manter Arquivo",
                "icon": "fa-home",
                "locked": true,
                "target": "arquivo",
                "title": "Arquivo"
            },
            {
                "description": "Sobre a aplicação",
                "icon": "fa-question",
                "target": "sobre",
                "title": "Sobre"
            }
        ],
        "tipo": "vertical"
    }],
    "menusNotes": [],
    "model": 2,
    "name": "Sistema de Pagamento Social",
    "new": false,
    "newProject": true,
    "notes": [],
    "notificacoes": true,
    "order": "20210112160107",
    "owner": "Caixa Econômica Federal",
    "server": {
        "active": true,
        "address": "crjsvapllx0129",
        "apps": null,
        "description": "",
        "http": 13019,
        "icon": "fa-server",
        "id": "18",
        "info": {
            "SystemLoadAverage": "0.25",
            "TotalPhysicalMemorySize": "33652899840",
            "freePhysicalMemorySize": "13935063040",
            "heapMemoryMax": "239075328",
            "heapMemoryTotal": "121110528",
            "heapMemoryUsed": "69679608",
            "threadCount": "114",
            "uptime": 407403
        },
        "instance": "Exclusiva",
        "name": "andrea.lourenco@caixa.gov.br",
        "new": false,
        "password": "Redh@t20",
        "port": "9999",
        "remote": 12339,
        "remotepass": "Redh@t20",
        "remoteuser": "siogpadmin",
        "server": "crjsvapllx0129",
        "serveractive": true,
        "status": "ATIVA",
        "tipo": 1,
        "username": "siogpadmin"
    },
    "sessionId": "wLlieBEV7WDUd5KWZEP1Xnf39Ajq_ufCQvHLJk-C",
    "sessionToken": "wLlieBEV7WDUd5KWZEP1Xnf39Ajq_ufCQvHLJk-C",
    "sessionUser": "andrea.lourenco@caixa.gov.br",
    "shareNotes": [],
    "theme": {
        "content": "/*\r\nTEMA para PRIMO\r\ninicializado automaticamente pelo PRIMO Front-end\r\nde acordo com o tema selecionado no projeto\r\n*/\r\n\r\n/*---------- fontes */\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN45__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: 500;\r\n\tfont-style: normal;\r\n}\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN85__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: bold;\r\n\tfont-style: normal;\r\n}\r\n\r\n/*---------- fontes */\r\n\r\n.theme-app {\r\n\tbackground-color: #fff;\r\n}\r\n\r\n.theme-header {\r\n\tbackground-color: #296fa7;\r\n\tborder-bottom: 3px solid #F39A00!important;\r\n}\r\n.theme-app.tabbed .theme-header {\r\n\tborder-bottom: none!important;\r\n}\r\n\r\n.theme-header-tabs {\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-header-right > .navbar-brand {\r\n\tcolor: #fff;\r\n\tpadding-right: 5px;\r\n}\r\n.theme-header-left > .navbar-brand {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-header-middle.navbar-brand{\r\n\tcolor: #fff;\r\n}\r\n.theme-header-tabs {\r\n\t    background-color: #fff;\r\n}\r\n\r\n.theme-header-tabs > li.active > a {\r\n\tbackground-color: #296fa7;\r\n\tcolor: #fff;\r\n}\r\n.theme-footer {\r\n\tbackground-color: #296fa7;\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-footer-right {\r\n\tpadding-right: 10px;\r\n}\r\n.theme-footer-middle {\r\n\r\n}\r\n.theme-footer-left {\r\n\tpadding-left: 10px;\r\n}\r\n\r\n.theme-header-left > a {\r\n\tbackground: url(../imgs/theme-padrao/caixab.png) no-repeat!important;\r\n\twidth: 112px;\r\n\theight: 24px;\r\n\tmargin-top: 20px!important;\r\n\tmargin-left: 10px!important;\r\n}\r\n\r\n.theme-header-left-caption {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.theme-header-title {\r\n\theight: 63px;\r\n\tpadding:;\r\n}\r\n\r\n.form-group{\r\n\t/* top:20px; */\r\n}\r\n\r\n.theme-header-acessibilidade{\r\n\theight: 25px;\r\n\tbackground-color: #2ca5fe;\r\n}\r\n\r\n.theme-link-acessibilidade{\r\n\tposition: relative;\r\n\ttop: 3px;\r\n\tleft: 10px;\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-app.tabbed .theme-menu-container {\r\n    margin-top: 120px!important;\r\n}\r\n.theme-app .theme-menu-container {\r\n    margin-top: 80px!important;\r\n}\r\n\r\n.theme-app.collapse.in .theme-submenu-item > a {\r\n\tpadding-left: 20px;\r\n}\r\n\r\n.theme-app .theme-main-container {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 70px 0 50px 0px;\r\n}\r\n\r\n.theme-app.menu .theme-main-container {\r\n\tmargin: 10px 0 50px 0px;\r\n}\r\n@media (min-width: 768px) {\r\n\t.theme-app.tabbed .theme-menu-container {\r\n\t    margin-top: 20px!important;\r\n\t}\r\n\t.theme-app .theme-menu-container {\r\n\t    margin-top: 0px!important;\r\n\t    padding-bottom: 120px;\r\n\t}\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 15px!important;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tposition: fixed;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-header-right {\r\n\t\tpadding-right: 15px;\r\n\t}\r\n\t\t\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 10px!important;\r\n\t}\r\n\r\n\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 0 70px!important;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 0px!important;\r\n\t}\r\n\r\n\t.theme-main-container {\r\n\t\tmargin: 67px 0 0 70px;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tmargin-top: 3px!important;\r\n\t}\r\n}\r\n\r\n\r\n.sidebar-nav > .nav li > a.active {\r\n    margin: 0;\r\n    border-left: 4px solid #ffa100;\r\n    border-left-width: 4px;\r\n    border-left-style: solid;\r\n    border-left-color: #ffa100;\r\n    border-top: 1px solid #d9d9d9;\r\n    border-top-width: 1px;\r\n    border-top-style: solid;\r\n    border-top-color: rgb(217, 217, 217);\r\n    border-bottom: 1px solid #d9d9d9;\r\n    border-bottom-width: 1px;\r\n    border-bottom-style: solid;\r\n    border-bottom-color: rgb(217, 217, 217);\r\n    background-color: #f5f7f7;\r\n}\r\n\r\n.theme-header .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n.theme-footer .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n\r\nbutton {\r\n\tmargin-right: 5px;\r\n}\r\n\r\n.table-responsive{\r\n\ttop:20px;\r\n}\r\n\r\n/* texto */\r\n.text-primary {\r\n\tcolor: #296fa7;\r\n}\r\n.text-primary-important {\r\n\tcolor: #296fa7!important;\r\n}\r\n.text-warning {\r\n\tcolor: #ffa100;\r\n}\r\n.text-warning-important {\r\n\tcolor: #ffa100!important;\r\n}\r\n.text-success {\r\n\tcolor: #3c763d;\r\n}\r\n.text-success-important {\r\n\tcolor: #3c763d!important;\r\n}\r\n.text-black {\r\n\tcolor: #464646;\r\n\tfont-weight: 100;\r\n}\r\n.text-purple {\r\n\tcolor: #494d62;\r\n\tfont-weight: 100;\r\n}\r\n.text-laranja {\r\n\tcolor: #ffa100;\r\n\tfont-weight: 100;\r\n}\r\n.text-info {\r\n\tcolor: #c0b723;\r\n\tfont-weight: 100;\r\n}\r\n.text-danger {\r\n\tcolor: #920A04;\r\n\tfont-weight: 100;\r\n}\r\n\r\n/* Botoes */\r\n.btn-outline {\r\n\tcolor: inherit;\r\n\tbackground-color: transparent;\r\n\ttransition: all .5s;\r\n}\r\n\r\n.btn-primary.btn-outline {\r\n\tcolor: #428bca;\r\n}\r\n\r\n.btn-success.btn-outline {\r\n\tcolor: #5cb85c;\r\n}\r\n\r\n.btn-info.btn-outline {\r\n\tcolor: #5bc0de;\r\n}\r\n\r\n.btn-warning.btn-outline {\r\n\tcolor: #f0ad4e;\r\n}\r\n\r\n.btn-danger.btn-outline {\r\n\tcolor: #d9534f;\r\n}\r\n\r\n.btn-primary.btn-outline:hover,\r\n.btn-success.btn-outline:hover,\r\n.btn-info.btn-outline:hover,\r\n.btn-warning.btn-outline:hover,\r\n.btn-danger.btn-outline:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-menu-container {\r\n\tborder-right: 1px solid #ADADAD;\r\n\theight: 100%;\r\n\tbackground: #fff;\r\n}\r\n\r\n.theme-main-container.menu {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 0px 0 50px 0px;\r\n}\r\n\r\n.theme-app.tabbed .page-wrapper {\r\n\tmargin-top: 110px;\r\n}\r\n\r\n\r\n.theme-menu-item {\r\n\tborder-bottom: 0px!important;\r\n}\r\n\r\n.table-bordered{\r\n\tborder: none;\r\n}\r\n\r\n.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, \r\n.table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, \r\n.table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th{\r\n\tborder-top: 1px solid #ccc;\r\n}\r\n\r\n/* Material Design Switch */\r\n.material-switch-contraste-contraste {\r\n\tmargin-top: 5px;\r\n}\r\n.material-switch-contraste > input[type=checkbox] {\r\n\tdisplay: none;\r\n}\r\n\r\n.material-switch-contraste > label {\r\n\tcursor: pointer;\r\n\theight: 0px;\r\n\tposition: relative;\r\n\twidth: 40px;\r\n\ttop: -20px;\r\n}\r\n\r\n.material-switch-contraste > label::before {\r\n\tleft: 0px;\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\tborder-radius: 8px;\r\n\tcontent: '';\r\n\theight: 13px;\r\n\tposition:absolute;\r\n\topacity: 0.3;\r\n\ttransition: all 0.4s ease-in-out;\r\n\twidth: 34px;\r\n\ttop: 14px;\r\n}\r\n.material-switch-contraste > label::after {\r\n\tbackground: rgb(255, 255, 255);\r\n\tborder-radius: 16px;\r\n\tbox-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);\r\n\tcontent: '';\r\n\theight: 20px;\r\n\tleft: 0px;\r\n\tposition: absolute;\r\n\ttop: 11px;\r\n\ttransition: all 0.3s ease-in-out;\r\n\twidth: 20px;\r\n}\r\n\r\n.material-switch-contraste > input[type=checkbox]:checked + label::before {\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\topacity: 0.1;\r\n}\r\n\r\n.material-switch-contraste > input[type=checkbox]:checked + label::after {\r\n\tbackground: inherit;\r\n\tbox-shadow: 0px 0px 5px rgba(255, 255, 255, 0.5);\r\n\tleft: 20px;\r\n}\r\n\r\n.breadcrumb{\r\n\tmargin-top: 10px;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n}\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none!important;\r\n}\r\n\r\n\r\n\r\n\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n/*---------------------------------------------- TEMPLATE INTRANET 2018 -------------------------------------------------*/\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n\r\n\r\n/*-----cabecalho-----*/\r\n\r\n.theme-header {\r\n\tborder-bottom: none !important;\r\n\tbox-sizing: border-box !important;\r\n\tbackground-image: url(../imgs/theme-intranet/bg_header.jpg);\r\n\tbackground-repeat: no-repeat;\r\n\tbackground-position: center 20px;\r\n\twidth: 100%;\r\n}\r\n\r\n.theme-appGerado .theme-header{\r\n\tbackground-position: initial;\r\n}\r\n\r\n.theme-header-right-title {\r\n\tmargin-top: 5px;\r\n\tmargin-right: 25px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.navbar-left.theme-header-left {\r\n\theight: 63px !important;\r\n\tbackground-image: url(../imgs/theme-intranet/logo_caixa.png) !important;\r\n\tbackground-repeat: no-repeat !important;\r\n\tbackground-position: center left !important;\r\n\tmargin: 0 !important;\r\n\tpadding: 0 !important;\r\n\tmargin-left: 15% !important;\r\n}\r\n\r\n.theme-header-left a {background: none !important;}\r\n\r\n.navbar-brand  {padding-right: inherit !important;}\r\n\r\n.navbar-brand[title^=Avaliação]  {padding-right: inherit !important;}\r\n\r\n.navbar-toggle {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n\tborder: none;\r\n}\r\n\t\r\n.navbar-toggle i {\r\n\twidth: 20px;\r\n\theight: 20px;\r\n\tmargin-right: 36px;\r\n}\r\n\r\n.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:active, \r\n.navbar-default .navbar-toggle:focus, .nav li a:hover, .nav li a:active, .nav li a:focus {background: none;}\r\n\r\n/*-----rodape-----*/\r\n\r\n.theme-footer {\r\n\tborder: none !important;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n/*-----menu horizontal-----*/\r\n\r\nul[ng-hide=currentview.telainicial] {\r\n\tborder-top: none !important;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px;\r\n\tborder-bottom: 1px solid #B3C7CB;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li {\r\n\tpadding-top: 10px;\r\n\tpadding-bottom: 10px;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li a {\r\n\tcolor: #B3C7CB;\r\n\tborder-right: 1px solid #B3C7CB !important;\r\n\tborder-radius: 0;\r\n\tdisplay: inline-block;\r\n\tpadding-top: 0;\r\n\theight: 16px;\r\n\tline-height: 1;\r\n}\r\n\r\n.nav .open>a, .nav .open>a:focus, .nav .open>a:hover {\r\n\tbackground: none;\r\n\tborder: none;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li a:hover {\r\n\tborder: none;\r\n\toutline: none;\r\n\tborder-right: 1px solid #B3C7CB;\r\n\tcolor: #3A4859;\r\n}\r\n\r\nul.theme-header-tabs > li:last-child a {border: none !important;}\r\n\r\nul[ng-hide=currentview.telainicial] li a i {display: none;}\r\n\r\nul[ng-hide=currentview.telainicial] li ul li a {border: none !important;}\r\n\r\n/*-----menu vertical-----*/\r\n\r\n.sidebar-nav .nav li a.active {\r\n\tborder: none;\r\n\tcolor: white;\r\n\tfont-size: 13px;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n.sidebar, .sidebar-nav {\r\n\tborder: none;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-weight: bold;\r\n\tbackground-color: #F9F9F9;\r\n\twidth: 217px;\r\n}\r\n\r\n.sidebar-nav .nav li {padding:0;}\r\n\r\n.sidebar-nav .nav li a {\r\n\tcolor: #9aacaf;\r\n\tfont-size: 14px;\r\n\tdisplay: block;\r\n\tpadding-left: 16px;\r\n\tline-height: 23.5px;\r\n\tmin-height: 47px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li a i {display: none;}\r\n\r\n.sidebar-nav .nav li.open > a {background-color: #F4F4F4; display: block;}\r\n\r\n.sidebar-nav .nav li > a[aria-expanded=true] {\r\n\tcolor: white;\r\n\tfont-size: 13px;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n.sidebar-nav .nav li ul li a {\r\n\tbackground-image: none !important;\r\n\tbackground-color: #F4F4F4 !important;\r\n\tcolor: #B3C7CB !important;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tpadding-left: 28px;\r\n\tline-height: 16px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li ul li a.active {\r\n\tcolor: #54BBAB !important;\r\n\tfont-size: 12px;\r\n}\r\n\r\n/*-----carrossel-----*/\r\n\r\n.carousel {\r\n\tmargin: 16px 16px 0 16px;\r\n\t/* display: inline-block;\r\n\twidth: 679px;\r\n\theight: 215px; */\r\n}\r\n\r\n.carousel-control {display: none;}\r\n\r\n.carousel-indicators li, .carousel-indicators .active {\r\n\tmargin: 16px 9px;\r\n\tborder-color: #BCBEC0;\r\n\tbackground-color: #BCBEC0;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.carousel-indicators .active {\r\n\tborder-color: #54BBAB;\r\n\tbackground-color: #54BBAB;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nol.carousel-indicators {\r\n\tposition: static;\r\n\tlist-style: none;\r\n\tmargin: 0 auto;\r\n}\r\n\r\n.carousel-caption {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tbackground: none;\r\n\t/\r\n\tmargin-bottom: 28px;\r\n\t/\r\n\tmargin-left: 31px;\r\n\tpadding: 0;\r\n\ttext-shadow: none;\r\n\tposition: relative;\r\n\tleft: 210px;\r\n\ttop: -52px;\r\n}\r\n\r\n.carousel-caption h4 {\r\n\tfont-size: 12px !important;\r\n\tfont-weight: bold;\r\n\tmargin-bottom: 0;\r\n}\r\n\r\n.carousel-caption p {\r\n\tmargin-left: 16px;\r\n\tmargin-bottom: 0;\r\n}\r\n\r\n.carousel-caption h4:before {\r\n\tcontent:'0025E3';\r\n\tfont-size: 12px;\r\n\tmargin-right: 6px;\r\n\tcolor: #EB7F2A;\r\n}\r\n\r\n/*-----texto-----*/\r\n\r\n.text-primary, .text-primary-important, .text-warning,\r\n.text-warning-important, .text-success, .text-success-important,\r\n.text-default, .text-black, .text-purple, .text-laranja, .text-info,\r\n.text-danger {\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-weight: normal;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\t/text-align: left;\r\n}\r\ni.fa.text-primary {\r\n\tfont-family: FontAwesome;\r\n}\r\n\r\n.text-primary {color: #3A4859;}\r\n.text-primary-important {color: #3A4859 !important;}\r\n.text-warning {color: #F39200;}\r\n.text-warning-important {color: #F39200 !important;}\r\n.text-success {color: #54BBAB;}\r\n.text-success-important {color: #54BBAB !important;}\r\n.text-default {color: #3A4859; font-weight: 100;}\r\n.text-black {color: #3A4859;font-weight: 100;}\r\n.text-purple {color: #494d62; font-weight: 100;}\r\n.text-laranja {color: #F39200; font-weight: 100;}\r\n.text-info {color: #F9B000; font-weight: 100;}\r\n.text-danger {color: #F9765E; font-weight: 100;}\r\n\r\ndiv.theme-main-list label,\r\nh5.theme-main-push-status {\r\n\tcolor: #3A4859;\r\n\tfont-weight: normal;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\tpadding: 0;\r\n\tmargin: 0 0 5px 0;\r\n}\r\n\r\nh5.theme-main-h4, h6.theme-main-h6 {\r\n\tfont-weight: bold;\r\n\tline-height: 1;\r\n\tcolor: #9aacaf;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 20px !important;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tmargin-top: 0;\r\n}\r\n\r\nh5.theme-main-h4 {\r\n\tborder-bottom: 1px solid #9aacaf;\r\n\tpadding-bottom: 6px;\r\n\tmargin-bottom: 30px;\r\n}\r\n\r\nh6.theme-main-h6 {\r\n\tfont-size: 14px !important;\r\n\tmargin-bottom: 12px;\r\n}\r\n\r\n\r\n/*-----tabelas-----*/\r\n\r\nthead tr th {\r\n\tbackground-color: white;\r\n\tcolor: #3A4859;\r\n\tfont-size: 13px !important;\r\n\tborder-top: none !important;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tvertical-align: bottom;\r\n    border-bottom: 2px solid #ddd !important;\r\n\theight: 35px;\r\n\tfont-size: 14px;\r\n\tpadding: 8px !important;\r\n\tline-height: 13px !important;\r\n}\r\n\r\ntbody tr td {\r\n\tcolor: #3A4859;\r\n\tline-height: 1.428571429;\r\n\tvertical-align: top;\r\n\tborder-top: 1px solid #ddd;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tborder-bottom: none !important;\r\n\theight: 35px !important;\r\n\tfont-size: 13px;\r\n\tpadding: 8px !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ntbody tr:nth-child(odd),\r\ntbody tr:nth-child(odd):hover {background-color: #f9f9f9; !important;}\r\n\r\ntbody tr:nth-child(even),\r\ntbody tr:nth-child(even):hover {background-color: white;}\r\n\r\ntd button {\r\n\tbackground: none;\r\n\tmargin:0 !important;\r\n\tpadding:0!important;\r\n}\r\n\r\n/*-----inputs-----*/\r\n\r\ndiv.form-group {\r\n\tpadding: 0;\r\n\tmargin-bottom: 20px !important;\r\n\t/*display: inline-block;*/\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.form-control {\r\n\tbox-shadow:none;\r\n}\r\n\r\ndiv.form-group label {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tline-height: 16px;\r\n\tcolor: #54BBAB;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 0;\r\n\tline-height: 1;\r\n}\r\n\r\ndiv.input-group {\r\n    width: inherit;\r\n    height: 34px;\r\n    min-width: 100%;\r\n    padding-right: 30px;\r\n}\r\n\r\ndiv.input-group input:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.input-group input {\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB !important;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding: 13px 0 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio label  {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tcolor: #54BBAB;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 2px;\r\n}\r\n\r\ndiv.input-group input::-webkit-input-placeholder {color: #3A4859;}\r\ndiv.input-group input:-moz-placeholder {color: #3A4859;}\r\ndiv.input-group input::-moz-placeholder {color: #3A4859;}\r\ndiv.input-group input:-ms-input-placeholder {color: #3A4859;}\r\ndiv.input-group input::-ms-input-placeholder {color: #3A4859;}\r\n\r\nspan.input-group-addon {display: none;}\r\n\r\n.form-control[disabled],\r\n.form-control[readonly],\r\nfieldset[disabled] .form-control,\r\n.form-control[disabled]:active,\r\n.form-control[readonly]:active,\r\nfieldset[disabled] .form-control:active,\r\n.form-control[disabled]:focus,\r\n.form-control[readonly]:focus,\r\nfieldset[disabled] .form-control:focus\r\n {\r\n\tbackground-color: rgba(0,0,0,0);\r\n\tcolor: #B3C7CB;\r\n\tborder-bottom-color: #B3C7CB;\r\n}\r\n\r\n.form-control[disabled] > label.label-mobilidade,\r\n.form-control[readonly] > label.label-mobilidade,\r\nfieldset[disabled] .form-control > label.label-mobilidade {\r\n\tcolor: #B3C7CB !important;\r\n}\r\n\r\n/*-----combo box-----*/\r\n\r\n.theme-main-input-check label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tfont-weight: normal !important;\r\n\tcolor: #54BBAB;\r\n\tmargin-bottom: 2px !important;\r\n}\r\n\r\n.input-group select {\r\n\t-webkit-appearance: none;\r\n\t-moz-appearance: none;\r\n\tappearance: none;\r\n\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat top right;\r\n\tborder-radius: 0;\r\n\tborder-top: none;\r\n\tborder-right: none;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-left: none;\r\n\tpadding: 0 0 10px 0;\r\n\theight: 26px;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 6px !important;\r\n\tbox-sizing: border-box;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tline-height: 12px;\r\n}\r\n\r\n.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\r\n/*-----caixa de texto-----*/\r\n\r\ndiv.input-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.input-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n/*-----botoes-----*/\r\n\r\n.theme-main-button {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n}\r\n\r\n.btn-primary, .btn-warning {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:#F9B000;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\n.btn-primary:hover,\r\n.btn-warning:hover,\r\n.btn-primary:active,\r\n.btn-warning:active,\r\n.btn-primary:focus,\r\n.btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white !important;\r\n\tcolor:#F9B000 !important;\r\n\tborder: 1px solid #F9B000 !important;\r\n\tbox-shadow: none !important;\r\n}\t\r\n\r\n.theme-main-button[disabled=disabled],\r\n.theme-main-button[disabled=disabled]:hover,\r\n.theme-main-button[disabled=disabled]:focus {\r\n\tbackground-color:#d0e0e3 !important;\r\n\tborder-color:#d0e0e3 !important;\r\n\tcolor:white; \r\n\topacity:1 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton#optOpces {background-color: white;}\r\nbutton#optOpces.active {color:#48586C;}\r\n\r\nbutton.btn-default,\r\nbutton.theme-main-button-subscribe,\r\nbutton.theme-main-button-unsubscribe {\r\n\tbox-sizing: border-box;\r\n\tcolor:#54BBAB;\r\n\tbackground-color: white;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\theight: 45px;\r\n\tborder: 1px solid #54BBAB;\r\n}\r\n\r\nbutton.btn-default:hover,\r\nbutton.theme-main-button-subscribe:hover,\r\nbutton.theme-main-button-unsubscribe:hover,\r\nbutton.btn-default:active,\r\nbutton.theme-main-button-subscribe:active,\r\nbutton.theme-main-button-unsubscribe:active,\r\nbutton.btn-default:focus,\r\nbutton.theme-main-button-subscribe:focus,\r\nbutton.theme-main-button-unsubscribe:focus {\r\n\tcolor:white !important;\r\n\tbackground-color: #54BBAB !important;\r\n\tborder: 1px solid #54BBAB !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-left: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton.theme-main-button-subscribe:first-child {\r\n\tmargin-left:0;\r\n}\r\n\r\nbutton#btnEnviar {\r\n\tfont-size:0.5em;\r\n}\r\n\r\n#btnEnviar:hover, #btnEnviar:active, #btnEnviar:focus {\r\n\tdisplay: block !important;\r\n\tmargin-right: auto !important;\r\n\tmargin-left: auto !important;\r\n\tmargin-bottom: 0 !important;\r\n\tbox-sizing: border-box;\r\n\theight: 38px;\r\n}\r\n\r\n.modal-dialog button.btn {\r\n\theight: initial;\r\n\tfont-family: inherit;\r\n\tfont-weight: inherit;\r\n}\r\n\r\n\r\n.modal-dialog button.btn-primary,\r\n.modal-dialog button.btn-primary:hover {\r\n\tmargin: 0 !important;\r\n\theight: 34px;\r\n}\r\n\r\n\r\n/*-----radio-----*/\r\n\r\ndiv.theme-main-input-radio {\r\n\tpadding: 0;\r\n}\r\n\r\ndiv.theme-main-input-radio button {\r\n\tcolor: #6c6c6c;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tborder: 1px solid #D0E0E3;\r\n\topacity: 1 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n\tborder-radius: 3px;\r\n\tpadding: 0 9px;\r\n\r\n}\r\n\r\ndiv.theme-main-input-radio button:hover {\r\n\tbackground-color: #6c6c6c !important;\r\n\tborder: 1px solid #D0E0E3 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active,\r\ndiv.theme-main-input-radio button.active:active,\r\ndiv.theme-main-input-radio button.active:focus {\r\n\tcolor: white !important;\r\n\tbackground-color: #058CE1 !important;\r\n\tborder: 1px solid #058CE1 !important;\r\n\tbox-shadow: none;\r\n\tfont-weight: normal;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active:hover {\r\n\tbackground-color: white !important;\r\n\tborder: 1px solid #058CE1 !important;\r\n\tcolor: #058CE1 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\n/*-----checkbox-----*/\r\n\t\r\n.input-group {margin-bottom: 0px;}\r\n\r\n.input-group > label {\r\n\tdisplay: block;\r\n\t/color: #48586C;\r\n\t/height: 20px;\r\n\t/margin: 0 14px 5px 0;\r\n}\r\n\r\n.theme-main-input-check div.input-group label {\r\n\tcolor:#48586C;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*\r\n.input-group > label input[type=checkbox] {\r\n\tposition: relative;\r\n\tbottom: -40%;\r\n\tmargin-right: 14px;\r\n}\r\n\r\n.input-group > label input[type=checkbox]:before {\r\n\tcontent: '';\r\n\tposition: relative;\r\n\tbottom: -15%;\r\n\tbackground-color: white !important;\r\n\tdisplay: inline-block;\r\n\twidth: 18px;\r\n\theight: 18px;\r\n\tborder: 1px solid #D0E0E3;\r\n}\r\n\r\n.input-group > label input[type=checkbox]:checked:before {\r\n\tcontent: '';\r\n\tbackground-color: #54BBAB !important;\r\n\tdisplay: inline-block;\r\n\twidth: 17px;\r\n\theight: 17px;\r\n\tborder: 4px solid white;\r\n\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\tbox-sizing: border-box;\r\n}\r\n*/\r\n\r\n/*-----breadcrumb-----*/\r\n\r\nol.breadcrumb {\r\n\tbackground-color: white;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tcolor: #3A4859;\r\n}\r\n\r\nol.breadcrumb li a {color: #54BBAB; text-decoration: underline;}\r\n\r\nol.breadcrumb:before {\r\n\tcontent: 'Você  está em';\r\n\tfont-weight: bold;\r\n\tpadding-right: 8px;\r\n}\r\n\r\nol.breadcrumb li:before {content:''; padding-left:0 !important;}\r\n\r\nol.breadcrumb li:after {content:'\\25BA'; padding-left:1ch;}\r\n\r\nol.breadcrumb li:last-child:after {content:'';}\r\n\r\nol.breadcrumb li span {color: #3A4859;}\r\n\r\n/*-----navbar-----*/\r\n\r\n.navbar-brand-middle {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 18px;\r\n\tpadding-top: 22px;\r\n}\r\n\r\n/*-----links-----*/\r\n\r\n.theme-main-link a {\r\n\tcolor: #54BBAB;\r\n\tfont-size: 11px;\r\n\ttext-decoration: none !important;\r\n}\r\n\r\n.theme-main-link a:hover {\r\n\ttext-decoration: underline !important;\r\n}\r\n\r\n/*-----listagem-----*/\r\n\r\ndiv.theme-main-list {margin-top: 2em;}\r\n\r\ndiv.theme-main-list,\r\ndiv.theme-main-list div.text-left,\r\ndiv.theme-main-list div.text-right {padding: 0;}\r\n\r\n\r\n*:focus {outline: none !important;}\r\n\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n\tborder: none;\r\n\tmargin-bottom: 35px;\r\n}\r\n\r\n.rodape-atm{\r\n\tdisplay: none;\r\n}\r\n\r\n.caixa-azul{\r\n\tdisplay: none;\r\n}\r\n\r\n.theme-header-ATM{\r\n\tdisplay: none;\r\n}\r\n\r\nspan.input-group-addon {display: none;}\r\n\r\ndiv.input-group input:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n.form-group {margin-bottom: 0;}\r\n\r\n.form-control {\r\n\tborder: 0;\r\n\tpadding: 4px 0;\r\n\tborder-bottom: 1px solid #ccc;\r\n\tbackground-color: transparent;\r\n\tbox-shadow: none;\r\n}\r\n\r\n.effect{\r\n\tposition:absolute;    \r\n\ttransition:0.3s;\r\n}\r\n\r\n.form-group.col-xs-12.theme-main-input-check {\r\n\tpadding-bottom: 10px;\r\n}\r\n\r\ndiv#telefone-group .input-group .col-xs-4 {\r\n\tpadding-left: 0;\r\n}\r\n\r\n\r\n/*-----combo box-----*/\r\n\r\n.theme-main-input-select label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tfont-weight: normal !important;\r\n\tcolor: #54BBAB !important;\r\n\tmargin-bottom: 2px !important;\r\n}\r\n\r\n.input-group select {\r\n\t-webkit-appearance: none;\r\n\t-moz-appearance: none;\r\n\tappearance: none;\r\n\tbackground: url(../imgs/theme-intranet/seta-combox-desktop.png) no-repeat top right;\r\n\tborder-radius: 0;\r\n\tborder-top: none;\r\n\tborder-right: none;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-left: none;\r\n\tpadding: 0 0 10px 0;\r\n\theight: 26px;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 6px !important;\r\n\tbox-sizing: border-box;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tline-height: 12px;\r\n}\r\n\r\n.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\r\n/*-----caixa de texto-----*/\r\n\r\ndiv.input-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.input-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n\r\n.side-menubar{\r\n    display:none;\r\n}\r\n\r\n\r\n/*-----transicao labels-----*/\r\n\r\ninput.form-control ~ label {\r\n\tmargin-top:0;\r\n\tposition:absolute;\r\n\ttop:-5px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n\tfont-size:12px !important;\r\n}\r\n\r\ninput.form-control {\r\n    margin-top:0px !important;\r\n    transition:0.3s;\r\n}\r\n\r\ninput.form-control:placeholder-shown ~ label{\r\n    transition:0.3s;\r\n    top:5px;\r\n\tfont-size:14px!important;\r\n}\r\n\r\ninput.form-control:placeholder{\r\n    opacity:0;\r\n    color:transparent;\r\n}\r\n\r\nlabel{\r\n\tfont-size:14px !important;\r\n\ttransition:0.3s;\r\n}\r\n\r\n.form-control::-webkit-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n.form-control::-moz-placeholder {opacity:0;\r\n    color:transparent;}\r\n.form-control:-ms-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n\r\n\r\n.form-group label:nth-child(1) {\r\n   display: none;\r\n}\r\n.form-group .theme-main-input-select label:nth-child(1),\r\n.form-group.pick-list label:nth-child(1),\r\n.form-group.theme-main-input-select label:nth-child(1),\r\n.form-group.theme-main-text-area label:nth-child(1),\r\n.form-group.theme-main-input-check label:nth-child(1) {\r\n\tdisplay: block;\r\n}\r\n\r\n.theme-main-input-radio label:nth-child(1),\r\n#uplEscolhaoarquivo label {\r\n\tdisplay:block;\r\n}\r\n\r\n/*-----abas-----*/\r\nul.tabs-nav {\r\n\tborder-bottom: 2px solid #54bbab;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tpadding-bottom: 12px;\r\n}\r\n\r\nul.tabs-nav li {\r\n\tmargin: 0 0px -1px;\r\n}\r\n\r\n.tabs-nav li:first-child {\r\n    margin-left: 0 !important;\r\n}\r\n\r\nul.tabs-nav li a {\r\n\tbackground-color: #b3c7cb;\r\n    border-radius: 0;\r\n    border: none !important;\r\n    color: white !important;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    padding: 10px 30px;\r\n}\r\n\r\nul.tabs-nav li a:hover {\r\n\tbackground-color: #54bbab;\r\n}\r\n\r\nul.tabs-nav li a.active {\r\n\tbackground-color: #54bbab;\r\n    border-radius: 0;\r\n    border: none !important;\r\n    color: white !important;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    padding: 10px 30px;\r\n}\r\n\r\nul.tabs-nav li a.active:hover {\r\n\tcursor: default;\r\n}\r\n\r\ndiv.theme-main-tab .tab-content {\r\n\tmargin-top: 15px;\r\n}\r\n\r\n/*-----graficos-----*/\r\n\r\n.theme-main-chart label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tcolor: #8492af;\r\n\tfont-size: 18px !important;\r\n\tdisplay: block;\r\n\ttext-align: left;\r\n}\r\n\r\n.theme-main-chart text {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n[fill=#f0ad4e] {fill: #F39200;}\r\n[fill=#3c763d] {fill: #0E7639;}\r\n[fill=#277db6] {fill: #005CA9;}\r\n[fill=#5cb85c] {fill: #29C0B3;}\r\n[fill=#f1ca3a] {fill: #F9B000;}\r\n[text-anchor=start] {\r\n\tfont-weight: normal !important;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*-----paineis-----*/\r\n\r\n.theme-main-detail-panel {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary {border-color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-heading {\r\n\tbackground-color: #005CA9;\r\n\tborder-color: #005CA9;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-footer {color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-warning {border-color: #F9B000;}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-heading {\r\n\tbackground-color: #F9B000;\r\n\tborder-color: #F9B000;\r\n}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-footer {\r\n\tbackground-color: #EFF5F6;\r\n\tcolor: #F39200;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default {border-color: #B3C7CB;}\r\n\r\n.theme-main-detail-panel .panel-default .panel-heading {\r\n\tbackground-color: #EFF5F6;\r\n\tborder-color: #B3C7CB;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default .panel-footer {\r\n\tbackground-color: white;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger {border-color: #F51C1F;}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-heading {\r\n\tbackground-color: #F51C1F;\r\n\tborder-color: #F51C1F;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-footer {\r\n\tcolor: #F51C1F;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\n\r\n@media (min-width: 768px) {\r\n\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 26px;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    margin-right: 106px;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: white;\r\n    text-decoration: none;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid #76bad1;\r\n    padding: 3px 18px;\r\n    font-weight: bold;\r\n    box-sizing: border-box;\r\n    width: 80px;\r\n    height: 24px;\r\n}\r\n\r\n.item-sair-intranet a:hover {\r\n    text-decoration: underline;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.menu-item-intranet ul li a span {\r\n\tcolor: transparent;\r\n}\r\n\r\n.menu-item-intranet ul li.item-calendario-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/calendario_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-pesquisa-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/pesquisa_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-config-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/config_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: normal;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n    font-size: 13px !important;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n    position: absolute;\r\n    right: 18px;\r\n    border: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    width: 265px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n\tfont-size: 13px;\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #656565;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 15px;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 16px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 16px;\r\n    padding: 0 15px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 19px;\r\n}\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 24px !important;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    /margin-right: 106px;\r\n    margin-right: 2%;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: aliceblue;\r\n    text-decoration: none;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid #76bad1;\r\n    padding: 3px 18px;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: 400;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n\tposition: absolute;\r\n\tright: 15%;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\twidth: 265px;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #3A4859;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n    font-size: 13px !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 14px !important;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 18px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 14px;\r\n    padding: 0 14px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 16px;\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n\r\n\r\n/*-----componente calendario-----*/\r\n\r\n .hasDatepicker .ui-datepicker-inline {\r\n  background: transparent;\r\n  border: none;\r\n  /padding: 1px;\r\n  width: auto;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header {\r\n  background-color: white;\r\n  border: none;\r\n  padding-top: 8px;\r\n  padding-bottom: 8px;\r\n  border-bottom: 1px solid #d2d2d2;\r\n  margin-bottom: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background-position: 50%;\r\n  background-repeat: no-repeat;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next .ui-icon,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev .ui-icon {\r\n  display: none;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background: url(../imgs/theme-intranet/bt_anteriorMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-left: 16px;\r\n  padding: 0;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next {\r\n  background: url(../imgs/theme-intranet/bt_proximoMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-right: 16px;\r\n  padding: 0;\r\n  float: right;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-title {\r\n  display: inline-block;\r\n  width: calc(100% - 56px);\r\n  margin: 0 auto !important;\r\n  margin-top: 0 !important;\r\n  color: #3A4859;\r\n  font-weight: 400;\r\n  text-transform: uppercase;\r\n  text-align: center;\r\n  vertical-align: top;\r\n  font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n  font-size: 14px;\r\n  line-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar thead tr th {\r\n  background-color: #EFF5F6;\r\n  color: #3A4859;\r\n  font-size: 13px !important;\r\n  font-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n  border-bottom: none !important;\r\n  vertical-align: middle;\r\n  text-align: center;\r\n  max-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td {\r\n  background-color: white;\r\n  border: none !important;\r\n  text-align: center;\r\n  vertical-align: middle;\r\n  padding: 0 !important;\r\n  height: 2em !important;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td a {\r\n  background-color: white;\r\n  border: none;\r\n  color: #3A4859;\r\n  font-size: 13px;\r\n  font-weight: 400;\r\n  text-align: center;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td.ui-datepicker-current-day a {\r\n  background-color: #54BBAB;\r\n  color: #fff;\r\n  /padding: .2em;\r\n  padding: 4px .35em;\r\n  font-weight: 700;\r\n}\r\n\r\n.calendario-intranet.sub-item {\r\n\tdisplay:none;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\tpadding: 0;\r\n\tpadding-bottom: 12px;\r\n\twidth: 236px;\r\n\tposition: absolute;\r\n\tright: 13%;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\ntd.ui-datepicker-week-end {\r\n    border: none !important;\r\n}\r\n\r\n.evento-intranet h5 {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tborder-top: 1px solid #d2d2d2;\r\n\tborder-bottom: 1px solid #d2d2d2;\r\n\ttext-align: center;\r\n\tpadding: 9px 0;\r\n\ttext-transform: uppercase;\r\n\tvertical-align: middle !important;\r\n}\r\n\r\n.conteudo-intranet {\r\n    box-sizing: content-box;\r\n    padding: 0 12px;\r\n}\r\n\r\n.evento-intranet a.verMais {\r\n    color: #54BBAB;\r\n    font-size: 11px;\r\n    font-weight: 700;\r\n    padding-left: 10px;\r\n    position: relative;\r\n}\r\n\r\n.evento-intranet a.verMais:before {\r\n    border-top: 3px solid transparent;\r\n    border-bottom: 3px solid transparent;\r\n    border-left: 4px solid #54BBAB;\r\n    content:  ;\r\n    left: 0;\r\n    position: absolute;\r\n    top: 3px;\r\n}\r\n\r\n.ui-datepicker-calendar {\r\n\twidth: calc(100% - 32px);\r\n\tmargin: 0 auto;\r\n}\r\n\r\n/*-----titulo-----*/\r\n\r\ndiv.theme-header-title span.navbar-brand {\r\n\tdisplay: none;\r\n}\r\n\r\n/*-----header botoes a direita-----*/\r\n\r\n.theme-header-right {\r\n\tdisplay: block !important;\r\n}\r\n\r\n/*-----picklist-----*/\r\n\r\nselect[data-picklist-src], select[data-picklist-dest] {\r\n\tpadding: 2px 1px 1px 6px;\r\n\tborder: solid;\r\n\tborder-width: 1px;\r\n\tborder-color: rgb(84, 187, 171);\r\n\tbackground-color: transparent;\r\n\tbox-shadow: none;\r\n\tborder-radius: 0;\r\n\tcolor: #3A4859;\r\n    \tfont-size: 12px !important;\r\n}\r\n\r\nselect[data-picklist-src]:focus, select[data-picklist-dest]:focus {\r\n\tbox-shadow: none;\r\n\tborder-color: rgb(84, 187, 171);\r\n}\r\n\r\n/*-----mensagem push-----*/\r\n\r\ndiv.analytics-wizard-container .form-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.analytics-wizard-container .form-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .input-group-addon {\r\n\tdisplay: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary,\r\ndiv.analytics-wizard-container .btn-warning {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tbox-sizing: border-box;\r\n\tbackground-color:#F9B000;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary:hover,\r\ndiv.analytics-wizard-container .btn-warning:hover,\r\ndiv.analytics-wizard-container .btn-primary:active,\r\ndiv.analytics-wizard-container .btn-warning:active,\r\ndiv.analytics-wizard-container .btn-primary:focus,\r\ndiv.analytics-wizard-container .btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white !important;\r\n\tcolor:#F9B000 !important;\r\n\tborder: 1px solid #F9B000 !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 5px !important;\r\n\t/margin-left: 2px !important;\r\n}\t\r\n\r\n\r\n/*----MS Edge Browser CSS Start----*/\r\n\r\n@supports (-ms-accelerator:true) {\r\n\r\n\t\t.label-mobilidade{\r\n\t\t\ttop:14px !important;\r\n\t\t\tfont-size:14px !important;\r\n\t\t}\r\n}\r\n/*----MS Edge Browser CSS End----*/\r\n\r\n/*-----Angular 4-----*/\r\n\r\n\r\n@media (min-width: 767px) {\r\n\r\n\tapp-root .theme-header {\r\n\t\tbackground-position: initial;\r\n\t}\r\n\tapp-root .breadcrumb>li {\r\n\t    display: inline;\r\n\t}\r\n\tapp-root .panel.panel-primary.theme-main-map-container {\r\n\t    display: inline-grid;\r\n\t    position: relative;\r\n\t    width: 100%;\r\n\t    text-align: center;\r\n\t    margin-top: 30px;\r\n\t    margin-bottom: 30px;\r\n\t}\r\n\tapp-root div.form-group{\r\n\t\twidth:100%;\r\n\t}\r\n\tapp-root .alert.alert-danger.errorDiv {\r\n\t    margin-top: 10px;\r\n\t    height: auto;\r\n\t    padding: 8px;\r\n\t    width: auto;\r\n\t    display: inline-block;\r\n\t}\r\n\tapp-root .panel.panel-primary.theme-main-map-container {\r\n    display: inline-grid;\r\n    position:  relative;\r\n    width:  100%;\r\n    text-align:  center;\r\n    margin-top: 30px;\r\n    margin-bottom:  30px;\r\n\t}\r\n\t\r\n\tapp-root .alert.alert-danger.errorDiv {\r\n\t    margin-top:  10px;\r\n\t    height:  auto;\r\n\t    padding:  8px;\r\n\t    width:  auto;\r\n\t    display: inline-block;\r\n\t}\r\n\t\r\n\t\r\n\tapp-root .dual-list button.btn.btn-default.pull-right {\r\n\t    box-sizing: border-box;\r\n\t    background-color: white !important;\r\n\t    color: #F9B000 !important;\r\n\t    padding: 5px 12px;\r\n\t    border: 1px solid #F9B000 !important;\r\n\t    box-shadow: none !important;\r\n\t    margin-right: 0 !important;\r\n\t    height:  auto;\r\n\t}\r\n\t\r\n\tapp-root button.btn.btn-primary.btn-block.point-right:hover {\r\n\t    margin-right:  0 !important;\r\n\t    height: 32px;\r\n\t}\r\n\tapp-root .theme-main-input-number-cpf .label-mobilidade {\r\n\t    position: absolute;\r\n\t    z-index: 2;\r\n\t}\r\n\tapp-root .theme-main-input-number-conta .label-mobilidade, app-root .theme-main-input-number-cep .label-mobilidade,\r\n\tapp-root .theme-main-input-number-operacao .label-mobilidade, app-root .theme-main-input-number-matricula .label-mobilidade, \r\n\tapp-root .theme-main-input-number-telefone .label-mobilidade, app-root .theme-main-input-date .label-mobilidade {\r\n\t    position: absolute;\r\n\t    z-index: 2;\r\n\t    top: 0;\r\n\t}\r\n}\r\n\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n/*---------------------------------------------- Mobile\t -------------------------------------------------*/\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n\r\n@media (max-width: 767px) {\r\n\t\r\n\t/*-----cabecalho-----*/\r\n\r\n\t.theme-header {\r\n\t\theight: 56px;\r\n\t\tpadding: 18px 16px;\r\n\t\tborder-bottom: none !important;\r\n\t\tbackground: #54bbab;\r\n\t\tbackground: -moz-linear-gradient(left, #54bbab 1%, #005ca9 100%);\r\n\t\tbackground: -webkit-linear-gradient(left, #54bbab 1%,#005ca9 100%);\r\n\t\tbackground: linear-gradient(to right, #54bbab 1%,#005ca9 100%);\r\n\t\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#54bbab', endColorstr='#005ca9',GradientType=1 );\r\n\t}\r\n\t\r\n\t.theme-header-right-title {\r\n\t\tmargin-right: 18px;\r\n\t\tmargin-top: 2px;\r\n\t\tfont-size: 20px;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-weight: bolder;\r\n\t}\r\n\t\r\n\t.theme-header-right-subtitle {display: none;}\r\n\t\r\n\t.navbar-left {float: right;}\r\n\t\r\n\t.theme-header-left a {\r\n\t\tbackground: url(../imgs/theme-mobilidade-2017/caixa-sintese-branco.png) no-repeat!important;\r\n\t\twidth: 23.5px;\r\n\t\theight: 20px;\r\n\t\tmargin: 0!important;\r\n\t}\r\n\t\r\n\t.navbar-brand {\r\n\t\tpadding: 0!important;\r\n\t\tdisplay: block;\r\n\t\tfloat: right;\r\n    }\r\n\t\r\n\t.navbar-right {float: left!important;}\r\n\t\r\n\t.navbar-toggle {\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none;\r\n\t}\r\n\t\r\n\t.navbar-toggle i {\r\n\t\twidth: 20px;\r\n\t\theight: 20px;\r\n\t\tmargin-right: 36px;\r\n\t}\r\n\t\r\n\t.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:active, \r\n\t.navbar-default .navbar-toggle:focus, .nav li a:hover, .nav li a:active, .nav li a:focus {background: none;}\r\n\r\n\t.theme-header-right-logo {display: none !important;}\r\n\t\r\n\th1, h2, h3, h4, h5, h6, ul {font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;}\r\n\t\r\n\tli a {font-size: 1.2em;}\r\n\r\n\t/*-----rodape-----*/\r\n\r\n\t.theme-footer {display: none;}\r\n\t\r\n\t/*-----menu vertical-----*/\r\n\r\n\t.sidebar, .sidebar-nav {\r\n\t\tborder: none;\r\n\t\tbackground: white;\r\n\t\twidth: 100% !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li a {\r\n\t\tpadding: 0;\r\n\t\tfont-size: 16px;\r\n\t\tcolor: #48586C;\r\n\t\tborder-top: 1px solid #D0E0E3;\r\n\t\tfont-weight: normal;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li a.active {\r\n\t\tborder: none;\r\n\t\tbackground-color: #D0E0E3;\r\n\t\tborder-top: 1px solid #D0E0E3;\r\n\t\tcolor: #48586C;\r\n\t\tfont-size: 16px;\r\n\t\tbackground-image: none;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li i {\r\n\t\tdisplay: inline-block !important;\r\n\t\tfont-size: 18px;\r\n\t\tmargin: 14px 37px 14px 15px !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li.open > a {background-color: #eee; display: block;}\r\n\r\n\t.sidebar-nav .nav li > a[aria-expanded=\"true\"] {\r\n\t\tcolor: #48586C;\r\n\t\tfont-size: 16px;\r\n\t\tbackground-image: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li ul li a {\r\n\t\tbackground-image: none !important;\r\n\t\tbackground-color: white !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 14px;\r\n\t\tpadding-left: 0;\r\n\t\tborder: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t\tline-height: 23px;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li ul li a.active {\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-size: 14px;\r\n\t\tbackground-color: #D0E0E3 !important;\r\n\t\tborder: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t}\r\n\r\n\t/*-----inputs-----*/\r\n\r\n\t.form-control {box-shadow:none;}\r\n\t\r\n\tdiv.form-group label {\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 14px;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t}\r\n\r\n\t.input-group {font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;}\r\n\t\r\n\tspan.input-group-addon {display: none;}\r\n\t\r\n\tdiv.input-group input {\r\n\t\tborder-bottom: 1px solid #D0E0E3;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tmargin-bottom: 20px !important;\r\n\t\tfont-size: 18px !important;\r\n\t\tpadding: 0;\r\n\t}\r\n\t\r\n\tdiv.input-group input:focus {\r\n\t    border-color: #D0E0E3;\r\n\t    box-shadow: none;\r\n\t}\r\n\t\r\n\t.form-group {margin-bottom: 0;}\r\n\t\r\n\th5.padding.text-primary.bold.theme-main-h4 {\r\n\t\tfont-weight: bolder;\r\n\t\tmargin-left: -7px;\r\n\t\tfont-size: 20px !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tpadding-left: 6px;\r\n\t\tpadding-bottom: 0px;\r\n\t}\r\n\r\n\th6.padding.text-primary.theme-main-h6 {\r\n\t\tfont-weight: bolder;\r\n\t\tfont-size: 16px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tspan.label.padding.theme-main-label.text-primary {\r\n\t\tfont-size: 12px;\r\n\t\tfont-weight: lighter;\r\n\t\tcolor: #48586C;\r\n\t}\r\n\t/*span.label.padding.theme-main-label.ng-binding.text-primary.pull-left.col-xs-12*/\r\n\t\r\n\t/*-----abas-----*/\r\n\t\r\n\t.tabs-nav {\r\n\t\tmargin: 70px 0 0 0;\r\n\t\tpadding: 0;\r\n\t\tdisplay: inline-block !important;\r\n\t\theight: 75px;\r\n\t\twidth: 100%;\r\n\t\tbackground: #54bbab;\r\n\t\tbackground: -moz-linear-gradient(left, #54bbab 1%, #005ca9 100%);\r\n\t\tbackground: -webkit-linear-gradient(left, #54bbab 1%,#005ca9 100%);\r\n\t\tbackground: linear-gradient(to right, #54bbab 1%,#005ca9 100%);\r\n\t\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#54bbab', endColorstr='#005ca9',GradientType=1 );\r\n\t\toverflow: hidden;\r\n\t\tposition: relative;\r\n\t}\r\n\r\n\t.tabs-nav li {\r\n\t\tmargin: 0 !important;\r\n\t\tborder: none !important;\r\n\t\tpadding: 0 !important;\r\n\t}\r\n\r\n\t.tabs-nav li a {\r\n\t\tmargin: 25px 0;\r\n\t\tpadding: 2.5px 13px 0 13px;\r\n\t\twidth: 32.5% !important;\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tborder-left: 1px solid rgba(255, 255, 255, 0.35);\r\n\t\tborder-radius: 0;\r\n\t\theight: 25px;\r\n\t\tcolor: white;\r\n\t\ttext-align: center;\r\n\t\tfloat: left;\r\n\t\toverflow: hidden;\r\n\t}\r\n\t\t\r\n\t.tabs-nav li a.active {\r\n\t\tbackground: none;\r\n\t\tborder-bottom: none;\r\n\t}\r\n\r\n\t.tabs-nav li a.active::after {\r\n\t\tcontent: url('../imgs/theme-mobilidade-2017/seta.png');\r\n\t\ttop: 60px;\r\n\t\tmargin-left: -30px;\r\n\t\tvertical-align: bottom;\r\n\t\tposition: absolute;\r\n\t}\r\n\r\n\t/*-----tabelas-----*/\r\n\r\n\tthead tr th {\r\n\t\tpadding: 0 16px 30px 0 !important;\r\n\t\tbackground: none !important;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-size: 14px;\r\n\t\tborder: none !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\ttbody > tr > td:first-child {font-weight: normal;}\r\n\r\n\ttbody tr {background-color: white !important;}\r\n\r\n\ttbody tr td {\r\n\t\tpadding: 0 16px 30px 0 !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-size: 14px;\r\n\t\tborder: none !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\tth, td {border: none !important;}\r\n\r\n\ttd button {\r\n\t\tbackground: none;\r\n\t\tmargin: 0 !important;\r\n\t\tpadding: 0 !important;\r\n\t\tline-height: inherit !important;\r\n\t}\r\n\r\n\ttd button i {line-height: inherit !important;}\r\n\r\n\ttd button:hover, td button i:hover {color: #48586C;}\r\n    \r\n    /*-----barra de rolagem-----*/\r\n\r\n\t.table-responsive::-webkit-scrollbar {width: 5px; height: 5px;}\r\n\t.table-responsive::-webkit-scrollbar-button {width: 0; height: 0;}\r\n\t.table-responsive::-webkit-scrollbar-thumb {\r\n\t\tbackground:#54BBAB !important;\r\n\t\tborder: none;\r\n\t\tborder-radius: 0;\r\n\t}\r\n\t.table-responsive::-webkit-scrollbar-thumb:hover,\r\n\t.table-responsive::-webkit-scrollbar-thumb:active {background:#54BBAB !important;}\r\n\t.table-responsive::-webkit-scrollbar-track {\r\n\t\tbackground:#D0E0E3 !important;\r\n\t\tborder: none;\r\n\t\tborder-radius: 0;\r\n\t}\r\n\t.table-responsive::-webkit-scrollbar-track:hover,\r\n\t.table-responsive::-webkit-scrollbar-track:active {background:#D0E0E3 !important;}\r\n\r\n\t/*-----combo box-----*/\r\n\r\n\t.theme-main-input-select {margin: 20px auto;}\r\n\r\n\t.theme-main-input-select label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tfont-weight: bolder !important;\r\n\t\tcolor: #005CA9 !important;\r\n\t}\r\n\r\n\t.input-group select {\r\n\t\t-webkit-appearance: none;\r\n  \t\t-moz-appearance: none;\r\n  \t\tappearance: none;\r\n\t\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat right;\r\n\t\tborder-radius: 0;\r\n\t\tborder-top: none;\r\n\t\tborder-right: none;\r\n\t\tborder-bottom: 1px solid #D0E0E3;\r\n\t\tborder-left: none;\r\n\t\tpadding: 0 !important;\r\n\t\tmargin: 0 !important;\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 16px !important;\r\n\t\tline-height: 16px;\r\n\t\tmin-width: 152px;\r\n\t}\r\n\r\n\t.input-group select:focus {border-color: #D0E0E3; box-shadow: none;}\r\n\r\n\t/*-----separador-----*/\r\n\r\n\thr {border-color:#005CA9; margin: 20px 0 !important;}\r\n\r\n\t/*-----botoes-----*/\r\n\r\n\t.theme-main-button {\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-weight: bolder;\r\n\t\tfont-size: 16px !important;\r\n\t\tborder-radius: 0;\r\n\t\tmargin-top: 10px;\r\n\t\tmargin-bottom: 0;\r\n\t\tbox-sizing: border-box;\r\n\t\tpadding: 8px !important;\r\n\t}\r\n\r\n\t.btn-primary {background-color:#005CA9; border:0;}\r\n\t.btn-warning {background-color:#F39200; border:0;}\r\n\r\n\t.btn-primary:hover {background-color:#0071CF !important;}\r\n\t.btn-warning:hover {background-color:#feb21e !important;}\t\r\n\tbutton.col-xs-4 {\r\n\t    width: 33%;\r\n\t    margin-right: 7px;\r\n\t}\r\n\t.btn-primary:active {background-color:#004C8C !important; box-shadow:none;}\r\n\t.btn-warning:active {background-color:#ec7500 !important; box-shadow:none;}\t\r\n\r\n\t.theme-main-button[disabled=\"disabled\"],\r\n\t.theme-main-button[disabled=\"disabled\"]:hover,\r\n\t.theme-main-button[disabled=\"disabled\"]:focus {background-color:#d0e0e3 !important; border-color:#d0e0e3 !important; color:white; opacity:1 !important;}\r\n    \r\n    /*-----menu horizontal-----*/\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li {\r\n\t\tpadding-top: 0;\r\n\t\tpadding-bottom: 0;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a {\r\n\t\tcolor: white;\r\n\t\tborder-right: none !important;\r\n\t\tdisplay: inline-block !important;\r\n\t\tpadding-top: 0px !important;\r\n\t\tline-height: inherit;\r\n\t}\r\n\r\n\t.nav .open>a, .nav .open>a:focus, .nav .open>a:hover {\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tcolor: white;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a:hover {\r\n\t\toutline: none;\r\n\t\tborder: none;\r\n\t\tcolor: white;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a i {display: inline-block !important;}\r\n\r\n    .theme-header-tabs {\r\n\t\tbackground-color: #54BBAB;\r\n\t\tposition: fixed;\r\n\t\tbottom: 0;\r\n\t\tleft: 0;\r\n\t\theight: 48px;\r\n\t\tmax-height: none;\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none !important;\r\n\t\tdisplay: block;\r\n\t}\r\n\r\n\t.theme-header-tabs .caixa-azul {display: none;}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs {\r\n\t\tmax-height: none;\r\n\t\toverflow-y: visible !important;\r\n\t\toverflow-x: visible !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li {\r\n\t\theight: 48px;\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none !important;\r\n\t\twidth: 25% !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li a {\r\n\t\tcolor: white;\r\n\t\tfont-size: 22px;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 32px;\r\n\t\theight: 22px;\r\n\t\ttext-align: center;\r\n\t\tvertical-align: top !important;\r\n\t\tmargin: 9px 0px 13px 10px;\r\n\t\tpadding: 0 !important;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs li a[class=\"ng-scope active\"]::before {\r\n\t\tcontent: '';\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 100%;\r\n\t\theight: 4px;\r\n\t\tbackground-color: #005CA9;\r\n\t\tposition: absolute;\r\n\t\tright: 0;\r\n\t\ttop: -4px;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs li a[class=\"ng-scope active\"] {\r\n\t\tbackground-color: #66cfbf;\r\n\t\toverflow: visible;\r\n\t\theight: 48px !important;\r\n\t\tmargin: 0 !important;\r\n\t\tpadding: 9px 29px 13px 29px !important;\r\n\t\twidth: 100% !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li:hover {\r\n\t\tcursor: pointer;\r\n\t\tbackground-color: #66cfbf;\r\n\t\tmargin: 0 !important;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs:focus {outline:none;}\r\n\r\n\tul.theme-header-tabs:hover {display: block !important;}\r\n\r\n\t/*-----submenus-----*/\r\n\r\n\tdiv.page-wrapper {margin-top: 77px !important;}\r\n\r\n\tul.theme-header-tabs li.dropdown {width: 25%;}\r\n\r\n\tul.theme-header-tabs li.dropdown a,\r\n\tul.theme-header-tabs li.dropdown a:focus,\r\n\tul.theme-header-tabs li.dropdown a:hover {\r\n\t\tbackground-color: transparent;\r\n\t\tfont-size: 22px;\r\n\t\twidth: 32px;\r\n\t\theight: 22px;\r\n\t\ttext-align: center;\r\n\t\tvertical-align: top !important;\r\n\t\tmargin: 0;\r\n\t\tpadding: 9px 29px 13px 29px !important;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul  {box-shadow: none;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu {display: none;}\r\n\t\r\n\tul.theme-header-tabs li.open ul.dropdown-menu {\r\n\t\tbackground: none;\r\n\t\tdisplay: inline-block;\r\n\t\tbottom: 58px;\r\n\t\twidth: 90px !important;\r\n\t\tmargin: 0;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:first-child  {\r\n\t\tdisplay: inline-block;\r\n\t\tposition: absolute;\r\n\t\tbottom: 58px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(2)  {\r\n\t\tdisplay: inline-block !important;\r\n\t\tposition: relative;\r\n\t\tbottom: 153px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(3)  {\r\n\t\tdisplay: inline-block !important;\r\n\t\tposition: relative;\r\n\t\tbottom: 258px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(n+4) {display: none;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:first-child,\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(2),\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(3) {\r\n\t\tbackground-color: #005CA9;\r\n\t\theight: 48px;\r\n\t\twidth: 90px !important;\r\n\t\ttransition: all 0.3s ease-out 0s;\r\n\t\toverflow: hidden;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown:after {\r\n\t\tcontent: '\\\r\nF6';\r\n\t\tfont-size: 12px;\r\n\t\tcolor: white;\r\n\t\tposition: relative;\r\n\t\ttop: 2px !important;\r\n\t\tleft: 4px !important;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:hover {background-color:#00B5E5;}\r\n\r\n\tul.theme-header-tabs li.dropdown.open:hover {background-color: #54bbab;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a:hover {color: white;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a span {color: transparent;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a span i {color: white;}\r\n\r\n\t/*-----carrossel-----*/\r\n\r\n\t.carousel-indicators li, .carousel-indicators .active {\r\n\t\tmargin: 20px 6px auto 6px;\r\n\t\tborder-color: #F39200;\r\n\t\tbackground-color: white;\r\n\t\twidth: 12px;\r\n\t\theight: 12px;\r\n\t}\r\n\r\n\t.carousel-indicators .active {\r\n\t\tbackground-color: #F39200;\r\n\t\twidth: 12px;\r\n\t\theight: 12px;\r\n\t}\r\n\r\n\tol.carousel-indicators {\r\n\t\tposition: static;\r\n\t\tlist-style: none;\r\n\t\twidth: auto;\r\n\t\theight: auto;\r\n\t\ttop: 100%;\r\n\t\tright: 0;\r\n\t\ttext-align: right;\r\n\t}\r\n\r\n\tol.carousel-indicators li:last-child {margin-right: 0;}\r\n\r\n\t.carousel-caption {display: none;}\r\n\r\n\t.carousel-control {display: none;}\r\n\r\n\t/*-----radio-----*/\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 14px !important;\r\n\t\tcolor: #48586C;\r\n\t\tdisplay: block;\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tpadding: 0;\r\n\t\theight: 20px;\r\n\t\tmargin: 0 0 5px 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:hover, \r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:active,\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:focus {\r\n\t\tcolor: #48586C;\r\n\t\tbackground: none !important;\r\n\t\tborder: none;\r\n\t\toutline: none;\r\n\t\tcursor: auto;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn.active,\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn:active {box-shadow: none;}\r\n\t\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn:before {\r\n\t\tcontent: '';\r\n\t\tposition: relative;\r\n\t\tbottom: -4px;\r\n\t\tbackground-color: white;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 18px;\r\n\t\theight: 18px;\r\n\t\tborder: 1px solid #D0E0E3;\r\n\t\tborder-radius: 50%;\r\n\t\tmargin: 0 10px 0 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn.active:before {\r\n\t\tcontent: '';\r\n\t\tbackground-color: #54BBAB;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 8px;\r\n\t\theight: 8px;\r\n\t\tborder: 5px solid white;\r\n\t\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\t\tbox-sizing: content-box;\r\n\t\tborder-radius: 50%;\r\n\t\tmargin: 0 10px 0 0;\r\n\t}\r\n\t\t\r\n\t/*-----checkbox-----*/\r\n\t\r\n\tdiv[ng-if=\"item.type=='input-check'\"] label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group {margin-bottom: 40px;}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 14px !important;\r\n\t\tcolor: #48586C;\r\n\t\tdisplay: block;\r\n\t\theight: 20px;\r\n\t\tmargin: 0 14px 5px 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"] {\r\n\t\tposition: relative;\r\n\t\tbottom: -40%;\r\n\t\tmargin-right: 14px;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"]:before {\r\n\t\tcontent: '';\r\n\t\tposition: relative;\r\n\t\tbottom: -15%;\r\n\t\tbackground-color: white !important;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 18px;\r\n\t\theight: 18px;\r\n\t\tborder: 1px solid #D0E0E3;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"]:checked:before {\r\n\t\tcontent: '';\r\n\t\tbackground-color: #54BBAB !important;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 17px;\r\n\t\theight: 17px;\r\n\t\tborder: 4px solid white;\r\n\t\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\t/*-----breadcrumb-----*/\r\n\r\n\tol.breadcrumb {background-color: #f5f5f5;}\r\n\r\n\tol.breadcrumb li a {color: #337ab7; text-decoration: none;}\r\n\r\n\tol.breadcrumb:before {content: ''; padding-right: 0;}\r\n\r\n\tol.breadcrumb li:before {content:''; padding-left:0 !important;}\r\n\r\n\tol.breadcrumb li:after {content:\"/\\00a0\"; color:#ccc; padding:0 5px;}\r\n\r\n\tol.breadcrumb li:last-child:before {padding:0 !important;}\r\n\r\n\r\n\t/*-----texto-----*/\r\n\r\n\th5.theme-main-h4, h6.theme-main-h6 {line-height: 1.1;}\r\n\r\n\th5.theme-main-h4 {border-bottom: none;}\r\n\r\n\t.text-primary, .text-primary-important, .text-warning,\r\n\t.text-warning-important, .text-success, .text-success-important,\r\n\t.text-default, .text-black, .text-purple, .text-laranja, .text-info,\r\n\t.text-danger {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\t/* font-size: 14px !important; */\r\n\t\tline-height: 18px;\r\n\t}\r\n\r\n\t.text-primary {color: #005CA9 !important;}\r\n\t.text-primary-important {color: #005CA9 !important;}\r\n\t.text-warning {color: #F39200;}\r\n\t.text-warning-important {color: #F39200 !important;}\r\n\t.text-success {color: #54BBAB;}\r\n\t.text-success-important {color: #54BBAB !important;}\r\n\t.text-default {color: #48586C; font-weight: 100;}\r\n\t.text-black {color: #48586C; font-weight: 100;}\r\n\t.text-purple {color: #B26F9B; font-weight: 100;}\r\n\t.text-laranja {color: #F39200; font-weight: 100;}\r\n\t.text-info {color: #AFCA0B; font-weight: 100;}\r\n\t.text-danger {color: #F9765E; font-weight: 100;}\r\n\r\n\t/*-----links-----*/\r\n\r\n\t.theme-main-link a {color: #337ab7; font-size: 12px;}\r\n\r\n\r\n\t.side-menubar .theme-header-title {\r\n    \tmargin-top: 18px;\r\n\t}\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse {\r\n        display: block;\r\n        height: 100%!important;\r\n        margin-left: -700px;\r\n        position: fixed!important;\r\n        width: 85% !important;\r\n        overflow: hidden;\r\n        z-index: 9099999 !important;\r\n    }\r\n\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse.in {\r\n        display: inline !important;\r\n        height: auto !important;\r\n        margin-left: 0px !important;\r\n        background-color: white;\r\n        transition: all 2s;\r\n        z-index: 9999 !important;\r\n        padding-bottom: 60px !important;\r\n        max-width: 85%;\r\n        bottom: 0;\r\n        max-height: 59%;\r\n        min-height: 59%;\r\n    }\r\n\r\n    li.theme-menu-item {\r\n        width:100%;\r\n        position: relative;\r\n        \r\n    }\r\n    .navbar-toggle i {\r\n        width: 20px;\r\n        height: 20px;\r\n        margin-right: 13px;\r\n        margin-top: 5px;\r\n    }\r\n\r\n\r\n    li.theme-menu-item:nth-child(7) a:nth-child(2){\r\n        bottom: 0;\r\n        position: fixed;\r\n        background: #005ca9;\r\n        color: white;\r\n        width: 85%;\r\n    }\r\n\r\n\r\n    .theme-app.menu .theme-menu-container {\r\n        overflow-y: auto;\r\n        overflow: auto;\r\n        display: inline-block;\r\n        height: auto;\r\n        position: absolute;\r\n        top: 9px;\r\n        bottom: 0;\r\n        width: 85% !important;\r\n    }\r\n\r\n    .sidebar .sidebar-nav.navbar-collapse {\r\n        transition: all 0.5s ease !important;\r\n    }\r\n\r\n    .theme-app.menu .theme-main-container {\r\n        margin: 10px 0 0 0px;\r\n     \r\n    }\r\n\r\n    .theme-app.menu .theme-main-container {\r\n        margin: 10px 0 0 0px;\r\n     }\r\n     \r\n     .overlay {\r\n        display: none;\r\n        background: rgba(0,0,0,.7);\r\n        height: 100%;\r\n        left: 0;\r\n        position: absolute;\r\n        top: 0;\r\n        width: 100%;\r\n        z-index: 98;\r\n    }\r\n    .theme-app.menu .theme-main-container {\r\n        margin-top: 76px !important;\r\n    }\r\n    .side-menubar{\r\n        display: block !important;\r\n        width:85%;\r\n        margin-left:-700px;\r\n        transition: all 0.5s ease !important;\r\n        background: white;\r\n        height: 52%;\r\n    } \r\n    .side-menubar:after {\r\n        content: \"\";\r\n        background: #D0E0E3;\r\n        position: absolute;\r\n        bottom: 0;\r\n        left: 0;\r\n        height: 1px;\r\n        width: 33%;\r\n    }\r\n    .seta{\r\n        padding: 3px 0px;\r\n        background: #F39200;\r\n        border-radius: 50%;\r\n        float: left;\r\n        margin: 0 ;\r\n    }\r\n    \r\n    .setaleft {\r\n       color:#FFFFFF; \r\n       font-size:13px;\r\n    }\r\n    .glyphicon-menu-left:before {\r\n        margin-left: 8px;\r\n    }   \r\n    .fa-navicon{\r\n        font-size: 23px !important;\r\n        margin: 1px 13px 0 0 !important;\r\n    }\r\n    li.theme-menu-item:nth-child(2) a {\r\n        border-top: none;\r\n    }\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse.in{\r\n        overflow-y: scroll;\r\n    }\r\n    .feedback-menu a{\r\n        color: #F39200 !important;\r\n        font-size: 25px;    \r\n    }\r\n    .informacao-header {\r\n        height: auto;\r\n        background: white;\r\n    }\r\n\r\n    .informacao-header .form-group.col-xs-12.theme-main-input-text {\r\n        padding: 0;\r\n        top: 0;\r\n    }\r\n\r\n    .informacao-header .circle.col-xs-6 {\r\n        height: 104px;\r\n        width: 104px;\r\n        margin-top: -2px;\r\n    }\r\n    \r\n    .informacao-header .circle.col-xs-6 .fa.fa-user{\r\n           margin: 2px 3px;\r\n           font-size: 7em;\r\n           color: #F39200;\r\n    }\r\n    \r\n\r\n    .informacao-header .theme-main-input-text p {\r\n        font-weight: normal;\r\n        font-size: 14px;\r\n        font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n        margin: 0;\r\n    }\r\n\r\n    .form-group.col-xs-12.theme-main-input-text.nome-usuario {\r\n        padding-bottom: 10px;\r\n    }\r\n\r\n    a.btn-sair-menu {\r\n        display: block;\r\n        padding-left: 16px;\r\n        line-height: 23.5px;\r\n        min-height: 47px;\r\n        box-sizing: border-box;\r\n        padding: 0;\r\n        font-size: 16px;\r\n        border-top: 1px solid #D0E0E3;\r\n        font-weight: normal;\r\n        bottom: 0;\r\n        position: fixed;\r\n        background: #005ca9;\r\n        color: white;\r\n        cursor: pointer;\r\n        width: 85%;\r\n    }\r\n\t\r\n    .btn-sair-menu i.fa.fa-sign-out {\r\n        display: inline-block !important;\r\n        font-size: 18px;\r\n        margin: 14px 37px 14px 15px !important;\r\n    }\r\n\r\n    .btn-sair-menu span.theme-menu-item-caption {\r\n        text-decoration: none;\r\n    }\r\n\r\n    a.btn-sair-menu:hover {\r\n        text-decoration: none;\r\n    }\r\n    .barra-menu{\r\n    \tdisplay:block;\r\n        height: 20px;\r\n        width: 100%;\r\n        background: url(../imgs/theme-mobilidade-2017/barra-menu.jpg);\r\n        position: fixed;\r\n        top: 0;\r\n        z-index: 99999;\r\n    }\r\n    .theme-header{\r\n        margin-top: 20px;\r\n    }\r\n    .side-menubar{\r\n\t    display:block;\r\n        margin-top:0;\r\n        z-index: 9999;\r\n    }\r\n\t.table-responsive.table-bordered.theme-main-table.ng-scope.col-xs-12 {\r\n\t    margin-bottom: 34px;\r\n\t    margin-top: 5px;\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-4{\r\n\t    width: 33.33333333%;\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-12{\r\n\t    width: 100%\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-6{\r\n\t    width: 50%;\r\n\t}\r\n\tbutton.btn.btn-sm.margin-3x.theme-main-button.toggle-menu.btn-primary.pull-left.col-xs-12 {\r\n\t    height: auto;\r\n\t}\r\n\t\r\n\tbutton.btn.btn-sm.margin-3x.theme-main-button.toggle-menu.btn-primary.pull-left.col-xs-12 .menu ol li {\r\n\t    margin-top: 16px;\r\n\t    margin-left: -19px;\r\n\t    white-space: normal;\r\n\t}\r\n\r\n\r\n\ti.fa.theme-main-icon.ng-scope.fa-play-circle-o.text-primary.floatRight:before {\r\n\t    float: right;\r\n\t}    \r\n    a.form-group.panel-center.theme-main-img-button.ng-scope.floatLeft {margin-left: 15px;margin-top: 6px;}\r\n\r\n\ta.form-group.panel-center.theme-main-img-button.ng-scope.floatNone.text-center {\r\n\t    text-align: center;\r\n\t    display:  inline-block;\r\n\t    width:  100%;\r\n\t    margin-top:  10px;\r\n\t}\r\n\t\r\n\ta.theme-main-img-button.floatNone img {\r\n\t    margin: 0 auto;\r\n\t    text-align:  center;\r\n\t}\r\n\t\r\n\ta.form-group.panel-center.theme-main-img-button.ng-scope.floatRight {\r\n\t    margin-top: 10px;\r\n\t    text-align: right;\r\n\t    margin-right: 15px;\r\n\t}\r\n    .tabs-nav li{\r\n\t    display:none;\r\n\t}\r\n\t.tabs-nav li:nth-child(1), .tabs-nav li:nth-child(2), .tabs-nav li:nth-child(3){\r\n\t    display:block;\r\n\r\n\t}\r\n\t.tabs-nav li a.active::after{\r\n\t\tmargin-left: -21px;\r\n\t}\r\n\t.tabs-nav a{\r\n\t\tfont-size: 17px;\r\n\t}\r\n    \r\n\t\r\n\tlabel.ng-binding {\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 14px;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tmargin-bottom: 2px;\r\n\t}\r\n\t\r\n\tdiv.input-group {width: inherit;}\r\n\t\r\n\tdiv.input-group input {\r\n\t\tcolor: #3A4859;\r\n\t\tfont-size: 12px !important;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tpadding-bottom: 7px;\r\n\t\tpadding-left: 0;\r\n\t\theight: 26px;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 0 !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\t\r\n\tspan.input-group-addon {display: none;}\r\n\t\r\n\tdiv.input-group input:focus {\r\n\t\tborder-color: #54BBAB;\r\n\t\tbox-shadow: none;\r\n\t}\r\n\t\r\n\t.form-group {margin-bottom: 0;}\r\n\t\r\n\t\r\n\t\r\n\t.form-control{border: 0; padding: 4px 0; border-bottom: 1px solid #ccc; background-color: transparent; box-shadow: none;}\r\n\t\r\n\t\r\n\t\r\n\t.form-group.col-xs-12.theme-main-input-check {\r\n\t\tpadding-bottom: 10px;\r\n\t}\r\n\t\r\n\tdiv#telefone-group .input-group .col-xs-4 {\r\n\t\tpadding-left: 0;\r\n\t}\r\n\r\n\t\r\n\t/*-----combo box-----*/\r\n\t\r\n\t.theme-main-input-select label {\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 14px !important;\r\n\t\tfont-weight: normal !important;\r\n\t\tcolor: #54BBAB !important;\r\n\t\tmargin-bottom: 2px !important;\r\n\t}\r\n\t\r\n\t.input-group select {\r\n\t\t-webkit-appearance: none;\r\n\t\t-moz-appearance: none;\r\n\t\tappearance: none;\r\n\t\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat top right;\r\n\t\tborder-radius: 0;\r\n\t\tborder-top: none;\r\n\t\tborder-right: none;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-left: none;\r\n\t\tpadding: 0 0 10px 0;\r\n\t\theight: 26px;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 6px !important;\r\n\t\tbox-sizing: border-box;\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 12px !important;\r\n\t\tline-height: 12px;\r\n\t}\r\n\t\r\n\t.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\t\r\n\t/*-----caixa de texto-----*/\r\n\t\r\n\tdiv.input-group textarea {\r\n\t\twidth: inherit;\r\n\t\tcolor: #3A4859;\r\n\t\tfont-size: 12px !important;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tpadding-bottom: 7px;\r\n\t\tpadding-left: 0;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 0 !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\t\r\n\tdiv.input-group textarea:focus {\r\n\t\tborder-color: #54BBAB;\r\n\t\tbox-shadow: none;\r\n\t}\r\n\r\n\t.splash .navbar-right.theme-header-right .navbar-brand  {\r\n\t\tdisplay: none;\r\n\t}\r\n\t.splash ol.breadcrumb.ng-isolate-scope {\r\n\t    display: none;\r\n\t}\r\n\r\n\t.splash .theme-header{    \r\n\t   background: #065CA7 !important;\r\n\t}\r\n\r\n\t.splash {\r\n\t    background-color: #065CA7;\r\n\t    position: absolute;\r\n\t    height: 100%;\r\n\t}\r\n\r\n\t.splash span.ng-binding {\r\n\t    color: #fff;\r\n\t}\r\n\r\n\t.splash .navbar-right.theme-header-right {\r\n\t\twidth: 0;\r\n\t    height: 0;\r\n\t    border: 0 solid transparent;\r\n\t    border-left-width: 0px;\r\n\t    border-right-width: 100PX;\r\n\t    border-top: 100px solid #FF9300;\r\n\t    margin: 0;\r\n\t    vertical-align: middle;\r\n\t    position: absolute;\r\n\t    top: 0;\r\n\t    left: 0;\r\n\t}\r\n\t.splash .theme-header-left a{\r\n\t\tbackground: url(../imgs/theme-mobilidade-2017/titlefullc.png) no-repeat!important;\r\n\t}\r\n\t.splash .navbar-left.theme-header-left {\r\n\t    float: none;\r\n\t    margin-left: 33%;\r\n\t    width: 100% !important;\r\n\t    height: 31px;\r\n\t}\r\n\t.splash .barra-menu {\r\n    \tdisplay: none !important;\r\n\t}\r\n\t\r\n\t.splash .navbar-default.sidebar.theme-menu-container {\r\n\t\tdisplay:none;\r\n\t    background: none;\r\n\t}\r\n\t.splash nav.navbar.navbar-default.navbar-fixed-top.theme-header {\r\n\t    margin-top: 0;\r\n\t}\r\n\t\r\n\t.splash a.navbar-brand {\r\n\t    width: 100%;\r\n\t    height: 100%;\r\n\t}\r\n\t\r\n\t.splash .theme-header-title {\r\n\t    overflow: hidden;\r\n\t}\r\n\t.splash span.label.padding.theme-main-label.text-primary{\r\n\t\tcolor:#fff !important\r\n\t}\r\n\r\n\t/*-----Page loader-----*/\r\n\r\n\t.page-loader{\r\n\t    height: 100%;\r\n\t    width: 100%;\r\n\t    background: rgba(0,0,0,0.6);\r\n\t    display:block;\r\n\t    position: absolute;\r\n\t    z-index: 9999999999999999999;\r\n\t    top: 0;\r\n\t    transition:2s;\r\n\t}\r\n\t\r\n\t.page-loader:before {\r\n    content: '';\r\n    width: 100%;\r\n    background-image: url(../imgs/theme-mobilidade-2017/loading.gif);\r\n    position: absolute;\r\n    bottom: 0;\r\n    height: 19px;\r\n    background-repeat: no-repeat;\r\n    background-position: center;\r\n\t}\r\n\t/*-----Splash para Angular 4-----*/\r\n\r\n\t.splash-body .navbar-right.theme-header-right .navbar-brand  {\r\n\t\tdisplay: none;\r\n\t}\r\n\t.splash-body ol.breadcrumb.ng-isolate-scope {\r\n\t    display: none;\r\n\t}\r\n\r\n\t.splash-body .theme-header{    \r\n        background: #065CA7 !important;\r\n        margin-top: 0!important;\r\n\t}\r\n    .splash-body  .theme-app{\r\n        background: #065CA7 !important;\r\n    }\r\n\t.splash-body {\r\n\t    background-color: #065CA7;\r\n        position: relative !important;\r\n\t    height: 100%;\r\n\t}\r\n\r\n\t.splash-body span.ng-binding {\r\n\t    color: #fff;\r\n\t}\r\n\r\n\t.splash-body .navbar-right.theme-header-right {\r\n\t\twidth: 0;\r\n\t    height: 0;\r\n\t    border: 0 solid transparent;\r\n\t    border-left-width: 0px;\r\n\t    border-right-width: 100PX;\r\n\t    border-top: 100px solid #FF9300;\r\n\t    margin: 0;\r\n\t    vertical-align: middle;\r\n\t    position: absolute;\r\n\t    top: 0;\r\n\t    left: 0;\r\n\t}\r\n\t.splash-body .navbar-left.theme-header-left {\r\n\t    float: none;\r\n\t    margin-left: 33%;\r\n\t    width: 100% !important;\r\n\t    height: 31px;\r\n\t}\r\n\t.splash-body .barra-menu {\r\n    \tdisplay: none !important;\r\n\t}\r\n\t\r\n\t.splash-body .navbar-default.sidebar.theme-menu-container {\r\n\t\tdisplay:none;\r\n\t    background: none;\r\n\t}\r\n\t.splash-body nav.navbar.navbar-default.navbar-fixed-top.theme-header {\r\n\t    margin-top: 0;\r\n\t}\r\n\t\r\n\t.splash-body a.navbar-brand {\r\n\t    width: 100%;\r\n\t    height: 100%;\r\n\t}\r\n\t\r\n\t.splash-body .theme-header-title {\r\n\t    overflow: hidden;\r\n\t}\r\n\t.splash-body h5.padding.text-primary.bold.theme-main-h4, .splash-body span, .splash-body .theme-main-link a{\r\n\t\tcolor:#fff !important\r\n    }\r\n    \r\n    body.theme-app.splash-top {\r\n        background-color: #065CA7;\r\n    }\r\n\t  .navbar-usuario-intranet {\r\n\t \tdisplay:none !important;\r\n\t }\r\n\t .menu-item-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .overlay-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .pesquisa-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t  .config-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .calendario-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .navbar-left.theme-header-left{\r\n\t \theight:20px !important;\r\n\t }\r\n}",
        "contraste": 28,
        "icon": "fa-file-image-o",
        "id": 11,
        "name": "Intranet/Mobilidade",
        "preview_mode": [
            {
                "check": true,
                "icon": "fa fa-list-alt",
                "id": "preview",
                "name": "Preview"
            },
            {
                "check": false,
                "icon": "fa fa-desktop",
                "id": "desktop",
                "name": "Desktop"
            },
            {
                "check": false,
                "icon": "glyphicon glyphicon-globe",
                "id": "mobile",
                "name": "Browser Mobile"
            },
            {
                "check": false,
                "icon": "fa fa-mobile",
                "id": "nativo",
                "name": "App Mobile"
            },
            {
                "check": false,
                "icon": "fa fa-android",
                "id": "android",
                "name": "Android"
            },
            {
                "check": false,
                "icon": "fa fa-apple",
                "id": "ios",
                "name": "IOS"
            },
            {
                "check": false,
                "icon": "fa fa-windows",
                "id": "winphone",
                "name": "WinPhone"
            },
            {
                "check": false,
                "icon": "fa fa-print",
                "id": "printer",
                "name": "Impressão"
            }
        ],
        "tema": 11,
        "value": "theme-intranet.css"
    },
    "themeEscolhido": {
        "content": "/*\r\nTEMA para PRIMO\r\ninicializado automaticamente pelo PRIMO Front-end\r\nde acordo com o tema selecionado no projeto\r\n*/\r\n\r\n/*---------- fontes */\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN45__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: 500;\r\n\tfont-style: normal;\r\n}\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN85__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: bold;\r\n\tfont-style: normal;\r\n}\r\n\r\n/*---------- fontes */\r\n\r\n.theme-app {\r\n\tbackground-color: #fff;\r\n}\r\n\r\n.theme-header {\r\n\tbackground-color: #296fa7;\r\n\tborder-bottom: 3px solid #F39A00!important;\r\n}\r\n.theme-app.tabbed .theme-header {\r\n\tborder-bottom: none!important;\r\n}\r\n\r\n.theme-header-tabs {\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-header-right > .navbar-brand {\r\n\tcolor: #fff;\r\n\tpadding-right: 5px;\r\n}\r\n.theme-header-left > .navbar-brand {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-header-middle.navbar-brand{\r\n\tcolor: #fff;\r\n}\r\n.theme-header-tabs {\r\n\t    background-color: #fff;\r\n}\r\n\r\n.theme-header-tabs > li.active > a {\r\n\tbackground-color: #296fa7;\r\n\tcolor: #fff;\r\n}\r\n.theme-footer {\r\n\tbackground-color: #296fa7;\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-footer-right {\r\n\tpadding-right: 10px;\r\n}\r\n.theme-footer-middle {\r\n\r\n}\r\n.theme-footer-left {\r\n\tpadding-left: 10px;\r\n}\r\n\r\n.theme-header-left > a {\r\n\tbackground: url(../imgs/theme-padrao/caixab.png) no-repeat!important;\r\n\twidth: 112px;\r\n\theight: 24px;\r\n\tmargin-top: 20px!important;\r\n\tmargin-left: 10px!important;\r\n}\r\n\r\n.theme-header-left-caption {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.theme-header-title {\r\n\theight: 63px;\r\n\tpadding:;\r\n}\r\n\r\n.form-group{\r\n\t/* top:20px; */\r\n}\r\n\r\n.theme-header-acessibilidade{\r\n\theight: 25px;\r\n\tbackground-color: #2ca5fe;\r\n}\r\n\r\n.theme-link-acessibilidade{\r\n\tposition: relative;\r\n\ttop: 3px;\r\n\tleft: 10px;\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-app.tabbed .theme-menu-container {\r\n    margin-top: 120px!important;\r\n}\r\n.theme-app .theme-menu-container {\r\n    margin-top: 80px!important;\r\n}\r\n\r\n.theme-app.collapse.in .theme-submenu-item > a {\r\n\tpadding-left: 20px;\r\n}\r\n\r\n.theme-app .theme-main-container {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 70px 0 50px 0px;\r\n}\r\n\r\n.theme-app.menu .theme-main-container {\r\n\tmargin: 10px 0 50px 0px;\r\n}\r\n@media (min-width: 768px) {\r\n\t.theme-app.tabbed .theme-menu-container {\r\n\t    margin-top: 20px!important;\r\n\t}\r\n\t.theme-app .theme-menu-container {\r\n\t    margin-top: 0px!important;\r\n\t    padding-bottom: 120px;\r\n\t}\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 15px!important;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tposition: fixed;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-header-right {\r\n\t\tpadding-right: 15px;\r\n\t}\r\n\t\t\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 10px!important;\r\n\t}\r\n\r\n\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 0 70px!important;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 0px!important;\r\n\t}\r\n\r\n\t.theme-main-container {\r\n\t\tmargin: 67px 0 0 70px;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tmargin-top: 3px!important;\r\n\t}\r\n}\r\n\r\n\r\n.sidebar-nav > .nav li > a.active {\r\n    margin: 0;\r\n    border-left: 4px solid #ffa100;\r\n    border-left-width: 4px;\r\n    border-left-style: solid;\r\n    border-left-color: #ffa100;\r\n    border-top: 1px solid #d9d9d9;\r\n    border-top-width: 1px;\r\n    border-top-style: solid;\r\n    border-top-color: rgb(217, 217, 217);\r\n    border-bottom: 1px solid #d9d9d9;\r\n    border-bottom-width: 1px;\r\n    border-bottom-style: solid;\r\n    border-bottom-color: rgb(217, 217, 217);\r\n    background-color: #f5f7f7;\r\n}\r\n\r\n.theme-header .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n.theme-footer .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n\r\nbutton {\r\n\tmargin-right: 5px;\r\n}\r\n\r\n.table-responsive{\r\n\ttop:20px;\r\n}\r\n\r\n/* texto */\r\n.text-primary {\r\n\tcolor: #296fa7;\r\n}\r\n.text-primary-important {\r\n\tcolor: #296fa7!important;\r\n}\r\n.text-warning {\r\n\tcolor: #ffa100;\r\n}\r\n.text-warning-important {\r\n\tcolor: #ffa100!important;\r\n}\r\n.text-success {\r\n\tcolor: #3c763d;\r\n}\r\n.text-success-important {\r\n\tcolor: #3c763d!important;\r\n}\r\n.text-black {\r\n\tcolor: #464646;\r\n\tfont-weight: 100;\r\n}\r\n.text-purple {\r\n\tcolor: #494d62;\r\n\tfont-weight: 100;\r\n}\r\n.text-laranja {\r\n\tcolor: #ffa100;\r\n\tfont-weight: 100;\r\n}\r\n.text-info {\r\n\tcolor: #c0b723;\r\n\tfont-weight: 100;\r\n}\r\n.text-danger {\r\n\tcolor: #920A04;\r\n\tfont-weight: 100;\r\n}\r\n\r\n/* Botoes */\r\n.btn-outline {\r\n\tcolor: inherit;\r\n\tbackground-color: transparent;\r\n\ttransition: all .5s;\r\n}\r\n\r\n.btn-primary.btn-outline {\r\n\tcolor: #428bca;\r\n}\r\n\r\n.btn-success.btn-outline {\r\n\tcolor: #5cb85c;\r\n}\r\n\r\n.btn-info.btn-outline {\r\n\tcolor: #5bc0de;\r\n}\r\n\r\n.btn-warning.btn-outline {\r\n\tcolor: #f0ad4e;\r\n}\r\n\r\n.btn-danger.btn-outline {\r\n\tcolor: #d9534f;\r\n}\r\n\r\n.btn-primary.btn-outline:hover,\r\n.btn-success.btn-outline:hover,\r\n.btn-info.btn-outline:hover,\r\n.btn-warning.btn-outline:hover,\r\n.btn-danger.btn-outline:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-menu-container {\r\n\tborder-right: 1px solid #ADADAD;\r\n\theight: 100%;\r\n\tbackground: #fff;\r\n}\r\n\r\n.theme-main-container.menu {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 0px 0 50px 0px;\r\n}\r\n\r\n.theme-app.tabbed .page-wrapper {\r\n\tmargin-top: 110px;\r\n}\r\n\r\n\r\n.theme-menu-item {\r\n\tborder-bottom: 0px!important;\r\n}\r\n\r\n.table-bordered{\r\n\tborder: none;\r\n}\r\n\r\n.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, \r\n.table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, \r\n.table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th{\r\n\tborder-top: 1px solid #ccc;\r\n}\r\n\r\n/* Material Design Switch */\r\n.material-switch-contraste-contraste {\r\n\tmargin-top: 5px;\r\n}\r\n.material-switch-contraste > input[type=checkbox] {\r\n\tdisplay: none;\r\n}\r\n\r\n.material-switch-contraste > label {\r\n\tcursor: pointer;\r\n\theight: 0px;\r\n\tposition: relative;\r\n\twidth: 40px;\r\n\ttop: -20px;\r\n}\r\n\r\n.material-switch-contraste > label::before {\r\n\tleft: 0px;\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\tborder-radius: 8px;\r\n\tcontent: '';\r\n\theight: 13px;\r\n\tposition:absolute;\r\n\topacity: 0.3;\r\n\ttransition: all 0.4s ease-in-out;\r\n\twidth: 34px;\r\n\ttop: 14px;\r\n}\r\n.material-switch-contraste > label::after {\r\n\tbackground: rgb(255, 255, 255);\r\n\tborder-radius: 16px;\r\n\tbox-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);\r\n\tcontent: '';\r\n\theight: 20px;\r\n\tleft: 0px;\r\n\tposition: absolute;\r\n\ttop: 11px;\r\n\ttransition: all 0.3s ease-in-out;\r\n\twidth: 20px;\r\n}\r\n\r\n.material-switch-contraste > input[type=checkbox]:checked + label::before {\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\topacity: 0.1;\r\n}\r\n\r\n.material-switch-contraste > input[type=checkbox]:checked + label::after {\r\n\tbackground: inherit;\r\n\tbox-shadow: 0px 0px 5px rgba(255, 255, 255, 0.5);\r\n\tleft: 20px;\r\n}\r\n\r\n.breadcrumb{\r\n\tmargin-top: 10px;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n}\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none!important;\r\n}\r\n\r\n\r\n\r\n\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n/*---------------------------------------------- TEMPLATE INTRANET 2018 -------------------------------------------------*/\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n\r\n\r\n/*-----cabecalho-----*/\r\n\r\n.theme-header {\r\n\tborder-bottom: none !important;\r\n\tbox-sizing: border-box !important;\r\n\tbackground-image: url(../imgs/theme-intranet/bg_header.jpg);\r\n\tbackground-repeat: no-repeat;\r\n\tbackground-position: center 20px;\r\n\twidth: 100%;\r\n}\r\n\r\n.theme-appGerado .theme-header{\r\n\tbackground-position: initial;\r\n}\r\n\r\n.theme-header-right-title {\r\n\tmargin-top: 5px;\r\n\tmargin-right: 25px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.navbar-left.theme-header-left {\r\n\theight: 63px !important;\r\n\tbackground-image: url(../imgs/theme-intranet/logo_caixa.png) !important;\r\n\tbackground-repeat: no-repeat !important;\r\n\tbackground-position: center left !important;\r\n\tmargin: 0 !important;\r\n\tpadding: 0 !important;\r\n\tmargin-left: 15% !important;\r\n}\r\n\r\n.theme-header-left a {background: none !important;}\r\n\r\n.navbar-brand  {padding-right: inherit !important;}\r\n\r\n.navbar-brand[title^=Avaliação]  {padding-right: inherit !important;}\r\n\r\n.navbar-toggle {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n\tborder: none;\r\n}\r\n\t\r\n.navbar-toggle i {\r\n\twidth: 20px;\r\n\theight: 20px;\r\n\tmargin-right: 36px;\r\n}\r\n\r\n.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:active, \r\n.navbar-default .navbar-toggle:focus, .nav li a:hover, .nav li a:active, .nav li a:focus {background: none;}\r\n\r\n/*-----rodape-----*/\r\n\r\n.theme-footer {\r\n\tborder: none !important;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n/*-----menu horizontal-----*/\r\n\r\nul[ng-hide=currentview.telainicial] {\r\n\tborder-top: none !important;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px;\r\n\tborder-bottom: 1px solid #B3C7CB;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li {\r\n\tpadding-top: 10px;\r\n\tpadding-bottom: 10px;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li a {\r\n\tcolor: #B3C7CB;\r\n\tborder-right: 1px solid #B3C7CB !important;\r\n\tborder-radius: 0;\r\n\tdisplay: inline-block;\r\n\tpadding-top: 0;\r\n\theight: 16px;\r\n\tline-height: 1;\r\n}\r\n\r\n.nav .open>a, .nav .open>a:focus, .nav .open>a:hover {\r\n\tbackground: none;\r\n\tborder: none;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li a:hover {\r\n\tborder: none;\r\n\toutline: none;\r\n\tborder-right: 1px solid #B3C7CB;\r\n\tcolor: #3A4859;\r\n}\r\n\r\nul.theme-header-tabs > li:last-child a {border: none !important;}\r\n\r\nul[ng-hide=currentview.telainicial] li a i {display: none;}\r\n\r\nul[ng-hide=currentview.telainicial] li ul li a {border: none !important;}\r\n\r\n/*-----menu vertical-----*/\r\n\r\n.sidebar-nav .nav li a.active {\r\n\tborder: none;\r\n\tcolor: white;\r\n\tfont-size: 13px;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n.sidebar, .sidebar-nav {\r\n\tborder: none;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-weight: bold;\r\n\tbackground-color: #F9F9F9;\r\n\twidth: 217px;\r\n}\r\n\r\n.sidebar-nav .nav li {padding:0;}\r\n\r\n.sidebar-nav .nav li a {\r\n\tcolor: #9aacaf;\r\n\tfont-size: 14px;\r\n\tdisplay: block;\r\n\tpadding-left: 16px;\r\n\tline-height: 23.5px;\r\n\tmin-height: 47px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li a i {display: none;}\r\n\r\n.sidebar-nav .nav li.open > a {background-color: #F4F4F4; display: block;}\r\n\r\n.sidebar-nav .nav li > a[aria-expanded=true] {\r\n\tcolor: white;\r\n\tfont-size: 13px;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n.sidebar-nav .nav li ul li a {\r\n\tbackground-image: none !important;\r\n\tbackground-color: #F4F4F4 !important;\r\n\tcolor: #B3C7CB !important;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tpadding-left: 28px;\r\n\tline-height: 16px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li ul li a.active {\r\n\tcolor: #54BBAB !important;\r\n\tfont-size: 12px;\r\n}\r\n\r\n/*-----carrossel-----*/\r\n\r\n.carousel {\r\n\tmargin: 16px 16px 0 16px;\r\n\t/* display: inline-block;\r\n\twidth: 679px;\r\n\theight: 215px; */\r\n}\r\n\r\n.carousel-control {display: none;}\r\n\r\n.carousel-indicators li, .carousel-indicators .active {\r\n\tmargin: 16px 9px;\r\n\tborder-color: #BCBEC0;\r\n\tbackground-color: #BCBEC0;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.carousel-indicators .active {\r\n\tborder-color: #54BBAB;\r\n\tbackground-color: #54BBAB;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nol.carousel-indicators {\r\n\tposition: static;\r\n\tlist-style: none;\r\n\tmargin: 0 auto;\r\n}\r\n\r\n.carousel-caption {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tbackground: none;\r\n\t/\r\n\tmargin-bottom: 28px;\r\n\t/\r\n\tmargin-left: 31px;\r\n\tpadding: 0;\r\n\ttext-shadow: none;\r\n\tposition: relative;\r\n\tleft: 210px;\r\n\ttop: -52px;\r\n}\r\n\r\n.carousel-caption h4 {\r\n\tfont-size: 12px !important;\r\n\tfont-weight: bold;\r\n\tmargin-bottom: 0;\r\n}\r\n\r\n.carousel-caption p {\r\n\tmargin-left: 16px;\r\n\tmargin-bottom: 0;\r\n}\r\n\r\n.carousel-caption h4:before {\r\n\tcontent:'0025E3';\r\n\tfont-size: 12px;\r\n\tmargin-right: 6px;\r\n\tcolor: #EB7F2A;\r\n}\r\n\r\n/*-----texto-----*/\r\n\r\n.text-primary, .text-primary-important, .text-warning,\r\n.text-warning-important, .text-success, .text-success-important,\r\n.text-default, .text-black, .text-purple, .text-laranja, .text-info,\r\n.text-danger {\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-weight: normal;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\t/text-align: left;\r\n}\r\ni.fa.text-primary {\r\n\tfont-family: FontAwesome;\r\n}\r\n\r\n.text-primary {color: #3A4859;}\r\n.text-primary-important {color: #3A4859 !important;}\r\n.text-warning {color: #F39200;}\r\n.text-warning-important {color: #F39200 !important;}\r\n.text-success {color: #54BBAB;}\r\n.text-success-important {color: #54BBAB !important;}\r\n.text-default {color: #3A4859; font-weight: 100;}\r\n.text-black {color: #3A4859;font-weight: 100;}\r\n.text-purple {color: #494d62; font-weight: 100;}\r\n.text-laranja {color: #F39200; font-weight: 100;}\r\n.text-info {color: #F9B000; font-weight: 100;}\r\n.text-danger {color: #F9765E; font-weight: 100;}\r\n\r\ndiv.theme-main-list label,\r\nh5.theme-main-push-status {\r\n\tcolor: #3A4859;\r\n\tfont-weight: normal;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\tpadding: 0;\r\n\tmargin: 0 0 5px 0;\r\n}\r\n\r\nh5.theme-main-h4, h6.theme-main-h6 {\r\n\tfont-weight: bold;\r\n\tline-height: 1;\r\n\tcolor: #9aacaf;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 20px !important;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tmargin-top: 0;\r\n}\r\n\r\nh5.theme-main-h4 {\r\n\tborder-bottom: 1px solid #9aacaf;\r\n\tpadding-bottom: 6px;\r\n\tmargin-bottom: 30px;\r\n}\r\n\r\nh6.theme-main-h6 {\r\n\tfont-size: 14px !important;\r\n\tmargin-bottom: 12px;\r\n}\r\n\r\n\r\n/*-----tabelas-----*/\r\n\r\nthead tr th {\r\n\tbackground-color: white;\r\n\tcolor: #3A4859;\r\n\tfont-size: 13px !important;\r\n\tborder-top: none !important;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tvertical-align: bottom;\r\n    border-bottom: 2px solid #ddd !important;\r\n\theight: 35px;\r\n\tfont-size: 14px;\r\n\tpadding: 8px !important;\r\n\tline-height: 13px !important;\r\n}\r\n\r\ntbody tr td {\r\n\tcolor: #3A4859;\r\n\tline-height: 1.428571429;\r\n\tvertical-align: top;\r\n\tborder-top: 1px solid #ddd;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tborder-bottom: none !important;\r\n\theight: 35px !important;\r\n\tfont-size: 13px;\r\n\tpadding: 8px !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ntbody tr:nth-child(odd),\r\ntbody tr:nth-child(odd):hover {background-color: #f9f9f9; !important;}\r\n\r\ntbody tr:nth-child(even),\r\ntbody tr:nth-child(even):hover {background-color: white;}\r\n\r\ntd button {\r\n\tbackground: none;\r\n\tmargin:0 !important;\r\n\tpadding:0!important;\r\n}\r\n\r\n/*-----inputs-----*/\r\n\r\ndiv.form-group {\r\n\tpadding: 0;\r\n\tmargin-bottom: 20px !important;\r\n\t/*display: inline-block;*/\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.form-control {\r\n\tbox-shadow:none;\r\n}\r\n\r\ndiv.form-group label {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tline-height: 16px;\r\n\tcolor: #54BBAB;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 0;\r\n\tline-height: 1;\r\n}\r\n\r\ndiv.input-group {\r\n    width: inherit;\r\n    height: 34px;\r\n    min-width: 100%;\r\n    padding-right: 30px;\r\n}\r\n\r\ndiv.input-group input:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.input-group input {\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB !important;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding: 13px 0 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio label  {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tcolor: #54BBAB;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 2px;\r\n}\r\n\r\ndiv.input-group input::-webkit-input-placeholder {color: #3A4859;}\r\ndiv.input-group input:-moz-placeholder {color: #3A4859;}\r\ndiv.input-group input::-moz-placeholder {color: #3A4859;}\r\ndiv.input-group input:-ms-input-placeholder {color: #3A4859;}\r\ndiv.input-group input::-ms-input-placeholder {color: #3A4859;}\r\n\r\nspan.input-group-addon {display: none;}\r\n\r\n.form-control[disabled],\r\n.form-control[readonly],\r\nfieldset[disabled] .form-control,\r\n.form-control[disabled]:active,\r\n.form-control[readonly]:active,\r\nfieldset[disabled] .form-control:active,\r\n.form-control[disabled]:focus,\r\n.form-control[readonly]:focus,\r\nfieldset[disabled] .form-control:focus\r\n {\r\n\tbackground-color: rgba(0,0,0,0);\r\n\tcolor: #B3C7CB;\r\n\tborder-bottom-color: #B3C7CB;\r\n}\r\n\r\n.form-control[disabled] > label.label-mobilidade,\r\n.form-control[readonly] > label.label-mobilidade,\r\nfieldset[disabled] .form-control > label.label-mobilidade {\r\n\tcolor: #B3C7CB !important;\r\n}\r\n\r\n/*-----combo box-----*/\r\n\r\n.theme-main-input-check label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tfont-weight: normal !important;\r\n\tcolor: #54BBAB;\r\n\tmargin-bottom: 2px !important;\r\n}\r\n\r\n.input-group select {\r\n\t-webkit-appearance: none;\r\n\t-moz-appearance: none;\r\n\tappearance: none;\r\n\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat top right;\r\n\tborder-radius: 0;\r\n\tborder-top: none;\r\n\tborder-right: none;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-left: none;\r\n\tpadding: 0 0 10px 0;\r\n\theight: 26px;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 6px !important;\r\n\tbox-sizing: border-box;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tline-height: 12px;\r\n}\r\n\r\n.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\r\n/*-----caixa de texto-----*/\r\n\r\ndiv.input-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.input-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n/*-----botoes-----*/\r\n\r\n.theme-main-button {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n}\r\n\r\n.btn-primary, .btn-warning {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:#F9B000;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\n.btn-primary:hover,\r\n.btn-warning:hover,\r\n.btn-primary:active,\r\n.btn-warning:active,\r\n.btn-primary:focus,\r\n.btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white !important;\r\n\tcolor:#F9B000 !important;\r\n\tborder: 1px solid #F9B000 !important;\r\n\tbox-shadow: none !important;\r\n}\t\r\n\r\n.theme-main-button[disabled=disabled],\r\n.theme-main-button[disabled=disabled]:hover,\r\n.theme-main-button[disabled=disabled]:focus {\r\n\tbackground-color:#d0e0e3 !important;\r\n\tborder-color:#d0e0e3 !important;\r\n\tcolor:white; \r\n\topacity:1 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton#optOpces {background-color: white;}\r\nbutton#optOpces.active {color:#48586C;}\r\n\r\nbutton.btn-default,\r\nbutton.theme-main-button-subscribe,\r\nbutton.theme-main-button-unsubscribe {\r\n\tbox-sizing: border-box;\r\n\tcolor:#54BBAB;\r\n\tbackground-color: white;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\theight: 45px;\r\n\tborder: 1px solid #54BBAB;\r\n}\r\n\r\nbutton.btn-default:hover,\r\nbutton.theme-main-button-subscribe:hover,\r\nbutton.theme-main-button-unsubscribe:hover,\r\nbutton.btn-default:active,\r\nbutton.theme-main-button-subscribe:active,\r\nbutton.theme-main-button-unsubscribe:active,\r\nbutton.btn-default:focus,\r\nbutton.theme-main-button-subscribe:focus,\r\nbutton.theme-main-button-unsubscribe:focus {\r\n\tcolor:white !important;\r\n\tbackground-color: #54BBAB !important;\r\n\tborder: 1px solid #54BBAB !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-left: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton.theme-main-button-subscribe:first-child {\r\n\tmargin-left:0;\r\n}\r\n\r\nbutton#btnEnviar {\r\n\tfont-size:0.5em;\r\n}\r\n\r\n#btnEnviar:hover, #btnEnviar:active, #btnEnviar:focus {\r\n\tdisplay: block !important;\r\n\tmargin-right: auto !important;\r\n\tmargin-left: auto !important;\r\n\tmargin-bottom: 0 !important;\r\n\tbox-sizing: border-box;\r\n\theight: 38px;\r\n}\r\n\r\n.modal-dialog button.btn {\r\n\theight: initial;\r\n\tfont-family: inherit;\r\n\tfont-weight: inherit;\r\n}\r\n\r\n\r\n.modal-dialog button.btn-primary,\r\n.modal-dialog button.btn-primary:hover {\r\n\tmargin: 0 !important;\r\n\theight: 34px;\r\n}\r\n\r\n\r\n/*-----radio-----*/\r\n\r\ndiv.theme-main-input-radio {\r\n\tpadding: 0;\r\n}\r\n\r\ndiv.theme-main-input-radio button {\r\n\tcolor: #6c6c6c;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tborder: 1px solid #D0E0E3;\r\n\topacity: 1 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n\tborder-radius: 3px;\r\n\tpadding: 0 9px;\r\n\r\n}\r\n\r\ndiv.theme-main-input-radio button:hover {\r\n\tbackground-color: #6c6c6c !important;\r\n\tborder: 1px solid #D0E0E3 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active,\r\ndiv.theme-main-input-radio button.active:active,\r\ndiv.theme-main-input-radio button.active:focus {\r\n\tcolor: white !important;\r\n\tbackground-color: #058CE1 !important;\r\n\tborder: 1px solid #058CE1 !important;\r\n\tbox-shadow: none;\r\n\tfont-weight: normal;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active:hover {\r\n\tbackground-color: white !important;\r\n\tborder: 1px solid #058CE1 !important;\r\n\tcolor: #058CE1 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\n/*-----checkbox-----*/\r\n\t\r\n.input-group {margin-bottom: 0px;}\r\n\r\n.input-group > label {\r\n\tdisplay: block;\r\n\t/color: #48586C;\r\n\t/height: 20px;\r\n\t/margin: 0 14px 5px 0;\r\n}\r\n\r\n.theme-main-input-check div.input-group label {\r\n\tcolor:#48586C;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*\r\n.input-group > label input[type=checkbox] {\r\n\tposition: relative;\r\n\tbottom: -40%;\r\n\tmargin-right: 14px;\r\n}\r\n\r\n.input-group > label input[type=checkbox]:before {\r\n\tcontent: '';\r\n\tposition: relative;\r\n\tbottom: -15%;\r\n\tbackground-color: white !important;\r\n\tdisplay: inline-block;\r\n\twidth: 18px;\r\n\theight: 18px;\r\n\tborder: 1px solid #D0E0E3;\r\n}\r\n\r\n.input-group > label input[type=checkbox]:checked:before {\r\n\tcontent: '';\r\n\tbackground-color: #54BBAB !important;\r\n\tdisplay: inline-block;\r\n\twidth: 17px;\r\n\theight: 17px;\r\n\tborder: 4px solid white;\r\n\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\tbox-sizing: border-box;\r\n}\r\n*/\r\n\r\n/*-----breadcrumb-----*/\r\n\r\nol.breadcrumb {\r\n\tbackground-color: white;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tcolor: #3A4859;\r\n}\r\n\r\nol.breadcrumb li a {color: #54BBAB; text-decoration: underline;}\r\n\r\nol.breadcrumb:before {\r\n\tcontent: 'Você  está em';\r\n\tfont-weight: bold;\r\n\tpadding-right: 8px;\r\n}\r\n\r\nol.breadcrumb li:before {content:''; padding-left:0 !important;}\r\n\r\nol.breadcrumb li:after {content:'\\25BA'; padding-left:1ch;}\r\n\r\nol.breadcrumb li:last-child:after {content:'';}\r\n\r\nol.breadcrumb li span {color: #3A4859;}\r\n\r\n/*-----navbar-----*/\r\n\r\n.navbar-brand-middle {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 18px;\r\n\tpadding-top: 22px;\r\n}\r\n\r\n/*-----links-----*/\r\n\r\n.theme-main-link a {\r\n\tcolor: #54BBAB;\r\n\tfont-size: 11px;\r\n\ttext-decoration: none !important;\r\n}\r\n\r\n.theme-main-link a:hover {\r\n\ttext-decoration: underline !important;\r\n}\r\n\r\n/*-----listagem-----*/\r\n\r\ndiv.theme-main-list {margin-top: 2em;}\r\n\r\ndiv.theme-main-list,\r\ndiv.theme-main-list div.text-left,\r\ndiv.theme-main-list div.text-right {padding: 0;}\r\n\r\n\r\n*:focus {outline: none !important;}\r\n\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n\tborder: none;\r\n\tmargin-bottom: 35px;\r\n}\r\n\r\n.rodape-atm{\r\n\tdisplay: none;\r\n}\r\n\r\n.caixa-azul{\r\n\tdisplay: none;\r\n}\r\n\r\n.theme-header-ATM{\r\n\tdisplay: none;\r\n}\r\n\r\nspan.input-group-addon {display: none;}\r\n\r\ndiv.input-group input:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n.form-group {margin-bottom: 0;}\r\n\r\n.form-control {\r\n\tborder: 0;\r\n\tpadding: 4px 0;\r\n\tborder-bottom: 1px solid #ccc;\r\n\tbackground-color: transparent;\r\n\tbox-shadow: none;\r\n}\r\n\r\n.effect{\r\n\tposition:absolute;    \r\n\ttransition:0.3s;\r\n}\r\n\r\n.form-group.col-xs-12.theme-main-input-check {\r\n\tpadding-bottom: 10px;\r\n}\r\n\r\ndiv#telefone-group .input-group .col-xs-4 {\r\n\tpadding-left: 0;\r\n}\r\n\r\n\r\n/*-----combo box-----*/\r\n\r\n.theme-main-input-select label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tfont-weight: normal !important;\r\n\tcolor: #54BBAB !important;\r\n\tmargin-bottom: 2px !important;\r\n}\r\n\r\n.input-group select {\r\n\t-webkit-appearance: none;\r\n\t-moz-appearance: none;\r\n\tappearance: none;\r\n\tbackground: url(../imgs/theme-intranet/seta-combox-desktop.png) no-repeat top right;\r\n\tborder-radius: 0;\r\n\tborder-top: none;\r\n\tborder-right: none;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-left: none;\r\n\tpadding: 0 0 10px 0;\r\n\theight: 26px;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 6px !important;\r\n\tbox-sizing: border-box;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tline-height: 12px;\r\n}\r\n\r\n.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\r\n/*-----caixa de texto-----*/\r\n\r\ndiv.input-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.input-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n\r\n.side-menubar{\r\n    display:none;\r\n}\r\n\r\n\r\n/*-----transicao labels-----*/\r\n\r\ninput.form-control ~ label {\r\n\tmargin-top:0;\r\n\tposition:absolute;\r\n\ttop:-5px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n\tfont-size:12px !important;\r\n}\r\n\r\ninput.form-control {\r\n    margin-top:0px !important;\r\n    transition:0.3s;\r\n}\r\n\r\ninput.form-control:placeholder-shown ~ label{\r\n    transition:0.3s;\r\n    top:5px;\r\n\tfont-size:14px!important;\r\n}\r\n\r\ninput.form-control:placeholder{\r\n    opacity:0;\r\n    color:transparent;\r\n}\r\n\r\nlabel{\r\n\tfont-size:14px !important;\r\n\ttransition:0.3s;\r\n}\r\n\r\n.form-control::-webkit-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n.form-control::-moz-placeholder {opacity:0;\r\n    color:transparent;}\r\n.form-control:-ms-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n\r\n\r\n.form-group label:nth-child(1) {\r\n   display: none;\r\n}\r\n.form-group .theme-main-input-select label:nth-child(1),\r\n.form-group.pick-list label:nth-child(1),\r\n.form-group.theme-main-input-select label:nth-child(1),\r\n.form-group.theme-main-text-area label:nth-child(1),\r\n.form-group.theme-main-input-check label:nth-child(1) {\r\n\tdisplay: block;\r\n}\r\n\r\n.theme-main-input-radio label:nth-child(1),\r\n#uplEscolhaoarquivo label {\r\n\tdisplay:block;\r\n}\r\n\r\n/*-----abas-----*/\r\nul.tabs-nav {\r\n\tborder-bottom: 2px solid #54bbab;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tpadding-bottom: 12px;\r\n}\r\n\r\nul.tabs-nav li {\r\n\tmargin: 0 0px -1px;\r\n}\r\n\r\n.tabs-nav li:first-child {\r\n    margin-left: 0 !important;\r\n}\r\n\r\nul.tabs-nav li a {\r\n\tbackground-color: #b3c7cb;\r\n    border-radius: 0;\r\n    border: none !important;\r\n    color: white !important;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    padding: 10px 30px;\r\n}\r\n\r\nul.tabs-nav li a:hover {\r\n\tbackground-color: #54bbab;\r\n}\r\n\r\nul.tabs-nav li a.active {\r\n\tbackground-color: #54bbab;\r\n    border-radius: 0;\r\n    border: none !important;\r\n    color: white !important;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    padding: 10px 30px;\r\n}\r\n\r\nul.tabs-nav li a.active:hover {\r\n\tcursor: default;\r\n}\r\n\r\ndiv.theme-main-tab .tab-content {\r\n\tmargin-top: 15px;\r\n}\r\n\r\n/*-----graficos-----*/\r\n\r\n.theme-main-chart label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tcolor: #8492af;\r\n\tfont-size: 18px !important;\r\n\tdisplay: block;\r\n\ttext-align: left;\r\n}\r\n\r\n.theme-main-chart text {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n[fill=#f0ad4e] {fill: #F39200;}\r\n[fill=#3c763d] {fill: #0E7639;}\r\n[fill=#277db6] {fill: #005CA9;}\r\n[fill=#5cb85c] {fill: #29C0B3;}\r\n[fill=#f1ca3a] {fill: #F9B000;}\r\n[text-anchor=start] {\r\n\tfont-weight: normal !important;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*-----paineis-----*/\r\n\r\n.theme-main-detail-panel {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary {border-color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-heading {\r\n\tbackground-color: #005CA9;\r\n\tborder-color: #005CA9;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-footer {color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-warning {border-color: #F9B000;}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-heading {\r\n\tbackground-color: #F9B000;\r\n\tborder-color: #F9B000;\r\n}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-footer {\r\n\tbackground-color: #EFF5F6;\r\n\tcolor: #F39200;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default {border-color: #B3C7CB;}\r\n\r\n.theme-main-detail-panel .panel-default .panel-heading {\r\n\tbackground-color: #EFF5F6;\r\n\tborder-color: #B3C7CB;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default .panel-footer {\r\n\tbackground-color: white;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger {border-color: #F51C1F;}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-heading {\r\n\tbackground-color: #F51C1F;\r\n\tborder-color: #F51C1F;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-footer {\r\n\tcolor: #F51C1F;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\n\r\n@media (min-width: 768px) {\r\n\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 26px;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    margin-right: 106px;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: white;\r\n    text-decoration: none;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid #76bad1;\r\n    padding: 3px 18px;\r\n    font-weight: bold;\r\n    box-sizing: border-box;\r\n    width: 80px;\r\n    height: 24px;\r\n}\r\n\r\n.item-sair-intranet a:hover {\r\n    text-decoration: underline;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.menu-item-intranet ul li a span {\r\n\tcolor: transparent;\r\n}\r\n\r\n.menu-item-intranet ul li.item-calendario-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/calendario_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-pesquisa-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/pesquisa_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-config-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/config_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: normal;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n    font-size: 13px !important;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n    position: absolute;\r\n    right: 18px;\r\n    border: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    width: 265px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n\tfont-size: 13px;\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #656565;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 15px;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 16px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 16px;\r\n    padding: 0 15px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 19px;\r\n}\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 24px !important;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    /margin-right: 106px;\r\n    margin-right: 2%;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: aliceblue;\r\n    text-decoration: none;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid #76bad1;\r\n    padding: 3px 18px;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: 400;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n\tposition: absolute;\r\n\tright: 15%;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\twidth: 265px;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #3A4859;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n    font-size: 13px !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 14px !important;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 18px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 14px;\r\n    padding: 0 14px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 16px;\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n\r\n\r\n/*-----componente calendario-----*/\r\n\r\n .hasDatepicker .ui-datepicker-inline {\r\n  background: transparent;\r\n  border: none;\r\n  /padding: 1px;\r\n  width: auto;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header {\r\n  background-color: white;\r\n  border: none;\r\n  padding-top: 8px;\r\n  padding-bottom: 8px;\r\n  border-bottom: 1px solid #d2d2d2;\r\n  margin-bottom: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background-position: 50%;\r\n  background-repeat: no-repeat;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next .ui-icon,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev .ui-icon {\r\n  display: none;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background: url(../imgs/theme-intranet/bt_anteriorMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-left: 16px;\r\n  padding: 0;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next {\r\n  background: url(../imgs/theme-intranet/bt_proximoMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-right: 16px;\r\n  padding: 0;\r\n  float: right;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-title {\r\n  display: inline-block;\r\n  width: calc(100% - 56px);\r\n  margin: 0 auto !important;\r\n  margin-top: 0 !important;\r\n  color: #3A4859;\r\n  font-weight: 400;\r\n  text-transform: uppercase;\r\n  text-align: center;\r\n  vertical-align: top;\r\n  font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n  font-size: 14px;\r\n  line-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar thead tr th {\r\n  background-color: #EFF5F6;\r\n  color: #3A4859;\r\n  font-size: 13px !important;\r\n  font-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n  border-bottom: none !important;\r\n  vertical-align: middle;\r\n  text-align: center;\r\n  max-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td {\r\n  background-color: white;\r\n  border: none !important;\r\n  text-align: center;\r\n  vertical-align: middle;\r\n  padding: 0 !important;\r\n  height: 2em !important;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td a {\r\n  background-color: white;\r\n  border: none;\r\n  color: #3A4859;\r\n  font-size: 13px;\r\n  font-weight: 400;\r\n  text-align: center;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td.ui-datepicker-current-day a {\r\n  background-color: #54BBAB;\r\n  color: #fff;\r\n  /padding: .2em;\r\n  padding: 4px .35em;\r\n  font-weight: 700;\r\n}\r\n\r\n.calendario-intranet.sub-item {\r\n\tdisplay:none;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\tpadding: 0;\r\n\tpadding-bottom: 12px;\r\n\twidth: 236px;\r\n\tposition: absolute;\r\n\tright: 13%;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\ntd.ui-datepicker-week-end {\r\n    border: none !important;\r\n}\r\n\r\n.evento-intranet h5 {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tborder-top: 1px solid #d2d2d2;\r\n\tborder-bottom: 1px solid #d2d2d2;\r\n\ttext-align: center;\r\n\tpadding: 9px 0;\r\n\ttext-transform: uppercase;\r\n\tvertical-align: middle !important;\r\n}\r\n\r\n.conteudo-intranet {\r\n    box-sizing: content-box;\r\n    padding: 0 12px;\r\n}\r\n\r\n.evento-intranet a.verMais {\r\n    color: #54BBAB;\r\n    font-size: 11px;\r\n    font-weight: 700;\r\n    padding-left: 10px;\r\n    position: relative;\r\n}\r\n\r\n.evento-intranet a.verMais:before {\r\n    border-top: 3px solid transparent;\r\n    border-bottom: 3px solid transparent;\r\n    border-left: 4px solid #54BBAB;\r\n    content:  ;\r\n    left: 0;\r\n    position: absolute;\r\n    top: 3px;\r\n}\r\n\r\n.ui-datepicker-calendar {\r\n\twidth: calc(100% - 32px);\r\n\tmargin: 0 auto;\r\n}\r\n\r\n/*-----titulo-----*/\r\n\r\ndiv.theme-header-title span.navbar-brand {\r\n\tdisplay: none;\r\n}\r\n\r\n/*-----header botoes a direita-----*/\r\n\r\n.theme-header-right {\r\n\tdisplay: block !important;\r\n}\r\n\r\n/*-----picklist-----*/\r\n\r\nselect[data-picklist-src], select[data-picklist-dest] {\r\n\tpadding: 2px 1px 1px 6px;\r\n\tborder: solid;\r\n\tborder-width: 1px;\r\n\tborder-color: rgb(84, 187, 171);\r\n\tbackground-color: transparent;\r\n\tbox-shadow: none;\r\n\tborder-radius: 0;\r\n\tcolor: #3A4859;\r\n    \tfont-size: 12px !important;\r\n}\r\n\r\nselect[data-picklist-src]:focus, select[data-picklist-dest]:focus {\r\n\tbox-shadow: none;\r\n\tborder-color: rgb(84, 187, 171);\r\n}\r\n\r\n/*-----mensagem push-----*/\r\n\r\ndiv.analytics-wizard-container .form-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.analytics-wizard-container .form-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .input-group-addon {\r\n\tdisplay: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary,\r\ndiv.analytics-wizard-container .btn-warning {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tbox-sizing: border-box;\r\n\tbackground-color:#F9B000;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary:hover,\r\ndiv.analytics-wizard-container .btn-warning:hover,\r\ndiv.analytics-wizard-container .btn-primary:active,\r\ndiv.analytics-wizard-container .btn-warning:active,\r\ndiv.analytics-wizard-container .btn-primary:focus,\r\ndiv.analytics-wizard-container .btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white !important;\r\n\tcolor:#F9B000 !important;\r\n\tborder: 1px solid #F9B000 !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 5px !important;\r\n\t/margin-left: 2px !important;\r\n}\t\r\n\r\n\r\n/*----MS Edge Browser CSS Start----*/\r\n\r\n@supports (-ms-accelerator:true) {\r\n\r\n\t\t.label-mobilidade{\r\n\t\t\ttop:14px !important;\r\n\t\t\tfont-size:14px !important;\r\n\t\t}\r\n}\r\n/*----MS Edge Browser CSS End----*/\r\n\r\n/*-----Angular 4-----*/\r\n\r\n\r\n@media (min-width: 767px) {\r\n\r\n\tapp-root .theme-header {\r\n\t\tbackground-position: initial;\r\n\t}\r\n\tapp-root .breadcrumb>li {\r\n\t    display: inline;\r\n\t}\r\n\tapp-root .panel.panel-primary.theme-main-map-container {\r\n\t    display: inline-grid;\r\n\t    position: relative;\r\n\t    width: 100%;\r\n\t    text-align: center;\r\n\t    margin-top: 30px;\r\n\t    margin-bottom: 30px;\r\n\t}\r\n\tapp-root div.form-group{\r\n\t\twidth:100%;\r\n\t}\r\n\tapp-root .alert.alert-danger.errorDiv {\r\n\t    margin-top: 10px;\r\n\t    height: auto;\r\n\t    padding: 8px;\r\n\t    width: auto;\r\n\t    display: inline-block;\r\n\t}\r\n\tapp-root .panel.panel-primary.theme-main-map-container {\r\n    display: inline-grid;\r\n    position:  relative;\r\n    width:  100%;\r\n    text-align:  center;\r\n    margin-top: 30px;\r\n    margin-bottom:  30px;\r\n\t}\r\n\t\r\n\tapp-root .alert.alert-danger.errorDiv {\r\n\t    margin-top:  10px;\r\n\t    height:  auto;\r\n\t    padding:  8px;\r\n\t    width:  auto;\r\n\t    display: inline-block;\r\n\t}\r\n\t\r\n\t\r\n\tapp-root .dual-list button.btn.btn-default.pull-right {\r\n\t    box-sizing: border-box;\r\n\t    background-color: white !important;\r\n\t    color: #F9B000 !important;\r\n\t    padding: 5px 12px;\r\n\t    border: 1px solid #F9B000 !important;\r\n\t    box-shadow: none !important;\r\n\t    margin-right: 0 !important;\r\n\t    height:  auto;\r\n\t}\r\n\t\r\n\tapp-root button.btn.btn-primary.btn-block.point-right:hover {\r\n\t    margin-right:  0 !important;\r\n\t    height: 32px;\r\n\t}\r\n\tapp-root .theme-main-input-number-cpf .label-mobilidade {\r\n\t    position: absolute;\r\n\t    z-index: 2;\r\n\t}\r\n\tapp-root .theme-main-input-number-conta .label-mobilidade, app-root .theme-main-input-number-cep .label-mobilidade,\r\n\tapp-root .theme-main-input-number-operacao .label-mobilidade, app-root .theme-main-input-number-matricula .label-mobilidade, \r\n\tapp-root .theme-main-input-number-telefone .label-mobilidade, app-root .theme-main-input-date .label-mobilidade {\r\n\t    position: absolute;\r\n\t    z-index: 2;\r\n\t    top: 0;\r\n\t}\r\n}\r\n\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n/*---------------------------------------------- Mobile\t -------------------------------------------------*/\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n\r\n@media (max-width: 767px) {\r\n\t\r\n\t/*-----cabecalho-----*/\r\n\r\n\t.theme-header {\r\n\t\theight: 56px;\r\n\t\tpadding: 18px 16px;\r\n\t\tborder-bottom: none !important;\r\n\t\tbackground: #54bbab;\r\n\t\tbackground: -moz-linear-gradient(left, #54bbab 1%, #005ca9 100%);\r\n\t\tbackground: -webkit-linear-gradient(left, #54bbab 1%,#005ca9 100%);\r\n\t\tbackground: linear-gradient(to right, #54bbab 1%,#005ca9 100%);\r\n\t\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#54bbab', endColorstr='#005ca9',GradientType=1 );\r\n\t}\r\n\t\r\n\t.theme-header-right-title {\r\n\t\tmargin-right: 18px;\r\n\t\tmargin-top: 2px;\r\n\t\tfont-size: 20px;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-weight: bolder;\r\n\t}\r\n\t\r\n\t.theme-header-right-subtitle {display: none;}\r\n\t\r\n\t.navbar-left {float: right;}\r\n\t\r\n\t.theme-header-left a {\r\n\t\tbackground: url(../imgs/theme-mobilidade-2017/caixa-sintese-branco.png) no-repeat!important;\r\n\t\twidth: 23.5px;\r\n\t\theight: 20px;\r\n\t\tmargin: 0!important;\r\n\t}\r\n\t\r\n\t.navbar-brand {\r\n\t\tpadding: 0!important;\r\n\t\tdisplay: block;\r\n\t\tfloat: right;\r\n    }\r\n\t\r\n\t.navbar-right {float: left!important;}\r\n\t\r\n\t.navbar-toggle {\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none;\r\n\t}\r\n\t\r\n\t.navbar-toggle i {\r\n\t\twidth: 20px;\r\n\t\theight: 20px;\r\n\t\tmargin-right: 36px;\r\n\t}\r\n\t\r\n\t.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:active, \r\n\t.navbar-default .navbar-toggle:focus, .nav li a:hover, .nav li a:active, .nav li a:focus {background: none;}\r\n\r\n\t.theme-header-right-logo {display: none !important;}\r\n\t\r\n\th1, h2, h3, h4, h5, h6, ul {font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;}\r\n\t\r\n\tli a {font-size: 1.2em;}\r\n\r\n\t/*-----rodape-----*/\r\n\r\n\t.theme-footer {display: none;}\r\n\t\r\n\t/*-----menu vertical-----*/\r\n\r\n\t.sidebar, .sidebar-nav {\r\n\t\tborder: none;\r\n\t\tbackground: white;\r\n\t\twidth: 100% !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li a {\r\n\t\tpadding: 0;\r\n\t\tfont-size: 16px;\r\n\t\tcolor: #48586C;\r\n\t\tborder-top: 1px solid #D0E0E3;\r\n\t\tfont-weight: normal;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li a.active {\r\n\t\tborder: none;\r\n\t\tbackground-color: #D0E0E3;\r\n\t\tborder-top: 1px solid #D0E0E3;\r\n\t\tcolor: #48586C;\r\n\t\tfont-size: 16px;\r\n\t\tbackground-image: none;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li i {\r\n\t\tdisplay: inline-block !important;\r\n\t\tfont-size: 18px;\r\n\t\tmargin: 14px 37px 14px 15px !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li.open > a {background-color: #eee; display: block;}\r\n\r\n\t.sidebar-nav .nav li > a[aria-expanded=\"true\"] {\r\n\t\tcolor: #48586C;\r\n\t\tfont-size: 16px;\r\n\t\tbackground-image: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li ul li a {\r\n\t\tbackground-image: none !important;\r\n\t\tbackground-color: white !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 14px;\r\n\t\tpadding-left: 0;\r\n\t\tborder: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t\tline-height: 23px;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li ul li a.active {\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-size: 14px;\r\n\t\tbackground-color: #D0E0E3 !important;\r\n\t\tborder: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t}\r\n\r\n\t/*-----inputs-----*/\r\n\r\n\t.form-control {box-shadow:none;}\r\n\t\r\n\tdiv.form-group label {\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 14px;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t}\r\n\r\n\t.input-group {font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;}\r\n\t\r\n\tspan.input-group-addon {display: none;}\r\n\t\r\n\tdiv.input-group input {\r\n\t\tborder-bottom: 1px solid #D0E0E3;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tmargin-bottom: 20px !important;\r\n\t\tfont-size: 18px !important;\r\n\t\tpadding: 0;\r\n\t}\r\n\t\r\n\tdiv.input-group input:focus {\r\n\t    border-color: #D0E0E3;\r\n\t    box-shadow: none;\r\n\t}\r\n\t\r\n\t.form-group {margin-bottom: 0;}\r\n\t\r\n\th5.padding.text-primary.bold.theme-main-h4 {\r\n\t\tfont-weight: bolder;\r\n\t\tmargin-left: -7px;\r\n\t\tfont-size: 20px !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tpadding-left: 6px;\r\n\t\tpadding-bottom: 0px;\r\n\t}\r\n\r\n\th6.padding.text-primary.theme-main-h6 {\r\n\t\tfont-weight: bolder;\r\n\t\tfont-size: 16px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tspan.label.padding.theme-main-label.text-primary {\r\n\t\tfont-size: 12px;\r\n\t\tfont-weight: lighter;\r\n\t\tcolor: #48586C;\r\n\t}\r\n\t/*span.label.padding.theme-main-label.ng-binding.text-primary.pull-left.col-xs-12*/\r\n\t\r\n\t/*-----abas-----*/\r\n\t\r\n\t.tabs-nav {\r\n\t\tmargin: 70px 0 0 0;\r\n\t\tpadding: 0;\r\n\t\tdisplay: inline-block !important;\r\n\t\theight: 75px;\r\n\t\twidth: 100%;\r\n\t\tbackground: #54bbab;\r\n\t\tbackground: -moz-linear-gradient(left, #54bbab 1%, #005ca9 100%);\r\n\t\tbackground: -webkit-linear-gradient(left, #54bbab 1%,#005ca9 100%);\r\n\t\tbackground: linear-gradient(to right, #54bbab 1%,#005ca9 100%);\r\n\t\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#54bbab', endColorstr='#005ca9',GradientType=1 );\r\n\t\toverflow: hidden;\r\n\t\tposition: relative;\r\n\t}\r\n\r\n\t.tabs-nav li {\r\n\t\tmargin: 0 !important;\r\n\t\tborder: none !important;\r\n\t\tpadding: 0 !important;\r\n\t}\r\n\r\n\t.tabs-nav li a {\r\n\t\tmargin: 25px 0;\r\n\t\tpadding: 2.5px 13px 0 13px;\r\n\t\twidth: 32.5% !important;\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tborder-left: 1px solid rgba(255, 255, 255, 0.35);\r\n\t\tborder-radius: 0;\r\n\t\theight: 25px;\r\n\t\tcolor: white;\r\n\t\ttext-align: center;\r\n\t\tfloat: left;\r\n\t\toverflow: hidden;\r\n\t}\r\n\t\t\r\n\t.tabs-nav li a.active {\r\n\t\tbackground: none;\r\n\t\tborder-bottom: none;\r\n\t}\r\n\r\n\t.tabs-nav li a.active::after {\r\n\t\tcontent: url('../imgs/theme-mobilidade-2017/seta.png');\r\n\t\ttop: 60px;\r\n\t\tmargin-left: -30px;\r\n\t\tvertical-align: bottom;\r\n\t\tposition: absolute;\r\n\t}\r\n\r\n\t/*-----tabelas-----*/\r\n\r\n\tthead tr th {\r\n\t\tpadding: 0 16px 30px 0 !important;\r\n\t\tbackground: none !important;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-size: 14px;\r\n\t\tborder: none !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\ttbody > tr > td:first-child {font-weight: normal;}\r\n\r\n\ttbody tr {background-color: white !important;}\r\n\r\n\ttbody tr td {\r\n\t\tpadding: 0 16px 30px 0 !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-size: 14px;\r\n\t\tborder: none !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\tth, td {border: none !important;}\r\n\r\n\ttd button {\r\n\t\tbackground: none;\r\n\t\tmargin: 0 !important;\r\n\t\tpadding: 0 !important;\r\n\t\tline-height: inherit !important;\r\n\t}\r\n\r\n\ttd button i {line-height: inherit !important;}\r\n\r\n\ttd button:hover, td button i:hover {color: #48586C;}\r\n    \r\n    /*-----barra de rolagem-----*/\r\n\r\n\t.table-responsive::-webkit-scrollbar {width: 5px; height: 5px;}\r\n\t.table-responsive::-webkit-scrollbar-button {width: 0; height: 0;}\r\n\t.table-responsive::-webkit-scrollbar-thumb {\r\n\t\tbackground:#54BBAB !important;\r\n\t\tborder: none;\r\n\t\tborder-radius: 0;\r\n\t}\r\n\t.table-responsive::-webkit-scrollbar-thumb:hover,\r\n\t.table-responsive::-webkit-scrollbar-thumb:active {background:#54BBAB !important;}\r\n\t.table-responsive::-webkit-scrollbar-track {\r\n\t\tbackground:#D0E0E3 !important;\r\n\t\tborder: none;\r\n\t\tborder-radius: 0;\r\n\t}\r\n\t.table-responsive::-webkit-scrollbar-track:hover,\r\n\t.table-responsive::-webkit-scrollbar-track:active {background:#D0E0E3 !important;}\r\n\r\n\t/*-----combo box-----*/\r\n\r\n\t.theme-main-input-select {margin: 20px auto;}\r\n\r\n\t.theme-main-input-select label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tfont-weight: bolder !important;\r\n\t\tcolor: #005CA9 !important;\r\n\t}\r\n\r\n\t.input-group select {\r\n\t\t-webkit-appearance: none;\r\n  \t\t-moz-appearance: none;\r\n  \t\tappearance: none;\r\n\t\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat right;\r\n\t\tborder-radius: 0;\r\n\t\tborder-top: none;\r\n\t\tborder-right: none;\r\n\t\tborder-bottom: 1px solid #D0E0E3;\r\n\t\tborder-left: none;\r\n\t\tpadding: 0 !important;\r\n\t\tmargin: 0 !important;\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 16px !important;\r\n\t\tline-height: 16px;\r\n\t\tmin-width: 152px;\r\n\t}\r\n\r\n\t.input-group select:focus {border-color: #D0E0E3; box-shadow: none;}\r\n\r\n\t/*-----separador-----*/\r\n\r\n\thr {border-color:#005CA9; margin: 20px 0 !important;}\r\n\r\n\t/*-----botoes-----*/\r\n\r\n\t.theme-main-button {\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-weight: bolder;\r\n\t\tfont-size: 16px !important;\r\n\t\tborder-radius: 0;\r\n\t\tmargin-top: 10px;\r\n\t\tmargin-bottom: 0;\r\n\t\tbox-sizing: border-box;\r\n\t\tpadding: 8px !important;\r\n\t}\r\n\r\n\t.btn-primary {background-color:#005CA9; border:0;}\r\n\t.btn-warning {background-color:#F39200; border:0;}\r\n\r\n\t.btn-primary:hover {background-color:#0071CF !important;}\r\n\t.btn-warning:hover {background-color:#feb21e !important;}\t\r\n\tbutton.col-xs-4 {\r\n\t    width: 33%;\r\n\t    margin-right: 7px;\r\n\t}\r\n\t.btn-primary:active {background-color:#004C8C !important; box-shadow:none;}\r\n\t.btn-warning:active {background-color:#ec7500 !important; box-shadow:none;}\t\r\n\r\n\t.theme-main-button[disabled=\"disabled\"],\r\n\t.theme-main-button[disabled=\"disabled\"]:hover,\r\n\t.theme-main-button[disabled=\"disabled\"]:focus {background-color:#d0e0e3 !important; border-color:#d0e0e3 !important; color:white; opacity:1 !important;}\r\n    \r\n    /*-----menu horizontal-----*/\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li {\r\n\t\tpadding-top: 0;\r\n\t\tpadding-bottom: 0;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a {\r\n\t\tcolor: white;\r\n\t\tborder-right: none !important;\r\n\t\tdisplay: inline-block !important;\r\n\t\tpadding-top: 0px !important;\r\n\t\tline-height: inherit;\r\n\t}\r\n\r\n\t.nav .open>a, .nav .open>a:focus, .nav .open>a:hover {\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tcolor: white;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a:hover {\r\n\t\toutline: none;\r\n\t\tborder: none;\r\n\t\tcolor: white;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a i {display: inline-block !important;}\r\n\r\n    .theme-header-tabs {\r\n\t\tbackground-color: #54BBAB;\r\n\t\tposition: fixed;\r\n\t\tbottom: 0;\r\n\t\tleft: 0;\r\n\t\theight: 48px;\r\n\t\tmax-height: none;\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none !important;\r\n\t\tdisplay: block;\r\n\t}\r\n\r\n\t.theme-header-tabs .caixa-azul {display: none;}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs {\r\n\t\tmax-height: none;\r\n\t\toverflow-y: visible !important;\r\n\t\toverflow-x: visible !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li {\r\n\t\theight: 48px;\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none !important;\r\n\t\twidth: 25% !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li a {\r\n\t\tcolor: white;\r\n\t\tfont-size: 22px;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 32px;\r\n\t\theight: 22px;\r\n\t\ttext-align: center;\r\n\t\tvertical-align: top !important;\r\n\t\tmargin: 9px 0px 13px 10px;\r\n\t\tpadding: 0 !important;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs li a[class=\"ng-scope active\"]::before {\r\n\t\tcontent: '';\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 100%;\r\n\t\theight: 4px;\r\n\t\tbackground-color: #005CA9;\r\n\t\tposition: absolute;\r\n\t\tright: 0;\r\n\t\ttop: -4px;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs li a[class=\"ng-scope active\"] {\r\n\t\tbackground-color: #66cfbf;\r\n\t\toverflow: visible;\r\n\t\theight: 48px !important;\r\n\t\tmargin: 0 !important;\r\n\t\tpadding: 9px 29px 13px 29px !important;\r\n\t\twidth: 100% !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li:hover {\r\n\t\tcursor: pointer;\r\n\t\tbackground-color: #66cfbf;\r\n\t\tmargin: 0 !important;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs:focus {outline:none;}\r\n\r\n\tul.theme-header-tabs:hover {display: block !important;}\r\n\r\n\t/*-----submenus-----*/\r\n\r\n\tdiv.page-wrapper {margin-top: 77px !important;}\r\n\r\n\tul.theme-header-tabs li.dropdown {width: 25%;}\r\n\r\n\tul.theme-header-tabs li.dropdown a,\r\n\tul.theme-header-tabs li.dropdown a:focus,\r\n\tul.theme-header-tabs li.dropdown a:hover {\r\n\t\tbackground-color: transparent;\r\n\t\tfont-size: 22px;\r\n\t\twidth: 32px;\r\n\t\theight: 22px;\r\n\t\ttext-align: center;\r\n\t\tvertical-align: top !important;\r\n\t\tmargin: 0;\r\n\t\tpadding: 9px 29px 13px 29px !important;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul  {box-shadow: none;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu {display: none;}\r\n\t\r\n\tul.theme-header-tabs li.open ul.dropdown-menu {\r\n\t\tbackground: none;\r\n\t\tdisplay: inline-block;\r\n\t\tbottom: 58px;\r\n\t\twidth: 90px !important;\r\n\t\tmargin: 0;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:first-child  {\r\n\t\tdisplay: inline-block;\r\n\t\tposition: absolute;\r\n\t\tbottom: 58px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(2)  {\r\n\t\tdisplay: inline-block !important;\r\n\t\tposition: relative;\r\n\t\tbottom: 153px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(3)  {\r\n\t\tdisplay: inline-block !important;\r\n\t\tposition: relative;\r\n\t\tbottom: 258px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(n+4) {display: none;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:first-child,\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(2),\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(3) {\r\n\t\tbackground-color: #005CA9;\r\n\t\theight: 48px;\r\n\t\twidth: 90px !important;\r\n\t\ttransition: all 0.3s ease-out 0s;\r\n\t\toverflow: hidden;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown:after {\r\n\t\tcontent: '\\\r\nF6';\r\n\t\tfont-size: 12px;\r\n\t\tcolor: white;\r\n\t\tposition: relative;\r\n\t\ttop: 2px !important;\r\n\t\tleft: 4px !important;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:hover {background-color:#00B5E5;}\r\n\r\n\tul.theme-header-tabs li.dropdown.open:hover {background-color: #54bbab;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a:hover {color: white;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a span {color: transparent;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a span i {color: white;}\r\n\r\n\t/*-----carrossel-----*/\r\n\r\n\t.carousel-indicators li, .carousel-indicators .active {\r\n\t\tmargin: 20px 6px auto 6px;\r\n\t\tborder-color: #F39200;\r\n\t\tbackground-color: white;\r\n\t\twidth: 12px;\r\n\t\theight: 12px;\r\n\t}\r\n\r\n\t.carousel-indicators .active {\r\n\t\tbackground-color: #F39200;\r\n\t\twidth: 12px;\r\n\t\theight: 12px;\r\n\t}\r\n\r\n\tol.carousel-indicators {\r\n\t\tposition: static;\r\n\t\tlist-style: none;\r\n\t\twidth: auto;\r\n\t\theight: auto;\r\n\t\ttop: 100%;\r\n\t\tright: 0;\r\n\t\ttext-align: right;\r\n\t}\r\n\r\n\tol.carousel-indicators li:last-child {margin-right: 0;}\r\n\r\n\t.carousel-caption {display: none;}\r\n\r\n\t.carousel-control {display: none;}\r\n\r\n\t/*-----radio-----*/\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 14px !important;\r\n\t\tcolor: #48586C;\r\n\t\tdisplay: block;\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tpadding: 0;\r\n\t\theight: 20px;\r\n\t\tmargin: 0 0 5px 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:hover, \r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:active,\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:focus {\r\n\t\tcolor: #48586C;\r\n\t\tbackground: none !important;\r\n\t\tborder: none;\r\n\t\toutline: none;\r\n\t\tcursor: auto;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn.active,\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn:active {box-shadow: none;}\r\n\t\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn:before {\r\n\t\tcontent: '';\r\n\t\tposition: relative;\r\n\t\tbottom: -4px;\r\n\t\tbackground-color: white;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 18px;\r\n\t\theight: 18px;\r\n\t\tborder: 1px solid #D0E0E3;\r\n\t\tborder-radius: 50%;\r\n\t\tmargin: 0 10px 0 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn.active:before {\r\n\t\tcontent: '';\r\n\t\tbackground-color: #54BBAB;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 8px;\r\n\t\theight: 8px;\r\n\t\tborder: 5px solid white;\r\n\t\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\t\tbox-sizing: content-box;\r\n\t\tborder-radius: 50%;\r\n\t\tmargin: 0 10px 0 0;\r\n\t}\r\n\t\t\r\n\t/*-----checkbox-----*/\r\n\t\r\n\tdiv[ng-if=\"item.type=='input-check'\"] label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group {margin-bottom: 40px;}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 14px !important;\r\n\t\tcolor: #48586C;\r\n\t\tdisplay: block;\r\n\t\theight: 20px;\r\n\t\tmargin: 0 14px 5px 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"] {\r\n\t\tposition: relative;\r\n\t\tbottom: -40%;\r\n\t\tmargin-right: 14px;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"]:before {\r\n\t\tcontent: '';\r\n\t\tposition: relative;\r\n\t\tbottom: -15%;\r\n\t\tbackground-color: white !important;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 18px;\r\n\t\theight: 18px;\r\n\t\tborder: 1px solid #D0E0E3;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"]:checked:before {\r\n\t\tcontent: '';\r\n\t\tbackground-color: #54BBAB !important;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 17px;\r\n\t\theight: 17px;\r\n\t\tborder: 4px solid white;\r\n\t\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\t/*-----breadcrumb-----*/\r\n\r\n\tol.breadcrumb {background-color: #f5f5f5;}\r\n\r\n\tol.breadcrumb li a {color: #337ab7; text-decoration: none;}\r\n\r\n\tol.breadcrumb:before {content: ''; padding-right: 0;}\r\n\r\n\tol.breadcrumb li:before {content:''; padding-left:0 !important;}\r\n\r\n\tol.breadcrumb li:after {content:\"/\\00a0\"; color:#ccc; padding:0 5px;}\r\n\r\n\tol.breadcrumb li:last-child:before {padding:0 !important;}\r\n\r\n\r\n\t/*-----texto-----*/\r\n\r\n\th5.theme-main-h4, h6.theme-main-h6 {line-height: 1.1;}\r\n\r\n\th5.theme-main-h4 {border-bottom: none;}\r\n\r\n\t.text-primary, .text-primary-important, .text-warning,\r\n\t.text-warning-important, .text-success, .text-success-important,\r\n\t.text-default, .text-black, .text-purple, .text-laranja, .text-info,\r\n\t.text-danger {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\t/* font-size: 14px !important; */\r\n\t\tline-height: 18px;\r\n\t}\r\n\r\n\t.text-primary {color: #005CA9 !important;}\r\n\t.text-primary-important {color: #005CA9 !important;}\r\n\t.text-warning {color: #F39200;}\r\n\t.text-warning-important {color: #F39200 !important;}\r\n\t.text-success {color: #54BBAB;}\r\n\t.text-success-important {color: #54BBAB !important;}\r\n\t.text-default {color: #48586C; font-weight: 100;}\r\n\t.text-black {color: #48586C; font-weight: 100;}\r\n\t.text-purple {color: #B26F9B; font-weight: 100;}\r\n\t.text-laranja {color: #F39200; font-weight: 100;}\r\n\t.text-info {color: #AFCA0B; font-weight: 100;}\r\n\t.text-danger {color: #F9765E; font-weight: 100;}\r\n\r\n\t/*-----links-----*/\r\n\r\n\t.theme-main-link a {color: #337ab7; font-size: 12px;}\r\n\r\n\r\n\t.side-menubar .theme-header-title {\r\n    \tmargin-top: 18px;\r\n\t}\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse {\r\n        display: block;\r\n        height: 100%!important;\r\n        margin-left: -700px;\r\n        position: fixed!important;\r\n        width: 85% !important;\r\n        overflow: hidden;\r\n        z-index: 9099999 !important;\r\n    }\r\n\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse.in {\r\n        display: inline !important;\r\n        height: auto !important;\r\n        margin-left: 0px !important;\r\n        background-color: white;\r\n        transition: all 2s;\r\n        z-index: 9999 !important;\r\n        padding-bottom: 60px !important;\r\n        max-width: 85%;\r\n        bottom: 0;\r\n        max-height: 59%;\r\n        min-height: 59%;\r\n    }\r\n\r\n    li.theme-menu-item {\r\n        width:100%;\r\n        position: relative;\r\n        \r\n    }\r\n    .navbar-toggle i {\r\n        width: 20px;\r\n        height: 20px;\r\n        margin-right: 13px;\r\n        margin-top: 5px;\r\n    }\r\n\r\n\r\n    li.theme-menu-item:nth-child(7) a:nth-child(2){\r\n        bottom: 0;\r\n        position: fixed;\r\n        background: #005ca9;\r\n        color: white;\r\n        width: 85%;\r\n    }\r\n\r\n\r\n    .theme-app.menu .theme-menu-container {\r\n        overflow-y: auto;\r\n        overflow: auto;\r\n        display: inline-block;\r\n        height: auto;\r\n        position: absolute;\r\n        top: 9px;\r\n        bottom: 0;\r\n        width: 85% !important;\r\n    }\r\n\r\n    .sidebar .sidebar-nav.navbar-collapse {\r\n        transition: all 0.5s ease !important;\r\n    }\r\n\r\n    .theme-app.menu .theme-main-container {\r\n        margin: 10px 0 0 0px;\r\n     \r\n    }\r\n\r\n    .theme-app.menu .theme-main-container {\r\n        margin: 10px 0 0 0px;\r\n     }\r\n     \r\n     .overlay {\r\n        display: none;\r\n        background: rgba(0,0,0,.7);\r\n        height: 100%;\r\n        left: 0;\r\n        position: absolute;\r\n        top: 0;\r\n        width: 100%;\r\n        z-index: 98;\r\n    }\r\n    .theme-app.menu .theme-main-container {\r\n        margin-top: 76px !important;\r\n    }\r\n    .side-menubar{\r\n        display: block !important;\r\n        width:85%;\r\n        margin-left:-700px;\r\n        transition: all 0.5s ease !important;\r\n        background: white;\r\n        height: 52%;\r\n    } \r\n    .side-menubar:after {\r\n        content: \"\";\r\n        background: #D0E0E3;\r\n        position: absolute;\r\n        bottom: 0;\r\n        left: 0;\r\n        height: 1px;\r\n        width: 33%;\r\n    }\r\n    .seta{\r\n        padding: 3px 0px;\r\n        background: #F39200;\r\n        border-radius: 50%;\r\n        float: left;\r\n        margin: 0 ;\r\n    }\r\n    \r\n    .setaleft {\r\n       color:#FFFFFF; \r\n       font-size:13px;\r\n    }\r\n    .glyphicon-menu-left:before {\r\n        margin-left: 8px;\r\n    }   \r\n    .fa-navicon{\r\n        font-size: 23px !important;\r\n        margin: 1px 13px 0 0 !important;\r\n    }\r\n    li.theme-menu-item:nth-child(2) a {\r\n        border-top: none;\r\n    }\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse.in{\r\n        overflow-y: scroll;\r\n    }\r\n    .feedback-menu a{\r\n        color: #F39200 !important;\r\n        font-size: 25px;    \r\n    }\r\n    .informacao-header {\r\n        height: auto;\r\n        background: white;\r\n    }\r\n\r\n    .informacao-header .form-group.col-xs-12.theme-main-input-text {\r\n        padding: 0;\r\n        top: 0;\r\n    }\r\n\r\n    .informacao-header .circle.col-xs-6 {\r\n        height: 104px;\r\n        width: 104px;\r\n        margin-top: -2px;\r\n    }\r\n    \r\n    .informacao-header .circle.col-xs-6 .fa.fa-user{\r\n           margin: 2px 3px;\r\n           font-size: 7em;\r\n           color: #F39200;\r\n    }\r\n    \r\n\r\n    .informacao-header .theme-main-input-text p {\r\n        font-weight: normal;\r\n        font-size: 14px;\r\n        font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n        margin: 0;\r\n    }\r\n\r\n    .form-group.col-xs-12.theme-main-input-text.nome-usuario {\r\n        padding-bottom: 10px;\r\n    }\r\n\r\n    a.btn-sair-menu {\r\n        display: block;\r\n        padding-left: 16px;\r\n        line-height: 23.5px;\r\n        min-height: 47px;\r\n        box-sizing: border-box;\r\n        padding: 0;\r\n        font-size: 16px;\r\n        border-top: 1px solid #D0E0E3;\r\n        font-weight: normal;\r\n        bottom: 0;\r\n        position: fixed;\r\n        background: #005ca9;\r\n        color: white;\r\n        cursor: pointer;\r\n        width: 85%;\r\n    }\r\n\t\r\n    .btn-sair-menu i.fa.fa-sign-out {\r\n        display: inline-block !important;\r\n        font-size: 18px;\r\n        margin: 14px 37px 14px 15px !important;\r\n    }\r\n\r\n    .btn-sair-menu span.theme-menu-item-caption {\r\n        text-decoration: none;\r\n    }\r\n\r\n    a.btn-sair-menu:hover {\r\n        text-decoration: none;\r\n    }\r\n    .barra-menu{\r\n    \tdisplay:block;\r\n        height: 20px;\r\n        width: 100%;\r\n        background: url(../imgs/theme-mobilidade-2017/barra-menu.jpg);\r\n        position: fixed;\r\n        top: 0;\r\n        z-index: 99999;\r\n    }\r\n    .theme-header{\r\n        margin-top: 20px;\r\n    }\r\n    .side-menubar{\r\n\t    display:block;\r\n        margin-top:0;\r\n        z-index: 9999;\r\n    }\r\n\t.table-responsive.table-bordered.theme-main-table.ng-scope.col-xs-12 {\r\n\t    margin-bottom: 34px;\r\n\t    margin-top: 5px;\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-4{\r\n\t    width: 33.33333333%;\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-12{\r\n\t    width: 100%\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-6{\r\n\t    width: 50%;\r\n\t}\r\n\tbutton.btn.btn-sm.margin-3x.theme-main-button.toggle-menu.btn-primary.pull-left.col-xs-12 {\r\n\t    height: auto;\r\n\t}\r\n\t\r\n\tbutton.btn.btn-sm.margin-3x.theme-main-button.toggle-menu.btn-primary.pull-left.col-xs-12 .menu ol li {\r\n\t    margin-top: 16px;\r\n\t    margin-left: -19px;\r\n\t    white-space: normal;\r\n\t}\r\n\r\n\r\n\ti.fa.theme-main-icon.ng-scope.fa-play-circle-o.text-primary.floatRight:before {\r\n\t    float: right;\r\n\t}    \r\n    a.form-group.panel-center.theme-main-img-button.ng-scope.floatLeft {margin-left: 15px;margin-top: 6px;}\r\n\r\n\ta.form-group.panel-center.theme-main-img-button.ng-scope.floatNone.text-center {\r\n\t    text-align: center;\r\n\t    display:  inline-block;\r\n\t    width:  100%;\r\n\t    margin-top:  10px;\r\n\t}\r\n\t\r\n\ta.theme-main-img-button.floatNone img {\r\n\t    margin: 0 auto;\r\n\t    text-align:  center;\r\n\t}\r\n\t\r\n\ta.form-group.panel-center.theme-main-img-button.ng-scope.floatRight {\r\n\t    margin-top: 10px;\r\n\t    text-align: right;\r\n\t    margin-right: 15px;\r\n\t}\r\n    .tabs-nav li{\r\n\t    display:none;\r\n\t}\r\n\t.tabs-nav li:nth-child(1), .tabs-nav li:nth-child(2), .tabs-nav li:nth-child(3){\r\n\t    display:block;\r\n\r\n\t}\r\n\t.tabs-nav li a.active::after{\r\n\t\tmargin-left: -21px;\r\n\t}\r\n\t.tabs-nav a{\r\n\t\tfont-size: 17px;\r\n\t}\r\n    \r\n\t\r\n\tlabel.ng-binding {\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 14px;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tmargin-bottom: 2px;\r\n\t}\r\n\t\r\n\tdiv.input-group {width: inherit;}\r\n\t\r\n\tdiv.input-group input {\r\n\t\tcolor: #3A4859;\r\n\t\tfont-size: 12px !important;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tpadding-bottom: 7px;\r\n\t\tpadding-left: 0;\r\n\t\theight: 26px;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 0 !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\t\r\n\tspan.input-group-addon {display: none;}\r\n\t\r\n\tdiv.input-group input:focus {\r\n\t\tborder-color: #54BBAB;\r\n\t\tbox-shadow: none;\r\n\t}\r\n\t\r\n\t.form-group {margin-bottom: 0;}\r\n\t\r\n\t\r\n\t\r\n\t.form-control{border: 0; padding: 4px 0; border-bottom: 1px solid #ccc; background-color: transparent; box-shadow: none;}\r\n\t\r\n\t\r\n\t\r\n\t.form-group.col-xs-12.theme-main-input-check {\r\n\t\tpadding-bottom: 10px;\r\n\t}\r\n\t\r\n\tdiv#telefone-group .input-group .col-xs-4 {\r\n\t\tpadding-left: 0;\r\n\t}\r\n\r\n\t\r\n\t/*-----combo box-----*/\r\n\t\r\n\t.theme-main-input-select label {\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 14px !important;\r\n\t\tfont-weight: normal !important;\r\n\t\tcolor: #54BBAB !important;\r\n\t\tmargin-bottom: 2px !important;\r\n\t}\r\n\t\r\n\t.input-group select {\r\n\t\t-webkit-appearance: none;\r\n\t\t-moz-appearance: none;\r\n\t\tappearance: none;\r\n\t\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat top right;\r\n\t\tborder-radius: 0;\r\n\t\tborder-top: none;\r\n\t\tborder-right: none;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-left: none;\r\n\t\tpadding: 0 0 10px 0;\r\n\t\theight: 26px;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 6px !important;\r\n\t\tbox-sizing: border-box;\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 12px !important;\r\n\t\tline-height: 12px;\r\n\t}\r\n\t\r\n\t.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\t\r\n\t/*-----caixa de texto-----*/\r\n\t\r\n\tdiv.input-group textarea {\r\n\t\twidth: inherit;\r\n\t\tcolor: #3A4859;\r\n\t\tfont-size: 12px !important;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tpadding-bottom: 7px;\r\n\t\tpadding-left: 0;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 0 !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\t\r\n\tdiv.input-group textarea:focus {\r\n\t\tborder-color: #54BBAB;\r\n\t\tbox-shadow: none;\r\n\t}\r\n\r\n\t.splash .navbar-right.theme-header-right .navbar-brand  {\r\n\t\tdisplay: none;\r\n\t}\r\n\t.splash ol.breadcrumb.ng-isolate-scope {\r\n\t    display: none;\r\n\t}\r\n\r\n\t.splash .theme-header{    \r\n\t   background: #065CA7 !important;\r\n\t}\r\n\r\n\t.splash {\r\n\t    background-color: #065CA7;\r\n\t    position: absolute;\r\n\t    height: 100%;\r\n\t}\r\n\r\n\t.splash span.ng-binding {\r\n\t    color: #fff;\r\n\t}\r\n\r\n\t.splash .navbar-right.theme-header-right {\r\n\t\twidth: 0;\r\n\t    height: 0;\r\n\t    border: 0 solid transparent;\r\n\t    border-left-width: 0px;\r\n\t    border-right-width: 100PX;\r\n\t    border-top: 100px solid #FF9300;\r\n\t    margin: 0;\r\n\t    vertical-align: middle;\r\n\t    position: absolute;\r\n\t    top: 0;\r\n\t    left: 0;\r\n\t}\r\n\t.splash .theme-header-left a{\r\n\t\tbackground: url(../imgs/theme-mobilidade-2017/titlefullc.png) no-repeat!important;\r\n\t}\r\n\t.splash .navbar-left.theme-header-left {\r\n\t    float: none;\r\n\t    margin-left: 33%;\r\n\t    width: 100% !important;\r\n\t    height: 31px;\r\n\t}\r\n\t.splash .barra-menu {\r\n    \tdisplay: none !important;\r\n\t}\r\n\t\r\n\t.splash .navbar-default.sidebar.theme-menu-container {\r\n\t\tdisplay:none;\r\n\t    background: none;\r\n\t}\r\n\t.splash nav.navbar.navbar-default.navbar-fixed-top.theme-header {\r\n\t    margin-top: 0;\r\n\t}\r\n\t\r\n\t.splash a.navbar-brand {\r\n\t    width: 100%;\r\n\t    height: 100%;\r\n\t}\r\n\t\r\n\t.splash .theme-header-title {\r\n\t    overflow: hidden;\r\n\t}\r\n\t.splash span.label.padding.theme-main-label.text-primary{\r\n\t\tcolor:#fff !important\r\n\t}\r\n\r\n\t/*-----Page loader-----*/\r\n\r\n\t.page-loader{\r\n\t    height: 100%;\r\n\t    width: 100%;\r\n\t    background: rgba(0,0,0,0.6);\r\n\t    display:block;\r\n\t    position: absolute;\r\n\t    z-index: 9999999999999999999;\r\n\t    top: 0;\r\n\t    transition:2s;\r\n\t}\r\n\t\r\n\t.page-loader:before {\r\n    content: '';\r\n    width: 100%;\r\n    background-image: url(../imgs/theme-mobilidade-2017/loading.gif);\r\n    position: absolute;\r\n    bottom: 0;\r\n    height: 19px;\r\n    background-repeat: no-repeat;\r\n    background-position: center;\r\n\t}\r\n\t/*-----Splash para Angular 4-----*/\r\n\r\n\t.splash-body .navbar-right.theme-header-right .navbar-brand  {\r\n\t\tdisplay: none;\r\n\t}\r\n\t.splash-body ol.breadcrumb.ng-isolate-scope {\r\n\t    display: none;\r\n\t}\r\n\r\n\t.splash-body .theme-header{    \r\n        background: #065CA7 !important;\r\n        margin-top: 0!important;\r\n\t}\r\n    .splash-body  .theme-app{\r\n        background: #065CA7 !important;\r\n    }\r\n\t.splash-body {\r\n\t    background-color: #065CA7;\r\n        position: relative !important;\r\n\t    height: 100%;\r\n\t}\r\n\r\n\t.splash-body span.ng-binding {\r\n\t    color: #fff;\r\n\t}\r\n\r\n\t.splash-body .navbar-right.theme-header-right {\r\n\t\twidth: 0;\r\n\t    height: 0;\r\n\t    border: 0 solid transparent;\r\n\t    border-left-width: 0px;\r\n\t    border-right-width: 100PX;\r\n\t    border-top: 100px solid #FF9300;\r\n\t    margin: 0;\r\n\t    vertical-align: middle;\r\n\t    position: absolute;\r\n\t    top: 0;\r\n\t    left: 0;\r\n\t}\r\n\t.splash-body .navbar-left.theme-header-left {\r\n\t    float: none;\r\n\t    margin-left: 33%;\r\n\t    width: 100% !important;\r\n\t    height: 31px;\r\n\t}\r\n\t.splash-body .barra-menu {\r\n    \tdisplay: none !important;\r\n\t}\r\n\t\r\n\t.splash-body .navbar-default.sidebar.theme-menu-container {\r\n\t\tdisplay:none;\r\n\t    background: none;\r\n\t}\r\n\t.splash-body nav.navbar.navbar-default.navbar-fixed-top.theme-header {\r\n\t    margin-top: 0;\r\n\t}\r\n\t\r\n\t.splash-body a.navbar-brand {\r\n\t    width: 100%;\r\n\t    height: 100%;\r\n\t}\r\n\t\r\n\t.splash-body .theme-header-title {\r\n\t    overflow: hidden;\r\n\t}\r\n\t.splash-body h5.padding.text-primary.bold.theme-main-h4, .splash-body span, .splash-body .theme-main-link a{\r\n\t\tcolor:#fff !important\r\n    }\r\n    \r\n    body.theme-app.splash-top {\r\n        background-color: #065CA7;\r\n    }\r\n\t  .navbar-usuario-intranet {\r\n\t \tdisplay:none !important;\r\n\t }\r\n\t .menu-item-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .overlay-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .pesquisa-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t  .config-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .calendario-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .navbar-left.theme-header-left{\r\n\t \theight:20px !important;\r\n\t }\r\n}",
        "contraste": 28,
        "icon": "fa-file-image-o",
        "id": 11,
        "name": "Intranet/Mobilidade",
        "preview_mode": [
            {
                "check": true,
                "icon": "fa fa-list-alt",
                "id": "preview",
                "name": "Preview"
            },
            {
                "check": false,
                "icon": "fa fa-desktop",
                "id": "desktop",
                "name": "Desktop"
            },
            {
                "check": false,
                "icon": "glyphicon glyphicon-globe",
                "id": "mobile",
                "name": "Browser Mobile"
            },
            {
                "check": false,
                "icon": "fa fa-mobile",
                "id": "nativo",
                "name": "App Mobile"
            },
            {
                "check": false,
                "icon": "fa fa-android",
                "id": "android",
                "name": "Android"
            },
            {
                "check": false,
                "icon": "fa fa-apple",
                "id": "ios",
                "name": "IOS"
            },
            {
                "check": false,
                "icon": "fa fa-windows",
                "id": "winphone",
                "name": "WinPhone"
            },
            {
                "check": false,
                "icon": "fa fa-print",
                "id": "printer",
                "name": "Impressão"
            }
        ],
        "tema": 11,
        "value": "theme-intranet.css"
    },
    "themename": "Caixa Material",
    "themes": [
        {
            "content": ".theme-app {\r\n\tbackground-color: #fff;\r\n}\r\n\r\n.theme-header {\r\n\tbackground-color: #296fa7;\r\n\tborder-bottom: 3px solid #F39A00!important;\r\n}\r\n.theme-app.tabbed .theme-header {\r\n\tborder-bottom: none!important;\r\n}\r\n\r\n.theme-header-tabs {\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-header-right > .navbar-brand {\r\n\tcolor: #fff;\r\n\tpadding-right: 5px;\r\n}\r\n.theme-header-left > .navbar-brand {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-header-middle.navbar-brand{\r\n\tcolor: #fff;\r\n}\r\n.theme-header-tabs {\r\n\t    background-color: #fff;\r\n}\r\n\r\n.theme-header-tabs > li.active > a {\r\n\tbackground-color: #296fa7;\r\n\tcolor: #fff;\r\n}\r\n.theme-footer {\r\n\tbackground-color: #296fa7;\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-footer-right {\r\n\tpadding-right: 10px;\r\n}\r\n.theme-footer-left {\r\n\tpadding-left: 10px;\r\n}\r\n\r\n.theme-header-left > a {\r\n\tbackground: url(../imgs/theme-padrao/caixab.png) no-repeat!important;\r\n\twidth: 112px;\r\n\theight: 24px;\r\n\tmargin-top: 20px!important;\r\n\tmargin-left: 10px!important;\r\n}\r\n.theme-header-left-caption {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.theme-header-title {\r\n\theight: 63px;\r\n}\r\n\r\n.form-group{\r\n\ttop:20px;\r\n}\r\n\r\n.theme-header-acessibilidade{\r\n\theight: 25px;\r\n\tbackground-color: #2ca5fe;\r\n}\r\n\r\n.theme-link-acessibilidade{\r\n\tposition: relative;\r\n\ttop: 3px;\r\n\tleft: 10px;\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-app.tabbed .theme-menu-container {\r\n    margin-top: 120px!important;\r\n}\r\n.theme-app .theme-menu-container {\r\n    margin-top: 60px!important;\r\n}\r\n\r\n.theme-app.collapse.in .theme-submenu-item > a {\r\n\tpadding-left: 20px;\r\n}\r\n\r\n@media (min-width: 768px) {\r\n\tapp-menu-principal {\r\n\t\tmargin-top: 30px;\r\n\t}\r\n\r\n\t.theme-main-container {\r\n\t\tpadding-top: 20px;\r\n\t}\r\n\r\n\t.theme-app.tabbed .theme-menu-container {\r\n\t    margin-top: 20px!important;\r\n\t}\r\n\t.theme-app .theme-menu-container {\r\n\t    margin-top: 0px!important;\r\n\t}\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 15px!important;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tposition: fixed;\r\n\t}\r\n\r\n\t.theme-header-right {\r\n\t\tpadding-right: 15px;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 10px!important;\r\n\t}\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 0 70px!important;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 0px!important;\r\n\t}\r\n\r\n\t.theme-menu-container {\r\n\t\tmargin-top: 3px!important;\r\n\t}\r\n}\r\n\r\n\r\n.sidebar-nav > .nav li > a.active {\r\n    margin: 0;\r\n    border-left: 4px solid #ffa100;\r\n    border-left-width: 4px;\r\n    border-left-style: solid;\r\n    border-left-color: #ffa100;\r\n    border-top: 1px solid #d9d9d9;\r\n    border-top-width: 1px;\r\n    border-top-style: solid;\r\n    border-top-color: rgb(217, 217, 217);\r\n    border-bottom: 1px solid #d9d9d9;\r\n    border-bottom-width: 1px;\r\n    border-bottom-style: solid;\r\n    border-bottom-color: rgb(217, 217, 217);\r\n    background-color: #f5f7f7;\r\n}\r\n\r\n.theme-header .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n.theme-footer .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n\r\nbutton {\r\n\tmargin-right: 5px;\r\n}\r\n\r\n.table-responsive{\r\n\ttop:20px;\r\n}\r\n\r\n/* texto */\r\n.text-primary {\r\n\tcolor: #296fa7;\r\n}\r\n.text-primary-important {\r\n\tcolor: #296fa7!important;\r\n}\r\n.text-warning {\r\n\tcolor: #ffa100;\r\n}\r\n.text-warning-important {\r\n\tcolor: #ffa100!important;\r\n}\r\n.text-success {\r\n\tcolor: #3c763d;\r\n}\r\n.text-success-important {\r\n\tcolor: #3c763d!important;\r\n}\r\n.text-black {\r\n\tcolor: #464646;\r\n\tfont-weight: 100;\r\n}\r\n.text-purple {\r\n\tcolor: #494d62;\r\n\tfont-weight: 100;\r\n}\r\n.text-laranja {\r\n\tcolor: #ffa100;\r\n\tfont-weight: 100;\r\n}\r\n.text-info {\r\n\tcolor: #c0b723;\r\n\tfont-weight: 100;\r\n}\r\n.text-danger {\r\n\tcolor: #920A04;\r\n\tfont-weight: 100;\r\n}\r\n\r\n/* Botoes */\r\n.btn-outline {\r\n\tcolor: inherit;\r\n\tbackground-color: transparent;\r\n\ttransition: all .5s;\r\n}\r\n\r\n.btn-primary.btn-outline {\r\n\tcolor: #428bca;\r\n}\r\n\r\n.btn-success.btn-outline {\r\n\tcolor: #5cb85c;\r\n}\r\n\r\n.btn-info.btn-outline {\r\n\tcolor: #5bc0de;\r\n}\r\n\r\n.btn-warning.btn-outline {\r\n\tcolor: #f0ad4e;\r\n}\r\n\r\n.btn-danger.btn-outline {\r\n\tcolor: #d9534f;\r\n}\r\n\r\n.btn-primary.btn-outline:hover,\r\n.btn-success.btn-outline:hover,\r\n.btn-info.btn-outline:hover,\r\n.btn-warning.btn-outline:hover,\r\n.btn-danger.btn-outline:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-menu-container {\r\n\tborder-right: 1px solid #ADADAD;\r\n\theight: 100%;\r\n\tbackground: #fff;\r\n}\r\n\r\n.theme-main-container.menu {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 0px 0 50px 0px;\r\n}\r\n\r\n.theme-app.tabbed .page-wrapper {\r\n\tmargin-top: 110px;\r\n}\r\n\r\n\r\n.theme-menu-item {\r\n\tborder-bottom: 0px!important;\r\n}\r\n\r\n.table-bordered{\r\n\tborder: none;\r\n}\r\n\r\n.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, \r\n.table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, \r\n.table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th{\r\n\tborder-top: 1px solid #ccc;\r\n}\r\n\r\n/* Material Design Switch */\r\n.material-switch-contraste-contraste {\r\n\tmargin-top: 5px;\r\n}\r\n.material-switch-contraste > input[type=\"checkbox\"] {\r\n\tdisplay: none;\r\n}\r\n\r\n.material-switch-contraste > label {\r\n\tcursor: pointer;\r\n\theight: 0px;\r\n\tposition: relative;\r\n\twidth: 40px;\r\n\ttop: -20px;\r\n}\r\n\r\n.material-switch-contraste > label::before {\r\n\tleft: 0px;\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\tborder-radius: 8px;\r\n\tcontent: '';\r\n\theight: 13px;\r\n\tposition:absolute;\r\n\topacity: 0.3;\r\n\ttransition: all 0.4s ease-in-out;\r\n\twidth: 34px;\r\n\ttop: 14px;\r\n}\r\n.material-switch-contraste > label::after {\r\n\tbackground: rgb(255, 255, 255);\r\n\tborder-radius: 16px;\r\n\tbox-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);\r\n\tcontent: '';\r\n\theight: 20px;\r\n\tleft: 0px;\r\n\tposition: absolute;\r\n\ttop: 11px;\r\n\ttransition: all 0.3s ease-in-out;\r\n\twidth: 20px;\r\n}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::before {\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\topacity: 0.1;\r\n}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::after {\r\n\tbackground: inherit;\r\n\tbox-shadow: 0px 0px 5px rgba(255, 255, 255, 0.5);\r\n\tleft: 20px;\r\n}\r\n\r\n.col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, \r\n.col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, \r\n.col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, \r\n.col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, \r\n.col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, \r\n.col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, \r\n.col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9 {\r\n\tpadding-bottom: 0px;\r\n}\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n\tborder: none;\r\n\tmargin-bottom: 35px;\r\n}\r\n\r\n.rodape-atm{\r\n\tdisplay: none;\r\n}\r\n\r\n.caixa-azul{\r\n\tdisplay: none;\r\n}\r\n\r\n.theme-header-ATM{\r\n\tdisplay: none;\r\n}\r\n\r\nnav.navbar.navbar-default.navbar-fixed-top.theme-header.ng-scope {\r\n    border-bottom: 1px solid #ddd !important;\r\n}\r\n\r\n\r\n@media screen and (max-width: 768px){\r\n\r\n    div#menu-container {\r\n        position:  relative;\r\n        z-index: 9999;\r\n\t}\r\n\r\n \t.navbar-fixed-bottom, .navbar-fixed-top{\r\n \t    z-index: 99999;\r\n \t}\r\n \tmodal-dialog.modal-md {\r\n    \tmargin: 200px 0 0 0;\r\n\t}\r\n}\r\n\r\n\r\n.theme-main-chart {\r\n    text-align: center;\r\n    margin-top: 52px;\r\n}\r\n\r\n@media screen and (min-width: 768px){\r\n\t.sidebar-nav.navbar-collapse.collapse.theme-menu.ng-scope {\r\n    \tmargin-top: inherit !important;\r\n\t}\r\n    .overlay{\r\n        display:none!important;\r\n    }\r\n}\r\nlabel.switch-box-slider {\r\n    margin: 30px -14px 23px 10px;\r\n}\r\n\r\nlabel.switch-box-label.ng-scope {\r\n    margin: 19px 0px 23px 28px !important;\r\n}\r\n\r\n.autoCompleteCredito{\r\n    display:none !important;\r\n    }\r\n    \r\ndiv.overlay{\r\n\tdisplay: none!important;\t\r\n}\r\n\r\n.theme-main-input-number-cpf input.ui-inputtext.ui-corner-all.ui-state-default.ui-widget{\r\n    width: 100%;\r\n    height: 28px;\r\n    padding: 0 !important;\r\n    margin: -11px;\r\n    border: none;\r\n}\r\n\r\n.theme-header-container {\r\n    padding-bottom: 34px;\r\n}\r\n#btnEnviar i {\r\n\tfont-size:1em;\r\n}",
            "contraste": 20,
            "icon": "fa-dropbox",
            "id": 0,
            "name": "Caixa Material",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "tema": 0,
            "value": "theme-padrao.css"
        },
        {
            "contraste": 23,
            "icon": "fa-taxi",
            "id": 7,
            "name": "Federal",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "restrict": true,
            "tema": 7,
            "value": "theme-federal.css"
        },
        {
            "contraste": 25,
            "icon": "fa-th-list",
            "id": 8,
            "name": "ATM",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "tema": 8,
            "value": "atm.css"
        },
        {
            "content": "/*\r\nTEMA para PRIMO\r\ninicializado automaticamente pelo PRIMO Front-end\r\nde acordo com o tema selecionado no projeto\r\n*/\r\n\r\n/*---------- fontes */\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN45__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: 500;\r\n\tfont-style: normal;\r\n}\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN85__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: bold;\r\n\tfont-style: normal;\r\n}\r\n\r\n/*---------- fontes */\r\n\r\n.theme-app {\r\n\tbackground-color: #fff;\r\n}\r\n\r\n.theme-header {\r\n\tbackground-color: #296fa7;\r\n\tborder-bottom: 3px solid #F39A00!important;\r\n}\r\n.theme-app.tabbed .theme-header {\r\n\tborder-bottom: none!important;\r\n}\r\n\r\n.theme-header-tabs {\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-header-right > .navbar-brand {\r\n\tcolor: #fff;\r\n\tpadding-right: 5px;\r\n}\r\n.theme-header-left > .navbar-brand {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-header-middle.navbar-brand{\r\n\tcolor: #fff;\r\n}\r\n.theme-header-tabs {\r\n\t    background-color: #fff;\r\n}\r\n\r\n.theme-header-tabs > li.active > a {\r\n\tbackground-color: #296fa7;\r\n\tcolor: #fff;\r\n}\r\n.theme-footer {\r\n\tbackground-color: #296fa7;\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-footer-right {\r\n\tpadding-right: 10px;\r\n}\r\n.theme-footer-middle {\r\n\r\n}\r\n.theme-footer-left {\r\n\tpadding-left: 10px;\r\n}\r\n\r\n.theme-header-left > a {\r\n\tbackground: url(../imgs/theme-padrao/caixab.png) no-repeat!important;\r\n\twidth: 112px;\r\n\theight: 24px;\r\n\tmargin-top: 20px!important;\r\n\tmargin-left: 10px!important;\r\n}\r\n\r\n.theme-header-left-caption {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.theme-header-title {\r\n\theight: 63px;\r\n\tpadding:;\r\n}\r\n\r\n.form-group{\r\n\t/* top:20px; */\r\n}\r\n\r\n.theme-header-acessibilidade{\r\n\theight: 25px;\r\n\tbackground-color: #2ca5fe;\r\n}\r\n\r\n.theme-link-acessibilidade{\r\n\tposition: relative;\r\n\ttop: 3px;\r\n\tleft: 10px;\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-app.tabbed .theme-menu-container {\r\n    margin-top: 120px!important;\r\n}\r\n.theme-app .theme-menu-container {\r\n    margin-top: 80px!important;\r\n}\r\n\r\n.theme-app.collapse.in .theme-submenu-item > a {\r\n\tpadding-left: 20px;\r\n}\r\n\r\n.theme-app .theme-main-container {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 70px 0 50px 0px;\r\n}\r\n\r\n.theme-app.menu .theme-main-container {\r\n\tmargin: 10px 0 50px 0px;\r\n}\r\n@media (min-width: 768px) {\r\n\t.theme-app.tabbed .theme-menu-container {\r\n\t    margin-top: 20px!important;\r\n\t}\r\n\t.theme-app .theme-menu-container {\r\n\t    margin-top: 0px!important;\r\n\t    padding-bottom: 120px;\r\n\t}\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 15px!important;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tposition: fixed;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-header-right {\r\n\t\tpadding-right: 15px;\r\n\t}\r\n\t\t\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 10px!important;\r\n\t}\r\n\r\n\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 0 70px!important;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 0px!important;\r\n\t}\r\n\r\n\t.theme-main-container {\r\n\t\tmargin: 67px 0 0 70px;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tmargin-top: 3px!important;\r\n\t}\r\n}\r\n\r\n\r\n.sidebar-nav > .nav li > a.active {\r\n    margin: 0;\r\n    border-left: 4px solid #ffa100;\r\n    border-left-width: 4px;\r\n    border-left-style: solid;\r\n    border-left-color: #ffa100;\r\n    border-top: 1px solid #d9d9d9;\r\n    border-top-width: 1px;\r\n    border-top-style: solid;\r\n    border-top-color: rgb(217, 217, 217);\r\n    border-bottom: 1px solid #d9d9d9;\r\n    border-bottom-width: 1px;\r\n    border-bottom-style: solid;\r\n    border-bottom-color: rgb(217, 217, 217);\r\n    background-color: #f5f7f7;\r\n}\r\n\r\n.theme-header .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n.theme-footer .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n\r\nbutton {\r\n\tmargin-right: 5px;\r\n}\r\n\r\n.table-responsive{\r\n\ttop:20px;\r\n}\r\n\r\n/* texto */\r\n.text-primary {\r\n\tcolor: #296fa7;\r\n}\r\n.text-primary-important {\r\n\tcolor: #296fa7!important;\r\n}\r\n.text-warning {\r\n\tcolor: #ffa100;\r\n}\r\n.text-warning-important {\r\n\tcolor: #ffa100!important;\r\n}\r\n.text-success {\r\n\tcolor: #3c763d;\r\n}\r\n.text-success-important {\r\n\tcolor: #3c763d!important;\r\n}\r\n.text-black {\r\n\tcolor: #464646;\r\n\tfont-weight: 100;\r\n}\r\n.text-purple {\r\n\tcolor: #494d62;\r\n\tfont-weight: 100;\r\n}\r\n.text-laranja {\r\n\tcolor: #ffa100;\r\n\tfont-weight: 100;\r\n}\r\n.text-info {\r\n\tcolor: #c0b723;\r\n\tfont-weight: 100;\r\n}\r\n.text-danger {\r\n\tcolor: #920A04;\r\n\tfont-weight: 100;\r\n}\r\n\r\n/* Botoes */\r\n.btn-outline {\r\n\tcolor: inherit;\r\n\tbackground-color: transparent;\r\n\ttransition: all .5s;\r\n}\r\n\r\n.btn-primary.btn-outline {\r\n\tcolor: #428bca;\r\n}\r\n\r\n.btn-success.btn-outline {\r\n\tcolor: #5cb85c;\r\n}\r\n\r\n.btn-info.btn-outline {\r\n\tcolor: #5bc0de;\r\n}\r\n\r\n.btn-warning.btn-outline {\r\n\tcolor: #f0ad4e;\r\n}\r\n\r\n.btn-danger.btn-outline {\r\n\tcolor: #d9534f;\r\n}\r\n\r\n.btn-primary.btn-outline:hover,\r\n.btn-success.btn-outline:hover,\r\n.btn-info.btn-outline:hover,\r\n.btn-warning.btn-outline:hover,\r\n.btn-danger.btn-outline:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-menu-container {\r\n\tborder-right: 1px solid #ADADAD;\r\n\theight: 100%;\r\n\tbackground: #fff;\r\n}\r\n\r\n.theme-main-container.menu {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 0px 0 50px 0px;\r\n}\r\n\r\n.theme-app.tabbed .page-wrapper {\r\n\tmargin-top: 110px;\r\n}\r\n\r\n\r\n.theme-menu-item {\r\n\tborder-bottom: 0px!important;\r\n}\r\n\r\n.table-bordered{\r\n\tborder: none;\r\n}\r\n\r\n.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, \r\n.table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, \r\n.table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th{\r\n\tborder-top: 1px solid #ccc;\r\n}\r\n\r\n/* Material Design Switch */\r\n.material-switch-contraste-contraste {\r\n\tmargin-top: 5px;\r\n}\r\n.material-switch-contraste > input[type=checkbox] {\r\n\tdisplay: none;\r\n}\r\n\r\n.material-switch-contraste > label {\r\n\tcursor: pointer;\r\n\theight: 0px;\r\n\tposition: relative;\r\n\twidth: 40px;\r\n\ttop: -20px;\r\n}\r\n\r\n.material-switch-contraste > label::before {\r\n\tleft: 0px;\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\tborder-radius: 8px;\r\n\tcontent: '';\r\n\theight: 13px;\r\n\tposition:absolute;\r\n\topacity: 0.3;\r\n\ttransition: all 0.4s ease-in-out;\r\n\twidth: 34px;\r\n\ttop: 14px;\r\n}\r\n.material-switch-contraste > label::after {\r\n\tbackground: rgb(255, 255, 255);\r\n\tborder-radius: 16px;\r\n\tbox-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);\r\n\tcontent: '';\r\n\theight: 20px;\r\n\tleft: 0px;\r\n\tposition: absolute;\r\n\ttop: 11px;\r\n\ttransition: all 0.3s ease-in-out;\r\n\twidth: 20px;\r\n}\r\n\r\n.material-switch-contraste > input[type=checkbox]:checked + label::before {\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\topacity: 0.1;\r\n}\r\n\r\n.material-switch-contraste > input[type=checkbox]:checked + label::after {\r\n\tbackground: inherit;\r\n\tbox-shadow: 0px 0px 5px rgba(255, 255, 255, 0.5);\r\n\tleft: 20px;\r\n}\r\n\r\n.breadcrumb{\r\n\tmargin-top: 10px;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n}\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none!important;\r\n}\r\n\r\n\r\n\r\n\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n/*---------------------------------------------- TEMPLATE INTRANET 2018 -------------------------------------------------*/\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n\r\n\r\n/*-----cabecalho-----*/\r\n\r\n.theme-header {\r\n\tborder-bottom: none !important;\r\n\tbox-sizing: border-box !important;\r\n\tbackground-image: url(../imgs/theme-intranet/bg_header.jpg);\r\n\tbackground-repeat: no-repeat;\r\n\tbackground-position: center 20px;\r\n\twidth: 100%;\r\n}\r\n\r\n.theme-appGerado .theme-header{\r\n\tbackground-position: initial;\r\n}\r\n\r\n.theme-header-right-title {\r\n\tmargin-top: 5px;\r\n\tmargin-right: 25px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.navbar-left.theme-header-left {\r\n\theight: 63px !important;\r\n\tbackground-image: url(../imgs/theme-intranet/logo_caixa.png) !important;\r\n\tbackground-repeat: no-repeat !important;\r\n\tbackground-position: center left !important;\r\n\tmargin: 0 !important;\r\n\tpadding: 0 !important;\r\n\tmargin-left: 15% !important;\r\n}\r\n\r\n.theme-header-left a {background: none !important;}\r\n\r\n.navbar-brand  {padding-right: inherit !important;}\r\n\r\n.navbar-brand[title^=Avaliação]  {padding-right: inherit !important;}\r\n\r\n.navbar-toggle {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n\tborder: none;\r\n}\r\n\t\r\n.navbar-toggle i {\r\n\twidth: 20px;\r\n\theight: 20px;\r\n\tmargin-right: 36px;\r\n}\r\n\r\n.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:active, \r\n.navbar-default .navbar-toggle:focus, .nav li a:hover, .nav li a:active, .nav li a:focus {background: none;}\r\n\r\n/*-----rodape-----*/\r\n\r\n.theme-footer {\r\n\tborder: none !important;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n/*-----menu horizontal-----*/\r\n\r\nul[ng-hide=currentview.telainicial] {\r\n\tborder-top: none !important;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px;\r\n\tborder-bottom: 1px solid #B3C7CB;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li {\r\n\tpadding-top: 10px;\r\n\tpadding-bottom: 10px;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li a {\r\n\tcolor: #B3C7CB;\r\n\tborder-right: 1px solid #B3C7CB !important;\r\n\tborder-radius: 0;\r\n\tdisplay: inline-block;\r\n\tpadding-top: 0;\r\n\theight: 16px;\r\n\tline-height: 1;\r\n}\r\n\r\n.nav .open>a, .nav .open>a:focus, .nav .open>a:hover {\r\n\tbackground: none;\r\n\tborder: none;\r\n}\r\n\r\nul[ng-hide=currentview.telainicial] li a:hover {\r\n\tborder: none;\r\n\toutline: none;\r\n\tborder-right: 1px solid #B3C7CB;\r\n\tcolor: #3A4859;\r\n}\r\n\r\nul.theme-header-tabs > li:last-child a {border: none !important;}\r\n\r\nul[ng-hide=currentview.telainicial] li a i {display: none;}\r\n\r\nul[ng-hide=currentview.telainicial] li ul li a {border: none !important;}\r\n\r\n/*-----menu vertical-----*/\r\n\r\n.sidebar-nav .nav li a.active {\r\n\tborder: none;\r\n\tcolor: white;\r\n\tfont-size: 13px;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n.sidebar, .sidebar-nav {\r\n\tborder: none;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-weight: bold;\r\n\tbackground-color: #F9F9F9;\r\n\twidth: 217px;\r\n}\r\n\r\n.sidebar-nav .nav li {padding:0;}\r\n\r\n.sidebar-nav .nav li a {\r\n\tcolor: #9aacaf;\r\n\tfont-size: 14px;\r\n\tdisplay: block;\r\n\tpadding-left: 16px;\r\n\tline-height: 23.5px;\r\n\tmin-height: 47px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li a i {display: none;}\r\n\r\n.sidebar-nav .nav li.open > a {background-color: #F4F4F4; display: block;}\r\n\r\n.sidebar-nav .nav li > a[aria-expanded=true] {\r\n\tcolor: white;\r\n\tfont-size: 13px;\r\n\tbackground: #005ca9;\r\n\tbackground: -moz-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: -webkit-linear-gradient(left, #005ca9 1%, #54bbab 100%);\r\n\tbackground: linear-gradient(to right, #005ca9 1%, #54bbab 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005ca9', endColorstr='#54bbab',GradientType=1 );\r\n}\r\n\r\n.sidebar-nav .nav li ul li a {\r\n\tbackground-image: none !important;\r\n\tbackground-color: #F4F4F4 !important;\r\n\tcolor: #B3C7CB !important;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tpadding-left: 28px;\r\n\tline-height: 16px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li ul li a.active {\r\n\tcolor: #54BBAB !important;\r\n\tfont-size: 12px;\r\n}\r\n\r\n/*-----carrossel-----*/\r\n\r\n.carousel {\r\n\tmargin: 16px 16px 0 16px;\r\n\t/* display: inline-block;\r\n\twidth: 679px;\r\n\theight: 215px; */\r\n}\r\n\r\n.carousel-control {display: none;}\r\n\r\n.carousel-indicators li, .carousel-indicators .active {\r\n\tmargin: 16px 9px;\r\n\tborder-color: #BCBEC0;\r\n\tbackground-color: #BCBEC0;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.carousel-indicators .active {\r\n\tborder-color: #54BBAB;\r\n\tbackground-color: #54BBAB;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nol.carousel-indicators {\r\n\tposition: static;\r\n\tlist-style: none;\r\n\tmargin: 0 auto;\r\n}\r\n\r\n.carousel-caption {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tbackground: none;\r\n\t/\r\n\tmargin-bottom: 28px;\r\n\t/\r\n\tmargin-left: 31px;\r\n\tpadding: 0;\r\n\ttext-shadow: none;\r\n\tposition: relative;\r\n\tleft: 210px;\r\n\ttop: -52px;\r\n}\r\n\r\n.carousel-caption h4 {\r\n\tfont-size: 12px !important;\r\n\tfont-weight: bold;\r\n\tmargin-bottom: 0;\r\n}\r\n\r\n.carousel-caption p {\r\n\tmargin-left: 16px;\r\n\tmargin-bottom: 0;\r\n}\r\n\r\n.carousel-caption h4:before {\r\n\tcontent:'0025E3';\r\n\tfont-size: 12px;\r\n\tmargin-right: 6px;\r\n\tcolor: #EB7F2A;\r\n}\r\n\r\n/*-----texto-----*/\r\n\r\n.text-primary, .text-primary-important, .text-warning,\r\n.text-warning-important, .text-success, .text-success-important,\r\n.text-default, .text-black, .text-purple, .text-laranja, .text-info,\r\n.text-danger {\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-weight: normal;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\t/text-align: left;\r\n}\r\ni.fa.text-primary {\r\n\tfont-family: FontAwesome;\r\n}\r\n\r\n.text-primary {color: #3A4859;}\r\n.text-primary-important {color: #3A4859 !important;}\r\n.text-warning {color: #F39200;}\r\n.text-warning-important {color: #F39200 !important;}\r\n.text-success {color: #54BBAB;}\r\n.text-success-important {color: #54BBAB !important;}\r\n.text-default {color: #3A4859; font-weight: 100;}\r\n.text-black {color: #3A4859;font-weight: 100;}\r\n.text-purple {color: #494d62; font-weight: 100;}\r\n.text-laranja {color: #F39200; font-weight: 100;}\r\n.text-info {color: #F9B000; font-weight: 100;}\r\n.text-danger {color: #F9765E; font-weight: 100;}\r\n\r\ndiv.theme-main-list label,\r\nh5.theme-main-push-status {\r\n\tcolor: #3A4859;\r\n\tfont-weight: normal;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\tpadding: 0;\r\n\tmargin: 0 0 5px 0;\r\n}\r\n\r\nh5.theme-main-h4, h6.theme-main-h6 {\r\n\tfont-weight: bold;\r\n\tline-height: 1;\r\n\tcolor: #9aacaf;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 20px !important;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tmargin-top: 0;\r\n}\r\n\r\nh5.theme-main-h4 {\r\n\tborder-bottom: 1px solid #9aacaf;\r\n\tpadding-bottom: 6px;\r\n\tmargin-bottom: 30px;\r\n}\r\n\r\nh6.theme-main-h6 {\r\n\tfont-size: 14px !important;\r\n\tmargin-bottom: 12px;\r\n}\r\n\r\n\r\n/*-----tabelas-----*/\r\n\r\nthead tr th {\r\n\tbackground-color: white;\r\n\tcolor: #3A4859;\r\n\tfont-size: 13px !important;\r\n\tborder-top: none !important;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tvertical-align: bottom;\r\n    border-bottom: 2px solid #ddd !important;\r\n\theight: 35px;\r\n\tfont-size: 14px;\r\n\tpadding: 8px !important;\r\n\tline-height: 13px !important;\r\n}\r\n\r\ntbody tr td {\r\n\tcolor: #3A4859;\r\n\tline-height: 1.428571429;\r\n\tvertical-align: top;\r\n\tborder-top: 1px solid #ddd;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tborder-bottom: none !important;\r\n\theight: 35px !important;\r\n\tfont-size: 13px;\r\n\tpadding: 8px !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ntbody tr:nth-child(odd),\r\ntbody tr:nth-child(odd):hover {background-color: #f9f9f9; !important;}\r\n\r\ntbody tr:nth-child(even),\r\ntbody tr:nth-child(even):hover {background-color: white;}\r\n\r\ntd button {\r\n\tbackground: none;\r\n\tmargin:0 !important;\r\n\tpadding:0!important;\r\n}\r\n\r\n/*-----inputs-----*/\r\n\r\ndiv.form-group {\r\n\tpadding: 0;\r\n\tmargin-bottom: 20px !important;\r\n\t/*display: inline-block;*/\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.form-control {\r\n\tbox-shadow:none;\r\n}\r\n\r\ndiv.form-group label {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tline-height: 16px;\r\n\tcolor: #54BBAB;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 0;\r\n\tline-height: 1;\r\n}\r\n\r\ndiv.input-group {\r\n    width: inherit;\r\n    height: 34px;\r\n    min-width: 100%;\r\n    padding-right: 30px;\r\n}\r\n\r\ndiv.input-group input:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.input-group input {\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB !important;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding: 13px 0 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio label  {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tcolor: #54BBAB;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 2px;\r\n}\r\n\r\ndiv.input-group input::-webkit-input-placeholder {color: #3A4859;}\r\ndiv.input-group input:-moz-placeholder {color: #3A4859;}\r\ndiv.input-group input::-moz-placeholder {color: #3A4859;}\r\ndiv.input-group input:-ms-input-placeholder {color: #3A4859;}\r\ndiv.input-group input::-ms-input-placeholder {color: #3A4859;}\r\n\r\nspan.input-group-addon {display: none;}\r\n\r\n.form-control[disabled],\r\n.form-control[readonly],\r\nfieldset[disabled] .form-control,\r\n.form-control[disabled]:active,\r\n.form-control[readonly]:active,\r\nfieldset[disabled] .form-control:active,\r\n.form-control[disabled]:focus,\r\n.form-control[readonly]:focus,\r\nfieldset[disabled] .form-control:focus\r\n {\r\n\tbackground-color: rgba(0,0,0,0);\r\n\tcolor: #B3C7CB;\r\n\tborder-bottom-color: #B3C7CB;\r\n}\r\n\r\n.form-control[disabled] > label.label-mobilidade,\r\n.form-control[readonly] > label.label-mobilidade,\r\nfieldset[disabled] .form-control > label.label-mobilidade {\r\n\tcolor: #B3C7CB !important;\r\n}\r\n\r\n/*-----combo box-----*/\r\n\r\n.theme-main-input-check label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tfont-weight: normal !important;\r\n\tcolor: #54BBAB;\r\n\tmargin-bottom: 2px !important;\r\n}\r\n\r\n.input-group select {\r\n\t-webkit-appearance: none;\r\n\t-moz-appearance: none;\r\n\tappearance: none;\r\n\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat top right;\r\n\tborder-radius: 0;\r\n\tborder-top: none;\r\n\tborder-right: none;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-left: none;\r\n\tpadding: 0 0 10px 0;\r\n\theight: 26px;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 6px !important;\r\n\tbox-sizing: border-box;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tline-height: 12px;\r\n}\r\n\r\n.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\r\n/*-----caixa de texto-----*/\r\n\r\ndiv.input-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.input-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n/*-----botoes-----*/\r\n\r\n.theme-main-button {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n}\r\n\r\n.btn-primary, .btn-warning {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:#F9B000;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\n.btn-primary:hover,\r\n.btn-warning:hover,\r\n.btn-primary:active,\r\n.btn-warning:active,\r\n.btn-primary:focus,\r\n.btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white !important;\r\n\tcolor:#F9B000 !important;\r\n\tborder: 1px solid #F9B000 !important;\r\n\tbox-shadow: none !important;\r\n}\t\r\n\r\n.theme-main-button[disabled=disabled],\r\n.theme-main-button[disabled=disabled]:hover,\r\n.theme-main-button[disabled=disabled]:focus {\r\n\tbackground-color:#d0e0e3 !important;\r\n\tborder-color:#d0e0e3 !important;\r\n\tcolor:white; \r\n\topacity:1 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton#optOpces {background-color: white;}\r\nbutton#optOpces.active {color:#48586C;}\r\n\r\nbutton.btn-default,\r\nbutton.theme-main-button-subscribe,\r\nbutton.theme-main-button-unsubscribe {\r\n\tbox-sizing: border-box;\r\n\tcolor:#54BBAB;\r\n\tbackground-color: white;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\theight: 45px;\r\n\tborder: 1px solid #54BBAB;\r\n}\r\n\r\nbutton.btn-default:hover,\r\nbutton.theme-main-button-subscribe:hover,\r\nbutton.theme-main-button-unsubscribe:hover,\r\nbutton.btn-default:active,\r\nbutton.theme-main-button-subscribe:active,\r\nbutton.theme-main-button-unsubscribe:active,\r\nbutton.btn-default:focus,\r\nbutton.theme-main-button-subscribe:focus,\r\nbutton.theme-main-button-unsubscribe:focus {\r\n\tcolor:white !important;\r\n\tbackground-color: #54BBAB !important;\r\n\tborder: 1px solid #54BBAB !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-left: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton.theme-main-button-subscribe:first-child {\r\n\tmargin-left:0;\r\n}\r\n\r\nbutton#btnEnviar {\r\n\tfont-size:0.5em;\r\n}\r\n\r\n#btnEnviar:hover, #btnEnviar:active, #btnEnviar:focus {\r\n\tdisplay: block !important;\r\n\tmargin-right: auto !important;\r\n\tmargin-left: auto !important;\r\n\tmargin-bottom: 0 !important;\r\n\tbox-sizing: border-box;\r\n\theight: 38px;\r\n}\r\n\r\n.modal-dialog button.btn {\r\n\theight: initial;\r\n\tfont-family: inherit;\r\n\tfont-weight: inherit;\r\n}\r\n\r\n\r\n.modal-dialog button.btn-primary,\r\n.modal-dialog button.btn-primary:hover {\r\n\tmargin: 0 !important;\r\n\theight: 34px;\r\n}\r\n\r\n\r\n/*-----radio-----*/\r\n\r\ndiv.theme-main-input-radio {\r\n\tpadding: 0;\r\n}\r\n\r\ndiv.theme-main-input-radio button {\r\n\tcolor: #6c6c6c;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tborder: 1px solid #D0E0E3;\r\n\topacity: 1 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n\tborder-radius: 3px;\r\n\tpadding: 0 9px;\r\n\r\n}\r\n\r\ndiv.theme-main-input-radio button:hover {\r\n\tbackground-color: #6c6c6c !important;\r\n\tborder: 1px solid #D0E0E3 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active,\r\ndiv.theme-main-input-radio button.active:active,\r\ndiv.theme-main-input-radio button.active:focus {\r\n\tcolor: white !important;\r\n\tbackground-color: #058CE1 !important;\r\n\tborder: 1px solid #058CE1 !important;\r\n\tbox-shadow: none;\r\n\tfont-weight: normal;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active:hover {\r\n\tbackground-color: white !important;\r\n\tborder: 1px solid #058CE1 !important;\r\n\tcolor: #058CE1 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\n/*-----checkbox-----*/\r\n\t\r\n.input-group {margin-bottom: 0px;}\r\n\r\n.input-group > label {\r\n\tdisplay: block;\r\n\t/color: #48586C;\r\n\t/height: 20px;\r\n\t/margin: 0 14px 5px 0;\r\n}\r\n\r\n.theme-main-input-check div.input-group label {\r\n\tcolor:#48586C;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*\r\n.input-group > label input[type=checkbox] {\r\n\tposition: relative;\r\n\tbottom: -40%;\r\n\tmargin-right: 14px;\r\n}\r\n\r\n.input-group > label input[type=checkbox]:before {\r\n\tcontent: '';\r\n\tposition: relative;\r\n\tbottom: -15%;\r\n\tbackground-color: white !important;\r\n\tdisplay: inline-block;\r\n\twidth: 18px;\r\n\theight: 18px;\r\n\tborder: 1px solid #D0E0E3;\r\n}\r\n\r\n.input-group > label input[type=checkbox]:checked:before {\r\n\tcontent: '';\r\n\tbackground-color: #54BBAB !important;\r\n\tdisplay: inline-block;\r\n\twidth: 17px;\r\n\theight: 17px;\r\n\tborder: 4px solid white;\r\n\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\tbox-sizing: border-box;\r\n}\r\n*/\r\n\r\n/*-----breadcrumb-----*/\r\n\r\nol.breadcrumb {\r\n\tbackground-color: white;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tcolor: #3A4859;\r\n}\r\n\r\nol.breadcrumb li a {color: #54BBAB; text-decoration: underline;}\r\n\r\nol.breadcrumb:before {\r\n\tcontent: 'Você  está em';\r\n\tfont-weight: bold;\r\n\tpadding-right: 8px;\r\n}\r\n\r\nol.breadcrumb li:before {content:''; padding-left:0 !important;}\r\n\r\nol.breadcrumb li:after {content:'\\25BA'; padding-left:1ch;}\r\n\r\nol.breadcrumb li:last-child:after {content:'';}\r\n\r\nol.breadcrumb li span {color: #3A4859;}\r\n\r\n/*-----navbar-----*/\r\n\r\n.navbar-brand-middle {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 18px;\r\n\tpadding-top: 22px;\r\n}\r\n\r\n/*-----links-----*/\r\n\r\n.theme-main-link a {\r\n\tcolor: #54BBAB;\r\n\tfont-size: 11px;\r\n\ttext-decoration: none !important;\r\n}\r\n\r\n.theme-main-link a:hover {\r\n\ttext-decoration: underline !important;\r\n}\r\n\r\n/*-----listagem-----*/\r\n\r\ndiv.theme-main-list {margin-top: 2em;}\r\n\r\ndiv.theme-main-list,\r\ndiv.theme-main-list div.text-left,\r\ndiv.theme-main-list div.text-right {padding: 0;}\r\n\r\n\r\n*:focus {outline: none !important;}\r\n\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n\tborder: none;\r\n\tmargin-bottom: 35px;\r\n}\r\n\r\n.rodape-atm{\r\n\tdisplay: none;\r\n}\r\n\r\n.caixa-azul{\r\n\tdisplay: none;\r\n}\r\n\r\n.theme-header-ATM{\r\n\tdisplay: none;\r\n}\r\n\r\nspan.input-group-addon {display: none;}\r\n\r\ndiv.input-group input:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n.form-group {margin-bottom: 0;}\r\n\r\n.form-control {\r\n\tborder: 0;\r\n\tpadding: 4px 0;\r\n\tborder-bottom: 1px solid #ccc;\r\n\tbackground-color: transparent;\r\n\tbox-shadow: none;\r\n}\r\n\r\n.effect{\r\n\tposition:absolute;    \r\n\ttransition:0.3s;\r\n}\r\n\r\n.form-group.col-xs-12.theme-main-input-check {\r\n\tpadding-bottom: 10px;\r\n}\r\n\r\ndiv#telefone-group .input-group .col-xs-4 {\r\n\tpadding-left: 0;\r\n}\r\n\r\n\r\n/*-----combo box-----*/\r\n\r\n.theme-main-input-select label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tfont-weight: normal !important;\r\n\tcolor: #54BBAB !important;\r\n\tmargin-bottom: 2px !important;\r\n}\r\n\r\n.input-group select {\r\n\t-webkit-appearance: none;\r\n\t-moz-appearance: none;\r\n\tappearance: none;\r\n\tbackground: url(../imgs/theme-intranet/seta-combox-desktop.png) no-repeat top right;\r\n\tborder-radius: 0;\r\n\tborder-top: none;\r\n\tborder-right: none;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-left: none;\r\n\tpadding: 0 0 10px 0;\r\n\theight: 26px;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 6px !important;\r\n\tbox-sizing: border-box;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tline-height: 12px;\r\n}\r\n\r\n.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\r\n/*-----caixa de texto-----*/\r\n\r\ndiv.input-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.input-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\n\r\n.side-menubar{\r\n    display:none;\r\n}\r\n\r\n\r\n/*-----transicao labels-----*/\r\n\r\ninput.form-control ~ label {\r\n\tmargin-top:0;\r\n\tposition:absolute;\r\n\ttop:-5px;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n\tfont-size:12px !important;\r\n}\r\n\r\ninput.form-control {\r\n    margin-top:0px !important;\r\n    transition:0.3s;\r\n}\r\n\r\ninput.form-control:placeholder-shown ~ label{\r\n    transition:0.3s;\r\n    top:5px;\r\n\tfont-size:14px!important;\r\n}\r\n\r\ninput.form-control:placeholder{\r\n    opacity:0;\r\n    color:transparent;\r\n}\r\n\r\nlabel{\r\n\tfont-size:14px !important;\r\n\ttransition:0.3s;\r\n}\r\n\r\n.form-control::-webkit-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n.form-control::-moz-placeholder {opacity:0;\r\n    color:transparent;}\r\n.form-control:-ms-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n\r\n\r\n.form-group label:nth-child(1) {\r\n   display: none;\r\n}\r\n.form-group .theme-main-input-select label:nth-child(1),\r\n.form-group.pick-list label:nth-child(1),\r\n.form-group.theme-main-input-select label:nth-child(1),\r\n.form-group.theme-main-text-area label:nth-child(1),\r\n.form-group.theme-main-input-check label:nth-child(1) {\r\n\tdisplay: block;\r\n}\r\n\r\n.theme-main-input-radio label:nth-child(1),\r\n#uplEscolhaoarquivo label {\r\n\tdisplay:block;\r\n}\r\n\r\n/*-----abas-----*/\r\nul.tabs-nav {\r\n\tborder-bottom: 2px solid #54bbab;\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tpadding-bottom: 12px;\r\n}\r\n\r\nul.tabs-nav li {\r\n\tmargin: 0 0px -1px;\r\n}\r\n\r\n.tabs-nav li:first-child {\r\n    margin-left: 0 !important;\r\n}\r\n\r\nul.tabs-nav li a {\r\n\tbackground-color: #b3c7cb;\r\n    border-radius: 0;\r\n    border: none !important;\r\n    color: white !important;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    padding: 10px 30px;\r\n}\r\n\r\nul.tabs-nav li a:hover {\r\n\tbackground-color: #54bbab;\r\n}\r\n\r\nul.tabs-nav li a.active {\r\n\tbackground-color: #54bbab;\r\n    border-radius: 0;\r\n    border: none !important;\r\n    color: white !important;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    padding: 10px 30px;\r\n}\r\n\r\nul.tabs-nav li a.active:hover {\r\n\tcursor: default;\r\n}\r\n\r\ndiv.theme-main-tab .tab-content {\r\n\tmargin-top: 15px;\r\n}\r\n\r\n/*-----graficos-----*/\r\n\r\n.theme-main-chart label {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tcolor: #8492af;\r\n\tfont-size: 18px !important;\r\n\tdisplay: block;\r\n\ttext-align: left;\r\n}\r\n\r\n.theme-main-chart text {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n[fill=#f0ad4e] {fill: #F39200;}\r\n[fill=#3c763d] {fill: #0E7639;}\r\n[fill=#277db6] {fill: #005CA9;}\r\n[fill=#5cb85c] {fill: #29C0B3;}\r\n[fill=#f1ca3a] {fill: #F9B000;}\r\n[text-anchor=start] {\r\n\tfont-weight: normal !important;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*-----paineis-----*/\r\n\r\n.theme-main-detail-panel {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary {border-color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-heading {\r\n\tbackground-color: #005CA9;\r\n\tborder-color: #005CA9;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-footer {color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-warning {border-color: #F9B000;}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-heading {\r\n\tbackground-color: #F9B000;\r\n\tborder-color: #F9B000;\r\n}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-footer {\r\n\tbackground-color: #EFF5F6;\r\n\tcolor: #F39200;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default {border-color: #B3C7CB;}\r\n\r\n.theme-main-detail-panel .panel-default .panel-heading {\r\n\tbackground-color: #EFF5F6;\r\n\tborder-color: #B3C7CB;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default .panel-footer {\r\n\tbackground-color: white;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger {border-color: #F51C1F;}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-heading {\r\n\tbackground-color: #F51C1F;\r\n\tborder-color: #F51C1F;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-footer {\r\n\tcolor: #F51C1F;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\n\r\n@media (min-width: 768px) {\r\n\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 26px;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    margin-right: 106px;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: white;\r\n    text-decoration: none;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid #76bad1;\r\n    padding: 3px 18px;\r\n    font-weight: bold;\r\n    box-sizing: border-box;\r\n    width: 80px;\r\n    height: 24px;\r\n}\r\n\r\n.item-sair-intranet a:hover {\r\n    text-decoration: underline;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.menu-item-intranet ul li a span {\r\n\tcolor: transparent;\r\n}\r\n\r\n.menu-item-intranet ul li.item-calendario-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/calendario_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-pesquisa-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/pesquisa_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-config-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/config_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: normal;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n    font-size: 13px !important;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n    position: absolute;\r\n    right: 18px;\r\n    border: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    width: 265px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n\tfont-size: 13px;\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #656565;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 15px;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 16px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 16px;\r\n    padding: 0 15px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 19px;\r\n}\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 24px !important;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    /margin-right: 106px;\r\n    margin-right: 2%;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: aliceblue;\r\n    text-decoration: none;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid #76bad1;\r\n    padding: 3px 18px;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: 400;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n\tposition: absolute;\r\n\tright: 15%;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\twidth: 265px;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #3A4859;\r\n    font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n    font-size: 13px !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 14px !important;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 18px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 14px;\r\n    padding: 0 14px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 16px;\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n\r\n\r\n/*-----componente calendario-----*/\r\n\r\n .hasDatepicker .ui-datepicker-inline {\r\n  background: transparent;\r\n  border: none;\r\n  /padding: 1px;\r\n  width: auto;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header {\r\n  background-color: white;\r\n  border: none;\r\n  padding-top: 8px;\r\n  padding-bottom: 8px;\r\n  border-bottom: 1px solid #d2d2d2;\r\n  margin-bottom: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background-position: 50%;\r\n  background-repeat: no-repeat;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next .ui-icon,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev .ui-icon {\r\n  display: none;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background: url(../imgs/theme-intranet/bt_anteriorMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-left: 16px;\r\n  padding: 0;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next {\r\n  background: url(../imgs/theme-intranet/bt_proximoMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-right: 16px;\r\n  padding: 0;\r\n  float: right;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-title {\r\n  display: inline-block;\r\n  width: calc(100% - 56px);\r\n  margin: 0 auto !important;\r\n  margin-top: 0 !important;\r\n  color: #3A4859;\r\n  font-weight: 400;\r\n  text-transform: uppercase;\r\n  text-align: center;\r\n  vertical-align: top;\r\n  font-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif !important;\r\n  font-size: 14px;\r\n  line-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar thead tr th {\r\n  background-color: #EFF5F6;\r\n  color: #3A4859;\r\n  font-size: 13px !important;\r\n  font-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n  border-bottom: none !important;\r\n  vertical-align: middle;\r\n  text-align: center;\r\n  max-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td {\r\n  background-color: white;\r\n  border: none !important;\r\n  text-align: center;\r\n  vertical-align: middle;\r\n  padding: 0 !important;\r\n  height: 2em !important;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td a {\r\n  background-color: white;\r\n  border: none;\r\n  color: #3A4859;\r\n  font-size: 13px;\r\n  font-weight: 400;\r\n  text-align: center;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td.ui-datepicker-current-day a {\r\n  background-color: #54BBAB;\r\n  color: #fff;\r\n  /padding: .2em;\r\n  padding: 4px .35em;\r\n  font-weight: 700;\r\n}\r\n\r\n.calendario-intranet.sub-item {\r\n\tdisplay:none;\r\n\tfont-family: Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\tpadding: 0;\r\n\tpadding-bottom: 12px;\r\n\twidth: 236px;\r\n\tposition: absolute;\r\n\tright: 13%;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\ntd.ui-datepicker-week-end {\r\n    border: none !important;\r\n}\r\n\r\n.evento-intranet h5 {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tborder-top: 1px solid #d2d2d2;\r\n\tborder-bottom: 1px solid #d2d2d2;\r\n\ttext-align: center;\r\n\tpadding: 9px 0;\r\n\ttext-transform: uppercase;\r\n\tvertical-align: middle !important;\r\n}\r\n\r\n.conteudo-intranet {\r\n    box-sizing: content-box;\r\n    padding: 0 12px;\r\n}\r\n\r\n.evento-intranet a.verMais {\r\n    color: #54BBAB;\r\n    font-size: 11px;\r\n    font-weight: 700;\r\n    padding-left: 10px;\r\n    position: relative;\r\n}\r\n\r\n.evento-intranet a.verMais:before {\r\n    border-top: 3px solid transparent;\r\n    border-bottom: 3px solid transparent;\r\n    border-left: 4px solid #54BBAB;\r\n    content:  ;\r\n    left: 0;\r\n    position: absolute;\r\n    top: 3px;\r\n}\r\n\r\n.ui-datepicker-calendar {\r\n\twidth: calc(100% - 32px);\r\n\tmargin: 0 auto;\r\n}\r\n\r\n/*-----titulo-----*/\r\n\r\ndiv.theme-header-title span.navbar-brand {\r\n\tdisplay: none;\r\n}\r\n\r\n/*-----header botoes a direita-----*/\r\n\r\n.theme-header-right {\r\n\tdisplay: block !important;\r\n}\r\n\r\n/*-----picklist-----*/\r\n\r\nselect[data-picklist-src], select[data-picklist-dest] {\r\n\tpadding: 2px 1px 1px 6px;\r\n\tborder: solid;\r\n\tborder-width: 1px;\r\n\tborder-color: rgb(84, 187, 171);\r\n\tbackground-color: transparent;\r\n\tbox-shadow: none;\r\n\tborder-radius: 0;\r\n\tcolor: #3A4859;\r\n    \tfont-size: 12px !important;\r\n}\r\n\r\nselect[data-picklist-src]:focus, select[data-picklist-dest]:focus {\r\n\tbox-shadow: none;\r\n\tborder-color: rgb(84, 187, 171);\r\n}\r\n\r\n/*-----mensagem push-----*/\r\n\r\ndiv.analytics-wizard-container .form-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.analytics-wizard-container .form-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .input-group-addon {\r\n\tdisplay: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary,\r\ndiv.analytics-wizard-container .btn-warning {\r\n\tfont-family: FuturaWeb,Helvetica Neue,Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tbox-sizing: border-box;\r\n\tbackground-color:#F9B000;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary:hover,\r\ndiv.analytics-wizard-container .btn-warning:hover,\r\ndiv.analytics-wizard-container .btn-primary:active,\r\ndiv.analytics-wizard-container .btn-warning:active,\r\ndiv.analytics-wizard-container .btn-primary:focus,\r\ndiv.analytics-wizard-container .btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white !important;\r\n\tcolor:#F9B000 !important;\r\n\tborder: 1px solid #F9B000 !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 5px !important;\r\n\t/margin-left: 2px !important;\r\n}\t\r\n\r\n\r\n/*----MS Edge Browser CSS Start----*/\r\n\r\n@supports (-ms-accelerator:true) {\r\n\r\n\t\t.label-mobilidade{\r\n\t\t\ttop:14px !important;\r\n\t\t\tfont-size:14px !important;\r\n\t\t}\r\n}\r\n/*----MS Edge Browser CSS End----*/\r\n\r\n/*-----Angular 4-----*/\r\n\r\n\r\n@media (min-width: 767px) {\r\n\r\n\tapp-root .theme-header {\r\n\t\tbackground-position: initial;\r\n\t}\r\n\tapp-root .breadcrumb>li {\r\n\t    display: inline;\r\n\t}\r\n\tapp-root .panel.panel-primary.theme-main-map-container {\r\n\t    display: inline-grid;\r\n\t    position: relative;\r\n\t    width: 100%;\r\n\t    text-align: center;\r\n\t    margin-top: 30px;\r\n\t    margin-bottom: 30px;\r\n\t}\r\n\tapp-root div.form-group{\r\n\t\twidth:100%;\r\n\t}\r\n\tapp-root .alert.alert-danger.errorDiv {\r\n\t    margin-top: 10px;\r\n\t    height: auto;\r\n\t    padding: 8px;\r\n\t    width: auto;\r\n\t    display: inline-block;\r\n\t}\r\n\tapp-root .panel.panel-primary.theme-main-map-container {\r\n    display: inline-grid;\r\n    position:  relative;\r\n    width:  100%;\r\n    text-align:  center;\r\n    margin-top: 30px;\r\n    margin-bottom:  30px;\r\n\t}\r\n\t\r\n\tapp-root .alert.alert-danger.errorDiv {\r\n\t    margin-top:  10px;\r\n\t    height:  auto;\r\n\t    padding:  8px;\r\n\t    width:  auto;\r\n\t    display: inline-block;\r\n\t}\r\n\t\r\n\t\r\n\tapp-root .dual-list button.btn.btn-default.pull-right {\r\n\t    box-sizing: border-box;\r\n\t    background-color: white !important;\r\n\t    color: #F9B000 !important;\r\n\t    padding: 5px 12px;\r\n\t    border: 1px solid #F9B000 !important;\r\n\t    box-shadow: none !important;\r\n\t    margin-right: 0 !important;\r\n\t    height:  auto;\r\n\t}\r\n\t\r\n\tapp-root button.btn.btn-primary.btn-block.point-right:hover {\r\n\t    margin-right:  0 !important;\r\n\t    height: 32px;\r\n\t}\r\n\tapp-root .theme-main-input-number-cpf .label-mobilidade {\r\n\t    position: absolute;\r\n\t    z-index: 2;\r\n\t}\r\n\tapp-root .theme-main-input-number-conta .label-mobilidade, app-root .theme-main-input-number-cep .label-mobilidade,\r\n\tapp-root .theme-main-input-number-operacao .label-mobilidade, app-root .theme-main-input-number-matricula .label-mobilidade, \r\n\tapp-root .theme-main-input-number-telefone .label-mobilidade, app-root .theme-main-input-date .label-mobilidade {\r\n\t    position: absolute;\r\n\t    z-index: 2;\r\n\t    top: 0;\r\n\t}\r\n}\r\n\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n/*---------------------------------------------- Mobile\t -------------------------------------------------*/\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n\r\n@media (max-width: 767px) {\r\n\t\r\n\t/*-----cabecalho-----*/\r\n\r\n\t.theme-header {\r\n\t\theight: 56px;\r\n\t\tpadding: 18px 16px;\r\n\t\tborder-bottom: none !important;\r\n\t\tbackground: #54bbab;\r\n\t\tbackground: -moz-linear-gradient(left, #54bbab 1%, #005ca9 100%);\r\n\t\tbackground: -webkit-linear-gradient(left, #54bbab 1%,#005ca9 100%);\r\n\t\tbackground: linear-gradient(to right, #54bbab 1%,#005ca9 100%);\r\n\t\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#54bbab', endColorstr='#005ca9',GradientType=1 );\r\n\t}\r\n\t\r\n\t.theme-header-right-title {\r\n\t\tmargin-right: 18px;\r\n\t\tmargin-top: 2px;\r\n\t\tfont-size: 20px;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-weight: bolder;\r\n\t}\r\n\t\r\n\t.theme-header-right-subtitle {display: none;}\r\n\t\r\n\t.navbar-left {float: right;}\r\n\t\r\n\t.theme-header-left a {\r\n\t\tbackground: url(../imgs/theme-mobilidade-2017/caixa-sintese-branco.png) no-repeat!important;\r\n\t\twidth: 23.5px;\r\n\t\theight: 20px;\r\n\t\tmargin: 0!important;\r\n\t}\r\n\t\r\n\t.navbar-brand {\r\n\t\tpadding: 0!important;\r\n\t\tdisplay: block;\r\n\t\tfloat: right;\r\n    }\r\n\t\r\n\t.navbar-right {float: left!important;}\r\n\t\r\n\t.navbar-toggle {\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none;\r\n\t}\r\n\t\r\n\t.navbar-toggle i {\r\n\t\twidth: 20px;\r\n\t\theight: 20px;\r\n\t\tmargin-right: 36px;\r\n\t}\r\n\t\r\n\t.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:active, \r\n\t.navbar-default .navbar-toggle:focus, .nav li a:hover, .nav li a:active, .nav li a:focus {background: none;}\r\n\r\n\t.theme-header-right-logo {display: none !important;}\r\n\t\r\n\th1, h2, h3, h4, h5, h6, ul {font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;}\r\n\t\r\n\tli a {font-size: 1.2em;}\r\n\r\n\t/*-----rodape-----*/\r\n\r\n\t.theme-footer {display: none;}\r\n\t\r\n\t/*-----menu vertical-----*/\r\n\r\n\t.sidebar, .sidebar-nav {\r\n\t\tborder: none;\r\n\t\tbackground: white;\r\n\t\twidth: 100% !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li a {\r\n\t\tpadding: 0;\r\n\t\tfont-size: 16px;\r\n\t\tcolor: #48586C;\r\n\t\tborder-top: 1px solid #D0E0E3;\r\n\t\tfont-weight: normal;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li a.active {\r\n\t\tborder: none;\r\n\t\tbackground-color: #D0E0E3;\r\n\t\tborder-top: 1px solid #D0E0E3;\r\n\t\tcolor: #48586C;\r\n\t\tfont-size: 16px;\r\n\t\tbackground-image: none;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li i {\r\n\t\tdisplay: inline-block !important;\r\n\t\tfont-size: 18px;\r\n\t\tmargin: 14px 37px 14px 15px !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li.open > a {background-color: #eee; display: block;}\r\n\r\n\t.sidebar-nav .nav li > a[aria-expanded=\"true\"] {\r\n\t\tcolor: #48586C;\r\n\t\tfont-size: 16px;\r\n\t\tbackground-image: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li ul li a {\r\n\t\tbackground-image: none !important;\r\n\t\tbackground-color: white !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 14px;\r\n\t\tpadding-left: 0;\r\n\t\tborder: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t\tline-height: 23px;\r\n\t}\r\n\r\n\t.sidebar-nav .nav li ul li a.active {\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-size: 14px;\r\n\t\tbackground-color: #D0E0E3 !important;\r\n\t\tborder: none;\r\n\t\tborder-top: 1px solid #D0E0E3 !important;\r\n\t}\r\n\r\n\t/*-----inputs-----*/\r\n\r\n\t.form-control {box-shadow:none;}\r\n\t\r\n\tdiv.form-group label {\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 14px;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t}\r\n\r\n\t.input-group {font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;}\r\n\t\r\n\tspan.input-group-addon {display: none;}\r\n\t\r\n\tdiv.input-group input {\r\n\t\tborder-bottom: 1px solid #D0E0E3;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tmargin-bottom: 20px !important;\r\n\t\tfont-size: 18px !important;\r\n\t\tpadding: 0;\r\n\t}\r\n\t\r\n\tdiv.input-group input:focus {\r\n\t    border-color: #D0E0E3;\r\n\t    box-shadow: none;\r\n\t}\r\n\t\r\n\t.form-group {margin-bottom: 0;}\r\n\t\r\n\th5.padding.text-primary.bold.theme-main-h4 {\r\n\t\tfont-weight: bolder;\r\n\t\tmargin-left: -7px;\r\n\t\tfont-size: 20px !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tpadding-left: 6px;\r\n\t\tpadding-bottom: 0px;\r\n\t}\r\n\r\n\th6.padding.text-primary.theme-main-h6 {\r\n\t\tfont-weight: bolder;\r\n\t\tfont-size: 16px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tspan.label.padding.theme-main-label.text-primary {\r\n\t\tfont-size: 12px;\r\n\t\tfont-weight: lighter;\r\n\t\tcolor: #48586C;\r\n\t}\r\n\t/*span.label.padding.theme-main-label.ng-binding.text-primary.pull-left.col-xs-12*/\r\n\t\r\n\t/*-----abas-----*/\r\n\t\r\n\t.tabs-nav {\r\n\t\tmargin: 70px 0 0 0;\r\n\t\tpadding: 0;\r\n\t\tdisplay: inline-block !important;\r\n\t\theight: 75px;\r\n\t\twidth: 100%;\r\n\t\tbackground: #54bbab;\r\n\t\tbackground: -moz-linear-gradient(left, #54bbab 1%, #005ca9 100%);\r\n\t\tbackground: -webkit-linear-gradient(left, #54bbab 1%,#005ca9 100%);\r\n\t\tbackground: linear-gradient(to right, #54bbab 1%,#005ca9 100%);\r\n\t\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#54bbab', endColorstr='#005ca9',GradientType=1 );\r\n\t\toverflow: hidden;\r\n\t\tposition: relative;\r\n\t}\r\n\r\n\t.tabs-nav li {\r\n\t\tmargin: 0 !important;\r\n\t\tborder: none !important;\r\n\t\tpadding: 0 !important;\r\n\t}\r\n\r\n\t.tabs-nav li a {\r\n\t\tmargin: 25px 0;\r\n\t\tpadding: 2.5px 13px 0 13px;\r\n\t\twidth: 32.5% !important;\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tborder-left: 1px solid rgba(255, 255, 255, 0.35);\r\n\t\tborder-radius: 0;\r\n\t\theight: 25px;\r\n\t\tcolor: white;\r\n\t\ttext-align: center;\r\n\t\tfloat: left;\r\n\t\toverflow: hidden;\r\n\t}\r\n\t\t\r\n\t.tabs-nav li a.active {\r\n\t\tbackground: none;\r\n\t\tborder-bottom: none;\r\n\t}\r\n\r\n\t.tabs-nav li a.active::after {\r\n\t\tcontent: url('../imgs/theme-mobilidade-2017/seta.png');\r\n\t\ttop: 60px;\r\n\t\tmargin-left: -30px;\r\n\t\tvertical-align: bottom;\r\n\t\tposition: absolute;\r\n\t}\r\n\r\n\t/*-----tabelas-----*/\r\n\r\n\tthead tr th {\r\n\t\tpadding: 0 16px 30px 0 !important;\r\n\t\tbackground: none !important;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-size: 14px;\r\n\t\tborder: none !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\ttbody > tr > td:first-child {font-weight: normal;}\r\n\r\n\ttbody tr {background-color: white !important;}\r\n\r\n\ttbody tr td {\r\n\t\tpadding: 0 16px 30px 0 !important;\r\n\t\tcolor: #48586C !important;\r\n\t\tfont-size: 14px;\r\n\t\tborder: none !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\tth, td {border: none !important;}\r\n\r\n\ttd button {\r\n\t\tbackground: none;\r\n\t\tmargin: 0 !important;\r\n\t\tpadding: 0 !important;\r\n\t\tline-height: inherit !important;\r\n\t}\r\n\r\n\ttd button i {line-height: inherit !important;}\r\n\r\n\ttd button:hover, td button i:hover {color: #48586C;}\r\n    \r\n    /*-----barra de rolagem-----*/\r\n\r\n\t.table-responsive::-webkit-scrollbar {width: 5px; height: 5px;}\r\n\t.table-responsive::-webkit-scrollbar-button {width: 0; height: 0;}\r\n\t.table-responsive::-webkit-scrollbar-thumb {\r\n\t\tbackground:#54BBAB !important;\r\n\t\tborder: none;\r\n\t\tborder-radius: 0;\r\n\t}\r\n\t.table-responsive::-webkit-scrollbar-thumb:hover,\r\n\t.table-responsive::-webkit-scrollbar-thumb:active {background:#54BBAB !important;}\r\n\t.table-responsive::-webkit-scrollbar-track {\r\n\t\tbackground:#D0E0E3 !important;\r\n\t\tborder: none;\r\n\t\tborder-radius: 0;\r\n\t}\r\n\t.table-responsive::-webkit-scrollbar-track:hover,\r\n\t.table-responsive::-webkit-scrollbar-track:active {background:#D0E0E3 !important;}\r\n\r\n\t/*-----combo box-----*/\r\n\r\n\t.theme-main-input-select {margin: 20px auto;}\r\n\r\n\t.theme-main-input-select label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tfont-weight: bolder !important;\r\n\t\tcolor: #005CA9 !important;\r\n\t}\r\n\r\n\t.input-group select {\r\n\t\t-webkit-appearance: none;\r\n  \t\t-moz-appearance: none;\r\n  \t\tappearance: none;\r\n\t\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat right;\r\n\t\tborder-radius: 0;\r\n\t\tborder-top: none;\r\n\t\tborder-right: none;\r\n\t\tborder-bottom: 1px solid #D0E0E3;\r\n\t\tborder-left: none;\r\n\t\tpadding: 0 !important;\r\n\t\tmargin: 0 !important;\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 16px !important;\r\n\t\tline-height: 16px;\r\n\t\tmin-width: 152px;\r\n\t}\r\n\r\n\t.input-group select:focus {border-color: #D0E0E3; box-shadow: none;}\r\n\r\n\t/*-----separador-----*/\r\n\r\n\thr {border-color:#005CA9; margin: 20px 0 !important;}\r\n\r\n\t/*-----botoes-----*/\r\n\r\n\t.theme-main-button {\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-weight: bolder;\r\n\t\tfont-size: 16px !important;\r\n\t\tborder-radius: 0;\r\n\t\tmargin-top: 10px;\r\n\t\tmargin-bottom: 0;\r\n\t\tbox-sizing: border-box;\r\n\t\tpadding: 8px !important;\r\n\t}\r\n\r\n\t.btn-primary {background-color:#005CA9; border:0;}\r\n\t.btn-warning {background-color:#F39200; border:0;}\r\n\r\n\t.btn-primary:hover {background-color:#0071CF !important;}\r\n\t.btn-warning:hover {background-color:#feb21e !important;}\t\r\n\tbutton.col-xs-4 {\r\n\t    width: 33%;\r\n\t    margin-right: 7px;\r\n\t}\r\n\t.btn-primary:active {background-color:#004C8C !important; box-shadow:none;}\r\n\t.btn-warning:active {background-color:#ec7500 !important; box-shadow:none;}\t\r\n\r\n\t.theme-main-button[disabled=\"disabled\"],\r\n\t.theme-main-button[disabled=\"disabled\"]:hover,\r\n\t.theme-main-button[disabled=\"disabled\"]:focus {background-color:#d0e0e3 !important; border-color:#d0e0e3 !important; color:white; opacity:1 !important;}\r\n    \r\n    /*-----menu horizontal-----*/\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li {\r\n\t\tpadding-top: 0;\r\n\t\tpadding-bottom: 0;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a {\r\n\t\tcolor: white;\r\n\t\tborder-right: none !important;\r\n\t\tdisplay: inline-block !important;\r\n\t\tpadding-top: 0px !important;\r\n\t\tline-height: inherit;\r\n\t}\r\n\r\n\t.nav .open>a, .nav .open>a:focus, .nav .open>a:hover {\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tcolor: white;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a:hover {\r\n\t\toutline: none;\r\n\t\tborder: none;\r\n\t\tcolor: white;\r\n\t}\r\n\r\n\tul[ng-hide=\"currentview.telainicial\"] li a i {display: inline-block !important;}\r\n\r\n    .theme-header-tabs {\r\n\t\tbackground-color: #54BBAB;\r\n\t\tposition: fixed;\r\n\t\tbottom: 0;\r\n\t\tleft: 0;\r\n\t\theight: 48px;\r\n\t\tmax-height: none;\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none !important;\r\n\t\tdisplay: block;\r\n\t}\r\n\r\n\t.theme-header-tabs .caixa-azul {display: none;}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs {\r\n\t\tmax-height: none;\r\n\t\toverflow-y: visible !important;\r\n\t\toverflow-x: visible !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li {\r\n\t\theight: 48px;\r\n\t\tmargin: 0;\r\n\t\tpadding: 0;\r\n\t\tborder: none !important;\r\n\t\twidth: 25% !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li a {\r\n\t\tcolor: white;\r\n\t\tfont-size: 22px;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 32px;\r\n\t\theight: 22px;\r\n\t\ttext-align: center;\r\n\t\tvertical-align: top !important;\r\n\t\tmargin: 9px 0px 13px 10px;\r\n\t\tpadding: 0 !important;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs li a[class=\"ng-scope active\"]::before {\r\n\t\tcontent: '';\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 100%;\r\n\t\theight: 4px;\r\n\t\tbackground-color: #005CA9;\r\n\t\tposition: absolute;\r\n\t\tright: 0;\r\n\t\ttop: -4px;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs li a[class=\"ng-scope active\"] {\r\n\t\tbackground-color: #66cfbf;\r\n\t\toverflow: visible;\r\n\t\theight: 48px !important;\r\n\t\tmargin: 0 !important;\r\n\t\tpadding: 9px 29px 13px 29px !important;\r\n\t\twidth: 100% !important;\r\n\t}\r\n\r\n\t.theme-header-tabs li:hover {\r\n\t\tcursor: pointer;\r\n\t\tbackground-color: #66cfbf;\r\n\t\tmargin: 0 !important;\r\n\t}\r\n\r\n\t.theme-app.tabbed .navbar .nav.nav-tabs:focus {outline:none;}\r\n\r\n\tul.theme-header-tabs:hover {display: block !important;}\r\n\r\n\t/*-----submenus-----*/\r\n\r\n\tdiv.page-wrapper {margin-top: 77px !important;}\r\n\r\n\tul.theme-header-tabs li.dropdown {width: 25%;}\r\n\r\n\tul.theme-header-tabs li.dropdown a,\r\n\tul.theme-header-tabs li.dropdown a:focus,\r\n\tul.theme-header-tabs li.dropdown a:hover {\r\n\t\tbackground-color: transparent;\r\n\t\tfont-size: 22px;\r\n\t\twidth: 32px;\r\n\t\theight: 22px;\r\n\t\ttext-align: center;\r\n\t\tvertical-align: top !important;\r\n\t\tmargin: 0;\r\n\t\tpadding: 9px 29px 13px 29px !important;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul  {box-shadow: none;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu {display: none;}\r\n\t\r\n\tul.theme-header-tabs li.open ul.dropdown-menu {\r\n\t\tbackground: none;\r\n\t\tdisplay: inline-block;\r\n\t\tbottom: 58px;\r\n\t\twidth: 90px !important;\r\n\t\tmargin: 0;\r\n\t\tborder: none;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:first-child  {\r\n\t\tdisplay: inline-block;\r\n\t\tposition: absolute;\r\n\t\tbottom: 58px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(2)  {\r\n\t\tdisplay: inline-block !important;\r\n\t\tposition: relative;\r\n\t\tbottom: 153px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(3)  {\r\n\t\tdisplay: inline-block !important;\r\n\t\tposition: relative;\r\n\t\tbottom: 258px;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(n+4) {display: none;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:first-child,\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(2),\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:nth-child(3) {\r\n\t\tbackground-color: #005CA9;\r\n\t\theight: 48px;\r\n\t\twidth: 90px !important;\r\n\t\ttransition: all 0.3s ease-out 0s;\r\n\t\toverflow: hidden;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown:after {\r\n\t\tcontent: '\\\r\nF6';\r\n\t\tfont-size: 12px;\r\n\t\tcolor: white;\r\n\t\tposition: relative;\r\n\t\ttop: 2px !important;\r\n\t\tleft: 4px !important;\r\n\t}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li:hover {background-color:#00B5E5;}\r\n\r\n\tul.theme-header-tabs li.dropdown.open:hover {background-color: #54bbab;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a:hover {color: white;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a span {color: transparent;}\r\n\r\n\tul.theme-header-tabs li.dropdown ul.dropdown-menu li a span i {color: white;}\r\n\r\n\t/*-----carrossel-----*/\r\n\r\n\t.carousel-indicators li, .carousel-indicators .active {\r\n\t\tmargin: 20px 6px auto 6px;\r\n\t\tborder-color: #F39200;\r\n\t\tbackground-color: white;\r\n\t\twidth: 12px;\r\n\t\theight: 12px;\r\n\t}\r\n\r\n\t.carousel-indicators .active {\r\n\t\tbackground-color: #F39200;\r\n\t\twidth: 12px;\r\n\t\theight: 12px;\r\n\t}\r\n\r\n\tol.carousel-indicators {\r\n\t\tposition: static;\r\n\t\tlist-style: none;\r\n\t\twidth: auto;\r\n\t\theight: auto;\r\n\t\ttop: 100%;\r\n\t\tright: 0;\r\n\t\ttext-align: right;\r\n\t}\r\n\r\n\tol.carousel-indicators li:last-child {margin-right: 0;}\r\n\r\n\t.carousel-caption {display: none;}\r\n\r\n\t.carousel-control {display: none;}\r\n\r\n\t/*-----radio-----*/\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 14px !important;\r\n\t\tcolor: #48586C;\r\n\t\tdisplay: block;\r\n\t\tbackground: none;\r\n\t\tborder: none;\r\n\t\tpadding: 0;\r\n\t\theight: 20px;\r\n\t\tmargin: 0 0 5px 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:hover, \r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:active,\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button:focus {\r\n\t\tcolor: #48586C;\r\n\t\tbackground: none !important;\r\n\t\tborder: none;\r\n\t\toutline: none;\r\n\t\tcursor: auto;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn.active,\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn:active {box-shadow: none;}\r\n\t\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn:before {\r\n\t\tcontent: '';\r\n\t\tposition: relative;\r\n\t\tbottom: -4px;\r\n\t\tbackground-color: white;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 18px;\r\n\t\theight: 18px;\r\n\t\tborder: 1px solid #D0E0E3;\r\n\t\tborder-radius: 50%;\r\n\t\tmargin: 0 10px 0 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-radio'\"] .input-group > button.btn.active:before {\r\n\t\tcontent: '';\r\n\t\tbackground-color: #54BBAB;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 8px;\r\n\t\theight: 8px;\r\n\t\tborder: 5px solid white;\r\n\t\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\t\tbox-sizing: content-box;\r\n\t\tborder-radius: 50%;\r\n\t\tmargin: 0 10px 0 0;\r\n\t}\r\n\t\t\r\n\t/*-----checkbox-----*/\r\n\t\r\n\tdiv[ng-if=\"item.type=='input-check'\"] label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 12px !important;\r\n\t\tcolor: #48586C !important;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group {margin-bottom: 40px;}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\t\tfont-size: 14px !important;\r\n\t\tcolor: #48586C;\r\n\t\tdisplay: block;\r\n\t\theight: 20px;\r\n\t\tmargin: 0 14px 5px 0;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"] {\r\n\t\tposition: relative;\r\n\t\tbottom: -40%;\r\n\t\tmargin-right: 14px;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"]:before {\r\n\t\tcontent: '';\r\n\t\tposition: relative;\r\n\t\tbottom: -15%;\r\n\t\tbackground-color: white !important;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 18px;\r\n\t\theight: 18px;\r\n\t\tborder: 1px solid #D0E0E3;\r\n\t}\r\n\r\n\tdiv[ng-if=\"item.type=='input-check'\"] .input-group > label input[type=\"checkbox\"]:checked:before {\r\n\t\tcontent: '';\r\n\t\tbackground-color: #54BBAB !important;\r\n\t\tdisplay: inline-block;\r\n\t\twidth: 17px;\r\n\t\theight: 17px;\r\n\t\tborder: 4px solid white;\r\n\t\tbox-shadow: 0 0 0 1px #D0E0E3;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\r\n\t/*-----breadcrumb-----*/\r\n\r\n\tol.breadcrumb {background-color: #f5f5f5;}\r\n\r\n\tol.breadcrumb li a {color: #337ab7; text-decoration: none;}\r\n\r\n\tol.breadcrumb:before {content: ''; padding-right: 0;}\r\n\r\n\tol.breadcrumb li:before {content:''; padding-left:0 !important;}\r\n\r\n\tol.breadcrumb li:after {content:\"/\\00a0\"; color:#ccc; padding:0 5px;}\r\n\r\n\tol.breadcrumb li:last-child:before {padding:0 !important;}\r\n\r\n\r\n\t/*-----texto-----*/\r\n\r\n\th5.theme-main-h4, h6.theme-main-h6 {line-height: 1.1;}\r\n\r\n\th5.theme-main-h4 {border-bottom: none;}\r\n\r\n\t.text-primary, .text-primary-important, .text-warning,\r\n\t.text-warning-important, .text-success, .text-success-important,\r\n\t.text-default, .text-black, .text-purple, .text-laranja, .text-info,\r\n\t.text-danger {\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\t/* font-size: 14px !important; */\r\n\t\tline-height: 18px;\r\n\t}\r\n\r\n\t.text-primary {color: #005CA9 !important;}\r\n\t.text-primary-important {color: #005CA9 !important;}\r\n\t.text-warning {color: #F39200;}\r\n\t.text-warning-important {color: #F39200 !important;}\r\n\t.text-success {color: #54BBAB;}\r\n\t.text-success-important {color: #54BBAB !important;}\r\n\t.text-default {color: #48586C; font-weight: 100;}\r\n\t.text-black {color: #48586C; font-weight: 100;}\r\n\t.text-purple {color: #B26F9B; font-weight: 100;}\r\n\t.text-laranja {color: #F39200; font-weight: 100;}\r\n\t.text-info {color: #AFCA0B; font-weight: 100;}\r\n\t.text-danger {color: #F9765E; font-weight: 100;}\r\n\r\n\t/*-----links-----*/\r\n\r\n\t.theme-main-link a {color: #337ab7; font-size: 12px;}\r\n\r\n\r\n\t.side-menubar .theme-header-title {\r\n    \tmargin-top: 18px;\r\n\t}\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse {\r\n        display: block;\r\n        height: 100%!important;\r\n        margin-left: -700px;\r\n        position: fixed!important;\r\n        width: 85% !important;\r\n        overflow: hidden;\r\n        z-index: 9099999 !important;\r\n    }\r\n\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse.in {\r\n        display: inline !important;\r\n        height: auto !important;\r\n        margin-left: 0px !important;\r\n        background-color: white;\r\n        transition: all 2s;\r\n        z-index: 9999 !important;\r\n        padding-bottom: 60px !important;\r\n        max-width: 85%;\r\n        bottom: 0;\r\n        max-height: 59%;\r\n        min-height: 59%;\r\n    }\r\n\r\n    li.theme-menu-item {\r\n        width:100%;\r\n        position: relative;\r\n        \r\n    }\r\n    .navbar-toggle i {\r\n        width: 20px;\r\n        height: 20px;\r\n        margin-right: 13px;\r\n        margin-top: 5px;\r\n    }\r\n\r\n\r\n    li.theme-menu-item:nth-child(7) a:nth-child(2){\r\n        bottom: 0;\r\n        position: fixed;\r\n        background: #005ca9;\r\n        color: white;\r\n        width: 85%;\r\n    }\r\n\r\n\r\n    .theme-app.menu .theme-menu-container {\r\n        overflow-y: auto;\r\n        overflow: auto;\r\n        display: inline-block;\r\n        height: auto;\r\n        position: absolute;\r\n        top: 9px;\r\n        bottom: 0;\r\n        width: 85% !important;\r\n    }\r\n\r\n    .sidebar .sidebar-nav.navbar-collapse {\r\n        transition: all 0.5s ease !important;\r\n    }\r\n\r\n    .theme-app.menu .theme-main-container {\r\n        margin: 10px 0 0 0px;\r\n     \r\n    }\r\n\r\n    .theme-app.menu .theme-main-container {\r\n        margin: 10px 0 0 0px;\r\n     }\r\n     \r\n     .overlay {\r\n        display: none;\r\n        background: rgba(0,0,0,.7);\r\n        height: 100%;\r\n        left: 0;\r\n        position: absolute;\r\n        top: 0;\r\n        width: 100%;\r\n        z-index: 98;\r\n    }\r\n    .theme-app.menu .theme-main-container {\r\n        margin-top: 76px !important;\r\n    }\r\n    .side-menubar{\r\n        display: block !important;\r\n        width:85%;\r\n        margin-left:-700px;\r\n        transition: all 0.5s ease !important;\r\n        background: white;\r\n        height: 52%;\r\n    } \r\n    .side-menubar:after {\r\n        content: \"\";\r\n        background: #D0E0E3;\r\n        position: absolute;\r\n        bottom: 0;\r\n        left: 0;\r\n        height: 1px;\r\n        width: 33%;\r\n    }\r\n    .seta{\r\n        padding: 3px 0px;\r\n        background: #F39200;\r\n        border-radius: 50%;\r\n        float: left;\r\n        margin: 0 ;\r\n    }\r\n    \r\n    .setaleft {\r\n       color:#FFFFFF; \r\n       font-size:13px;\r\n    }\r\n    .glyphicon-menu-left:before {\r\n        margin-left: 8px;\r\n    }   \r\n    .fa-navicon{\r\n        font-size: 23px !important;\r\n        margin: 1px 13px 0 0 !important;\r\n    }\r\n    li.theme-menu-item:nth-child(2) a {\r\n        border-top: none;\r\n    }\r\n    .sidebar-nav.navbar-collapse.theme-menu.collapse.in{\r\n        overflow-y: scroll;\r\n    }\r\n    .feedback-menu a{\r\n        color: #F39200 !important;\r\n        font-size: 25px;    \r\n    }\r\n    .informacao-header {\r\n        height: auto;\r\n        background: white;\r\n    }\r\n\r\n    .informacao-header .form-group.col-xs-12.theme-main-input-text {\r\n        padding: 0;\r\n        top: 0;\r\n    }\r\n\r\n    .informacao-header .circle.col-xs-6 {\r\n        height: 104px;\r\n        width: 104px;\r\n        margin-top: -2px;\r\n    }\r\n    \r\n    .informacao-header .circle.col-xs-6 .fa.fa-user{\r\n           margin: 2px 3px;\r\n           font-size: 7em;\r\n           color: #F39200;\r\n    }\r\n    \r\n\r\n    .informacao-header .theme-main-input-text p {\r\n        font-weight: normal;\r\n        font-size: 14px;\r\n        font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n        margin: 0;\r\n    }\r\n\r\n    .form-group.col-xs-12.theme-main-input-text.nome-usuario {\r\n        padding-bottom: 10px;\r\n    }\r\n\r\n    a.btn-sair-menu {\r\n        display: block;\r\n        padding-left: 16px;\r\n        line-height: 23.5px;\r\n        min-height: 47px;\r\n        box-sizing: border-box;\r\n        padding: 0;\r\n        font-size: 16px;\r\n        border-top: 1px solid #D0E0E3;\r\n        font-weight: normal;\r\n        bottom: 0;\r\n        position: fixed;\r\n        background: #005ca9;\r\n        color: white;\r\n        cursor: pointer;\r\n        width: 85%;\r\n    }\r\n\t\r\n    .btn-sair-menu i.fa.fa-sign-out {\r\n        display: inline-block !important;\r\n        font-size: 18px;\r\n        margin: 14px 37px 14px 15px !important;\r\n    }\r\n\r\n    .btn-sair-menu span.theme-menu-item-caption {\r\n        text-decoration: none;\r\n    }\r\n\r\n    a.btn-sair-menu:hover {\r\n        text-decoration: none;\r\n    }\r\n    .barra-menu{\r\n    \tdisplay:block;\r\n        height: 20px;\r\n        width: 100%;\r\n        background: url(../imgs/theme-mobilidade-2017/barra-menu.jpg);\r\n        position: fixed;\r\n        top: 0;\r\n        z-index: 99999;\r\n    }\r\n    .theme-header{\r\n        margin-top: 20px;\r\n    }\r\n    .side-menubar{\r\n\t    display:block;\r\n        margin-top:0;\r\n        z-index: 9999;\r\n    }\r\n\t.table-responsive.table-bordered.theme-main-table.ng-scope.col-xs-12 {\r\n\t    margin-bottom: 34px;\r\n\t    margin-top: 5px;\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-4{\r\n\t    width: 33.33333333%;\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-12{\r\n\t    width: 100%\r\n\t}\r\n\t.slider-container.ng-scope.col-xs-6{\r\n\t    width: 50%;\r\n\t}\r\n\tbutton.btn.btn-sm.margin-3x.theme-main-button.toggle-menu.btn-primary.pull-left.col-xs-12 {\r\n\t    height: auto;\r\n\t}\r\n\t\r\n\tbutton.btn.btn-sm.margin-3x.theme-main-button.toggle-menu.btn-primary.pull-left.col-xs-12 .menu ol li {\r\n\t    margin-top: 16px;\r\n\t    margin-left: -19px;\r\n\t    white-space: normal;\r\n\t}\r\n\r\n\r\n\ti.fa.theme-main-icon.ng-scope.fa-play-circle-o.text-primary.floatRight:before {\r\n\t    float: right;\r\n\t}    \r\n    a.form-group.panel-center.theme-main-img-button.ng-scope.floatLeft {margin-left: 15px;margin-top: 6px;}\r\n\r\n\ta.form-group.panel-center.theme-main-img-button.ng-scope.floatNone.text-center {\r\n\t    text-align: center;\r\n\t    display:  inline-block;\r\n\t    width:  100%;\r\n\t    margin-top:  10px;\r\n\t}\r\n\t\r\n\ta.theme-main-img-button.floatNone img {\r\n\t    margin: 0 auto;\r\n\t    text-align:  center;\r\n\t}\r\n\t\r\n\ta.form-group.panel-center.theme-main-img-button.ng-scope.floatRight {\r\n\t    margin-top: 10px;\r\n\t    text-align: right;\r\n\t    margin-right: 15px;\r\n\t}\r\n    .tabs-nav li{\r\n\t    display:none;\r\n\t}\r\n\t.tabs-nav li:nth-child(1), .tabs-nav li:nth-child(2), .tabs-nav li:nth-child(3){\r\n\t    display:block;\r\n\r\n\t}\r\n\t.tabs-nav li a.active::after{\r\n\t\tmargin-left: -21px;\r\n\t}\r\n\t.tabs-nav a{\r\n\t\tfont-size: 17px;\r\n\t}\r\n    \r\n\t\r\n\tlabel.ng-binding {\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 14px;\r\n\t\tcolor: #54BBAB;\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tmargin-bottom: 2px;\r\n\t}\r\n\t\r\n\tdiv.input-group {width: inherit;}\r\n\t\r\n\tdiv.input-group input {\r\n\t\tcolor: #3A4859;\r\n\t\tfont-size: 12px !important;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tpadding-bottom: 7px;\r\n\t\tpadding-left: 0;\r\n\t\theight: 26px;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 0 !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\t\r\n\tspan.input-group-addon {display: none;}\r\n\t\r\n\tdiv.input-group input:focus {\r\n\t\tborder-color: #54BBAB;\r\n\t\tbox-shadow: none;\r\n\t}\r\n\t\r\n\t.form-group {margin-bottom: 0;}\r\n\t\r\n\t\r\n\t\r\n\t.form-control{border: 0; padding: 4px 0; border-bottom: 1px solid #ccc; background-color: transparent; box-shadow: none;}\r\n\t\r\n\t\r\n\t\r\n\t.form-group.col-xs-12.theme-main-input-check {\r\n\t\tpadding-bottom: 10px;\r\n\t}\r\n\t\r\n\tdiv#telefone-group .input-group .col-xs-4 {\r\n\t\tpadding-left: 0;\r\n\t}\r\n\r\n\t\r\n\t/*-----combo box-----*/\r\n\t\r\n\t.theme-main-input-select label {\r\n\t\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 14px !important;\r\n\t\tfont-weight: normal !important;\r\n\t\tcolor: #54BBAB !important;\r\n\t\tmargin-bottom: 2px !important;\r\n\t}\r\n\t\r\n\t.input-group select {\r\n\t\t-webkit-appearance: none;\r\n\t\t-moz-appearance: none;\r\n\t\tappearance: none;\r\n\t\tbackground: url('../imgs/theme-mobilidade-2017/seta_combox.png') no-repeat top right;\r\n\t\tborder-radius: 0;\r\n\t\tborder-top: none;\r\n\t\tborder-right: none;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-left: none;\r\n\t\tpadding: 0 0 10px 0;\r\n\t\theight: 26px;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 6px !important;\r\n\t\tbox-sizing: border-box;\r\n\t\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\t\tfont-size: 12px !important;\r\n\t\tline-height: 12px;\r\n\t}\r\n\t\r\n\t.input-group select:focus {border-color: #54BBAB; box-shadow: none;}\r\n\t\r\n\t/*-----caixa de texto-----*/\r\n\t\r\n\tdiv.input-group textarea {\r\n\t\twidth: inherit;\r\n\t\tcolor: #3A4859;\r\n\t\tfont-size: 12px !important;\r\n\t\tborder-bottom: 1px solid #54BBAB;\r\n\t\tborder-top: none;\r\n\t\tborder-left: none;\r\n\t\tborder-right: none;\r\n\t\tborder-radius: 0;\r\n\t\tpadding-bottom: 7px;\r\n\t\tpadding-left: 0;\r\n\t\tmargin-bottom: 21px !important;\r\n\t\tmargin-top: 0 !important;\r\n\t\tbox-sizing: border-box;\r\n\t}\r\n\t\r\n\tdiv.input-group textarea:focus {\r\n\t\tborder-color: #54BBAB;\r\n\t\tbox-shadow: none;\r\n\t}\r\n\r\n\t.splash .navbar-right.theme-header-right .navbar-brand  {\r\n\t\tdisplay: none;\r\n\t}\r\n\t.splash ol.breadcrumb.ng-isolate-scope {\r\n\t    display: none;\r\n\t}\r\n\r\n\t.splash .theme-header{    \r\n\t   background: #065CA7 !important;\r\n\t}\r\n\r\n\t.splash {\r\n\t    background-color: #065CA7;\r\n\t    position: absolute;\r\n\t    height: 100%;\r\n\t}\r\n\r\n\t.splash span.ng-binding {\r\n\t    color: #fff;\r\n\t}\r\n\r\n\t.splash .navbar-right.theme-header-right {\r\n\t\twidth: 0;\r\n\t    height: 0;\r\n\t    border: 0 solid transparent;\r\n\t    border-left-width: 0px;\r\n\t    border-right-width: 100PX;\r\n\t    border-top: 100px solid #FF9300;\r\n\t    margin: 0;\r\n\t    vertical-align: middle;\r\n\t    position: absolute;\r\n\t    top: 0;\r\n\t    left: 0;\r\n\t}\r\n\t.splash .theme-header-left a{\r\n\t\tbackground: url(../imgs/theme-mobilidade-2017/titlefullc.png) no-repeat!important;\r\n\t}\r\n\t.splash .navbar-left.theme-header-left {\r\n\t    float: none;\r\n\t    margin-left: 33%;\r\n\t    width: 100% !important;\r\n\t    height: 31px;\r\n\t}\r\n\t.splash .barra-menu {\r\n    \tdisplay: none !important;\r\n\t}\r\n\t\r\n\t.splash .navbar-default.sidebar.theme-menu-container {\r\n\t\tdisplay:none;\r\n\t    background: none;\r\n\t}\r\n\t.splash nav.navbar.navbar-default.navbar-fixed-top.theme-header {\r\n\t    margin-top: 0;\r\n\t}\r\n\t\r\n\t.splash a.navbar-brand {\r\n\t    width: 100%;\r\n\t    height: 100%;\r\n\t}\r\n\t\r\n\t.splash .theme-header-title {\r\n\t    overflow: hidden;\r\n\t}\r\n\t.splash span.label.padding.theme-main-label.text-primary{\r\n\t\tcolor:#fff !important\r\n\t}\r\n\r\n\t/*-----Page loader-----*/\r\n\r\n\t.page-loader{\r\n\t    height: 100%;\r\n\t    width: 100%;\r\n\t    background: rgba(0,0,0,0.6);\r\n\t    display:block;\r\n\t    position: absolute;\r\n\t    z-index: 9999999999999999999;\r\n\t    top: 0;\r\n\t    transition:2s;\r\n\t}\r\n\t\r\n\t.page-loader:before {\r\n    content: '';\r\n    width: 100%;\r\n    background-image: url(../imgs/theme-mobilidade-2017/loading.gif);\r\n    position: absolute;\r\n    bottom: 0;\r\n    height: 19px;\r\n    background-repeat: no-repeat;\r\n    background-position: center;\r\n\t}\r\n\t/*-----Splash para Angular 4-----*/\r\n\r\n\t.splash-body .navbar-right.theme-header-right .navbar-brand  {\r\n\t\tdisplay: none;\r\n\t}\r\n\t.splash-body ol.breadcrumb.ng-isolate-scope {\r\n\t    display: none;\r\n\t}\r\n\r\n\t.splash-body .theme-header{    \r\n        background: #065CA7 !important;\r\n        margin-top: 0!important;\r\n\t}\r\n    .splash-body  .theme-app{\r\n        background: #065CA7 !important;\r\n    }\r\n\t.splash-body {\r\n\t    background-color: #065CA7;\r\n        position: relative !important;\r\n\t    height: 100%;\r\n\t}\r\n\r\n\t.splash-body span.ng-binding {\r\n\t    color: #fff;\r\n\t}\r\n\r\n\t.splash-body .navbar-right.theme-header-right {\r\n\t\twidth: 0;\r\n\t    height: 0;\r\n\t    border: 0 solid transparent;\r\n\t    border-left-width: 0px;\r\n\t    border-right-width: 100PX;\r\n\t    border-top: 100px solid #FF9300;\r\n\t    margin: 0;\r\n\t    vertical-align: middle;\r\n\t    position: absolute;\r\n\t    top: 0;\r\n\t    left: 0;\r\n\t}\r\n\t.splash-body .navbar-left.theme-header-left {\r\n\t    float: none;\r\n\t    margin-left: 33%;\r\n\t    width: 100% !important;\r\n\t    height: 31px;\r\n\t}\r\n\t.splash-body .barra-menu {\r\n    \tdisplay: none !important;\r\n\t}\r\n\t\r\n\t.splash-body .navbar-default.sidebar.theme-menu-container {\r\n\t\tdisplay:none;\r\n\t    background: none;\r\n\t}\r\n\t.splash-body nav.navbar.navbar-default.navbar-fixed-top.theme-header {\r\n\t    margin-top: 0;\r\n\t}\r\n\t\r\n\t.splash-body a.navbar-brand {\r\n\t    width: 100%;\r\n\t    height: 100%;\r\n\t}\r\n\t\r\n\t.splash-body .theme-header-title {\r\n\t    overflow: hidden;\r\n\t}\r\n\t.splash-body h5.padding.text-primary.bold.theme-main-h4, .splash-body span, .splash-body .theme-main-link a{\r\n\t\tcolor:#fff !important\r\n    }\r\n    \r\n    body.theme-app.splash-top {\r\n        background-color: #065CA7;\r\n    }\r\n\t  .navbar-usuario-intranet {\r\n\t \tdisplay:none !important;\r\n\t }\r\n\t .menu-item-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .overlay-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .pesquisa-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t  .config-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .calendario-intranet{\r\n\t \tdisplay:none;\r\n\t }\r\n\t .navbar-left.theme-header-left{\r\n\t \theight:20px !important;\r\n\t }\r\n}",
            "contraste": 28,
            "icon": "fa-file-image-o",
            "id": 11,
            "name": "Intranet/Mobilidade",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "tema": 11,
            "value": "theme-intranet.css"
        },
        {
            "contraste": 27,
            "icon": "fa-globe",
            "id": 10,
            "name": "Caixa Portal",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "tema": 10,
            "value": "theme-portal.css"
        },
        {
            "content": ".theme-app {\r\n\tbackground-color: #000;\r\n}\r\n\r\n.theme-header {\r\n\tbackground-color: #000;\r\n\tborder-bottom: 3px solid #F39A00!important;\r\n}\r\n.theme-app.tabbed .theme-header {\r\n\tborder-bottom: none!important;\r\n}\r\n\r\n.theme-header-tabs {\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-header-right > .navbar-brand {\r\n\tcolor: #fff;\r\n\tpadding-right: 5px;\r\n}\r\n.theme-header-left > .navbar-brand {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-header-middle.navbar-brand{\r\n\tcolor: #fff;\r\n}\r\n.theme-header-tabs {\r\n\t    background-color: #000;\r\n}\r\n\r\n.theme-header-tabs > li.active > a,\r\n.nav-tabs>li>a.active {\r\n\tbackground-color: #333;\r\n\tcolor: #333;\r\n}\r\n\r\n.theme-footer {\r\n\tbackground-color: #000;\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-footer-right {\r\n\tpadding-right: 10px;\r\n}\r\n.theme-footer-middle {\r\n\r\n}\r\n.theme-footer-left {\r\n\tpadding-left: 10px;\r\n}\r\n\r\n.theme-header-left > a {\r\n\tbackground: url(../imgs/theme-padrao/caixab.png) no-repeat!important;\r\n\twidth: 112px;\r\n\theight: 24px;\r\n\tmargin-top: 20px!important;\r\n\tmargin-left: 10px!important;\r\n}\r\n.theme-header-left-caption {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.theme-header-title {\r\n\theight: 63px;\r\n}\r\n\r\n.form-group{\r\n\ttop:20px;\r\n}\r\n\r\n.theme-header-acessibilidade{\r\n\theight: 25px;\r\n\tbackground-color: #555;\r\n}\r\n\r\n.theme-link-acessibilidade{\r\n\tposition: relative;\r\n\ttop: 3px;\r\n\tleft: 10px;\r\n}\r\n\r\n.theme-header-right {\r\n\t/* padding: 7px; */\r\n\t/*padding-right: 15px;*/\r\n}\r\n\r\n.theme-app.tabbed .theme-menu-container {\r\n    margin-top: 120px!important;\r\n}\r\n.theme-main-container {\r\n\tborder-left: 0px;\r\n\tbackground-color: #000;\r\n\tmargin: 0px 0 50px 0px;\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-app.collapse.in .theme-submenu-item > a {\r\n\tpadding-left: 20px;\r\n}\r\n\r\n.theme-app .theme-main-container {\r\n\tborder-left: 0px;\r\n\tbackground-color: #000;\r\n\tmargin: 70px 0 50px 0px;\r\n}\r\n\r\n.theme-app.menu .theme-main-container {\r\n\tmargin: 10px 0 50px 0px;\r\n}\r\n\t\r\n@media (min-width: 768px) {\r\n\t.sidebar-nav.navbar-collapse.collapse.theme-menu.ng-scope {\r\n\t    \tmargin-top: auto !important;    \t\r\n\t}\r\n\t.navbar-default.sidebar.theme-menu-container.ng-scope {\r\n\t    padding-top: 0px !important;\r\n\t}\r\n\t\r\n\t.theme-app.tabbed .theme-menu-container {\r\n\t    margin-top: 20px!important;\r\n\t}\r\n\t.theme-app .theme-menu-container {\r\n\t    margin-top: 0px!important;\r\n\t}\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 15px!important;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tposition: fixed;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-header-right {\r\n\t\tpadding-right: 15px;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 10px!important;\r\n\t}\r\n\r\n\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 0 70px!important;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 0px!important;\r\n\t}\r\n\r\n\t.theme-main-container {\r\n\t\tmargin: 67px 0 0 70px;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tmargin-top: 3px!important;\r\n\t}\r\n}\r\n\r\n.sidebar-nav > .nav li > a.active {\r\n    margin: 0;\r\n    border-left: 4px solid #ffa100;\r\n    border-left-width: 4px;\r\n    border-left-style: solid;\r\n    border-left-color: #ffa100;\r\n    border-top: 1px solid #d9d9d9;\r\n    border-top-width: 1px;\r\n    border-top-style: solid;\r\n    border-top-color: rgb(217, 217, 217);\r\n    border-bottom: 1px solid #d9d9d9;\r\n    border-bottom-width: 1px;\r\n    border-bottom-style: solid;\r\n    border-bottom-color: rgb(217, 217, 217);\r\n    background-color: #333;\r\n    color: #333;\r\n}\r\n\r\n.theme-header .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n.theme-footer .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n\r\nbutton {\r\n\tmargin-right: 5px;\r\n\tbackground-color: #fff;\r\n}\r\n\r\n.table-responsive{\r\n\ttop:20px;\r\n}\r\n\r\n/* texto */\r\n.text-primary {\r\n    color: #fff;\r\n    top: 20px;\r\n}\r\n.text-primary-important {\r\n\tcolor: #fff!important;\r\n}\r\n.text-warning {\r\n\tcolor: #fff;\r\n}\r\n.text-warning-important {\r\n\tcolor: #fff!important;\r\n}\r\n.text-success {\r\n\tcolor: #fff;\r\n}\r\n.text-success-important {\r\n\tcolor: #fff!important;\r\n}\r\n.text-black {\r\n\tcolor: #fff;\r\n\tfont-weight: 100;\r\n}\r\n.text-purple {\r\n\tcolor: #fff;\r\n\tfont-weight: 100;\r\n}\r\n.text-laranja {\r\n\tcolor: #fff;\r\n\tfont-weight: 100;\r\n}\r\n.text-info {\r\n\tcolor: #fff;\r\n\tfont-weight: 100;\r\n}\r\n.text-danger {\r\n\tcolor: #fff;\r\n\tfont-weight: 100;\r\n}\r\n\r\n/* Botoes */\r\n\r\n.btn {\r\n\tcolor: #fff;\r\n\tbackground: #222;\r\n\tborder: #222;\r\n}\r\n\r\n.btn-primary.btn-outline,\r\n.btn-primary,\r\n.btn-default,\r\n.btn-default.btn-outline,\r\n.btn-secondary.btn-outline,\r\n.btn-secondary,\r\n.btn-success,\r\n.btn-success.btn-outline,\r\n.btn-info,\r\n.btn-info.btn-outline,\r\n.btn-warning,\r\n.btn-warning.btn-outline,\r\n.btn-danger,\r\n.btn-danger.btn-outline\r\n{\r\n\tcolor: #fff;\r\n\tbackground-color: #222;\r\n\tborder-color: #222;\r\n}\r\n\r\n.btn-primary:hover,\r\n.btn-primary[disabled]:hover,\r\n.btn-primary.btn-outline:hover,\r\n.btn-default:hover,\r\n.btn-default[disabled]:hover,\r\n.btn-default.btn-outline:hover,\r\n.btn-secondary:hover,\r\n.btn-secondary.btn-outline:hover,\r\n.btn-secondary[disabled]:hover,\r\n.btn-success:hover,\r\n.btn-success.btn-outline:hover,\r\n.btn-success[disabled]:hover,\r\n.btn-info:hover,\r\n.btn-info.btn-outline:hover,\r\n.btn-info[disabled]:hover,\r\n.btn-warning:hover,\r\n.btn-warning.btn-outline:hover,\r\n.btn-warning[disabled]:hover,\r\n.btn-danger:hover,\r\n.btn-danger.btn-outline:hover\r\n.btn-danger[disabled]:hover\r\n {\r\n \tcolor: #fff;\r\n\tbackground-color: #555;\r\n\tborder-color: #555;\r\n}\r\n\r\n.theme-menu-container {\r\n\tborder-right: 1px solid #ADADAD;\r\n\theight: 100%;\r\n\tbackground-color: #000;\r\n}\r\n\r\n.theme-main-container.menu {\r\n\tborder-left: 0px;\r\n\tbackground-color: #000;\r\n\tmargin: 0px 0 50px 0px;\r\n}\r\n\r\n.theme-main {\r\n\t\tbackground-color: #000;\r\n\t\ttext-align: left;\r\n}\r\n\r\n.theme-app.tabbed .page-wrapper {\r\n\tmargin-top: 110px;\r\n}\r\n\r\n\r\n.theme-menu-item {\r\n\tborder-bottom: 0px!important;\r\n}\r\n\r\n.theme-menu-item-caption{\r\n\tcolor: #fff;\r\n}\r\n\r\ni.fa,\r\nlabel{\r\n\tcolor: #fff;\r\n}\r\n\r\na,\r\na:hover{\r\n\tcolor: #fff333;\r\n}\r\n\r\n.table-striped > tbody > tr:nth-of-type(odd){\r\n\tbackground-color: #333;\r\n}\r\n\r\n.table-striped > tbody > tr:hover,\r\n.nav-tabs>li>a:hover,\r\n.nav>li>a:hover{\r\n\tbackground-color: #555;\r\n\tcolor: #fff;\r\n}\t\r\n\r\n.progress-bar{\r\n\tbackground-color: #666;\r\n\tborder-color: #fff\r\n}\r\n\r\n.pagination>.active>a,\r\n.pagination>.active>a:hover{\r\n\tbackground-color: #333;\r\n\tborder-color: #333\r\n}\r\n\r\n.pagination>li>a,\r\n.pagination>li>a:hover{\r\n\tbackground-color: #666;\r\n\tborder-color: #666;\r\n\tcolor: #fff;\r\n}\r\n\r\n.form-control,\r\n.input-group-addon:first-child{\r\n\tbackground-color: #333;\r\n\tborder-color: #fff;\r\n\tcolor: #fff;\r\n}\r\n\r\n.table-bordered{\r\n\tborder: none;\r\n}\r\n\r\n.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, \r\n.table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, \r\n.table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th{\r\n\tcolor: #fff;\r\n\tborder-top: 1px solid #fff;\r\n}\r\n\r\n.btn-primary.active,\r\n.btn-primary.active:hover{\r\n\tbackground-color: #666;\r\n\tborder-color: #fff;\r\n}\r\n\r\n.panel-primary>.panel-heading {\r\n    color:#fff;\r\n    background-color: #555;\r\n    border-color: #fff;\r\n}\r\n\r\n.panel-primary>.panel-footer {\r\n    background-color: #333;\r\n    border-color: #fff;\r\n}\r\n\r\n.panel-primary {\r\n    border-color: #fff;\r\n}\r\n\r\n.tabs-nav .active {\r\n    background-color: #333;\r\n    color: #fff;\r\n}\r\n\r\n.tabs-nav a {\r\n\tbackground-color: #666;\r\n    color: #fff;\r\n}\r\n\r\n\r\n/* Material Design Switch */\r\n.material-switch-contraste-contraste {\r\n\tmargin-top: 5px;\r\n}\r\n.material-switch-contraste > input[type=\"checkbox\"] {\r\n\tdisplay: none;\r\n}\r\n\r\n.material-switch-contraste > label {\r\n\tcursor: pointer;\r\n\theight: 0px;\r\n\tposition: relative;\r\n\twidth: 40px;\r\n\ttop:-20px;\r\n}\r\n\r\n.material-switch-contraste > label::before {\r\n\tleft: 0px;\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\tborder-radius: 8px;\r\n\tcontent: '';\r\n\theight: 13px;\r\n\tmargin-top: 3px;\r\n\tposition:absolute;\r\n\topacity: 0.3;\r\n\ttransition: all 0.4s ease-in-out;\r\n\twidth: 34px;\r\n\ttop: 11px;\r\n}\r\n.material-switch-contraste > label::after {\r\n\tbackground: rgb(255, 255, 255);\r\n\tborder-radius: 16px;\r\n\tbox-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);\r\n\tcontent: '';\r\n\theight: 20px;\r\n\tmargin-left: -6px;\r\n\tposition: absolute;\r\n\ttop: 11px;\r\n\ttransition: all 0.3s ease-in-out;\r\n\twidth: 20px;\r\n}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::before {\r\n\tbackground: #fff;\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\topacity: 1;\r\n\twidth: 34px;\r\n}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::after {\r\n\tbackground: inherit;\r\n\tbox-shadow: 0px 0px 5px rgba(255, 255, 255, 0.5);\r\n\tleft: 20px;\r\n\theight: 20px;\r\n\twidth: 20px;\r\n}\r\n\r\n.breadcrumb{\r\n\tbackground-color: #333;\r\n}\r\n\r\n.breadcrumb>.active{\r\n\tcolor: #fff;\r\n}\r\n\r\n.col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, \r\n.col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, \r\n.col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, \r\n.col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, \r\n.col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, \r\n.col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, \r\n.col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9 {\r\n\tpadding-bottom: 0px;\r\n}\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n\tborder: none;\r\n\tmargin-bottom: 35px;\r\n}\r\n\r\n.rodape-atm{\r\n\tdisplay: none;\r\n}\r\n\r\n.caixa-azul{\r\n\tdisplay: none;\r\n}\r\n\r\n.theme-header-ATM{\r\n\tdisplay: none;\r\n}\r\n\r\n\r\n@media screen and (max-width: 768px){\r\n\r\n    div#menu-container {\r\n        position:  relative;\r\n        z-index: 9999;\r\n    }\r\n \t.navbar-fixed-bottom, .navbar-fixed-top{\r\n \t    z-index: 99999;\r\n \t}\r\n \tmodal-dialog.modal-md {\r\n    \tmargin: 200px 0 0 0;\r\n\t}\r\n}\r\n\r\n.slider-label{\r\n\tcolor:white;\r\n}\r\n\r\n\r\n.theme-main-chart {\r\n    text-align: center;\r\n    margin-top: 52px;\r\n}\r\n\r\n\r\napp-root .theme-app .theme-main-container {\r\n    margin: 149px 0 50px 0px;\r\n}\r\n\r\n.autoCompleteCredito{\r\n    display:none !important;\r\n    }\r\n\r\n@media screen and (min-width: 768px){\r\n\r\n    .overlay{\r\n        display:none!important;\r\n    }\r\n}\r\nlabel.switch-box-slider {\r\n    margin: 30px -14px 23px 10px;\r\n}\r\n\r\nlabel.switch-box-label.ng-scope {\r\n    margin: 19px 0px 23px 28px !important;\r\n}\r\n\r\ndiv.overlay{\r\n\tdisplay: none;\t\r\n}\r\n\r\ndiv.overlay{\r\n\tdisplay: none!important;\t\r\n}\r\n#btnEnviar i {\r\n\tfont-size:1em;\r\n}",
            "contraste": 20,
            "icon": "fa-dropbox",
            "id": 20,
            "name": "Caixa Material Contraste Preto",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "tema": 0,
            "value": "preto-theme-padrao.css"
        },
        {
            "contraste": 23,
            "icon": "fa-taxi",
            "id": 23,
            "name": "Federal",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "restrict": true,
            "tema": 7,
            "value": "preto-theme-federal.css"
        },
        {
            "contraste": 25,
            "icon": "fa-th-list",
            "id": 25,
            "name": "ATM Contraste Preto",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "tema": 8,
            "value": "preto-atm.css"
        },
        {
            "contraste": 27,
            "icon": "fa-globe",
            "id": 27,
            "name": "Caixa Portal Preto",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "tema": 10,
            "value": "preto-theme-portal.css"
        },
        {
            "content": "/*---------- fontes */\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN45__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN45__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: 500;\r\n\tfont-style: normal;\r\n}\r\n\r\n@font-face {\r\n\tfont-family: 'FuturaWeb';\r\n\tsrc: url('../lib/fonts/futura/FTN85__W.eot'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.eot?#iefix') format('embedded-opentype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff2'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.woff') format('woff'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.ttf') format('truetype'),\r\n\t\turl('../lib/fonts/futura/FTN85__W.svg#FuturaWeb') format('svg');\r\n\tfont-weight: bold;\r\n\tfont-style: normal;\r\n}\r\n\r\n/*---------- fontes */\r\n\r\n.theme-app {\r\n\tbackground-color: #fff;\r\n}\r\n\r\n.theme-header {\r\n\tbackground-color: #296fa7;\r\n\tborder-bottom: 3px solid #F39A00!important;\r\n}\r\n.theme-app.tabbed .theme-header {\r\n\tborder-bottom: none!important;\r\n}\r\n\r\n.theme-header-tabs {\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-header-right > .navbar-brand {\r\n\tcolor: #fff;\r\n\tpadding-right: 5px;\r\n}\r\n.theme-header-left > .navbar-brand {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-header-middle.navbar-brand{\r\n\tcolor: #fff;\r\n}\r\n.theme-header-tabs {\r\n\t    background-color: #fff;\r\n}\r\n\r\n.theme-header-tabs > li.active > a {\r\n\tbackground-color: #296fa7;\r\n\tcolor: #fff;\r\n}\r\n.theme-footer {\r\n\tbackground-color: #296fa7;\r\n\tborder-top: 3px solid #F39A00!important;\r\n}\r\n\r\n.theme-footer-right {\r\n\tpadding-right: 10px;\r\n}\r\n.theme-footer-middle {\r\n\r\n}\r\n.theme-footer-left {\r\n\tpadding-left: 10px;\r\n}\r\n\r\n.theme-header-left > a {\r\n\tbackground: url(../imgs/theme-padrao/caixab.png) no-repeat!important;\r\n\twidth: 112px;\r\n\theight: 24px;\r\n\tmargin-top: 20px!important;\r\n\tmargin-left: 10px!important;\r\n}\r\n\r\n.theme-header-left-caption {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.theme-header-title {\r\n\theight: 63px;\r\n}\r\n\r\n.form-group{\r\n\t/* top:20px; */\r\n}\r\n\r\n.theme-header-acessibilidade{\r\n\theight: 25px;\r\n\tbackground-color: #2ca5fe;\r\n}\r\n\r\n.theme-link-acessibilidade{\r\n\tposition: relative;\r\n\ttop: 3px;\r\n\tleft: 10px;\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-app.tabbed .theme-menu-container {\r\n    margin-top: 120px!important;\r\n}\r\n.theme-app .theme-menu-container {\r\n    margin-top: 80px!important;\r\n}\r\n\r\n.theme-app.collapse.in .theme-submenu-item > a {\r\n\tpadding-left: 20px;\r\n}\r\n\r\n.theme-app .theme-main-container {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 70px 0 50px 0px;\r\n}\r\n\r\n.theme-app.menu .theme-main-container {\r\n\tmargin: 10px 0 50px 0px;\r\n}\r\n\t\r\n@media (min-width: 768px) {\r\n\t.theme-app.tabbed .theme-menu-container {\r\n\t    margin-top: 20px!important;\r\n\t}\r\n\t.theme-app .theme-menu-container {\r\n\t    margin-top: 0px!important;\r\n\t}\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 15px!important;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tposition: fixed;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.menu .theme-main-container {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 50px 250px;\r\n\t}\r\n\r\n\t.theme-header-right {\r\n\t\tpadding-right: 15px;\r\n\t}\r\n\t\t\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 10px!important;\r\n\t}\r\n\r\n\r\n\r\n\t.theme-app.collapse.in  .page-wrapper {\r\n\t\tmargin: 65px 0 0 70px!important;\r\n\t}\r\n\r\n\t.theme-app.collapse.in .theme-menu-container {\r\n\t\tmargin-top: 0px!important;\r\n\t}\r\n\r\n\t.theme-main-container {\r\n\t\tmargin: 67px 0 0 70px;\r\n\t}\r\n\t.theme-menu-container {\r\n\t\tmargin-top: 3px!important;\r\n\t}\r\n}\r\n\r\n\r\n.sidebar-nav > .nav li > a.active {\r\n    margin: 0;\r\n    border-left: 4px solid #ffa100;\r\n    border-left-width: 4px;\r\n    border-left-style: solid;\r\n    border-left-color: #ffa100;\r\n    border-top: 1px solid #d9d9d9;\r\n    border-top-width: 1px;\r\n    border-top-style: solid;\r\n    border-top-color: rgb(217, 217, 217);\r\n    border-bottom: 1px solid #d9d9d9;\r\n    border-bottom-width: 1px;\r\n    border-bottom-style: solid;\r\n    border-bottom-color: rgb(217, 217, 217);\r\n    background-color: #f5f7f7;\r\n}\r\n\r\n.theme-header .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n.theme-footer .navbar-brand:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n\r\nbutton {\r\n\tmargin-right: 5px;\r\n}\r\n\r\n.table-responsive{\r\n\ttop:20px;\r\n}\r\n\r\n/* texto */\r\n.text-primary {\r\n\tcolor: #296fa7;\r\n}\r\n.text-primary-important {\r\n\tcolor: #296fa7!important;\r\n}\r\n.text-warning {\r\n\tcolor: #ffa100;\r\n}\r\n.text-warning-important {\r\n\tcolor: #ffa100!important;\r\n}\r\n.text-success {\r\n\tcolor: #3c763d;\r\n}\r\n.text-success-important {\r\n\tcolor: #3c763d!important;\r\n}\r\n.text-black {\r\n\tcolor: #464646;\r\n\tfont-weight: 100;\r\n}\r\n.text-purple {\r\n\tcolor: #494d62;\r\n\tfont-weight: 100;\r\n}\r\n.text-laranja {\r\n\tcolor: #ffa100;\r\n\tfont-weight: 100;\r\n}\r\n.text-info {\r\n\tcolor: #c0b723;\r\n\tfont-weight: 100;\r\n}\r\n.text-danger {\r\n\tcolor: #920A04;\r\n\tfont-weight: 100;\r\n}\r\n\r\n/* Botoes */\r\n.btn-outline {\r\n\tcolor: inherit;\r\n\tbackground-color: transparent;\r\n\ttransition: all .5s;\r\n}\r\n\r\n.btn-primary.btn-outline {\r\n\tcolor: #428bca;\r\n}\r\n\r\n.btn-success.btn-outline {\r\n\tcolor: #5cb85c;\r\n}\r\n\r\n.btn-info.btn-outline {\r\n\tcolor: #5bc0de;\r\n}\r\n\r\n.btn-warning.btn-outline {\r\n\tcolor: #f0ad4e;\r\n}\r\n\r\n.btn-danger.btn-outline {\r\n\tcolor: #d9534f;\r\n}\r\n\r\n.btn-primary.btn-outline:hover,\r\n.btn-success.btn-outline:hover,\r\n.btn-info.btn-outline:hover,\r\n.btn-warning.btn-outline:hover,\r\n.btn-danger.btn-outline:hover {\r\n\tcolor: #fff;\r\n}\r\n\r\n.theme-menu-container {\r\n\tborder-right: 1px solid #ADADAD;\r\n\theight: 100%;\r\n\tbackground: #fff;\r\n}\r\n\r\n.theme-main-container.menu {\r\n\tborder-left: 0px;\r\n\tbackground-color: transparent;\r\n\tmargin: 0px 0 50px 0px;\r\n}\r\n\r\n.theme-app.tabbed .page-wrapper {\r\n\tmargin-top: 110px;\r\n}\r\n\r\n\r\n.theme-menu-item {\r\n\tborder-bottom: 0px!important;\r\n}\r\n\r\n.table-bordered{\r\n\tborder: none;\r\n}\r\n\r\n.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, \r\n.table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, \r\n.table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th{\r\n\tborder-top: 1px solid #ccc;\r\n}\r\n\r\n/* Material Design Switch */\r\n.material-switch-contraste-contraste {\r\n\tmargin-top: 5px;\r\n}\r\n.material-switch-contraste > input[type=\"checkbox\"] {\r\n\tdisplay: none;\r\n}\r\n\r\n.material-switch-contraste > label {\r\n\tcursor: pointer;\r\n\theight: 0px;\r\n\tposition: relative;\r\n\twidth: 40px;\r\n\ttop: -20px;\r\n}\r\n\r\n.material-switch-contraste > label::before {\r\n\tleft: 0px;\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\tborder-radius: 8px;\r\n\tcontent: '';\r\n\theight: 13px;\r\n\tposition:absolute;\r\n\topacity: 0.3;\r\n\ttransition: all 0.4s ease-in-out;\r\n\twidth: 34px;\r\n\ttop: 14px;\r\n}\r\n.material-switch-contraste > label::after {\r\n\tbackground: rgb(255, 255, 255);\r\n\tborder-radius: 16px;\r\n\tbox-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);\r\n\tcontent: '';\r\n\theight: 20px;\r\n\tleft: 0px;\r\n\tposition: absolute;\r\n\ttop: 11px;\r\n\ttransition: all 0.3s ease-in-out;\r\n\twidth: 20px;\r\n}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::before {\r\n\tbackground: rgb(0, 0, 0);\r\n\tbox-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n\topacity: 0.1;\r\n}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::after {\r\n\tbackground: inherit;\r\n\tbox-shadow: 0px 0px 5px rgba(255, 255, 255, 0.5);\r\n\tleft: 20px;\r\n}\r\n\r\n.breadcrumb{\r\n\tmargin-top: 10px;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none!important;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n}\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none!important;\r\n}\r\n\r\n\r\n\r\n\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n/*---------------------------------------------- TEMPLATE INTRANET 2018 -------------------------------------------------*/\r\n/*----------------------------------------------------------------------------------------------------------------*/\r\n\r\n\r\n/*-----geral-----*/\r\n\r\n.theme-header-acessibilidade {background-color: #3A4859;}\r\n\r\n.theme-header-acessibilidade a {color: #C2DC26;}\r\n\r\n.theme-app {background-color: black;}\r\n\r\n.material-switch-contraste > input[type=\"checkbox\"]:checked + label::before {\r\n    background: #EFF5F6;\r\n    box-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);\r\n}\r\n\r\n/*-----cabecalho-----*/\r\n\r\n.theme-header {\r\n\tborder-bottom: 3px solid white !important;\r\n\tbackground-image: none;\r\n\tbackground-color: black;\r\n\twidth: 100%;\r\n\tbox-sizing: border-box !important;\r\n}\r\n\r\n.theme-header-right-title {\r\n\tmargin-top: 5px;\r\n\tmargin-right: 25px;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.navbar-left.theme-header-left {\r\n\theight: 63px !important;\r\n\tbackground-image: url(../imgs/theme-intranet/logo_caixa.png) !important;\r\n\tbackground-repeat: no-repeat !important;\r\n\tbackground-position: center left !important;\r\n\tmargin: 0 !important;\r\n\tpadding: 0 !important;\r\n\tmargin-left: 15% !important;\r\n}\r\n\r\n.theme-header-left a {background: none !important;}\r\n\r\n.navbar-brand  {padding-right: inherit !important;}\r\n\r\n.navbar-brand[title^=\"Avalia��o\"]  {padding-right: inherit !important;}\r\n\r\n.navbar-toggle {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n\tborder: none;\r\n}\r\n\t\r\n.navbar-toggle i {\r\n\twidth: 20px;\r\n\theight: 20px;\r\n\tmargin-right: 36px;\r\n}\r\n\r\n.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:active, \r\n.navbar-default .navbar-toggle:focus, .nav li a:hover, .nav li a:active, .nav li a:focus {background: none;}\r\n\r\n/*-----rodape-----*/\r\n\r\n.theme-footer {\r\n\tborder-top: 3px solid white !important;\r\n\tbackground-color: black !important;\r\n\tbackground-image: none;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n/*-----menu horizontal-----*/\r\n\r\nul[ng-hide=\"currentview.telainicial\"] {\r\n\theight: 43px;\r\n\tborder-top: 3px solid white !important;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px;\r\n\tborder-bottom: 1px solid white;\r\n\tbackground-color: black;\r\n\tbox-sizing: border-box !important;\r\n}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li {\r\n\t/display: inline-block !important;\r\n\tpadding-top: 10px;\r\n\tpadding-bottom: 10px;\r\n\theight: 100%;\r\n}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li a {\r\n\tcolor: white;\r\n\tborder-right: 1px solid white !important;\r\n\tborder-radius: 0;\r\n\tdisplay: inline-block !important;\r\n\tpadding-top: 0 !important;\r\n\theight: 16px !important;\r\n\tline-height: 1 !important;\r\n}\r\n\r\n.nav .open>a, .nav .open>a:focus,.nav .open>a:hover {\r\n\tbackground: none;\r\n\tborder: none;\r\n}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li a:hover{\r\n\tcolor: #C2DC26;\r\n\tborder-color: black;\r\n\tborder-right: 1px solid white !important;\r\n\tborder-radius: 0;\r\n\tdisplay: inline-block !important;\r\n\tbox-sizing: border-box;\r\n\tpadding-top: 0 !important;\r\n\theight: 16px !important;\r\n\tline-height: 1 !important;\r\n}\r\n\r\nul.theme-header-tabs > li:last-child a {border: none !important;}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li a i {display: none;}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li ul {\r\n\tbackground-color: black;\r\n\tborder: 1px solid white;\r\n}\r\n\r\nul[ng-hide=\"currentview.telainicial\"] li ul li a {\r\n\tborder: none !important;\r\n\tcolor: white;\r\n}\r\n\r\n/*-----menu vertical-----*/\r\n\r\n.sidebar-nav .nav li a.active {\r\n\tborder: none;\r\n\tcolor: black;\r\n\tfont-size: 13px;\r\n\tbackground: #EFF5F6;\r\n\tbackground: -moz-linear-gradient(left, #EFF5F6 1%, #B3C7CB 100%);\r\n\tbackground: -webkit-linear-gradient(left, #EFF5F6 1%, #B3C7CB 100%);\r\n\tbackground: linear-gradient(to right, #EFF5F6 1%, #B3C7CB 100%);\r\n\tfilter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#EFF5F6', endColorstr='#B3C7CB',GradientType=1 );\r\n}\r\n\r\n.sidebar, .sidebar-nav {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-weight: bold;\r\n\tbackground-color: black;\r\n\twidth: 217px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li {padding:0;}\r\n\r\n.sidebar-nav .nav li a {\r\n\tcolor: white;\r\n\tfont-size: 14px;\r\n\tdisplay: block;\r\n\tpadding-left: 16px;\r\n\tline-height: 23.5px;\r\n\tmin-height: 47px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li a:hover {color: #C2DC26;}\r\n\r\n.sidebar-nav .nav li a.active:hover {color: black;}\r\n\r\n.sidebar-nav .nav li a i {display: none;}\r\n\r\n.sidebar-nav .nav li.open > a {background-color: #F4F4F4; display: block;}\r\n\r\n.sidebar-nav .nav li > a[aria-expanded=\"true\"] {\r\n\tcolor: white;\r\n\tfont-size: 13px;\r\n\tbackground-color: #3A4859;\r\n}\r\n\r\n.sidebar-nav .nav li > a[aria-expanded=\"true\"]:hover {color:#C2DC26;}\r\n\r\n.sidebar-nav .nav li ul li a {\r\n\tbackground-image: none !important;\r\n\tbackground-color: black !important;\r\n\tcolor: white !important;\r\n\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tpadding-left: 28px;\r\n\tline-height: 16px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.sidebar-nav .nav li ul li a:hover {color:#C2DC26 !important;}\r\n\r\n.sidebar-nav .nav li ul li a.active {\r\n\tfont-size: 12px;\r\n\tbackground-color: #B3C7CB !important;\r\n\tcolor: black !important;\r\n}\r\n\r\n.sidebar-nav .nav li ul li a.active span {\r\n\tposition:relative;\r\n\tleft: -4px;\r\n}\r\n\r\n/*-----carrossel-----*/\r\n\r\n.carousel {margin: 16px 16px 0 0;}\r\n\r\n.carousel-indicators li, .carousel-indicators .active {\r\n\tmargin: 16px 9px;\r\n\tborder-color: #9aacaf;\r\n\tbackground-color: #9aacaf;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.carousel-indicators .active {\r\n\tborder-color: #C2DC26;\r\n\tbackground-color: #C2DC26;\r\n\twidth: 7px;\r\n\theight: 7px;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nol.carousel-indicators {\r\n\tposition: static;\r\n\tlist-style: none;\r\n\tmargin: 0 auto;\r\n}\r\n\r\n.carousel-caption {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px;\r\n\tbackground: none;\r\n\tmargin-bottom: 28px;\r\n\tmargin-left: 31px;\r\n\tpadding: 0;\r\n\ttext-shadow: none;\r\n\tcolor: black;\r\n}\r\n\r\n.carousel-control {display: none;}\r\n\r\n.carousel-caption h4 {font-weight: bold; margin-bottom: 6px;}\r\n\r\n.carousel-caption p {margin-left: 16px; margin-bottom: 0;}\r\n\r\n.carousel-caption h4:before {\r\n\tcontent:'\\0025E3';\r\n\tfont-size: 12px;\r\n\tmargin-right: 6px;\r\n\tcolor: #C2DC26;\r\n}\r\n\r\n/*-----texto-----*/\r\n\r\n.text-primary, .text-primary-important, .text-warning,\r\n.text-warning-important, .text-success, .text-success-important,\r\n.text-default, .text-black, .text-purple, .text-laranja, .text-info,\r\n.text-danger {\r\n\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\tcolor: white !important;\r\n\tfont-weight: 100;\r\n}\r\n\r\ndiv.theme-main-list label,\r\nh5.theme-main-push-status {\r\n\tcolor: white;\r\n\tfont-weight: normal;\r\n\tfont-size: 13px;\r\n\tline-height: 16px;\r\n\tpadding: 0;\r\n\tmargin: 0 0 5px 0;\r\n}\r\n\r\nh5.theme-main-h4, h6.theme-main-h6 {\r\n\tfont-weight: bold;\r\n\tline-height: 1;\r\n\tcolor: white;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 20px !important;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tmargin-top: 0;\r\n}\r\n\r\nh5.theme-main-h4 {\r\n\tborder-bottom: 1px solid white;\r\n\tpadding-bottom: 6px;\r\n\tmargin-bottom: 30px;\r\n}\r\n\r\nh6.theme-main-h6 {\r\n\tfont-size: 14px !important;\r\n\tmargin-bottom: 12px;\r\n}\r\n\r\n/*-----tabelas-----*/\r\n\r\nthead tr th {\r\n\tbackground-color: black;\r\n\tcolor: white;\r\n\tfont-size: 13px !important;\r\n\tborder-top: none !important;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tvertical-align: bottom;\r\n    border-bottom: 2px solid white !important;\r\n\theight: 35px;\r\n\tfont-size: 14px;\r\n\tpadding: 8px !important;\r\n\tline-height: 13px !important;\r\n}\r\n\r\ntbody tr td {\r\n\tcolor: white;\r\n\tline-height: 1.428571429;\r\n\tvertical-align: top;\r\n\tborder-top: 1px solid white;\r\n\tborder-right: none !important;\r\n\tborder-left: none !important;\r\n\tborder-bottom: none !important;\r\n\theight: 35px !important;\r\n\tfont-size: 13px;\r\n\tpadding: 8px !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ntbody tr:nth-child(odd),\r\ntbody tr:nth-child(odd):hover {background-color: #3A4859 !important;}\r\n\r\ntbody tr:nth-child(even),\r\ntbody tr:nth-child(even):hover {background-color: black;}\r\n\r\ntd button {\r\n\tbackground: none;\r\n\tmargin:0 !important;\r\n\tpadding:0!important;\r\n}\r\n\r\ntd button:hover {\r\n\tcolor: white !important;\r\n}\r\n\r\n/*-----inputs-----*/\r\n\r\ndiv.form-group {\r\n\tpadding: 0;\r\n\tmargin-bottom: 20px !important;\r\n\tdisplay: inline-block;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.form-control {\r\n\tbox-shadow:none;\r\n}\r\n\r\ndiv.form-group label {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tline-height: 16px;\r\n\tcolor: white;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 0;\r\n\tline-height: 1;\r\n}\r\n\r\ndiv.input-group {\r\n\twidth: inherit;\r\n\theight: 34px;\r\n\tmin-width: 100%;\r\n    padding-right: 30px;\r\n}\r\n\r\ndiv.input-group input:focus {\r\n\tborder-color: white;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.input-group input {\r\n\tbackground-color: transparent;\r\n\tcolor: white;\r\n\tfont-size: 12px !important;\r\n\tborder-bottom: 1px solid white;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding: 13px 0 5px 0 !important;\r\n}\r\n\r\ndiv.input-group input[type=\"file\"] {\r\n\tcolor:black;\r\n}\r\n\r\ndiv.theme-main-input-radio label  {\r\n\tfont-weight: normal;\r\n\tfont-size: 14px;\r\n\tcolor: white;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tmargin-bottom: 2px;\r\n}\r\n\r\ndiv.input-group input::-webkit-input-placeholder {color: #9aacaf;}\r\ndiv.input-group input:-moz-placeholder {color: #9aacaf;}\r\ndiv.input-group input::-moz-placeholder {color: #9aacaf;}\r\ndiv.input-group input:-ms-input-placeholder {color: #9aacaf;}\r\ndiv.input-group input::-ms-input-placeholder {color: #9aacaf;}\r\n\r\nspan.input-group-addon {display: none;}\r\n\r\n.form-control[disabled],\r\n.form-control[readonly],\r\nfieldset[disabled] .form-control,\r\n.form-control[disabled]:active,\r\n.form-control[readonly]:active,\r\nfieldset[disabled] .form-control:active,\r\n.form-control[disabled]:focus,\r\n.form-control[readonly]:focus,\r\nfieldset[disabled] .form-control:focus\r\n {\r\n\tbackground-color: rgba(0,0,0,0);\r\n\tcolor: #9aacaf !important;\r\n\tborder-bottom-color: #9aacaf;\r\n}\r\n\r\n.form-control[disabled] > label.label-mobilidade,\r\n.form-control[readonly] > label.label-mobilidade,\r\nfieldset[disabled] .form-control > label.label-mobilidade {\r\n\tcolor: #9aacaf !important;\r\n}\r\n\r\n/*-----combo box-----*/\r\n\r\n.theme-main-input-select label {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tfont-weight: normal !important;\r\n\tcolor: #B3C7CB;\r\n\tmargin-bottom: 2px !important;\r\n}\r\n\r\n.input-group select {\r\n\t-webkit-appearance: none;\r\n\t-moz-appearance: none;\r\n\tappearance: none;\r\n\tbackground: url('../imgs/theme-intranet/seta-combox-intranetpreto.png') no-repeat top right;\r\n\tborder-radius: 0;\r\n\tborder-top: none;\r\n\tborder-right: none;\r\n\tborder-bottom: 1px solid white;\r\n\tborder-left: none;\r\n\tpadding: 0 0 10px 0;\r\n\theight: 26px;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 6px !important;\r\n\tbox-sizing: border-box;\r\n\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 12px !important;\r\n\tline-height: 12px;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.input-group select:focus {border-color: white; box-shadow: none;}\r\n\r\n.input-group select::placeholder {color: white !important;}\r\n\r\n/*-----transicao labels-----*/\r\n\r\ninput.form-control ~ label {\r\n\tmargin-top:0;\r\n\tposition:absolute;\r\n\ttop:-5px;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n\tfont-size:12px !important;\r\n\tcolor: white;\r\n}\r\n\r\ninput.form-control {\r\n    margin-top:0px !important;\r\n    transition:0.3s;\r\n    color: white !important;\r\n}\r\n\r\ninput.form-control:placeholder-shown ~ label{\r\n    transition:0.3s;\r\n    top:5px;\r\n\tfont-size:14px!important;\r\n}\r\n\r\ninput.form-control:placeholder{\r\n    opacity:0;\r\n    color:transparent;\r\n}\r\n\r\nlabel{\r\n\tfont-size:12px !important;\r\n\ttransition:0.3s;\r\n}\r\n\r\n.form-control::-webkit-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n.form-control::-moz-placeholder {opacity:0;\r\n    color:transparent;}\r\n.form-control:-ms-input-placeholder {opacity:0;\r\n    color:transparent; }\r\n\r\n\r\n.form-group label:nth-child(1) {\r\n   display: none;\r\n}\r\n.form-group .theme-main-input-select label:nth-child(1),\r\n.form-group.pick-list label:nth-child(1),\r\n.form-group.theme-main-input-select label:nth-child(1),\r\n.form-group.theme-main-text-area label:nth-child(1),\r\n.form-group.theme-main-input-check label:nth-child(1) {\r\n\tdisplay: block;\r\n}\r\n.theme-main-input-radio label:nth-child(1),\r\n#uplEscolhaoarquivo label {\r\n\tdisplay:block;\r\n}\r\n\r\n/*-----caixa de texto-----*/\r\n\r\ndiv.input-group textarea {\r\n\twidth: inherit;\r\n\tcolor: white;\r\n\tbackground-color: transparent;\r\n\tfont-size: 12px !important;\r\n\tborder-top, border-left, border-right: none;\r\n\tborder-bottom: 1px solid white;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.input-group textarea:focus {\r\n\tborder-color: white;\r\n\tbox-shadow: none;\r\n}\r\n\r\n\r\n.side-menubar {\r\n    display:none;\r\n}\r\n\r\n/*-----botoes-----*/\r\n\r\n.theme-main-button {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tmargin: 15px 26px 0 0 !important;\r\n}\r\n\r\n.btn-primary, .btn-warning {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white;\r\n\tcolor: black;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\n.btn-default, .btn-danger {\r\n\tbackground-color:black;\r\n\tborder: 1px solid white;\r\n\tcolor: white;\r\n\tfont-weight: normal;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n.btn-primary:hover,\r\n.btn-warning:hover,\r\n.btn-primary:active,\r\n.btn-warning:active,\r\n.btn-primary:focus,\r\n.btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:black !important;\r\n\tcolor:white!important;\r\n\tborder: 1px solid white !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 24px !important;\r\n\t/margin-left: 2px !important;\r\n}\t\r\n\r\n.theme-main-button[disabled=\"disabled\"],\r\n.theme-main-button[disabled=\"disabled\"]:hover,\r\n.theme-main-button[disabled=\"disabled\"]:focus {\r\n\tbackground-color:#d0e0e3 !important;\r\n\tborder-color:#d0e0e3 !important;\r\n\tcolor:white; opacity:1 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton#optOpces {background-color: white;}\r\nbutton#optOpces.active {color:#48586C;}\r\n\r\nbutton.btn-default,\r\nbutton.theme-main-button-subscribe,\r\nbutton.theme-main-button-unsubscribe {\r\n\tbox-sizing: border-box;\r\n\tcolor:white;\r\n\tbackground-color: black;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tmargin-left: 0 !important;\r\n\tmargin-right: 26px !important;\r\n\tborder: 1px solid white;\r\n}\r\n\r\nbutton.btn-default:hover,\r\nbutton.theme-main-button-subscribe:hover,\r\nbutton.theme-main-button-unsubscribe:hover,\r\nbutton.btn-default:active,\r\nbutton.theme-main-button-subscribe:active,\r\nbutton.theme-main-button-unsubscribe:active,\r\nbutton.btn-default:focus,\r\nbutton.theme-main-button-subscribe:focus,\r\nbutton.theme-main-button-unsubscribe:focus {\r\n\tcolor: black !important;\r\n\tbackground-color: #9aacaf !important;\r\n\tborder: 1px solid #9aacaf !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 26px !important;\r\n\tmargin-left: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\nbutton.theme-main-button-subscribe:first-child {\r\n\tmargin-left:0;\r\n}\r\n\r\nbutton#btnEnviar {\r\n\tfont-size:0.5em;\r\n}\r\n\r\n#btnEnviar:hover, #btnEnviar:active, #btnEnviar:focus {\r\n\tdisplay: block !important;\r\n\tmargin-right: auto !important;\r\n\tmargin-left: auto !important;\r\n\tmargin-bottom: 0 !important;\r\n\tbox-sizing: border-box;\r\n\theight: 38px;\r\n}\r\n\r\n/*-----botao imagem-----*/\r\n\r\na.theme-main-img-button {\r\n\tmargin-bottom: 0;\r\n}\r\n\r\nspan.theme-main-img-button-label {\r\n\tcolor: #C2DC26;\r\n}\r\n\r\nspan.theme-main-img-button-label:hover,\r\na.theme-main-img-button:hover {\r\n\tcolor: #C2DC26;\r\n\ttext-decoration: underline !important;\r\n}\r\n\r\n/*-----radio-----*/\r\n\r\ndiv.theme-main-input-radio {\r\n\tpadding: 0;\r\n}\r\n\r\ndiv.theme-main-input-radio button {\r\n\tcolor: white;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 11px !important;\r\n\tborder: 1px solid white;\r\n\topacity: 1 !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n\tborder-radius: 3px;\r\n\tpadding: 0 9px;\r\n\r\n}\r\n\r\ndiv.theme-main-input-radio button:hover {\r\n\tbackground-color: #9aacaf !important;\r\n\tborder: 1px solid #9aacaf !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active,\r\ndiv.theme-main-input-radio button.active:active,\r\ndiv.theme-main-input-radio button.active:focus {\r\n\tcolor: black !important;\r\n\tbackground-color: white !important;\r\n\tborder: 1px solid white !important;\r\n\tbox-shadow: none;\r\n\tfont-weight: normal;\r\n\theight: 23px;\r\n\tmin-width: 54px;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\r\ndiv.theme-main-input-radio button.active:hover {\r\n\tbackground-color: black !important;\r\n\tborder: 1px solid white !important;\r\n\tcolor: white !important;\r\n\tmargin: 0 9px 5px 0 !important;\r\n}\r\n\t\r\n/*-----checkbox-----*/\r\n\t\r\n.input-group {margin-bottom: 0px;}\r\n\r\n.input-group > label {\r\n\tdisplay: block;\r\n\t/color: #48586C;\r\n\t/height: 20px;\r\n\t/margin: 0 14px 5px 0;\r\n}\r\n\r\n.theme-main-input-check div.input-group label {\r\n\tcolor:white;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*-----breadcrumb-----*/\r\n\r\nol.breadcrumb {\r\n\tbackground-color: black;\r\n\tpadding-left: 0;\r\n\tpadding-right: 0;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\nol.breadcrumb li a {color: #C2DC26; text-decoration: underline;}\r\n\r\nol.breadcrumb:before {\r\n\tcontent: 'Voc\\00ea  est\\00e1  em';\r\n\tfont-weight: bold;\r\n\tpadding-right: 8px;\r\n}\r\n\r\nol.breadcrumb li:before {content:''; padding-left:0 !important;}\r\n\r\nol.breadcrumb li:after {content:'\\0023F5'; padding-left:1ch;}\r\n\r\nol.breadcrumb li:last-child:after {content:'';}\r\n\r\nol.breadcrumb li span {color: #9aacaf;}\r\n\r\n/*-----navbar-----*/\r\n\r\n.navbar-brand-middle {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 18px;\r\n\tpadding-top: 22px;\r\n}\r\n\r\n/*-----links-----*/\r\n\r\n.theme-main-link a {\r\n\tcolor: #C2DC26;\r\n\tfont-size: 11px;\r\n\ttext-decoration: none !important;\r\n}\r\n\r\n.theme-main-link a:hover {\r\n\ttext-decoration: underline !important;\r\n}\r\n\r\n/*-----listagem-----*/\r\n\r\ndiv.theme-main-list {margin-top: 2em;}\r\n\r\ndiv.theme-main-list,\r\ndiv.theme-main-list div.text-left,\r\ndiv.theme-main-list div.text-right {padding: 0;}\r\n\r\n/*-----timer-----*/\r\n\r\n.theme-main-timer button,\r\n.theme-main-timer button:hover,\r\n.theme-main-timer button:active,\r\n.theme-main-timer button:focus {\r\n\tcolor:#B3C7CB;\r\n\tborder: 1px solid #B3C7CB;\r\n\tbackground-color: black;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n\r\n*:focus {outline: none !important;}\r\n\r\n\r\n.coluna-esquerda {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-direita {\r\n\tdisplay: none;\r\n}\r\n\r\n.coluna-central {\r\n\tdisplay: inline!important;\r\n\tborder: none;\r\n\tmargin-bottom: 35px;\r\n}\r\n\r\n.rodape-atm{\r\n\tdisplay: none;\r\n}\r\n\r\n.caixa-azul{\r\n\tdisplay: none;\r\n}\r\n\r\n.theme-header-ATM{\r\n\tdisplay: none;\r\n}\r\n\r\n.side-menubar{\r\n    display:none;\r\n}\r\n\r\n/*-----abas-----*/\r\n\r\n.tabs-nav a {background: black; color: white;}\r\n\r\n.tabs-nav .active {\r\n\tbackground-color: #B3C7CB !important;\r\n\tborder: 1px solid white;\r\n\tcolor: black;\r\n}\r\n\r\nul.tabs-nav {\r\n\tborder-bottom: 2px solid white;\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tpadding-bottom: 12px;\r\n}\r\n\r\nul.tabs-nav li {\r\n\tmargin: 0 20px -1px;\r\n}\r\n\r\n.tabs-nav li:first-child {\r\n    margin-left: 0 !important;\r\n}\r\n\r\nul.tabs-nav li a {\r\n\tbackground-color: black;\r\n\tborder: 1px solid white !important;\r\n\tborder-radius: 0;\r\n    /border: none !important;\r\n\tcolor: white !important;\r\n\tfont-size: 16px;\r\n\tfont-weight: bold;\r\n\tpadding: 9px 29px;\r\n\ttext-transform: uppercase;\r\n\tbox-sizing: border-box !important;\r\n    /height: 30px;\r\n}\r\n\r\nul.tabs-nav li a:hover {\r\n\tbackground-color: #9aacaf;\r\n\tcolor: black !important;\r\n\tborder: 1px solid #9aacaf !important;\r\n}\r\n\r\nul.tabs-nav li a.active {\r\n\tbackground-color: white !important;\r\n    border-radius: 0;\r\n    border: none !important;\r\n    color: black !important;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    padding: 10px 30px;\r\n    text-transform: uppercase;\r\n}\r\n\r\nul.tabs-nav li a.active:hover {\r\n\tcursor: default;\r\n}\r\n\r\ndiv.theme-main-tab .tab-content {\r\n\tmargin-top: 15px;\r\n}\r\n\r\n/*-----graficos-----*/\r\n\r\n.theme-main-chart label {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tcolor: white;\r\n\tfont-size: 18px !important;\r\n\tdisplay: block;\r\n\ttext-align: left;\r\n}\r\n\r\n.theme-main-chart text {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n[fill=\"#f0ad4e\"] {fill: #F39200;}\r\n[fill=\"#3c763d\"] {fill: #0E7639;}\r\n[fill=\"#277db6\"] {fill: #005CA9;}\r\n[fill=\"#5cb85c\"] {fill: #29C0B3;}\r\n[fill=\"#f1ca3a\"] {fill: #F9B000;}\r\n[text-anchor=\"start\"] {\r\n\tfont-weight: normal !important;\r\n\tfont-size: 13px !important;\r\n}\r\n\r\n/*-----paineis-----*/\r\n\r\n.theme-main-detail-panel {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary {border-color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-heading {\r\n\tbackground-color: #005CA9;\r\n\tborder-color: #005CA9;\r\n}\r\n\r\n.theme-main-detail-panel .panel-primary .panel-footer {color: #005CA9;}\r\n\r\n.theme-main-detail-panel .panel-warning {border-color: #F9B000;}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-heading {\r\n\tbackground-color: #F9B000;\r\n\tborder-color: #F9B000;\r\n}\r\n\r\n.theme-main-detail-panel .panel-warning .panel-footer {\r\n\tbackground-color: #EFF5F6;\r\n\tcolor: #F39200;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default {border-color: #B3C7CB;}\r\n\r\n.theme-main-detail-panel .panel-default .panel-heading {\r\n\tbackground-color: #EFF5F6;\r\n\tborder-color: #B3C7CB;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-default .panel-footer {\r\n\tbackground-color: white;\r\n\tcolor: #9aacaf;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger {border-color: #F51C1F;}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-heading {\r\n\tbackground-color: #F51C1F;\r\n\tborder-color: #F51C1F;\r\n}\r\n\r\n.theme-main-detail-panel .panel-danger .panel-footer {\r\n\tcolor: #F51C1F;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\n\r\n@media (min-width: 768px) {\r\n\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 26px;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    margin-right: 106px;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: white;\r\n    text-decoration: none;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid #76bad1;\r\n    padding: 3px 18px;\r\n    font-weight: bold;\r\n    box-sizing: border-box;\r\n    width: 80px;\r\n    height: 24px;\r\n}\r\n\r\n.item-sair-intranet a:hover {\r\n    text-decoration: underline;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.menu-item-intranet ul li a span {\r\n\tcolor: transparent;\r\n}\r\n\r\n.menu-item-intranet ul li.item-calendario-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/calendario_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-pesquisa-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/pesquisa_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.menu-item-intranet ul li.item-config-intranet {\r\n\tbackground-image: url(../imgs/theme-intranet/config_header.png);\r\n\tbackground-position: center;\r\n\tbackground-repeat: no-repeat;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: normal;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n    font-size: 13px !important;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n    position: absolute;\r\n    right: 18px;\r\n    border: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    width: 265px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n\tfont-size: 13px;\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #656565;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 15px;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 16px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 16px;\r\n    padding: 0 15px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 19px;\r\n}\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n/*-----componentes barra superior-----*/\r\n\r\nh2.navbar-usuario-intranet {\r\n    display: inline-block;\r\n    font-size:  18px !important;\r\n    color: white;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n    float: left;\r\n    margin-top: 24px !important;\r\n}\r\n\r\n\r\n.menu-item-intranet {\r\n    display: inline-block;\r\n    float: right;\r\n    /margin-right: 106px;\r\n    margin-right: 2%;\r\n}\r\n\r\n.menu-item-intranet ul {\r\n    list-style: none;\r\n}\r\n\r\n.menu-item-intranet ul li {\r\n\tfloat: right;\r\n\tmargin-top: 10px;\r\n\tcolor: white;\r\n\tpadding: 10px;\r\n}\r\n\r\n.menu-item-intranet ul li a {\r\n    color: aliceblue;\r\n    text-decoration: none;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n}\r\n\r\n.item-sair-intranet a {\r\n    border: 1px solid white;\r\n    padding: 3px 18px;\r\n}\r\n\r\nli.item-sair-intranet {\r\n    margin-top: 15px !important;\r\n}\r\n\r\n.menu-item-intranet ul li a span.fa {\r\n    font-size: 23px;\r\n}\r\n\r\n.pesquisa-intranet.sub-item {\r\n    display: none;\r\n    border-bottom: 1px solid #cfcfcf;\r\n    background-color: #fff;\r\n    padding: 17px 25px;\r\n    width: 504px;\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 88px;\r\n    z-index: 99;\r\n}\r\n\r\n.pesquisa-intranet form label {\r\n    font-weight: 400;\r\n    margin: 0;\r\n    margin-right: 9px;\r\n}\r\n\r\n.pesquisa-intranet input[type=text] {\r\n    border: 1px solid #b8b8b8;\r\n    border-radius: 3px;\r\n    line-height: 25px;\r\n    padding: 0 10px;\r\n}\r\n\r\n.pesquisa-intranet button {\r\n    background-color: #f9b000;\r\n    border: none;\r\n    border-radius: 3px;\r\n    color: #fff;\r\n    display: block;\r\n    float: right;\r\n    font-size: 14px;\r\n    height: 27px;\r\n    width: 98px;\r\n}\r\n\r\n\r\n.config-intranet.sub-item {\r\n\tdisplay:none;\r\n\tposition: absolute;\r\n\tright: 15%;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\twidth: 265px;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\n.config-intranet h5 {\r\n    border-bottom: 1px solid #c8c8c8;\r\n    color: #3A4859;\r\n    font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n    font-size: 13px !important;\r\n    line-height: 30px;\r\n    margin-bottom: 12px;\r\n    padding: 0 14px !important;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.config-intranet ul li a {\r\n    color: #48586c;\r\n    line-height: 18px;\r\n    padding-left: 24px;\r\n    font-size: 13px;\r\n}\r\n\r\n.config-intranet ul li {\r\n    margin-bottom: 14px;\r\n    padding: 0 14px;\r\n    width: 100%;\r\n    list-style: none;\r\n    text-decoration: none;\r\n}\r\n\r\n.config-intranet ul {\r\n    padding: 0;\r\n}\r\n\r\nspan.fa.fa-gear {\r\n    color: #63C1B2;\r\n    position: absolute;\r\n    font-size: 16px;\r\n}\r\n\r\n.overlay-intranet {\r\n    display: none;\r\n    background: rgba(0,0,0,.75);\r\n    height: 100%;\r\n    left: 0;\r\n    position: fixed;\r\n    top: 0;\r\n    width: 100%;\r\n    z-index: 133;\r\n}\r\n\r\n.navbar-right.theme-header-right{\r\n\tdisplay:none;\r\n}\r\n\r\n\r\n\r\n/*-----componente calendario-----*/\r\n\r\n .hasDatepicker .ui-datepicker-inline {\r\n  background: transparent;\r\n  border: none;\r\n  /padding: 1px;\r\n  width: auto;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header {\r\n  background-color: white;\r\n  border: none;\r\n  padding-top: 8px;\r\n  padding-bottom: 8px;\r\n  border-bottom: 1px solid #d2d2d2;\r\n  margin-bottom: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background-position: 50%;\r\n  background-repeat: no-repeat;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next .ui-icon,  .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev .ui-icon {\r\n  display: none;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-prev {\r\n  background: url(../imgs/theme-intranet/bt_anteriorMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-left: 16px;\r\n  padding: 0;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-next {\r\n  background: url(../imgs/theme-intranet/bt_proximoMes.png) no-repeat center;\r\n  display: inline-block;\r\n  width: 12px;\r\n  height: 12px;\r\n  margin: 0;\r\n  margin-right: 16px;\r\n  padding: 0;\r\n  float: right;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-header .ui-datepicker-title {\r\n  display: inline-block;\r\n  width: calc(100% - 56px);\r\n  margin: 0 auto !important;\r\n  margin-top: 0 !important;\r\n  color: #3A4859;\r\n  font-weight: 400;\r\n  text-transform: uppercase;\r\n  text-align: center;\r\n  vertical-align: top;\r\n  font-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif !important;\r\n  font-size: 14px;\r\n  line-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar thead tr th {\r\n  background-color: #EFF5F6;\r\n  color: #3A4859;\r\n  font-size: 13px !important;\r\n  font-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n  border-bottom: none !important;\r\n  vertical-align: middle;\r\n  text-align: center;\r\n  max-height: 1em;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td {\r\n  background-color: white;\r\n  border: none !important;\r\n  text-align: center;\r\n  vertical-align: middle;\r\n  padding: 0 !important;\r\n  height: 2em !important;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td a {\r\n  background-color: white;\r\n  border: none;\r\n  color: #3A4859;\r\n  font-size: 13px;\r\n  font-weight: 400;\r\n  text-align: center;\r\n}\r\n\r\n .hasDatepicker .ui-datepicker-inline .ui-datepicker-calendar tbody tr td.ui-datepicker-current-day a {\r\n  background-color: #54BBAB;\r\n  color: #fff;\r\n  /padding: .2em;\r\n  padding: 4px .35em;\r\n  font-weight: 700;\r\n}\r\n\r\n.calendario-intranet.sub-item {\r\n\tfont-family: \"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tborder: 1px solid #cfcfcf;\r\n\tbackground-color: #fff;\r\n\tpadding: 0;\r\n\tpadding-bottom: 12px;\r\n\twidth: 236px;\r\n\tposition: absolute;\r\n\tright: 13%;\r\n\ttop: 88px;\r\n\tz-index: 99;\r\n}\r\n\r\ntd.ui-datepicker-week-end {\r\n    border: none !important;\r\n}\r\n\r\n.evento-intranet h5 {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tborder-top: 1px solid #d2d2d2;\r\n\tborder-bottom: 1px solid #d2d2d2;\r\n\ttext-align: center;\r\n\tpadding: 9px 0;\r\n\ttext-transform: uppercase;\r\n\tvertical-align: middle !important;\r\n}\r\n\r\n.conteudo-intranet {\r\n    box-sizing: content-box;\r\n    padding: 0 12px;\r\n}\r\n\r\n.evento-intranet a.verMais {\r\n    color: #54BBAB;\r\n    font-size: 11px;\r\n    font-weight: 700;\r\n    padding-left: 10px;\r\n    position: relative;\r\n}\r\n\r\n.evento-intranet a.verMais:before {\r\n    border-top: 3px solid transparent;\r\n    border-bottom: 3px solid transparent;\r\n    border-left: 4px solid #54BBAB;\r\n    content: \" \";\r\n    left: 0;\r\n    position: absolute;\r\n    top: 3px;\r\n}\r\n\r\n.ui-datepicker-calendar {\r\n\twidth: calc(100% - 32px);\r\n\tmargin: 0 auto;\r\n}\r\n\r\n/*-----titulo-----*/\r\n\r\ndiv.theme-header-title span.navbar-brand {\r\n\tdisplay: none;\r\n}\r\n\r\n/*-----header botoes a direita-----*/\r\n\r\n.theme-header-right {\r\n\tdisplay: block !important;\r\n}\r\n\r\n/*-----picklist-----*/\r\n\r\nselect[data-picklist-src], select[data-picklist-dest] {\r\n\tpadding: 2px 1px 1px 6px;\r\n\tbackground-color: transparent;\r\n\tbox-shadow: none;\r\n\tborder-radius: 0;\r\n\tcolor: #3A4859;\r\n    font-size: 12px !important;\r\n    background-color: white;\r\n}\r\n\r\nselect[data-picklist-src]:focus, select[data-picklist-dest]:focus {\r\n\tbox-shadow: none;\r\n\tborder-color: transparent;\r\n}\r\n\r\n/*-----mensagem push-----*/\r\n\r\ndiv.analytics-wizard-container .form-group textarea {\r\n\twidth: inherit;\r\n\tcolor: #3A4859;\r\n\tfont-size: 12px !important;\r\n\tborder-top, border-left, border-right: none;\r\n\tborder-bottom: 1px solid #54BBAB;\r\n\tborder-top: none;\r\n\tborder-left: none;\r\n\tborder-right: none;\r\n\tborder-radius: 0;\r\n\tpadding-bottom: 7px;\r\n\tpadding-left: 0;\r\n\tmargin-bottom: 21px !important;\r\n\tmargin-top: 0 !important;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\ndiv.analytics-wizard-container .form-group textarea:focus {\r\n\tborder-color: #54BBAB;\r\n\tbox-shadow: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .input-group-addon {\r\n\tdisplay: none;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary,\r\ndiv.analytics-wizard-container .btn-warning {\r\n\tfont-family: \"FuturaWeb\",\"Helvetica Neue\",Helvetica,Arial,sans-serif;\r\n\tfont-size: 14px !important;\r\n\tline-height: 14px;\r\n\theight: 45px;\r\n\tmin-width: 149px;\r\n\tbox-sizing: border-box;\r\n\tbackground-color:#F9B000;\r\n\tborder: 0;\r\n\tfont-weight: bolder;\r\n}\r\n\r\ndiv.analytics-wizard-container .btn-primary:hover,\r\ndiv.analytics-wizard-container .btn-warning:hover,\r\ndiv.analytics-wizard-container .btn-primary:active,\r\ndiv.analytics-wizard-container .btn-warning:active,\r\ndiv.analytics-wizard-container .btn-primary:focus,\r\ndiv.analytics-wizard-container .btn-warning:focus {\r\n\tbox-sizing: border-box;\r\n\tbackground-color:white !important;\r\n\tcolor:#F9B000 !important;\r\n\tborder: 1px solid #F9B000 !important;\r\n\tbox-shadow: none !important;\r\n\tmargin-right: 5px !important;\r\n}\r\n\r\n/*-----switcher-----*/\r\n\r\n.switch-box .switch-box-input ~ .switch-box-label {\r\n\tcolor: white !important;\r\n}\r\n\r\n.switch-box .switch-box-input:checked ~ .switch-box-label {\r\n    color: #1abc9c !important;\r\n}\r\n\r\n/*-----fieldset-----*/\r\n\r\np.fieldset-title-atm {color: white;}\r\n\r\n/*-----form group-----*/\r\n\r\nlabel.form-group {\r\n\tcolor: white;\r\n}\r\n\r\n/*-----modal------*/\r\n\r\n.modal-footer button {\r\n\tborder-radius: 4px;\r\n\tborder: 1px solid;\r\n\tbox-sizing: border-box;\r\n\tmargin: initial;\r\n}\r\n\r\n.modal-footer button:hover {\r\n\tbox-sizing: border-box !important;\r\n\tmargin: initial !important;\r\n\tborder: 1px solid black !important;\r\n}",
            "contraste": 28,
            "icon": "fa-file-image-o",
            "id": 28,
            "name": "Intranet Preto",
            "preview_mode": [
                {
                    "check": true,
                    "icon": "fa fa-list-alt",
                    "id": "preview",
                    "name": "Preview"
                },
                {
                    "check": false,
                    "icon": "fa fa-desktop",
                    "id": "desktop",
                    "name": "Desktop"
                },
                {
                    "check": false,
                    "icon": "glyphicon glyphicon-globe",
                    "id": "mobile",
                    "name": "Browser Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-mobile",
                    "id": "nativo",
                    "name": "App Mobile"
                },
                {
                    "check": false,
                    "icon": "fa fa-android",
                    "id": "android",
                    "name": "Android"
                },
                {
                    "check": false,
                    "icon": "fa fa-apple",
                    "id": "ios",
                    "name": "IOS"
                },
                {
                    "check": false,
                    "icon": "fa fa-windows",
                    "id": "winphone",
                    "name": "WinPhone"
                },
                {
                    "check": false,
                    "icon": "fa fa-print",
                    "id": "printer",
                    "name": "Impressão"
                }
            ],
            "tema": 11,
            "value": "preto-theme-intranet.css"
        }
    ],
    "type": "ANGULAR007v400",
    "user": "Andréa Lourenço",
    "variables": [
        {
            "name": "PROJETO",
            "value": "project"
        },
        {
            "name": "ID",
            "value": "project.id"
        },
        {
            "name": "NOME",
            "value": "project.name"
        },
        {
            "name": "VERSAO",
            "value": "project.version"
        },
        {
            "name": "ICONE",
            "value": "project.icon"
        },
        {
            "name": "DESCRICAO",
            "value": "project.description"
        },
        {
            "name": "PROPRIEDADE",
            "value": "project.owner"
        },
        {
            "name": "TELA",
            "value": "current"
        },
        {
            "name": "TELATITULO",
            "value": "current.title"
        },
        {
            "name": "TELADESCRICAO",
            "value": "current.description"
        },
        {
            "name": "TELAICONE",
            "value": "current.icon"
        },
        {
            "name": "DATAATUAL",
            "value": "dateNow(\"dd-MM-yyyy\")"
        },
        {
            "name": "RESPONSAVEL",
            "value": "user.fullname"
        },
        {
            "name": "AREARESPONSAVEL",
            "value": "CEDESRJ"
        },
        {
            "name": "CONTATO",
            "value": "user.name"
        },
        {
            "name": "RAIZ",
            "value": "%URL_SIOGP%/siogp/router/4939/app/layout/"
        }
    ],
    "version": "1.0",
    "views": [
        {
            "body": [
                {
                    "abbrev": "bti",
                    "align": {
                        "float": "floatRight",
                        "icon": "fa-align-right",
                        "id": "right",
                        "name": "Direita",
                        "pull": "pull-right",
                        "text": "text-right"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatNone text-center",
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Sub-título",
                    "filename": "icon013_primo_siogp_inverted_verysmall.png",
                    "help": "prototipado no PRIMO, suportado pelo SIOGP",
                    "id": "btiIcon013primosiogpinvertedverysmallpng2",
                    "imgsrc": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAYAAADE6YVjAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABRdJREFUeNqUVmtMW1UcP7fPS8vjttJSVthuBxtFCK3ZWAlmrrAtLDPInMnggwngfMyZsC0x8cuy+VE/KdEP4haBqYudk4GJCRgdoIuhG8tKtio4wLLR0fK8LX3c3vYWz6m9l0tXFE/SnMc9/f3+7//BwBZH8TmbGU6E4Iia/KjRsZX/Yv8BbIVTc+EzymOVOzVEgVrJf/vdTYGJOYp6vBTshdtuSDj0v0ggOAmnzuOVpPXV54uoXdrMMYZhXBGG8bAsS4vFYlwuk+lkMhk5OrNi+uznccI+OY9IWiGZKxVPnIagBUp+49OWavJEZeEPEjbSR0ciLsejZdDYMfLOTo1y6kKvs+7B7Aq7tzDzlhrH7K9YDL7qknzrTefc68q9x+3LI9ddm2qCCEr1RGfnm/td8UjIhqQWfv9+7AlpMag9f3oDhFopo8u2ZVO8tFC7QFzafObLEd0fbqpGaD5M6FioweC3bbVUNLTaLQR3PvETtjuPzQ+9gR3cmUopo46U5429ZNq2QWqpIqu57oMBwhdmnuNMJyS513P2IKlTgA6hBhf6nNbB8YUDmzm1QJXh+rjJZMvLxmlOo4ml6FutHb84IEkN7xNkJujkU/UVOht08CIHcPrrew326eWqf4tAPx0jbo4vFNcYNc5MuSS2trYWK1ApvNOL4WNUUd0w8o8oebf51EGjJxQO86p/2D9RdX/WZxYCHirXg7a6MgAFAtkZUv58MRDRnf1mrJHbI5ymKoMH4aK9BGpBQGdbdVnSAZ//Hyt5/TT+o9PLmwgBXnnbSpNq+QAbYylMhOHvHi03nbx8ywidnLgzuxIm+53zxiNl2nG032dQjaH8moRhjTQxH4YSRiIMr8V3d91GJhbHuf179SZai8fbV1cDDiRlMBgaZ+mA7fLJaodQI9vtRyZujfBQAqOASpDoYSbDXPBwFzx+mhBq8WKFbiA1nBNRE4sMHCjN58/DsTUjt0Z4yQpBIBJCLygXaOSrs/hQLdWrAE1HXOmcjoizcAkvnHs5iCZj6r2E41fDzIbDaGxdaj/8JhaJ8M2ia2ZhlV8nhd2RjmQIOU8qlfImWvSHvNzaUqQFl4anjOkIUJLen6VIbm/Mz+E1QXj+cJQncdmnFgCOy8l0QMgnR/cYLNdG3eZUgvM3nI0cEBpNlu0g2Q50CM8+NQ9QeZEkUv+czUGzGIqMtP2hrECFEwpZw8Weu5ZgmHEtBRlicj5gTM2hCn02gMmMtiaPP4pqWC/vEzjar/42TSoyMsjNbI/sPeejdfa/lqtSCWCegYsN5RwBgC3A/PngBMLq40mgNl1Xfn3oWqLX6lLBkSl/euAGyCxc4glHywu7waXXYOWJRfizWX8M77njQrWrK5HxfC8NMa2wTA9eb6tpgFsfd16Sp6RMBTkEIkLlxL0SAlm4FFiKNaC2NB9kS+MwJ9ZTCJPh4PxXI2jZ+lTTQoUsXlaPeXx0E6nN0Y1OLyYEUCuldmuxCpBqnNi/WwMa9hSC2pJcsCs3A2AsA2Isu4HgjS9GkMaoQ/an7YyQaMi7/TAGCQ5xZ4Zc5UyNUTsMq6sZJp+EYaIJ4Hg8vt5DJBIQjEvA6W47R9D1VDIKB7zwPpxeRqGdyCxNTolSqdCJRCL7hj9iGMDlciCWK8DV0Tlw4pMhV7Ijdm35tYKqM/Ir/J2B4Uk+CyNoX7E2EUEwesDtyfnEiwX6CoV9ezrwLT2JUl4v5uSPGwjcke51kjr+FmAA5ilTI4f0nq4AAAAASUVORK5CYII=",
                    "label": true,
                    "name": "Botão Imagem",
                    "option": "sobre",
                    "options": null,
                    "optionsname": "Ação",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        }
                    ],
                    "responsive": false,
                    "type": "img-button",
                    "value": ""
                },
                {
                    "name": "Quebra de linha (br)",
                    "platforms": [],
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "platforms": [],
                    "type": "line-break"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Arquivo",
                    "extensionType": "file",
                    "extensionrequired": true,
                    "filename": "splash.png",
                    "id": "imagem",
                    "label": true,
                    "name": "Imagem",
                    "platforms": [],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-4 col-lg-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-8 col-lg-8"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-12 col-md-10 col-lg-10"
                        }
                    ],
                    "type": "img",
                    "value": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAFj9JREFUeNrsXQtQVFea7m66gQZpXvIw3WojENMIRFHpOJhoDC6a2TAWTrTyqCybTTbrZEJNxa21as1WOTVjpbI1Y2ZxMlRKJ8NumcxkZ0Jck5JYML6iMYCiAtI8pRUaaJpu6HdDP9j/3gOHy+2m7+mXWLue6uo6nHP/c/57+vz/+c53/nvh5/zsT7xHiSwJHg3Bo8GKSBLi3OE9GxTSpEcjwkoqzeTR0zfZg4VGqrlflyCKMjvdVB2fD9+umRn4xoXM2vJNq+ta1IvVsmQrNssbbg0StvyQ1BZnpzEnkJA5ijBS1d90KJKXqSYs8Kckmqo1TbuooZwrZNYWrVkO1y9Wy5KFjuuu9BO2/JDUVu3KB7V9DxYMJ1yUlRxvcrokImFcdBQUjlqnIA+FVENOF8rMTcbkU28/i7pBfeCMSEB5Q6fHwyxkykLjtmnq90yNj1HQJeT9+peFKmn8gkLcSGZ8DGTgAmaDuBFvWSl9ve/BgokHwwkXaSwODY8nFlJK211uDd0TFKLLUAZqVZqJVz+6AHnpslhUiDNYFhfCsN4eM/qonWuZvF8SWWYhbsTgcOJa3CBuBMkWylOb+sZmZa1TUv+rIfwUKCMS8OHDKmTWeouQyz6cte/uzp+1FZHQ32oICXww00Q5EzZDwgTzHPkF+A0F/FmlRUIBKoRaKAeN42lFnZ4ZyCMRyJPLemgPzSzEjcTPDQGzwdfL8n5R15qRFPfr17Ygdw7lSFYcJVh0sM5cv3fyr6rc5PhOvQUrPTnlhDwU9k5YoY+81GWQwUpbnZQzkifGqY02yPiR/d2bTz+c4AAGqLRAeuTFTeIYISnOQqsmeGLwrGDVdnr4kYXbaXeLnDTO4Fr41tunce1DIsssxLIo4VpU+NbHl2WZkrZBgzInHV0wPwhuT9jMMFB0B45Aw/B39jmXoVmYgVppSrzGaDPZnT5r/csGWlvz5tPlHzaAU9//1JoDO/Oga2btooMFoBGgEKyasGx5L+EDE1ZYI55MTxygzZC1hOutU2jF9S/LufzLJOLC1alasyMjIVaeFD+mt0YaOlzv1gJggkzfgP7dE1d2b16N8RM3dEBrqoYB0tAYzyI3kXAewlnnINxcbRCy++Wp2zatgi1F9VtPX+warb3csz0lzsafEbpEkpQ4+MEPv7wZZmVrl7ZiW25dy4BGZyHpl1mIFTDT5bOQcE6ZlrvjTFB69Kvb87ILoYMPl2ZyuvCS4V0YllpYeuD71GtbYGiG9FZ1B3VHlb+9gPBO9bk7VWXrLnaP1jUPAEbDUM7gcmkM1sodT4C72P6Lr8Exm4yO0LV6oyyvvmt4sdpFZxZG8GjgWaYE38iUMAZhmgMq5JQFK6vYmgN+4cMvbx76/VUka7JOsfptvH5vdK4Qyw7ordLYmIYm9dWbg0WZSYd+tOHinWHVfYN20s6URSoxlcGNMM0Q38iXV/qQGXrLLpkZwgC98+MNv65vP/TfLQt2Yb5k3ylb16gaARv00+/+312Am1QWPvbG8/lHP2sJ2gwrsxWnbqh5PmU5EXzYU+6KxDP/XAYWBO6zsV1DIqIxwFI4TXJl7aUesFN5huTiv/0tWsiCwFkB81mIo8AoGVZZtFdCSBoNPLJqdI2Q2joIMEBDhSxZgHklihUuy/ShU9+jEp+y0kSxLC2h4smVvOgouGGoghsAWYAOGp2Zmp4GK2/aXXd7UK01OZ1u736h/M2PL/PcHlj7P/+uH98RUgYrj3TA7gnJHvzDd/iuYefPvBF/CB57otlZx+cvKLQuyIDG+AKxKMqn7Ntl+a339Rq9RUOjDZYsjMvOfOn+LdnpKXE+f0mJWCRZlTIPA7fmUAZ13/CtauSza/1mu5PZL9o5aC2OEkXmV9fvMZXB/fq8ow//oeTl4+dRLSjm8riZshwIHpwcAr4Y79qRU6SNGWcw2KV+KJcH16LrS9evVGanHfpjM+KGWLIF8tSKzVnlm1YHYzWrUuDzj2XrYK282jHcpjMx+627dhf+hK1VXYta1atjKY9mGUuZ87eGvO9otkE/CD5cCaaMWCg49nWbz6oPXirGG4tQUkVxFnz29Y1RP8nMgqqffHKlOCcdHBleOvyk+tb7wfgsBB1gLZfSwBf29Gj/BXmElWHFxaAZpiFYAcwp6hejBREOqN6db3BM133blxEbLZzhYVnwiAd3F2zbsDK8PwyMO7j25s6RX56+CTqBznanG5yvZshYuVOxu2hVTX3HvPLi6Fk7YNwIVh7JSuNj0Y1ISRC8wtfyr/C5hHtRtEqx6NPmu7Dks2R5ccIPXlJG7kCkOG9FTabkwCdX1DoL1qq2QWXiz/DA8qxTfqCDb1o50tABjOLA7nwEjphp5/qVp97eEemjIzBwACjgChdCECtYPbj8MB+FBcHBMxF8Eaz0elv999QGhSm7d3PWO+WFD4ycOvzjooKVySfPdeKN9PEvb8mT47dnpfXqzEvJwWNuSCHk1/zTtldgEzftZsqCy3iQI4VSuTLLxeeB15+9EYvDzpv55cvKVz86b9BbODn4Bfx9GDl4Zi34V5jzzNr9yjVgAktCfoJDOLxnA1bGaXcd+mMTQNwgGHoOBB8oFw4YvVCWXNPQyZQFJAUWsYRkceW2x7V6q/paP1K+V2epeX3r6aaBNrWexcFjIt+bv2ch+DA4eMVjSS1dowt8n1hUXVmy5OR61Q8LmKvKB2duhdPBB8HBw0LzedNd3hwaRrIfvPoU7FSC4J1hJW3s0BhMjorN8ovdo/BnkSxZFCsCMFWaLw10PYXd5ZEXN5X/6hzS2TROMR/rc9Lqbw8ybwQT+T74e04EHxCf/d6eDaCNNDYG1yqLswIF6LBxqb3cw7O5MN4Bo0Y3YLc6W4cmYNQamtQAmqrK1oE/CohRqNqVD7JIvb4RIwwfGixChj5s0CEjUXzgtxdhpPDqm5eZ+C8/DGD5a707/ulfu3pHjCweHfbMF1QjmhETs9+BCWvtN50Nzfd+Wl64jrHB9p/eKVtnGrPMcvBxMZ+f7y7NzlBpjeGBDuTk34mqZ5//929glcH4vmJrdooklvA2jp+7w4xDYfbbO2rSGG2onNWvxup47aMLFVvWwHpH2FHJk7LaVjVC8FI+D7wEWMM8gsddcJF/IXHwx+o7YKRwIfipii3ZhDcAOAisb7GWr/ZqtWa7Hx699lIPdE0ITbYXSqmzNQN1SKwetwCMIGfow8PBA+C8pR7H+2coLMl/jNCvHz/Tdu+egSnL4u+ZZrgY96/q1YEJv/LcEyQ9HvnRhiN/vo4QfHJ8bPmugvaeMdQgViCCHPyxjatOftvD5NE/UGYRWl/t1V7/HPypq33okNU/9//51X6Dyw1eibPTotx0s9ttpjlIk9aozFsBHjBQMwweZ+3/TSNrH0uytAM+QPFvnLviBJpO4UzQmvfW3SfpWlogm2fuL/dwRjaEjYPfV5LtmvbU37yPAVr5hlVE93a2HcQ5+XtldhrAHLNlioT7P362XVn1HGfXuwtlVzuGZ/NPykQeXp/BwlSAk4MX+OfgMWm9gM+mJ0jrgI7JwStzuIMkYKvRTM8CTv7+k/PdgCq8+/UpC8qQsJ2A/vAdNbZr1FozSwHEwbO6CwMH76KXFSYHXyBfzqnupZuDJPw9Akfo3JCQ+4cpAwsOJ6Bflb4MRhah+e1rV5i6FjTCycEH6bNYGAdcDOc6CN66gezQMKBzQzxnqeMy7m1sMs4f+Ju8MJB/JBx8zdftGXExmIPPypBw9tTYPsTJ3+N+tTBtp91IGULuv3dokvOQVZ6eIE+MQxz8wRNXZqn3iHLwvDihWBKjvTuFJ215PPfKpRqe1M9x4b5DrBn9vvBUlkHlBjMk5P7hsvo7GgCf/nXIkMSqAZHQsrBJPPI/FAdHzsEHcxQmEUfLFv6GJFsccBYBbK1b1Bo67pI8kZghc+qp7hvAdWhCNEPOjfSA3tqgV8N0ZXLwnD0lRAtTiQPScqTJgCGcsS7yOPhYAh3EImFucjzi4Mf0VrGbhy09Uhy8LFMCy/CJRhVmf4aMdk5FYRM7NGYijGUv3bQa7KVteJI8Dl4m4Pabpilnp96CZHNWp/Ra7K2jk+Hn4LevzazalU/Rj2XrYKSGDFbIgDFCHsrFQu5VtWKzXJGRiK6HZhEzBXYBGSlqh961QO1+5ZozN+5BCZQz+8XX435BVfiG8ty0BGifUwdmv4h0w/1CJmwcvNk2rb1vgHL1qEmlN0Ohy+4UeGZMlqnO+wY5YyexWOodNbrcHpNjupNup3toYsRk57k9fcNG+IZ2oGUoh1qPy/Oics2wyQblzH41OjOUgK/B/cL6Bd9m+7R4ho9Bpp8EcBb163K6dSb7kM4M/hcUoB6YsUxxcvBCcveJwt8BgkPmxFvbqn5/BcXBQ9XzBIMFDt5hn9ZMWOF60KOpT4di6GHJM9ud8GmeGUPtg9LyDMl19TgUsvqlru/X4X4BB6AtAXgiEsKDZq6pfuHHhkUJ9dvknkE3GC+KTBz8kbobs7QvsnD6mRj/CUA/eSz7t92jWrMdKUMYBy8nwHrjZsfklBPJvn/6VqAcfJDnhhWbs5i1JD4roBPJfcoshTSZ/HRPJhGXFkg5FbgxMI5lyzeuDunckJyDlyWKC1YkORzOCEGH5i6tYcKGmUhO6LCDYKQgOSxTCDqIxELhDA+j/8hy8Af+8ztpohgMfnYm008McEIH04SNMHi3ODXeNjOD4gVJAn9riuUkDqtt1IjuSMqPP9moCgP5x+SkMS3NYqwV0qRD5etxrd3lIflhSVpGtRuzlqNNgs9aliyCApy9w0qCZd/bsyFlLjbTv1bh4OBtLvWwMS91GTIHsEoSMySPofcZB+9TFrwV4TFPU+cIKIzolxu9Y4kzfNYhQAQ5+JRBvTM6SqU1RsIMSeLgkezhlzeTgAZABo09o+iOFKtS2kcmsTIPgoOH9AodPhyJRMhnvbtnPeHpd/W5O8y9REBkWagcPNq19w1NYsaau6e5RngEMfRN/WNaswOVL8bBH95bxMnJYN6xqXuUQuTCKJiGR79ohQblCWLUYMQ5eMSFv/ZMLjqGEgmjSJT2w6Oz+oXtDjor8tnvqtRln/+slDzooe5Kn5k+VYOWX9++9gU6pBw3GHEOHlV9dq1fuTYT/nTOxdL5R/CEMfSQ/tx0V0OzdN79Vu544u+eeZw8Sge8Vd21uzgOvkU93tg5DB3hBsk5+JDi4KmNVd9Y5bbHw+6zAApQxwp2J5NfrFLKAxomHCeA8/tKspv7dMxmHwQHj7lwYZTghfWrhnXcsfkAHURcPPqZyi1wJ2MTthxZUuPtId60u1CeOhMlkGckkGz9vNOZpgGT3oaV3124srljhHriY6ni4Pf+R+MXP91BBB24OHgFI5BIIUsOcXoCZD/4p2YMDsDH/X3NRd6Sx8HHxYhCb0RBHHJFuAIe/WzeAGGbvTNfGmKb4YmD1+jMYDghbqRJzrQJk33K9fNTTamx0SgoPy8z0WhzVX91O5dWYInj4MPCwUszJeGaU69+dB5sEL0DB5Q/9ubWI3WtKp2Z2S9vqeLgw8JnheVRMQAK4JjQsRtqGRbW6jNtTbMxFksdB08ISoVzjfB8vU+maM3y0EeqTa3/10+bJm3T+AU1sMeGvr78ttfPu2jI4+B9jB/eeWNJZiHOwM4A410SULqYrJ1+K1pRVlqITupYfTuAT7RlQYXJiWL0HgiEBha7I6QAqsWyuJYDwYOH80bwUIhhLn6vmMuzAJFzInifsnAnkAllZoGJnTzbcXFAx0ThaE6995frPIbyzCdZcQYpwELws4PwAJ5kDSIF57BgmI6fu0OFRNCoEqP/4rRlx891SGNjwqtk2B6hC4WDrwxwpGC9a7w1WN+idjk9+AUaWOd9zzze1K2FkXq4XmMXLugQmxwLs8P/5AKv1DZoaO7XtanHm/p0zBfk4ZX+vde3go8HlBDKa+z8QIeAH0fJTUuQZUrg3pi1JNChNF9ap7f5bLmxXQMfasvGn5HRD6ODKWnNDtiog0PRWB0qzQTMFLwpAXGmVrC1PrAzr+ZSd/W5DnDnrFpeaC+MCskMN65OTU+Nh91poGaYm57w/JOyQoujd2gSponPo7DbY0Zo2RUdlbdOqp0cofbAHr5pwpYQFeXT/LOWLyvMXs5zzySLoyWwzNtc6KTrwb1N0j8Hf/b2kDcXTsLB15zvgptXFj62+6msT6/0piTG3ujR8oKNgy9emwHIc9dmeavGUHupB6xvUR6dobzvB8oj9zhKSkpcRW5aXfMAs5b8KAxujJ5lkv3KNQbwzXQclup7C6vfjCQx4rNYR2GwH85IiIVhgl0x9bD4mVvYZ/nROZRaDgQPcxUcIUbwyJihEH4W6jbogyO4DKHwWXo+lpt1EM41QqlimXq/7qYVbCRamJuRqMhMrK78QePNwSGzPVUivnZn5KUt2XdGjLXnu6rK1rWNUHuXnzyX98aJy3A9eKWRcevRL1p59IsZUYNMnQFbIq1wIVY+iWZHqDA5zwxWJlUcjTLeskFG0eBkMDlUY6ZwIReYI3bLNFjc3mMN4G6GbFR8x5DBChNwcspJIynd1btjMMW6+sdxBA7zlTKE6dTbz8IAxdALkYc+TJXEiOz09BFFCZw0+BQI+J65yfVzBr0TPAefkigufCIDP1IyR2OHh4OHFRAd6uxY91ijakQ17aLeJWZ28IjfgeODR6cz5R828AJ8tzIRgvdvw9TPa3WwaoM4vvfvO9R6CzraC+/r88Lps0iO7xXLE5x8nmnhe9/CfnxvnrCjOPggXp8X6GvsInh8b3J7ZCskqhvqQKFDQMf3u4rlWqeL5Pg+xLdJAqAFAKwa0lPnSY5pCganLUN0WBg4eHAiJM/AhZiot19pJh7ABh6wy871VIzn3uLZ8Dk/YSYBH4VtXLN8p2Rlw61B5nEWn8cnMUMR8eMoOSsSURw8+eMoWJZ1nLXgHM/rlVBUNH+MCBoBi7Mnxt2Li4G5iQch1KMwvXXaFsWnJjBjwv/hfNeQ1eH/iVKSozDm4ygas6NteJL8cRRvM8SFCj9mmBpnm3JCBixuwGjT2qjI1flBCNEMqffw+ToTBtss/9W5gJ458ZMQS8V7yFLAHPwLP1ijzElXa02q+xMsHh2w9bG/tJZuWr2/JDtQDp63RO+DFwsFIiGdiRIsE6HrBYu9D17gn4PHHaPCimI5Yp2qK0vEMfNqYRpba7QfPX2zsuaiz3gCJgfvLeun34BkvXl0/y1jRE0je38cvMAbwSPUDhkKwtKf2ZU4iv/mc4rZsy/qNS8bURV8YEqiDJK92qN9/v2zF+8M++Tg0YOwi8l694tKyGXhAlYhbgQ3ixtEcJrKuD02t8dFjxeWDf5JVlaca4liRen6lX6IzYP/dY1641ewISsPJoFnrD3fjXwuelgDvfc6VA6+qW14+437rPfBs0LJWbJNnSMHdZZDFUU5sqSA4uB5//f+lQyP5N/BWBy9H1/auzWHIvOMjof/X8mQcvDF2WlVu/JhODX09gWtBchucWHQtTsLZBFqOXK1rH9SIWRSSwppEqr2GZsj9cr8f6hlIsf5wcL/a+1RWiw9+v+GjwYrMul/BRgArXujn0OLvmAAAAAASUVORK5CYII="
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "icon": " ",
                    "id": "titulo",
                    "label": true,
                    "name": "Título",
                    "platforms": [],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        }
                    ],
                    "type": "h4",
                    "value": "Sistema Genérico"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "id": "subtitulo",
                    "label": true,
                    "name": "Sub-título",
                    "platforms": [],
                    "size": {
                        "id": "auto",
                        "name": "Auto",
                        "style": "sizeAuto"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        },
                        {
                            "id": "auto",
                            "name": "Auto",
                            "style": "sizeAuto"
                        }
                    ],
                    "type": "h6",
                    "value": "v1.0"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "id": "texto",
                    "label": true,
                    "name": "Texto",
                    "platforms": [],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        }
                    ],
                    "style": {
                        "id": "primary",
                        "name": "Primário"
                    },
                    "styles": [
                        {
                            "id": "default",
                            "name": "Padrão"
                        },
                        {
                            "id": "primary",
                            "name": "Primário"
                        },
                        {
                            "id": "success",
                            "name": "Sucesso"
                        },
                        {
                            "id": "warning",
                            "name": "Aviso"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        },
                        {
                            "id": "info",
                            "name": "Informação"
                        }
                    ],
                    "type": "label",
                    "value": "Carregando..."
                },
                {
                    "name": "Quebra de linha (br)",
                    "platforms": [],
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        }
                    ],
                    "type": "line-break"
                },
                {
                    "delay": {
                        "id": 3,
                        "name": "3 segundos"
                    },
                    "id": "timer",
                    "name": "Timer",
                    "option": "login",
                    "options": null,
                    "optionsname": "Ação",
                    "platforms": [],
                    "type": "timer"
                },
                {
                    "delay": {
                        "id": 3,
                        "name": "3 segundos"
                    },
                    "id": "timer2",
                    "name": "Timer",
                    "option": "login",
                    "options": null,
                    "optionsname": "Ação",
                    "platforms": [
                        {
                            "check": false,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        }
                    ],
                    "type": "timer"
                },
                {
                    "align": {
                        "float": "floatNone text-center",
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatNone text-center",
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Nome",
                    "extensionrequired": true,
                    "help": "Clique para instalar a versão Mobile",
                    "href": "%URL_SIOGP%/siogp/router/4939/app/layout//LAYOUT-Mobile.apk",
                    "icon": "fa-android",
                    "id": "link",
                    "label": true,
                    "name": "Link",
                    "option": "_blank",
                    "options": null,
                    "optionsname": "Abrir em",
                    "platforms": [
                        {
                            "check": false,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        }
                    ],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        },
                        {
                            "id": "auto",
                            "name": "Auto",
                            "style": "sizeAuto"
                        }
                    ],
                    "type": "link",
                    "value": "Clique para instalar a versão Mobile"
                }
            ],
            "boolATM": false,
            "description": "Tela de Splash",
            "group": "Splash",
            "icon": "fa-picture-o",
            "id": "splash",
            "locked": false,
            "menuHorizontal": false,
            "menuVertical": true,
            "telainicial": true,
            "title": "Splash"
        },
        {
            "body": [
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "filename": "logo.png",
                    "id": "imagem",
                    "name": "Imagem",
                    "style": "vertical-center2",
                    "type": "img",
                    "value": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAFj9JREFUeNrsXQtQVFea7m66gQZpXvIw3WojENMIRFHpOJhoDC6a2TAWTrTyqCybTTbrZEJNxa21as1WOTVjpbI1Y2ZxMlRKJ8NumcxkZ0Jck5JYML6iMYCiAtI8pRUaaJpu6HdDP9j/3gOHy+2m7+mXWLue6uo6nHP/c/57+vz/+c53/nvh5/zsT7xHiSwJHg3Bo8GKSBLi3OE9GxTSpEcjwkoqzeTR0zfZg4VGqrlflyCKMjvdVB2fD9+umRn4xoXM2vJNq+ta1IvVsmQrNssbbg0StvyQ1BZnpzEnkJA5ijBS1d90KJKXqSYs8Kckmqo1TbuooZwrZNYWrVkO1y9Wy5KFjuuu9BO2/JDUVu3KB7V9DxYMJ1yUlRxvcrokImFcdBQUjlqnIA+FVENOF8rMTcbkU28/i7pBfeCMSEB5Q6fHwyxkykLjtmnq90yNj1HQJeT9+peFKmn8gkLcSGZ8DGTgAmaDuBFvWSl9ve/BgokHwwkXaSwODY8nFlJK211uDd0TFKLLUAZqVZqJVz+6AHnpslhUiDNYFhfCsN4eM/qonWuZvF8SWWYhbsTgcOJa3CBuBMkWylOb+sZmZa1TUv+rIfwUKCMS8OHDKmTWeouQyz6cte/uzp+1FZHQ32oICXww00Q5EzZDwgTzHPkF+A0F/FmlRUIBKoRaKAeN42lFnZ4ZyCMRyJPLemgPzSzEjcTPDQGzwdfL8n5R15qRFPfr17Ygdw7lSFYcJVh0sM5cv3fyr6rc5PhOvQUrPTnlhDwU9k5YoY+81GWQwUpbnZQzkifGqY02yPiR/d2bTz+c4AAGqLRAeuTFTeIYISnOQqsmeGLwrGDVdnr4kYXbaXeLnDTO4Fr41tunce1DIsssxLIo4VpU+NbHl2WZkrZBgzInHV0wPwhuT9jMMFB0B45Aw/B39jmXoVmYgVppSrzGaDPZnT5r/csGWlvz5tPlHzaAU9//1JoDO/Oga2btooMFoBGgEKyasGx5L+EDE1ZYI55MTxygzZC1hOutU2jF9S/LufzLJOLC1alasyMjIVaeFD+mt0YaOlzv1gJggkzfgP7dE1d2b16N8RM3dEBrqoYB0tAYzyI3kXAewlnnINxcbRCy++Wp2zatgi1F9VtPX+warb3csz0lzsafEbpEkpQ4+MEPv7wZZmVrl7ZiW25dy4BGZyHpl1mIFTDT5bOQcE6ZlrvjTFB69Kvb87ILoYMPl2ZyuvCS4V0YllpYeuD71GtbYGiG9FZ1B3VHlb+9gPBO9bk7VWXrLnaP1jUPAEbDUM7gcmkM1sodT4C72P6Lr8Exm4yO0LV6oyyvvmt4sdpFZxZG8GjgWaYE38iUMAZhmgMq5JQFK6vYmgN+4cMvbx76/VUka7JOsfptvH5vdK4Qyw7ordLYmIYm9dWbg0WZSYd+tOHinWHVfYN20s6URSoxlcGNMM0Q38iXV/qQGXrLLpkZwgC98+MNv65vP/TfLQt2Yb5k3ylb16gaARv00+/+312Am1QWPvbG8/lHP2sJ2gwrsxWnbqh5PmU5EXzYU+6KxDP/XAYWBO6zsV1DIqIxwFI4TXJl7aUesFN5huTiv/0tWsiCwFkB81mIo8AoGVZZtFdCSBoNPLJqdI2Q2joIMEBDhSxZgHklihUuy/ShU9+jEp+y0kSxLC2h4smVvOgouGGoghsAWYAOGp2Zmp4GK2/aXXd7UK01OZ1u736h/M2PL/PcHlj7P/+uH98RUgYrj3TA7gnJHvzDd/iuYefPvBF/CB57otlZx+cvKLQuyIDG+AKxKMqn7Ntl+a339Rq9RUOjDZYsjMvOfOn+LdnpKXE+f0mJWCRZlTIPA7fmUAZ13/CtauSza/1mu5PZL9o5aC2OEkXmV9fvMZXB/fq8ow//oeTl4+dRLSjm8riZshwIHpwcAr4Y79qRU6SNGWcw2KV+KJcH16LrS9evVGanHfpjM+KGWLIF8tSKzVnlm1YHYzWrUuDzj2XrYK282jHcpjMx+627dhf+hK1VXYta1atjKY9mGUuZ87eGvO9otkE/CD5cCaaMWCg49nWbz6oPXirGG4tQUkVxFnz29Y1RP8nMgqqffHKlOCcdHBleOvyk+tb7wfgsBB1gLZfSwBf29Gj/BXmElWHFxaAZpiFYAcwp6hejBREOqN6db3BM133blxEbLZzhYVnwiAd3F2zbsDK8PwyMO7j25s6RX56+CTqBznanG5yvZshYuVOxu2hVTX3HvPLi6Fk7YNwIVh7JSuNj0Y1ISRC8wtfyr/C5hHtRtEqx6NPmu7Dks2R5ccIPXlJG7kCkOG9FTabkwCdX1DoL1qq2QWXiz/DA8qxTfqCDb1o50tABjOLA7nwEjphp5/qVp97eEemjIzBwACjgChdCECtYPbj8MB+FBcHBMxF8Eaz0elv999QGhSm7d3PWO+WFD4ycOvzjooKVySfPdeKN9PEvb8mT47dnpfXqzEvJwWNuSCHk1/zTtldgEzftZsqCy3iQI4VSuTLLxeeB15+9EYvDzpv55cvKVz86b9BbODn4Bfx9GDl4Zi34V5jzzNr9yjVgAktCfoJDOLxnA1bGaXcd+mMTQNwgGHoOBB8oFw4YvVCWXNPQyZQFJAUWsYRkceW2x7V6q/paP1K+V2epeX3r6aaBNrWexcFjIt+bv2ch+DA4eMVjSS1dowt8n1hUXVmy5OR61Q8LmKvKB2duhdPBB8HBw0LzedNd3hwaRrIfvPoU7FSC4J1hJW3s0BhMjorN8ovdo/BnkSxZFCsCMFWaLw10PYXd5ZEXN5X/6hzS2TROMR/rc9Lqbw8ybwQT+T74e04EHxCf/d6eDaCNNDYG1yqLswIF6LBxqb3cw7O5MN4Bo0Y3YLc6W4cmYNQamtQAmqrK1oE/CohRqNqVD7JIvb4RIwwfGixChj5s0CEjUXzgtxdhpPDqm5eZ+C8/DGD5a707/ulfu3pHjCweHfbMF1QjmhETs9+BCWvtN50Nzfd+Wl64jrHB9p/eKVtnGrPMcvBxMZ+f7y7NzlBpjeGBDuTk34mqZ5//929glcH4vmJrdooklvA2jp+7w4xDYfbbO2rSGG2onNWvxup47aMLFVvWwHpH2FHJk7LaVjVC8FI+D7wEWMM8gsddcJF/IXHwx+o7YKRwIfipii3ZhDcAOAisb7GWr/ZqtWa7Hx699lIPdE0ITbYXSqmzNQN1SKwetwCMIGfow8PBA+C8pR7H+2coLMl/jNCvHz/Tdu+egSnL4u+ZZrgY96/q1YEJv/LcEyQ9HvnRhiN/vo4QfHJ8bPmugvaeMdQgViCCHPyxjatOftvD5NE/UGYRWl/t1V7/HPypq33okNU/9//51X6Dyw1eibPTotx0s9ttpjlIk9aozFsBHjBQMwweZ+3/TSNrH0uytAM+QPFvnLviBJpO4UzQmvfW3SfpWlogm2fuL/dwRjaEjYPfV5LtmvbU37yPAVr5hlVE93a2HcQ5+XtldhrAHLNlioT7P362XVn1HGfXuwtlVzuGZ/NPykQeXp/BwlSAk4MX+OfgMWm9gM+mJ0jrgI7JwStzuIMkYKvRTM8CTv7+k/PdgCq8+/UpC8qQsJ2A/vAdNbZr1FozSwHEwbO6CwMH76KXFSYHXyBfzqnupZuDJPw9Akfo3JCQ+4cpAwsOJ6Bflb4MRhah+e1rV5i6FjTCycEH6bNYGAdcDOc6CN66gezQMKBzQzxnqeMy7m1sMs4f+Ju8MJB/JBx8zdftGXExmIPPypBw9tTYPsTJ3+N+tTBtp91IGULuv3dokvOQVZ6eIE+MQxz8wRNXZqn3iHLwvDihWBKjvTuFJ215PPfKpRqe1M9x4b5DrBn9vvBUlkHlBjMk5P7hsvo7GgCf/nXIkMSqAZHQsrBJPPI/FAdHzsEHcxQmEUfLFv6GJFsccBYBbK1b1Bo67pI8kZghc+qp7hvAdWhCNEPOjfSA3tqgV8N0ZXLwnD0lRAtTiQPScqTJgCGcsS7yOPhYAh3EImFucjzi4Mf0VrGbhy09Uhy8LFMCy/CJRhVmf4aMdk5FYRM7NGYijGUv3bQa7KVteJI8Dl4m4Pabpilnp96CZHNWp/Ra7K2jk+Hn4LevzazalU/Rj2XrYKSGDFbIgDFCHsrFQu5VtWKzXJGRiK6HZhEzBXYBGSlqh961QO1+5ZozN+5BCZQz+8XX435BVfiG8ty0BGifUwdmv4h0w/1CJmwcvNk2rb1vgHL1qEmlN0Ohy+4UeGZMlqnO+wY5YyexWOodNbrcHpNjupNup3toYsRk57k9fcNG+IZ2oGUoh1qPy/Oics2wyQblzH41OjOUgK/B/cL6Bd9m+7R4ho9Bpp8EcBb163K6dSb7kM4M/hcUoB6YsUxxcvBCcveJwt8BgkPmxFvbqn5/BcXBQ9XzBIMFDt5hn9ZMWOF60KOpT4di6GHJM9ud8GmeGUPtg9LyDMl19TgUsvqlru/X4X4BB6AtAXgiEsKDZq6pfuHHhkUJ9dvknkE3GC+KTBz8kbobs7QvsnD6mRj/CUA/eSz7t92jWrMdKUMYBy8nwHrjZsfklBPJvn/6VqAcfJDnhhWbs5i1JD4roBPJfcoshTSZ/HRPJhGXFkg5FbgxMI5lyzeuDunckJyDlyWKC1YkORzOCEGH5i6tYcKGmUhO6LCDYKQgOSxTCDqIxELhDA+j/8hy8Af+8ztpohgMfnYm008McEIH04SNMHi3ODXeNjOD4gVJAn9riuUkDqtt1IjuSMqPP9moCgP5x+SkMS3NYqwV0qRD5etxrd3lIflhSVpGtRuzlqNNgs9aliyCApy9w0qCZd/bsyFlLjbTv1bh4OBtLvWwMS91GTIHsEoSMySPofcZB+9TFrwV4TFPU+cIKIzolxu9Y4kzfNYhQAQ5+JRBvTM6SqU1RsIMSeLgkezhlzeTgAZABo09o+iOFKtS2kcmsTIPgoOH9AodPhyJRMhnvbtnPeHpd/W5O8y9REBkWagcPNq19w1NYsaau6e5RngEMfRN/WNaswOVL8bBH95bxMnJYN6xqXuUQuTCKJiGR79ohQblCWLUYMQ5eMSFv/ZMLjqGEgmjSJT2w6Oz+oXtDjor8tnvqtRln/+slDzooe5Kn5k+VYOWX9++9gU6pBw3GHEOHlV9dq1fuTYT/nTOxdL5R/CEMfSQ/tx0V0OzdN79Vu544u+eeZw8Sge8Vd21uzgOvkU93tg5DB3hBsk5+JDi4KmNVd9Y5bbHw+6zAApQxwp2J5NfrFLKAxomHCeA8/tKspv7dMxmHwQHj7lwYZTghfWrhnXcsfkAHURcPPqZyi1wJ2MTthxZUuPtId60u1CeOhMlkGckkGz9vNOZpgGT3oaV3124srljhHriY6ni4Pf+R+MXP91BBB24OHgFI5BIIUsOcXoCZD/4p2YMDsDH/X3NRd6Sx8HHxYhCb0RBHHJFuAIe/WzeAGGbvTNfGmKb4YmD1+jMYDghbqRJzrQJk33K9fNTTamx0SgoPy8z0WhzVX91O5dWYInj4MPCwUszJeGaU69+dB5sEL0DB5Q/9ubWI3WtKp2Z2S9vqeLgw8JnheVRMQAK4JjQsRtqGRbW6jNtTbMxFksdB08ISoVzjfB8vU+maM3y0EeqTa3/10+bJm3T+AU1sMeGvr78ttfPu2jI4+B9jB/eeWNJZiHOwM4A410SULqYrJ1+K1pRVlqITupYfTuAT7RlQYXJiWL0HgiEBha7I6QAqsWyuJYDwYOH80bwUIhhLn6vmMuzAJFzInifsnAnkAllZoGJnTzbcXFAx0ThaE6995frPIbyzCdZcQYpwELws4PwAJ5kDSIF57BgmI6fu0OFRNCoEqP/4rRlx891SGNjwqtk2B6hC4WDrwxwpGC9a7w1WN+idjk9+AUaWOd9zzze1K2FkXq4XmMXLugQmxwLs8P/5AKv1DZoaO7XtanHm/p0zBfk4ZX+vde3go8HlBDKa+z8QIeAH0fJTUuQZUrg3pi1JNChNF9ap7f5bLmxXQMfasvGn5HRD6ODKWnNDtiog0PRWB0qzQTMFLwpAXGmVrC1PrAzr+ZSd/W5DnDnrFpeaC+MCskMN65OTU+Nh91poGaYm57w/JOyQoujd2gSponPo7DbY0Zo2RUdlbdOqp0cofbAHr5pwpYQFeXT/LOWLyvMXs5zzySLoyWwzNtc6KTrwb1N0j8Hf/b2kDcXTsLB15zvgptXFj62+6msT6/0piTG3ujR8oKNgy9emwHIc9dmeavGUHupB6xvUR6dobzvB8oj9zhKSkpcRW5aXfMAs5b8KAxujJ5lkv3KNQbwzXQclup7C6vfjCQx4rNYR2GwH85IiIVhgl0x9bD4mVvYZ/nROZRaDgQPcxUcIUbwyJihEH4W6jbogyO4DKHwWXo+lpt1EM41QqlimXq/7qYVbCRamJuRqMhMrK78QePNwSGzPVUivnZn5KUt2XdGjLXnu6rK1rWNUHuXnzyX98aJy3A9eKWRcevRL1p59IsZUYNMnQFbIq1wIVY+iWZHqDA5zwxWJlUcjTLeskFG0eBkMDlUY6ZwIReYI3bLNFjc3mMN4G6GbFR8x5DBChNwcspJIynd1btjMMW6+sdxBA7zlTKE6dTbz8IAxdALkYc+TJXEiOz09BFFCZw0+BQI+J65yfVzBr0TPAefkigufCIDP1IyR2OHh4OHFRAd6uxY91ijakQ17aLeJWZ28IjfgeODR6cz5R828AJ8tzIRgvdvw9TPa3WwaoM4vvfvO9R6CzraC+/r88Lps0iO7xXLE5x8nmnhe9/CfnxvnrCjOPggXp8X6GvsInh8b3J7ZCskqhvqQKFDQMf3u4rlWqeL5Pg+xLdJAqAFAKwa0lPnSY5pCganLUN0WBg4eHAiJM/AhZiot19pJh7ABh6wy871VIzn3uLZ8Dk/YSYBH4VtXLN8p2Rlw61B5nEWn8cnMUMR8eMoOSsSURw8+eMoWJZ1nLXgHM/rlVBUNH+MCBoBi7Mnxt2Li4G5iQch1KMwvXXaFsWnJjBjwv/hfNeQ1eH/iVKSozDm4ygas6NteJL8cRRvM8SFCj9mmBpnm3JCBixuwGjT2qjI1flBCNEMqffw+ToTBtss/9W5gJ458ZMQS8V7yFLAHPwLP1ijzElXa02q+xMsHh2w9bG/tJZuWr2/JDtQDp63RO+DFwsFIiGdiRIsE6HrBYu9D17gn4PHHaPCimI5Yp2qK0vEMfNqYRpba7QfPX2zsuaiz3gCJgfvLeun34BkvXl0/y1jRE0je38cvMAbwSPUDhkKwtKf2ZU4iv/mc4rZsy/qNS8bURV8YEqiDJK92qN9/v2zF+8M++Tg0YOwi8l694tKyGXhAlYhbgQ3ixtEcJrKuD02t8dFjxeWDf5JVlaca4liRen6lX6IzYP/dY1641ewISsPJoFnrD3fjXwuelgDvfc6VA6+qW14+437rPfBs0LJWbJNnSMHdZZDFUU5sqSA4uB5//f+lQyP5N/BWBy9H1/auzWHIvOMjof/X8mQcvDF2WlVu/JhODX09gWtBchucWHQtTsLZBFqOXK1rH9SIWRSSwppEqr2GZsj9cr8f6hlIsf5wcL/a+1RWiw9+v+GjwYrMul/BRgArXujn0OLvmAAAAAASUVORK5CYII="
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                }
            ],
            "description": "Tela Principal",
            "footer": [],
            "group": "Principal",
            "header": [],
            "icon": "fa-home",
            "id": "principal",
            "locked": true,
            "menuHorizontal": false,
            "menuVertical": true,
            "title": "Principal"
        },
        {
            "body": [
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "filename": "logo.png",
                    "id": "imagem",
                    "name": "Imagem",
                    "style": "vertical-center2",
                    "type": "img",
                    "value": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAFj9JREFUeNrsXQtQVFea7m66gQZpXvIw3WojENMIRFHpOJhoDC6a2TAWTrTyqCybTTbrZEJNxa21as1WOTVjpbI1Y2ZxMlRKJ8NumcxkZ0Jck5JYML6iMYCiAtI8pRUaaJpu6HdDP9j/3gOHy+2m7+mXWLue6uo6nHP/c/57+vz/+c53/nvh5/zsT7xHiSwJHg3Bo8GKSBLi3OE9GxTSpEcjwkoqzeTR0zfZg4VGqrlflyCKMjvdVB2fD9+umRn4xoXM2vJNq+ta1IvVsmQrNssbbg0StvyQ1BZnpzEnkJA5ijBS1d90KJKXqSYs8Kckmqo1TbuooZwrZNYWrVkO1y9Wy5KFjuuu9BO2/JDUVu3KB7V9DxYMJ1yUlRxvcrokImFcdBQUjlqnIA+FVENOF8rMTcbkU28/i7pBfeCMSEB5Q6fHwyxkykLjtmnq90yNj1HQJeT9+peFKmn8gkLcSGZ8DGTgAmaDuBFvWSl9ve/BgokHwwkXaSwODY8nFlJK211uDd0TFKLLUAZqVZqJVz+6AHnpslhUiDNYFhfCsN4eM/qonWuZvF8SWWYhbsTgcOJa3CBuBMkWylOb+sZmZa1TUv+rIfwUKCMS8OHDKmTWeouQyz6cte/uzp+1FZHQ32oICXww00Q5EzZDwgTzHPkF+A0F/FmlRUIBKoRaKAeN42lFnZ4ZyCMRyJPLemgPzSzEjcTPDQGzwdfL8n5R15qRFPfr17Ygdw7lSFYcJVh0sM5cv3fyr6rc5PhOvQUrPTnlhDwU9k5YoY+81GWQwUpbnZQzkifGqY02yPiR/d2bTz+c4AAGqLRAeuTFTeIYISnOQqsmeGLwrGDVdnr4kYXbaXeLnDTO4Fr41tunce1DIsssxLIo4VpU+NbHl2WZkrZBgzInHV0wPwhuT9jMMFB0B45Aw/B39jmXoVmYgVppSrzGaDPZnT5r/csGWlvz5tPlHzaAU9//1JoDO/Oga2btooMFoBGgEKyasGx5L+EDE1ZYI55MTxygzZC1hOutU2jF9S/LufzLJOLC1alasyMjIVaeFD+mt0YaOlzv1gJggkzfgP7dE1d2b16N8RM3dEBrqoYB0tAYzyI3kXAewlnnINxcbRCy++Wp2zatgi1F9VtPX+warb3csz0lzsafEbpEkpQ4+MEPv7wZZmVrl7ZiW25dy4BGZyHpl1mIFTDT5bOQcE6ZlrvjTFB69Kvb87ILoYMPl2ZyuvCS4V0YllpYeuD71GtbYGiG9FZ1B3VHlb+9gPBO9bk7VWXrLnaP1jUPAEbDUM7gcmkM1sodT4C72P6Lr8Exm4yO0LV6oyyvvmt4sdpFZxZG8GjgWaYE38iUMAZhmgMq5JQFK6vYmgN+4cMvbx76/VUka7JOsfptvH5vdK4Qyw7ordLYmIYm9dWbg0WZSYd+tOHinWHVfYN20s6URSoxlcGNMM0Q38iXV/qQGXrLLpkZwgC98+MNv65vP/TfLQt2Yb5k3ylb16gaARv00+/+312Am1QWPvbG8/lHP2sJ2gwrsxWnbqh5PmU5EXzYU+6KxDP/XAYWBO6zsV1DIqIxwFI4TXJl7aUesFN5huTiv/0tWsiCwFkB81mIo8AoGVZZtFdCSBoNPLJqdI2Q2joIMEBDhSxZgHklihUuy/ShU9+jEp+y0kSxLC2h4smVvOgouGGoghsAWYAOGp2Zmp4GK2/aXXd7UK01OZ1u736h/M2PL/PcHlj7P/+uH98RUgYrj3TA7gnJHvzDd/iuYefPvBF/CB57otlZx+cvKLQuyIDG+AKxKMqn7Ntl+a339Rq9RUOjDZYsjMvOfOn+LdnpKXE+f0mJWCRZlTIPA7fmUAZ13/CtauSza/1mu5PZL9o5aC2OEkXmV9fvMZXB/fq8ow//oeTl4+dRLSjm8riZshwIHpwcAr4Y79qRU6SNGWcw2KV+KJcH16LrS9evVGanHfpjM+KGWLIF8tSKzVnlm1YHYzWrUuDzj2XrYK282jHcpjMx+627dhf+hK1VXYta1atjKY9mGUuZ87eGvO9otkE/CD5cCaaMWCg49nWbz6oPXirGG4tQUkVxFnz29Y1RP8nMgqqffHKlOCcdHBleOvyk+tb7wfgsBB1gLZfSwBf29Gj/BXmElWHFxaAZpiFYAcwp6hejBREOqN6db3BM133blxEbLZzhYVnwiAd3F2zbsDK8PwyMO7j25s6RX56+CTqBznanG5yvZshYuVOxu2hVTX3HvPLi6Fk7YNwIVh7JSuNj0Y1ISRC8wtfyr/C5hHtRtEqx6NPmu7Dks2R5ccIPXlJG7kCkOG9FTabkwCdX1DoL1qq2QWXiz/DA8qxTfqCDb1o50tABjOLA7nwEjphp5/qVp97eEemjIzBwACjgChdCECtYPbj8MB+FBcHBMxF8Eaz0elv999QGhSm7d3PWO+WFD4ycOvzjooKVySfPdeKN9PEvb8mT47dnpfXqzEvJwWNuSCHk1/zTtldgEzftZsqCy3iQI4VSuTLLxeeB15+9EYvDzpv55cvKVz86b9BbODn4Bfx9GDl4Zi34V5jzzNr9yjVgAktCfoJDOLxnA1bGaXcd+mMTQNwgGHoOBB8oFw4YvVCWXNPQyZQFJAUWsYRkceW2x7V6q/paP1K+V2epeX3r6aaBNrWexcFjIt+bv2ch+DA4eMVjSS1dowt8n1hUXVmy5OR61Q8LmKvKB2duhdPBB8HBw0LzedNd3hwaRrIfvPoU7FSC4J1hJW3s0BhMjorN8ovdo/BnkSxZFCsCMFWaLw10PYXd5ZEXN5X/6hzS2TROMR/rc9Lqbw8ybwQT+T74e04EHxCf/d6eDaCNNDYG1yqLswIF6LBxqb3cw7O5MN4Bo0Y3YLc6W4cmYNQamtQAmqrK1oE/CohRqNqVD7JIvb4RIwwfGixChj5s0CEjUXzgtxdhpPDqm5eZ+C8/DGD5a707/ulfu3pHjCweHfbMF1QjmhETs9+BCWvtN50Nzfd+Wl64jrHB9p/eKVtnGrPMcvBxMZ+f7y7NzlBpjeGBDuTk34mqZ5//929glcH4vmJrdooklvA2jp+7w4xDYfbbO2rSGG2onNWvxup47aMLFVvWwHpH2FHJk7LaVjVC8FI+D7wEWMM8gsddcJF/IXHwx+o7YKRwIfipii3ZhDcAOAisb7GWr/ZqtWa7Hx699lIPdE0ITbYXSqmzNQN1SKwetwCMIGfow8PBA+C8pR7H+2coLMl/jNCvHz/Tdu+egSnL4u+ZZrgY96/q1YEJv/LcEyQ9HvnRhiN/vo4QfHJ8bPmugvaeMdQgViCCHPyxjatOftvD5NE/UGYRWl/t1V7/HPypq33okNU/9//51X6Dyw1eibPTotx0s9ttpjlIk9aozFsBHjBQMwweZ+3/TSNrH0uytAM+QPFvnLviBJpO4UzQmvfW3SfpWlogm2fuL/dwRjaEjYPfV5LtmvbU37yPAVr5hlVE93a2HcQ5+XtldhrAHLNlioT7P362XVn1HGfXuwtlVzuGZ/NPykQeXp/BwlSAk4MX+OfgMWm9gM+mJ0jrgI7JwStzuIMkYKvRTM8CTv7+k/PdgCq8+/UpC8qQsJ2A/vAdNbZr1FozSwHEwbO6CwMH76KXFSYHXyBfzqnupZuDJPw9Akfo3JCQ+4cpAwsOJ6Bflb4MRhah+e1rV5i6FjTCycEH6bNYGAdcDOc6CN66gezQMKBzQzxnqeMy7m1sMs4f+Ju8MJB/JBx8zdftGXExmIPPypBw9tTYPsTJ3+N+tTBtp91IGULuv3dokvOQVZ6eIE+MQxz8wRNXZqn3iHLwvDihWBKjvTuFJ215PPfKpRqe1M9x4b5DrBn9vvBUlkHlBjMk5P7hsvo7GgCf/nXIkMSqAZHQsrBJPPI/FAdHzsEHcxQmEUfLFv6GJFsccBYBbK1b1Bo67pI8kZghc+qp7hvAdWhCNEPOjfSA3tqgV8N0ZXLwnD0lRAtTiQPScqTJgCGcsS7yOPhYAh3EImFucjzi4Mf0VrGbhy09Uhy8LFMCy/CJRhVmf4aMdk5FYRM7NGYijGUv3bQa7KVteJI8Dl4m4Pabpilnp96CZHNWp/Ra7K2jk+Hn4LevzazalU/Rj2XrYKSGDFbIgDFCHsrFQu5VtWKzXJGRiK6HZhEzBXYBGSlqh961QO1+5ZozN+5BCZQz+8XX435BVfiG8ty0BGifUwdmv4h0w/1CJmwcvNk2rb1vgHL1qEmlN0Ohy+4UeGZMlqnO+wY5YyexWOodNbrcHpNjupNup3toYsRk57k9fcNG+IZ2oGUoh1qPy/Oics2wyQblzH41OjOUgK/B/cL6Bd9m+7R4ho9Bpp8EcBb163K6dSb7kM4M/hcUoB6YsUxxcvBCcveJwt8BgkPmxFvbqn5/BcXBQ9XzBIMFDt5hn9ZMWOF60KOpT4di6GHJM9ud8GmeGUPtg9LyDMl19TgUsvqlru/X4X4BB6AtAXgiEsKDZq6pfuHHhkUJ9dvknkE3GC+KTBz8kbobs7QvsnD6mRj/CUA/eSz7t92jWrMdKUMYBy8nwHrjZsfklBPJvn/6VqAcfJDnhhWbs5i1JD4roBPJfcoshTSZ/HRPJhGXFkg5FbgxMI5lyzeuDunckJyDlyWKC1YkORzOCEGH5i6tYcKGmUhO6LCDYKQgOSxTCDqIxELhDA+j/8hy8Af+8ztpohgMfnYm008McEIH04SNMHi3ODXeNjOD4gVJAn9riuUkDqtt1IjuSMqPP9moCgP5x+SkMS3NYqwV0qRD5etxrd3lIflhSVpGtRuzlqNNgs9aliyCApy9w0qCZd/bsyFlLjbTv1bh4OBtLvWwMS91GTIHsEoSMySPofcZB+9TFrwV4TFPU+cIKIzolxu9Y4kzfNYhQAQ5+JRBvTM6SqU1RsIMSeLgkezhlzeTgAZABo09o+iOFKtS2kcmsTIPgoOH9AodPhyJRMhnvbtnPeHpd/W5O8y9REBkWagcPNq19w1NYsaau6e5RngEMfRN/WNaswOVL8bBH95bxMnJYN6xqXuUQuTCKJiGR79ohQblCWLUYMQ5eMSFv/ZMLjqGEgmjSJT2w6Oz+oXtDjor8tnvqtRln/+slDzooe5Kn5k+VYOWX9++9gU6pBw3GHEOHlV9dq1fuTYT/nTOxdL5R/CEMfSQ/tx0V0OzdN79Vu544u+eeZw8Sge8Vd21uzgOvkU93tg5DB3hBsk5+JDi4KmNVd9Y5bbHw+6zAApQxwp2J5NfrFLKAxomHCeA8/tKspv7dMxmHwQHj7lwYZTghfWrhnXcsfkAHURcPPqZyi1wJ2MTthxZUuPtId60u1CeOhMlkGckkGz9vNOZpgGT3oaV3124srljhHriY6ni4Pf+R+MXP91BBB24OHgFI5BIIUsOcXoCZD/4p2YMDsDH/X3NRd6Sx8HHxYhCb0RBHHJFuAIe/WzeAGGbvTNfGmKb4YmD1+jMYDghbqRJzrQJk33K9fNTTamx0SgoPy8z0WhzVX91O5dWYInj4MPCwUszJeGaU69+dB5sEL0DB5Q/9ubWI3WtKp2Z2S9vqeLgw8JnheVRMQAK4JjQsRtqGRbW6jNtTbMxFksdB08ISoVzjfB8vU+maM3y0EeqTa3/10+bJm3T+AU1sMeGvr78ttfPu2jI4+B9jB/eeWNJZiHOwM4A410SULqYrJ1+K1pRVlqITupYfTuAT7RlQYXJiWL0HgiEBha7I6QAqsWyuJYDwYOH80bwUIhhLn6vmMuzAJFzInifsnAnkAllZoGJnTzbcXFAx0ThaE6995frPIbyzCdZcQYpwELws4PwAJ5kDSIF57BgmI6fu0OFRNCoEqP/4rRlx891SGNjwqtk2B6hC4WDrwxwpGC9a7w1WN+idjk9+AUaWOd9zzze1K2FkXq4XmMXLugQmxwLs8P/5AKv1DZoaO7XtanHm/p0zBfk4ZX+vde3go8HlBDKa+z8QIeAH0fJTUuQZUrg3pi1JNChNF9ap7f5bLmxXQMfasvGn5HRD6ODKWnNDtiog0PRWB0qzQTMFLwpAXGmVrC1PrAzr+ZSd/W5DnDnrFpeaC+MCskMN65OTU+Nh91poGaYm57w/JOyQoujd2gSponPo7DbY0Zo2RUdlbdOqp0cofbAHr5pwpYQFeXT/LOWLyvMXs5zzySLoyWwzNtc6KTrwb1N0j8Hf/b2kDcXTsLB15zvgptXFj62+6msT6/0piTG3ujR8oKNgy9emwHIc9dmeavGUHupB6xvUR6dobzvB8oj9zhKSkpcRW5aXfMAs5b8KAxujJ5lkv3KNQbwzXQclup7C6vfjCQx4rNYR2GwH85IiIVhgl0x9bD4mVvYZ/nROZRaDgQPcxUcIUbwyJihEH4W6jbogyO4DKHwWXo+lpt1EM41QqlimXq/7qYVbCRamJuRqMhMrK78QePNwSGzPVUivnZn5KUt2XdGjLXnu6rK1rWNUHuXnzyX98aJy3A9eKWRcevRL1p59IsZUYNMnQFbIq1wIVY+iWZHqDA5zwxWJlUcjTLeskFG0eBkMDlUY6ZwIReYI3bLNFjc3mMN4G6GbFR8x5DBChNwcspJIynd1btjMMW6+sdxBA7zlTKE6dTbz8IAxdALkYc+TJXEiOz09BFFCZw0+BQI+J65yfVzBr0TPAefkigufCIDP1IyR2OHh4OHFRAd6uxY91ijakQ17aLeJWZ28IjfgeODR6cz5R828AJ8tzIRgvdvw9TPa3WwaoM4vvfvO9R6CzraC+/r88Lps0iO7xXLE5x8nmnhe9/CfnxvnrCjOPggXp8X6GvsInh8b3J7ZCskqhvqQKFDQMf3u4rlWqeL5Pg+xLdJAqAFAKwa0lPnSY5pCganLUN0WBg4eHAiJM/AhZiot19pJh7ABh6wy871VIzn3uLZ8Dk/YSYBH4VtXLN8p2Rlw61B5nEWn8cnMUMR8eMoOSsSURw8+eMoWJZ1nLXgHM/rlVBUNH+MCBoBi7Mnxt2Li4G5iQch1KMwvXXaFsWnJjBjwv/hfNeQ1eH/iVKSozDm4ygas6NteJL8cRRvM8SFCj9mmBpnm3JCBixuwGjT2qjI1flBCNEMqffw+ToTBtss/9W5gJ458ZMQS8V7yFLAHPwLP1ijzElXa02q+xMsHh2w9bG/tJZuWr2/JDtQDp63RO+DFwsFIiGdiRIsE6HrBYu9D17gn4PHHaPCimI5Yp2qK0vEMfNqYRpba7QfPX2zsuaiz3gCJgfvLeun34BkvXl0/y1jRE0je38cvMAbwSPUDhkKwtKf2ZU4iv/mc4rZsy/qNS8bURV8YEqiDJK92qN9/v2zF+8M++Tg0YOwi8l694tKyGXhAlYhbgQ3ixtEcJrKuD02t8dFjxeWDf5JVlaca4liRen6lX6IzYP/dY1641ewISsPJoFnrD3fjXwuelgDvfc6VA6+qW14+437rPfBs0LJWbJNnSMHdZZDFUU5sqSA4uB5//f+lQyP5N/BWBy9H1/auzWHIvOMjof/X8mQcvDF2WlVu/JhODX09gWtBchucWHQtTsLZBFqOXK1rH9SIWRSSwppEqr2GZsj9cr8f6hlIsf5wcL/a+1RWiw9+v+GjwYrMul/BRgArXujn0OLvmAAAAAASUVORK5CYII="
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                }
            ],
            "description": "Tela Manter Arquivo",
            "footer": [],
            "group": "Arquivo",
            "header": [],
            "icon": "fa-home",
            "id": "arquivo",
            "locked": true,
            "menuHorizontal": false,
            "menuVertical": true,
            "title": "Arquivo"
        },
        {
            "body": [
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "filename": "logo.png",
                    "id": "imagem",
                    "name": "Imagem",
                    "style": "vertical-center2",
                    "type": "img",
                    "value": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAFj9JREFUeNrsXQtQVFea7m66gQZpXvIw3WojENMIRFHpOJhoDC6a2TAWTrTyqCybTTbrZEJNxa21as1WOTVjpbI1Y2ZxMlRKJ8NumcxkZ0Jck5JYML6iMYCiAtI8pRUaaJpu6HdDP9j/3gOHy+2m7+mXWLue6uo6nHP/c/57+vz/+c53/nvh5/zsT7xHiSwJHg3Bo8GKSBLi3OE9GxTSpEcjwkoqzeTR0zfZg4VGqrlflyCKMjvdVB2fD9+umRn4xoXM2vJNq+ta1IvVsmQrNssbbg0StvyQ1BZnpzEnkJA5ijBS1d90KJKXqSYs8Kckmqo1TbuooZwrZNYWrVkO1y9Wy5KFjuuu9BO2/JDUVu3KB7V9DxYMJ1yUlRxvcrokImFcdBQUjlqnIA+FVENOF8rMTcbkU28/i7pBfeCMSEB5Q6fHwyxkykLjtmnq90yNj1HQJeT9+peFKmn8gkLcSGZ8DGTgAmaDuBFvWSl9ve/BgokHwwkXaSwODY8nFlJK211uDd0TFKLLUAZqVZqJVz+6AHnpslhUiDNYFhfCsN4eM/qonWuZvF8SWWYhbsTgcOJa3CBuBMkWylOb+sZmZa1TUv+rIfwUKCMS8OHDKmTWeouQyz6cte/uzp+1FZHQ32oICXww00Q5EzZDwgTzHPkF+A0F/FmlRUIBKoRaKAeN42lFnZ4ZyCMRyJPLemgPzSzEjcTPDQGzwdfL8n5R15qRFPfr17Ygdw7lSFYcJVh0sM5cv3fyr6rc5PhOvQUrPTnlhDwU9k5YoY+81GWQwUpbnZQzkifGqY02yPiR/d2bTz+c4AAGqLRAeuTFTeIYISnOQqsmeGLwrGDVdnr4kYXbaXeLnDTO4Fr41tunce1DIsssxLIo4VpU+NbHl2WZkrZBgzInHV0wPwhuT9jMMFB0B45Aw/B39jmXoVmYgVppSrzGaDPZnT5r/csGWlvz5tPlHzaAU9//1JoDO/Oga2btooMFoBGgEKyasGx5L+EDE1ZYI55MTxygzZC1hOutU2jF9S/LufzLJOLC1alasyMjIVaeFD+mt0YaOlzv1gJggkzfgP7dE1d2b16N8RM3dEBrqoYB0tAYzyI3kXAewlnnINxcbRCy++Wp2zatgi1F9VtPX+warb3csz0lzsafEbpEkpQ4+MEPv7wZZmVrl7ZiW25dy4BGZyHpl1mIFTDT5bOQcE6ZlrvjTFB69Kvb87ILoYMPl2ZyuvCS4V0YllpYeuD71GtbYGiG9FZ1B3VHlb+9gPBO9bk7VWXrLnaP1jUPAEbDUM7gcmkM1sodT4C72P6Lr8Exm4yO0LV6oyyvvmt4sdpFZxZG8GjgWaYE38iUMAZhmgMq5JQFK6vYmgN+4cMvbx76/VUka7JOsfptvH5vdK4Qyw7ordLYmIYm9dWbg0WZSYd+tOHinWHVfYN20s6URSoxlcGNMM0Q38iXV/qQGXrLLpkZwgC98+MNv65vP/TfLQt2Yb5k3ylb16gaARv00+/+312Am1QWPvbG8/lHP2sJ2gwrsxWnbqh5PmU5EXzYU+6KxDP/XAYWBO6zsV1DIqIxwFI4TXJl7aUesFN5huTiv/0tWsiCwFkB81mIo8AoGVZZtFdCSBoNPLJqdI2Q2joIMEBDhSxZgHklihUuy/ShU9+jEp+y0kSxLC2h4smVvOgouGGoghsAWYAOGp2Zmp4GK2/aXXd7UK01OZ1u736h/M2PL/PcHlj7P/+uH98RUgYrj3TA7gnJHvzDd/iuYefPvBF/CB57otlZx+cvKLQuyIDG+AKxKMqn7Ntl+a339Rq9RUOjDZYsjMvOfOn+LdnpKXE+f0mJWCRZlTIPA7fmUAZ13/CtauSza/1mu5PZL9o5aC2OEkXmV9fvMZXB/fq8ow//oeTl4+dRLSjm8riZshwIHpwcAr4Y79qRU6SNGWcw2KV+KJcH16LrS9evVGanHfpjM+KGWLIF8tSKzVnlm1YHYzWrUuDzj2XrYK282jHcpjMx+627dhf+hK1VXYta1atjKY9mGUuZ87eGvO9otkE/CD5cCaaMWCg49nWbz6oPXirGG4tQUkVxFnz29Y1RP8nMgqqffHKlOCcdHBleOvyk+tb7wfgsBB1gLZfSwBf29Gj/BXmElWHFxaAZpiFYAcwp6hejBREOqN6db3BM133blxEbLZzhYVnwiAd3F2zbsDK8PwyMO7j25s6RX56+CTqBznanG5yvZshYuVOxu2hVTX3HvPLi6Fk7YNwIVh7JSuNj0Y1ISRC8wtfyr/C5hHtRtEqx6NPmu7Dks2R5ccIPXlJG7kCkOG9FTabkwCdX1DoL1qq2QWXiz/DA8qxTfqCDb1o50tABjOLA7nwEjphp5/qVp97eEemjIzBwACjgChdCECtYPbj8MB+FBcHBMxF8Eaz0elv999QGhSm7d3PWO+WFD4ycOvzjooKVySfPdeKN9PEvb8mT47dnpfXqzEvJwWNuSCHk1/zTtldgEzftZsqCy3iQI4VSuTLLxeeB15+9EYvDzpv55cvKVz86b9BbODn4Bfx9GDl4Zi34V5jzzNr9yjVgAktCfoJDOLxnA1bGaXcd+mMTQNwgGHoOBB8oFw4YvVCWXNPQyZQFJAUWsYRkceW2x7V6q/paP1K+V2epeX3r6aaBNrWexcFjIt+bv2ch+DA4eMVjSS1dowt8n1hUXVmy5OR61Q8LmKvKB2duhdPBB8HBw0LzedNd3hwaRrIfvPoU7FSC4J1hJW3s0BhMjorN8ovdo/BnkSxZFCsCMFWaLw10PYXd5ZEXN5X/6hzS2TROMR/rc9Lqbw8ybwQT+T74e04EHxCf/d6eDaCNNDYG1yqLswIF6LBxqb3cw7O5MN4Bo0Y3YLc6W4cmYNQamtQAmqrK1oE/CohRqNqVD7JIvb4RIwwfGixChj5s0CEjUXzgtxdhpPDqm5eZ+C8/DGD5a707/ulfu3pHjCweHfbMF1QjmhETs9+BCWvtN50Nzfd+Wl64jrHB9p/eKVtnGrPMcvBxMZ+f7y7NzlBpjeGBDuTk34mqZ5//929glcH4vmJrdooklvA2jp+7w4xDYfbbO2rSGG2onNWvxup47aMLFVvWwHpH2FHJk7LaVjVC8FI+D7wEWMM8gsddcJF/IXHwx+o7YKRwIfipii3ZhDcAOAisb7GWr/ZqtWa7Hx699lIPdE0ITbYXSqmzNQN1SKwetwCMIGfow8PBA+C8pR7H+2coLMl/jNCvHz/Tdu+egSnL4u+ZZrgY96/q1YEJv/LcEyQ9HvnRhiN/vo4QfHJ8bPmugvaeMdQgViCCHPyxjatOftvD5NE/UGYRWl/t1V7/HPypq33okNU/9//51X6Dyw1eibPTotx0s9ttpjlIk9aozFsBHjBQMwweZ+3/TSNrH0uytAM+QPFvnLviBJpO4UzQmvfW3SfpWlogm2fuL/dwRjaEjYPfV5LtmvbU37yPAVr5hlVE93a2HcQ5+XtldhrAHLNlioT7P362XVn1HGfXuwtlVzuGZ/NPykQeXp/BwlSAk4MX+OfgMWm9gM+mJ0jrgI7JwStzuIMkYKvRTM8CTv7+k/PdgCq8+/UpC8qQsJ2A/vAdNbZr1FozSwHEwbO6CwMH76KXFSYHXyBfzqnupZuDJPw9Akfo3JCQ+4cpAwsOJ6Bflb4MRhah+e1rV5i6FjTCycEH6bNYGAdcDOc6CN66gezQMKBzQzxnqeMy7m1sMs4f+Ju8MJB/JBx8zdftGXExmIPPypBw9tTYPsTJ3+N+tTBtp91IGULuv3dokvOQVZ6eIE+MQxz8wRNXZqn3iHLwvDihWBKjvTuFJ215PPfKpRqe1M9x4b5DrBn9vvBUlkHlBjMk5P7hsvo7GgCf/nXIkMSqAZHQsrBJPPI/FAdHzsEHcxQmEUfLFv6GJFsccBYBbK1b1Bo67pI8kZghc+qp7hvAdWhCNEPOjfSA3tqgV8N0ZXLwnD0lRAtTiQPScqTJgCGcsS7yOPhYAh3EImFucjzi4Mf0VrGbhy09Uhy8LFMCy/CJRhVmf4aMdk5FYRM7NGYijGUv3bQa7KVteJI8Dl4m4Pabpilnp96CZHNWp/Ra7K2jk+Hn4LevzazalU/Rj2XrYKSGDFbIgDFCHsrFQu5VtWKzXJGRiK6HZhEzBXYBGSlqh961QO1+5ZozN+5BCZQz+8XX435BVfiG8ty0BGifUwdmv4h0w/1CJmwcvNk2rb1vgHL1qEmlN0Ohy+4UeGZMlqnO+wY5YyexWOodNbrcHpNjupNup3toYsRk57k9fcNG+IZ2oGUoh1qPy/Oics2wyQblzH41OjOUgK/B/cL6Bd9m+7R4ho9Bpp8EcBb163K6dSb7kM4M/hcUoB6YsUxxcvBCcveJwt8BgkPmxFvbqn5/BcXBQ9XzBIMFDt5hn9ZMWOF60KOpT4di6GHJM9ud8GmeGUPtg9LyDMl19TgUsvqlru/X4X4BB6AtAXgiEsKDZq6pfuHHhkUJ9dvknkE3GC+KTBz8kbobs7QvsnD6mRj/CUA/eSz7t92jWrMdKUMYBy8nwHrjZsfklBPJvn/6VqAcfJDnhhWbs5i1JD4roBPJfcoshTSZ/HRPJhGXFkg5FbgxMI5lyzeuDunckJyDlyWKC1YkORzOCEGH5i6tYcKGmUhO6LCDYKQgOSxTCDqIxELhDA+j/8hy8Af+8ztpohgMfnYm008McEIH04SNMHi3ODXeNjOD4gVJAn9riuUkDqtt1IjuSMqPP9moCgP5x+SkMS3NYqwV0qRD5etxrd3lIflhSVpGtRuzlqNNgs9aliyCApy9w0qCZd/bsyFlLjbTv1bh4OBtLvWwMS91GTIHsEoSMySPofcZB+9TFrwV4TFPU+cIKIzolxu9Y4kzfNYhQAQ5+JRBvTM6SqU1RsIMSeLgkezhlzeTgAZABo09o+iOFKtS2kcmsTIPgoOH9AodPhyJRMhnvbtnPeHpd/W5O8y9REBkWagcPNq19w1NYsaau6e5RngEMfRN/WNaswOVL8bBH95bxMnJYN6xqXuUQuTCKJiGR79ohQblCWLUYMQ5eMSFv/ZMLjqGEgmjSJT2w6Oz+oXtDjor8tnvqtRln/+slDzooe5Kn5k+VYOWX9++9gU6pBw3GHEOHlV9dq1fuTYT/nTOxdL5R/CEMfSQ/tx0V0OzdN79Vu544u+eeZw8Sge8Vd21uzgOvkU93tg5DB3hBsk5+JDi4KmNVd9Y5bbHw+6zAApQxwp2J5NfrFLKAxomHCeA8/tKspv7dMxmHwQHj7lwYZTghfWrhnXcsfkAHURcPPqZyi1wJ2MTthxZUuPtId60u1CeOhMlkGckkGz9vNOZpgGT3oaV3124srljhHriY6ni4Pf+R+MXP91BBB24OHgFI5BIIUsOcXoCZD/4p2YMDsDH/X3NRd6Sx8HHxYhCb0RBHHJFuAIe/WzeAGGbvTNfGmKb4YmD1+jMYDghbqRJzrQJk33K9fNTTamx0SgoPy8z0WhzVX91O5dWYInj4MPCwUszJeGaU69+dB5sEL0DB5Q/9ubWI3WtKp2Z2S9vqeLgw8JnheVRMQAK4JjQsRtqGRbW6jNtTbMxFksdB08ISoVzjfB8vU+maM3y0EeqTa3/10+bJm3T+AU1sMeGvr78ttfPu2jI4+B9jB/eeWNJZiHOwM4A410SULqYrJ1+K1pRVlqITupYfTuAT7RlQYXJiWL0HgiEBha7I6QAqsWyuJYDwYOH80bwUIhhLn6vmMuzAJFzInifsnAnkAllZoGJnTzbcXFAx0ThaE6995frPIbyzCdZcQYpwELws4PwAJ5kDSIF57BgmI6fu0OFRNCoEqP/4rRlx891SGNjwqtk2B6hC4WDrwxwpGC9a7w1WN+idjk9+AUaWOd9zzze1K2FkXq4XmMXLugQmxwLs8P/5AKv1DZoaO7XtanHm/p0zBfk4ZX+vde3go8HlBDKa+z8QIeAH0fJTUuQZUrg3pi1JNChNF9ap7f5bLmxXQMfasvGn5HRD6ODKWnNDtiog0PRWB0qzQTMFLwpAXGmVrC1PrAzr+ZSd/W5DnDnrFpeaC+MCskMN65OTU+Nh91poGaYm57w/JOyQoujd2gSponPo7DbY0Zo2RUdlbdOqp0cofbAHr5pwpYQFeXT/LOWLyvMXs5zzySLoyWwzNtc6KTrwb1N0j8Hf/b2kDcXTsLB15zvgptXFj62+6msT6/0piTG3ujR8oKNgy9emwHIc9dmeavGUHupB6xvUR6dobzvB8oj9zhKSkpcRW5aXfMAs5b8KAxujJ5lkv3KNQbwzXQclup7C6vfjCQx4rNYR2GwH85IiIVhgl0x9bD4mVvYZ/nROZRaDgQPcxUcIUbwyJihEH4W6jbogyO4DKHwWXo+lpt1EM41QqlimXq/7qYVbCRamJuRqMhMrK78QePNwSGzPVUivnZn5KUt2XdGjLXnu6rK1rWNUHuXnzyX98aJy3A9eKWRcevRL1p59IsZUYNMnQFbIq1wIVY+iWZHqDA5zwxWJlUcjTLeskFG0eBkMDlUY6ZwIReYI3bLNFjc3mMN4G6GbFR8x5DBChNwcspJIynd1btjMMW6+sdxBA7zlTKE6dTbz8IAxdALkYc+TJXEiOz09BFFCZw0+BQI+J65yfVzBr0TPAefkigufCIDP1IyR2OHh4OHFRAd6uxY91ijakQ17aLeJWZ28IjfgeODR6cz5R828AJ8tzIRgvdvw9TPa3WwaoM4vvfvO9R6CzraC+/r88Lps0iO7xXLE5x8nmnhe9/CfnxvnrCjOPggXp8X6GvsInh8b3J7ZCskqhvqQKFDQMf3u4rlWqeL5Pg+xLdJAqAFAKwa0lPnSY5pCganLUN0WBg4eHAiJM/AhZiot19pJh7ABh6wy871VIzn3uLZ8Dk/YSYBH4VtXLN8p2Rlw61B5nEWn8cnMUMR8eMoOSsSURw8+eMoWJZ1nLXgHM/rlVBUNH+MCBoBi7Mnxt2Li4G5iQch1KMwvXXaFsWnJjBjwv/hfNeQ1eH/iVKSozDm4ygas6NteJL8cRRvM8SFCj9mmBpnm3JCBixuwGjT2qjI1flBCNEMqffw+ToTBtss/9W5gJ458ZMQS8V7yFLAHPwLP1ijzElXa02q+xMsHh2w9bG/tJZuWr2/JDtQDp63RO+DFwsFIiGdiRIsE6HrBYu9D17gn4PHHaPCimI5Yp2qK0vEMfNqYRpba7QfPX2zsuaiz3gCJgfvLeun34BkvXl0/y1jRE0je38cvMAbwSPUDhkKwtKf2ZU4iv/mc4rZsy/qNS8bURV8YEqiDJK92qN9/v2zF+8M++Tg0YOwi8l694tKyGXhAlYhbgQ3ixtEcJrKuD02t8dFjxeWDf5JVlaca4liRen6lX6IzYP/dY1641ewISsPJoFnrD3fjXwuelgDvfc6VA6+qW14+437rPfBs0LJWbJNnSMHdZZDFUU5sqSA4uB5//f+lQyP5N/BWBy9H1/auzWHIvOMjof/X8mQcvDF2WlVu/JhODX09gWtBchucWHQtTsLZBFqOXK1rH9SIWRSSwppEqr2GZsj9cr8f6hlIsf5wcL/a+1RWiw9+v+GjwYrMul/BRgArXujn0OLvmAAAAAASUVORK5CYII="
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                }
            ],
            "description": "Tela Manter Tipo Mensagem",
            "footer": [],
            "group": "Tipo Mensagem",
            "header": [],
            "icon": "fa-home",
            "id": "mensagem",
            "locked": true,
            "menuHorizontal": false,
            "menuVertical": true,
            "title": "Tipo Mensagem"
        },
        {
            "body": [
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "filename": "logo.png",
                    "id": "imagem",
                    "name": "Imagem",
                    "style": "vertical-center2",
                    "type": "img",
                    "value": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAFj9JREFUeNrsXQtQVFea7m66gQZpXvIw3WojENMIRFHpOJhoDC6a2TAWTrTyqCybTTbrZEJNxa21as1WOTVjpbI1Y2ZxMlRKJ8NumcxkZ0Jck5JYML6iMYCiAtI8pRUaaJpu6HdDP9j/3gOHy+2m7+mXWLue6uo6nHP/c/57+vz/+c53/nvh5/zsT7xHiSwJHg3Bo8GKSBLi3OE9GxTSpEcjwkoqzeTR0zfZg4VGqrlflyCKMjvdVB2fD9+umRn4xoXM2vJNq+ta1IvVsmQrNssbbg0StvyQ1BZnpzEnkJA5ijBS1d90KJKXqSYs8Kckmqo1TbuooZwrZNYWrVkO1y9Wy5KFjuuu9BO2/JDUVu3KB7V9DxYMJ1yUlRxvcrokImFcdBQUjlqnIA+FVENOF8rMTcbkU28/i7pBfeCMSEB5Q6fHwyxkykLjtmnq90yNj1HQJeT9+peFKmn8gkLcSGZ8DGTgAmaDuBFvWSl9ve/BgokHwwkXaSwODY8nFlJK211uDd0TFKLLUAZqVZqJVz+6AHnpslhUiDNYFhfCsN4eM/qonWuZvF8SWWYhbsTgcOJa3CBuBMkWylOb+sZmZa1TUv+rIfwUKCMS8OHDKmTWeouQyz6cte/uzp+1FZHQ32oICXww00Q5EzZDwgTzHPkF+A0F/FmlRUIBKoRaKAeN42lFnZ4ZyCMRyJPLemgPzSzEjcTPDQGzwdfL8n5R15qRFPfr17Ygdw7lSFYcJVh0sM5cv3fyr6rc5PhOvQUrPTnlhDwU9k5YoY+81GWQwUpbnZQzkifGqY02yPiR/d2bTz+c4AAGqLRAeuTFTeIYISnOQqsmeGLwrGDVdnr4kYXbaXeLnDTO4Fr41tunce1DIsssxLIo4VpU+NbHl2WZkrZBgzInHV0wPwhuT9jMMFB0B45Aw/B39jmXoVmYgVppSrzGaDPZnT5r/csGWlvz5tPlHzaAU9//1JoDO/Oga2btooMFoBGgEKyasGx5L+EDE1ZYI55MTxygzZC1hOutU2jF9S/LufzLJOLC1alasyMjIVaeFD+mt0YaOlzv1gJggkzfgP7dE1d2b16N8RM3dEBrqoYB0tAYzyI3kXAewlnnINxcbRCy++Wp2zatgi1F9VtPX+warb3csz0lzsafEbpEkpQ4+MEPv7wZZmVrl7ZiW25dy4BGZyHpl1mIFTDT5bOQcE6ZlrvjTFB69Kvb87ILoYMPl2ZyuvCS4V0YllpYeuD71GtbYGiG9FZ1B3VHlb+9gPBO9bk7VWXrLnaP1jUPAEbDUM7gcmkM1sodT4C72P6Lr8Exm4yO0LV6oyyvvmt4sdpFZxZG8GjgWaYE38iUMAZhmgMq5JQFK6vYmgN+4cMvbx76/VUka7JOsfptvH5vdK4Qyw7ordLYmIYm9dWbg0WZSYd+tOHinWHVfYN20s6URSoxlcGNMM0Q38iXV/qQGXrLLpkZwgC98+MNv65vP/TfLQt2Yb5k3ylb16gaARv00+/+312Am1QWPvbG8/lHP2sJ2gwrsxWnbqh5PmU5EXzYU+6KxDP/XAYWBO6zsV1DIqIxwFI4TXJl7aUesFN5huTiv/0tWsiCwFkB81mIo8AoGVZZtFdCSBoNPLJqdI2Q2joIMEBDhSxZgHklihUuy/ShU9+jEp+y0kSxLC2h4smVvOgouGGoghsAWYAOGp2Zmp4GK2/aXXd7UK01OZ1u736h/M2PL/PcHlj7P/+uH98RUgYrj3TA7gnJHvzDd/iuYefPvBF/CB57otlZx+cvKLQuyIDG+AKxKMqn7Ntl+a339Rq9RUOjDZYsjMvOfOn+LdnpKXE+f0mJWCRZlTIPA7fmUAZ13/CtauSza/1mu5PZL9o5aC2OEkXmV9fvMZXB/fq8ow//oeTl4+dRLSjm8riZshwIHpwcAr4Y79qRU6SNGWcw2KV+KJcH16LrS9evVGanHfpjM+KGWLIF8tSKzVnlm1YHYzWrUuDzj2XrYK282jHcpjMx+627dhf+hK1VXYta1atjKY9mGUuZ87eGvO9otkE/CD5cCaaMWCg49nWbz6oPXirGG4tQUkVxFnz29Y1RP8nMgqqffHKlOCcdHBleOvyk+tb7wfgsBB1gLZfSwBf29Gj/BXmElWHFxaAZpiFYAcwp6hejBREOqN6db3BM133blxEbLZzhYVnwiAd3F2zbsDK8PwyMO7j25s6RX56+CTqBznanG5yvZshYuVOxu2hVTX3HvPLi6Fk7YNwIVh7JSuNj0Y1ISRC8wtfyr/C5hHtRtEqx6NPmu7Dks2R5ccIPXlJG7kCkOG9FTabkwCdX1DoL1qq2QWXiz/DA8qxTfqCDb1o50tABjOLA7nwEjphp5/qVp97eEemjIzBwACjgChdCECtYPbj8MB+FBcHBMxF8Eaz0elv999QGhSm7d3PWO+WFD4ycOvzjooKVySfPdeKN9PEvb8mT47dnpfXqzEvJwWNuSCHk1/zTtldgEzftZsqCy3iQI4VSuTLLxeeB15+9EYvDzpv55cvKVz86b9BbODn4Bfx9GDl4Zi34V5jzzNr9yjVgAktCfoJDOLxnA1bGaXcd+mMTQNwgGHoOBB8oFw4YvVCWXNPQyZQFJAUWsYRkceW2x7V6q/paP1K+V2epeX3r6aaBNrWexcFjIt+bv2ch+DA4eMVjSS1dowt8n1hUXVmy5OR61Q8LmKvKB2duhdPBB8HBw0LzedNd3hwaRrIfvPoU7FSC4J1hJW3s0BhMjorN8ovdo/BnkSxZFCsCMFWaLw10PYXd5ZEXN5X/6hzS2TROMR/rc9Lqbw8ybwQT+T74e04EHxCf/d6eDaCNNDYG1yqLswIF6LBxqb3cw7O5MN4Bo0Y3YLc6W4cmYNQamtQAmqrK1oE/CohRqNqVD7JIvb4RIwwfGixChj5s0CEjUXzgtxdhpPDqm5eZ+C8/DGD5a707/ulfu3pHjCweHfbMF1QjmhETs9+BCWvtN50Nzfd+Wl64jrHB9p/eKVtnGrPMcvBxMZ+f7y7NzlBpjeGBDuTk34mqZ5//929glcH4vmJrdooklvA2jp+7w4xDYfbbO2rSGG2onNWvxup47aMLFVvWwHpH2FHJk7LaVjVC8FI+D7wEWMM8gsddcJF/IXHwx+o7YKRwIfipii3ZhDcAOAisb7GWr/ZqtWa7Hx699lIPdE0ITbYXSqmzNQN1SKwetwCMIGfow8PBA+C8pR7H+2coLMl/jNCvHz/Tdu+egSnL4u+ZZrgY96/q1YEJv/LcEyQ9HvnRhiN/vo4QfHJ8bPmugvaeMdQgViCCHPyxjatOftvD5NE/UGYRWl/t1V7/HPypq33okNU/9//51X6Dyw1eibPTotx0s9ttpjlIk9aozFsBHjBQMwweZ+3/TSNrH0uytAM+QPFvnLviBJpO4UzQmvfW3SfpWlogm2fuL/dwRjaEjYPfV5LtmvbU37yPAVr5hlVE93a2HcQ5+XtldhrAHLNlioT7P362XVn1HGfXuwtlVzuGZ/NPykQeXp/BwlSAk4MX+OfgMWm9gM+mJ0jrgI7JwStzuIMkYKvRTM8CTv7+k/PdgCq8+/UpC8qQsJ2A/vAdNbZr1FozSwHEwbO6CwMH76KXFSYHXyBfzqnupZuDJPw9Akfo3JCQ+4cpAwsOJ6Bflb4MRhah+e1rV5i6FjTCycEH6bNYGAdcDOc6CN66gezQMKBzQzxnqeMy7m1sMs4f+Ju8MJB/JBx8zdftGXExmIPPypBw9tTYPsTJ3+N+tTBtp91IGULuv3dokvOQVZ6eIE+MQxz8wRNXZqn3iHLwvDihWBKjvTuFJ215PPfKpRqe1M9x4b5DrBn9vvBUlkHlBjMk5P7hsvo7GgCf/nXIkMSqAZHQsrBJPPI/FAdHzsEHcxQmEUfLFv6GJFsccBYBbK1b1Bo67pI8kZghc+qp7hvAdWhCNEPOjfSA3tqgV8N0ZXLwnD0lRAtTiQPScqTJgCGcsS7yOPhYAh3EImFucjzi4Mf0VrGbhy09Uhy8LFMCy/CJRhVmf4aMdk5FYRM7NGYijGUv3bQa7KVteJI8Dl4m4Pabpilnp96CZHNWp/Ra7K2jk+Hn4LevzazalU/Rj2XrYKSGDFbIgDFCHsrFQu5VtWKzXJGRiK6HZhEzBXYBGSlqh961QO1+5ZozN+5BCZQz+8XX435BVfiG8ty0BGifUwdmv4h0w/1CJmwcvNk2rb1vgHL1qEmlN0Ohy+4UeGZMlqnO+wY5YyexWOodNbrcHpNjupNup3toYsRk57k9fcNG+IZ2oGUoh1qPy/Oics2wyQblzH41OjOUgK/B/cL6Bd9m+7R4ho9Bpp8EcBb163K6dSb7kM4M/hcUoB6YsUxxcvBCcveJwt8BgkPmxFvbqn5/BcXBQ9XzBIMFDt5hn9ZMWOF60KOpT4di6GHJM9ud8GmeGUPtg9LyDMl19TgUsvqlru/X4X4BB6AtAXgiEsKDZq6pfuHHhkUJ9dvknkE3GC+KTBz8kbobs7QvsnD6mRj/CUA/eSz7t92jWrMdKUMYBy8nwHrjZsfklBPJvn/6VqAcfJDnhhWbs5i1JD4roBPJfcoshTSZ/HRPJhGXFkg5FbgxMI5lyzeuDunckJyDlyWKC1YkORzOCEGH5i6tYcKGmUhO6LCDYKQgOSxTCDqIxELhDA+j/8hy8Af+8ztpohgMfnYm008McEIH04SNMHi3ODXeNjOD4gVJAn9riuUkDqtt1IjuSMqPP9moCgP5x+SkMS3NYqwV0qRD5etxrd3lIflhSVpGtRuzlqNNgs9aliyCApy9w0qCZd/bsyFlLjbTv1bh4OBtLvWwMS91GTIHsEoSMySPofcZB+9TFrwV4TFPU+cIKIzolxu9Y4kzfNYhQAQ5+JRBvTM6SqU1RsIMSeLgkezhlzeTgAZABo09o+iOFKtS2kcmsTIPgoOH9AodPhyJRMhnvbtnPeHpd/W5O8y9REBkWagcPNq19w1NYsaau6e5RngEMfRN/WNaswOVL8bBH95bxMnJYN6xqXuUQuTCKJiGR79ohQblCWLUYMQ5eMSFv/ZMLjqGEgmjSJT2w6Oz+oXtDjor8tnvqtRln/+slDzooe5Kn5k+VYOWX9++9gU6pBw3GHEOHlV9dq1fuTYT/nTOxdL5R/CEMfSQ/tx0V0OzdN79Vu544u+eeZw8Sge8Vd21uzgOvkU93tg5DB3hBsk5+JDi4KmNVd9Y5bbHw+6zAApQxwp2J5NfrFLKAxomHCeA8/tKspv7dMxmHwQHj7lwYZTghfWrhnXcsfkAHURcPPqZyi1wJ2MTthxZUuPtId60u1CeOhMlkGckkGz9vNOZpgGT3oaV3124srljhHriY6ni4Pf+R+MXP91BBB24OHgFI5BIIUsOcXoCZD/4p2YMDsDH/X3NRd6Sx8HHxYhCb0RBHHJFuAIe/WzeAGGbvTNfGmKb4YmD1+jMYDghbqRJzrQJk33K9fNTTamx0SgoPy8z0WhzVX91O5dWYInj4MPCwUszJeGaU69+dB5sEL0DB5Q/9ubWI3WtKp2Z2S9vqeLgw8JnheVRMQAK4JjQsRtqGRbW6jNtTbMxFksdB08ISoVzjfB8vU+maM3y0EeqTa3/10+bJm3T+AU1sMeGvr78ttfPu2jI4+B9jB/eeWNJZiHOwM4A410SULqYrJ1+K1pRVlqITupYfTuAT7RlQYXJiWL0HgiEBha7I6QAqsWyuJYDwYOH80bwUIhhLn6vmMuzAJFzInifsnAnkAllZoGJnTzbcXFAx0ThaE6995frPIbyzCdZcQYpwELws4PwAJ5kDSIF57BgmI6fu0OFRNCoEqP/4rRlx891SGNjwqtk2B6hC4WDrwxwpGC9a7w1WN+idjk9+AUaWOd9zzze1K2FkXq4XmMXLugQmxwLs8P/5AKv1DZoaO7XtanHm/p0zBfk4ZX+vde3go8HlBDKa+z8QIeAH0fJTUuQZUrg3pi1JNChNF9ap7f5bLmxXQMfasvGn5HRD6ODKWnNDtiog0PRWB0qzQTMFLwpAXGmVrC1PrAzr+ZSd/W5DnDnrFpeaC+MCskMN65OTU+Nh91poGaYm57w/JOyQoujd2gSponPo7DbY0Zo2RUdlbdOqp0cofbAHr5pwpYQFeXT/LOWLyvMXs5zzySLoyWwzNtc6KTrwb1N0j8Hf/b2kDcXTsLB15zvgptXFj62+6msT6/0piTG3ujR8oKNgy9emwHIc9dmeavGUHupB6xvUR6dobzvB8oj9zhKSkpcRW5aXfMAs5b8KAxujJ5lkv3KNQbwzXQclup7C6vfjCQx4rNYR2GwH85IiIVhgl0x9bD4mVvYZ/nROZRaDgQPcxUcIUbwyJihEH4W6jbogyO4DKHwWXo+lpt1EM41QqlimXq/7qYVbCRamJuRqMhMrK78QePNwSGzPVUivnZn5KUt2XdGjLXnu6rK1rWNUHuXnzyX98aJy3A9eKWRcevRL1p59IsZUYNMnQFbIq1wIVY+iWZHqDA5zwxWJlUcjTLeskFG0eBkMDlUY6ZwIReYI3bLNFjc3mMN4G6GbFR8x5DBChNwcspJIynd1btjMMW6+sdxBA7zlTKE6dTbz8IAxdALkYc+TJXEiOz09BFFCZw0+BQI+J65yfVzBr0TPAefkigufCIDP1IyR2OHh4OHFRAd6uxY91ijakQ17aLeJWZ28IjfgeODR6cz5R828AJ8tzIRgvdvw9TPa3WwaoM4vvfvO9R6CzraC+/r88Lps0iO7xXLE5x8nmnhe9/CfnxvnrCjOPggXp8X6GvsInh8b3J7ZCskqhvqQKFDQMf3u4rlWqeL5Pg+xLdJAqAFAKwa0lPnSY5pCganLUN0WBg4eHAiJM/AhZiot19pJh7ABh6wy871VIzn3uLZ8Dk/YSYBH4VtXLN8p2Rlw61B5nEWn8cnMUMR8eMoOSsSURw8+eMoWJZ1nLXgHM/rlVBUNH+MCBoBi7Mnxt2Li4G5iQch1KMwvXXaFsWnJjBjwv/hfNeQ1eH/iVKSozDm4ygas6NteJL8cRRvM8SFCj9mmBpnm3JCBixuwGjT2qjI1flBCNEMqffw+ToTBtss/9W5gJ458ZMQS8V7yFLAHPwLP1ijzElXa02q+xMsHh2w9bG/tJZuWr2/JDtQDp63RO+DFwsFIiGdiRIsE6HrBYu9D17gn4PHHaPCimI5Yp2qK0vEMfNqYRpba7QfPX2zsuaiz3gCJgfvLeun34BkvXl0/y1jRE0je38cvMAbwSPUDhkKwtKf2ZU4iv/mc4rZsy/qNS8bURV8YEqiDJK92qN9/v2zF+8M++Tg0YOwi8l694tKyGXhAlYhbgQ3ixtEcJrKuD02t8dFjxeWDf5JVlaca4liRen6lX6IzYP/dY1641ewISsPJoFnrD3fjXwuelgDvfc6VA6+qW14+437rPfBs0LJWbJNnSMHdZZDFUU5sqSA4uB5//f+lQyP5N/BWBy9H1/auzWHIvOMjof/X8mQcvDF2WlVu/JhODX09gWtBchucWHQtTsLZBFqOXK1rH9SIWRSSwppEqr2GZsj9cr8f6hlIsf5wcL/a+1RWiw9+v+GjwYrMul/BRgArXujn0OLvmAAAAAASUVORK5CYII="
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                }
            ],
            "description": "Tela Manter Evento",
            "footer": [],
            "group": "Evento",
            "header": [],
            "icon": "fa-home",
            "id": "evento",
            "locked": true,
            "menuHorizontal": false,
            "menuVertical": true,
            "title": "Evento"
        },
        {
            "body": [
                {
                    "abbrev": "img",
                    "align": {
                        "float": "floatNone text-center",
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatNone text-center",
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Arquivo",
                    "extensionType": "file",
                    "extensionrequired": true,
                    "filename": "icon013_primo_siogp_inverted_small.png",
                    "id": "imgIcon013primosiogpinvertedsmallpng",
                    "label": true,
                    "name": "Imagem",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        }
                    ],
                    "size": {
                        "id": "full",
                        "name": "Linha (1/linha)",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha (1/linha)",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno (3/linha)",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio (2/linha)",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande (1/linha)",
                            "style": "col-xs-10"
                        },
                        {
                            "id": "auto",
                            "name": "Auto",
                            "style": "sizeAuto"
                        }
                    ],
                    "type": "img",
                    "value": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAACglJREFUeNrsWntsU9cZP3ZsYztOcvMCQ3g4DY9AeZgCSSlbk0g8qoFIVjSybt0I/Wdtpg3YJlVV0VqkbVq1B6VTmTZpg6xUlGoqGE3TaKcmoWVtaCUcKMM8MkzBYJLgOH6/s+93c53Zzr3Xj0TbNO2Tjq7te8719zvf+zuXsf8RUkz3AxfuO8HRxUzDJIxUstJw43rjYLv7vw4IMd9Gl1YazanMNy6cmTav78ZgJqgeGr0E6tR/DAgxD4ZfogEQHJjeuHwOW1pTzhrrqiXXeYJRduWum50nUO995mBXHLxg7DS6aLxaqKQUBarOQRodNRXFrOPxRezJdbWsVKdmiUTCGY3F7LFY7H48FnfTZ3c0GuUZU6vVnFql4opURZxKpZpFn01KpdLocPnZO5/Y2dGz1wAScw8VAkiRJ4gOgCCmuRfbVhMAEzE/5o5EIv3+QMCaZDpXArhivd6s0WhW+cIxrovACIAgod0EpmdagaRKoePxxew7Wx5mhhkqdzAU7PV6fVaxNZ1vXmgNRuLan+5YbplVqg19cH3YeLh7YEsNp3P+fOfKM5nzS0oMZp1W13TPHeB+dMrK/kpqR3SAwLycC49FOYLoJik88eo31zMAGYvHet2jo5ZQKHxHbA2YPt53e5vLH6laUKUfWGIscf/uw5trL94ZNTvcwbnPfMHUm7mGpOoMhcP9XLE23rau1gRV/cDmbK5Y/xUTjV7Xx38MFQwkBYT5WGcLa6irDpEE3vT6fNaxsbGY1LoFlXrfkC8cXmwsGdi2cvYNkl5s2ZxSJ/0W37zM2LdqXtmw2Do8k8DYydZuNSyaXd+4aJaKJGMOxxJPEJgTcmAU2UCQQZtPf38zqVKRc8Q9eiJfOyiUYD/lXFn71Xse49OHu2E3R0nNdhcC5CRJog2SWDK71PnANdIVj8dD2Ri47wlp3708aLo+6DXedgVnhaJxbfJeebHGTdK6/1hdpf2Li6qcWfW+qEhbWVG+C2C2/+JdJnizfTkDIRB7YdzHvk3q9FBVaPiB61A2EJfverjXuwearjq99ZFYQpuNyRKtyk1q19vZUmfNBqaqsmLPyU9vaZ8/fh4/tYh5M4VEoLv5XfJM8E5u9+hvSG+dchL42V+uNfXddD1aiAoB0FMN8898Y/18m9Qc7YwZRo4r+9Zzvz8HbwbXvDozzihF1h1BoAMI8kq9ciDgnZ5948KuQkGAvKEY99uz/2j/wdsXt0jNAQ/g5ZWnGhB4sdF7M+coM6SBXKkZCxClycX2yIF4+fTfdw37wsbpMG5sBmKP1H3wAoeDDUZqJGiOpEReQs6EXMnn85+RUyeAyMUW8qFLFGfkwIAnxDFoDNEeUSACwmbkTpBGIBi0Sz1w71v97dMNIhXMGx99Xi92DzyBtx3reGF0SElkD5BuXF7DgqFQn9QfUZphvjMSNMkxg6gMZ4H4c/2XO/nRs38rg8pmpvZidPRv9lZIXeweeNtFUkHGLeR+k4A0byIQPPJAUNKD/OnivSY5JiD67v3bWOfGevv8co3F4/F2YZSoEl1fWjG79w/PNrnh1gFWiiBtcuWiDgS8Ye3GcV6b0oAkq7qNK2oYpeA2qZgBkcPLSDGAHX9h+0oni4a6hoYfdCGhhDokBwx2cGjo0Mo5hjPvv7g1JOi6KJ278aBR7HfwBh4bF/I1T1umRJr5io6MnFKQW1IPf982uErqHlL6tjXz+QxAzr5Aox7vx2ORYNfrHY+F5KTy9qcOs9g98NhYNzOpXqZUIOalNZwwKSYZNz53BUxSNvHC9lXuXNOYZGyYz6ktT66TNjeb07dEHEjMmeQ3WVongZSV6jQTnkEqBZHyVNBXtSLemyuIJPn9AVt7o0lSesO+iEnKe+EqgGlOk4hcnQ0aGPJJ2saa2qqQVIGVjZYYDf1Shj8w6NEiC5b2jhrZFEWUqssMkjpQrlfZC40b8EJoWEg1KlDn5/IcJZsG8gUj9wtdm00dKQAu+bcBuTXsnzGlPCu93zVBcM9UNZryAeK+4/LLTnzEVCFZGfbanAUnjlLpCGgugDCGZ3O5Aul3jAQmcn9RO9CpJYEU62aY4NUKAfLnS/cape4tncOxWDSKj/WZ9UmKJO2pQOxXHCPjtbJGLQokHIlIxhek1vtPXm7PF0S2vK11zTyWGBvDx7RADB4d/9KgNCBWvpXpcDN0AfM1Srjur21YaEQKLpXsianU8fO3JVN22MdDlbrkV2zuxHPBI9quoGTZqxS+8F3yvoFBcnfq+kJUBFLZvrbWjIrxdP9dk1wt80PL5WZUhXLPQ/YcDKbt3QRf4PG9S3wDb6LwU6VMPPXOJ3Z0EjnooFyJK5f5Ug5kfO3M5V1HPvzIuWJu6dW1pnJe9HdcQe6zu54FuTQnELG3raphrpGRtNgJzQFvSqWCEzqRFjEgFlKtDuhedYm+kYBYCpEMmPj1MxugpmjhGLttQ035PuOVrzYwr9eb+TMkotUX6xsBAqaAzZ8UR4QzCjvtJtOo1Wa51CAXcoz4C1qHUmAep2bR2ORGJtmGGbwdPXudB0E826UC4gG0+CGVkhJD01SACDqcN4itK2ejNhd383r9lr6BoaTbPSQZ2Qnh0VSp6HW6nKIq+k2OjICKP8yVkDRCHbevnstGRz2iczQaDdPptOzHpy7wRp7ZpBNLUfZBKmDEYDC0otOXjZEdDSb23JFz9CdWHlBy5EKoR1Aab6irZMMPXMm4kR61FQqqM0r4sxPhhGtf1lxLsJVTaE/i8KWcK2vNxsyjtVzI8r1NvKHjbOPrh3tk54+fdC3mGxI/2bmGJcIBqho9kvPLykrZNaeX/Yo0hY2fmUwqGVQSa3fTjjZ3HjnHHetsrq+oKG91uUYsMv0mS8AfaN+8rJq1PjKP+SMJ/pwQ2YJ33LtMeLSa8mL+SnU38wcCjGp7WdBlpaUsnFCy5986D09llTr4EQWCvirVwi1kVN0kGY6M0Exg5P7PRiphI0D1MFSqIdiymTr2sFHPf1YolMgMWDwR569gHtdsBBBRVsRwrEAqBZ36ct5pvCA+3l6gZjD+LP8LifGhOCrsNkCNuEf5wAbVwXdE62wgxm1iEoiWVHebVz0ieLHdAPN0Fr0XQFjYFAkShPRdwXgmCOuUCisBzGpSs1xOqmzCyJsgBYOhmFVWVrAe232Ggx0CYc0FRM4VovCg2tQkLW0X07OACRXLhci98wCqq6vYaHg8JmHgqC1XEKBCXhhAv/VgatWG3i6ay+FwuB89p0AwiNgjmd0iuEGFEOAo7eBjDoIwVFioL/I6Yy8ISEqLda/Q2ufQ19q0ooavS5JtUN5LxRMZu6/kJcDnYsQ8XuEA8ymvcRwQVDlvmvJLNYKEWpN9WABBrS3VJ0PGgPgiZK9uIYO1TPXFmml9zSl54kVjAZv8ilOSoPO3hHzJyv5P6fRPAQYAuzhA7Cd21fsAAAAASUVORK5CYII="
                },
                {
                    "abbrev": "lnk",
                    "align": {
                        "float": "floatNone text-center",
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatNone text-center",
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Nome",
                    "extensionrequired": true,
                    "help": "prototipado no PRIMO, suportado pelo SIOGP",
                    "href": "http://www.geradorprototipo.caixa.gov.br",
                    "icon": "none",
                    "id": "lnkPrimosiogp2",
                    "label": true,
                    "name": "Link",
                    "option": "_blank",
                    "options": null,
                    "optionsname": "Abrir em",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        }
                    ],
                    "size": {
                        "id": "full",
                        "name": "Linha (1/linha)",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha (1/linha)",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno (3/linha)",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio (2/linha)",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande (1/linha)",
                            "style": "col-xs-10"
                        },
                        {
                            "id": "auto",
                            "name": "Auto",
                            "style": "sizeAuto"
                        }
                    ],
                    "type": "link",
                    "value": "PRIMO/SIOGP"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "id": "texto2",
                    "label": true,
                    "name": "Texto",
                    "platforms": [],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        }
                    ],
                    "style": {
                        "id": "warning",
                        "name": "Aviso"
                    },
                    "styles": [
                        {
                            "id": "default",
                            "name": "Padrão"
                        },
                        {
                            "id": "primary",
                            "name": "Primário"
                        },
                        {
                            "id": "success",
                            "name": "Sucesso"
                        },
                        {
                            "id": "warning",
                            "name": "Aviso"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        },
                        {
                            "id": "info",
                            "name": "Informação"
                        }
                    ],
                    "type": "label",
                    "value": "CEDESRJ - Caixa Econômica Federal"
                },
                {
                    "abbrev": "lbp",
                    "align": {
                        "float": "floatNone text-center",
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatNone text-center",
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Mensagem",
                    "extensionType": "list",
                    "extensionrequired": false,
                    "help": "Exibe a situação atual da assinatura de notificações",
                    "icon": "fa-envelope",
                    "id": "lbpExibeasituacaoatualdaassinaturadenotificaces2",
                    "label": true,
                    "name": "Situação das Notificações",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-print",
                            "id": "printer",
                            "name": "Impressão"
                        }
                    ],
                    "size": {
                        "id": "full",
                        "name": "Linha (1/linha)",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha (1/linha)",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno (3/linha)",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio (2/linha)",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande (1/linha)",
                            "style": "col-xs-10"
                        },
                        {
                            "id": "auto",
                            "name": "Auto",
                            "style": "sizeAuto"
                        }
                    ],
                    "style": {
                        "id": "primary",
                        "name": "Primário"
                    },
                    "styles": [
                        {
                            "id": "default",
                            "name": "Padrão"
                        },
                        {
                            "id": "primary",
                            "name": "Primário"
                        },
                        {
                            "id": "success",
                            "name": "Sucesso"
                        },
                        {
                            "id": "warning",
                            "name": "Aviso"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        },
                        {
                            "id": "info",
                            "name": "Informação"
                        }
                    ],
                    "type": "label-push-status",
                    "values": [
                        "Notificações: RECEBER",
                        "Notificações: NÃO RECEBER",
                        "Notificações: CARREGANDO",
                        "Notificações: NÃO SUPORTADA"
                    ]
                },
                {
                    "abbrev": "btp",
                    "align": {
                        "float": "floatLeft",
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Título",
                    "help": "Clique aqui para receber notificações",
                    "icon": "fa-envelope",
                    "id": "btpRecebernotificaces",
                    "label": true,
                    "name": "Receber Notificações",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-print",
                            "id": "printer",
                            "name": "Impressão"
                        }
                    ],
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button-push-subscribe",
                    "value": "Receber Notificações"
                },
                {
                    "abbrev": "btp",
                    "align": {
                        "float": "floatLeft",
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Título",
                    "help": "Clique aqui para receber Email's",
                    "icon": "fa-envelope",
                    "id": "btpReceberEmail",
                    "label": true,
                    "name": "Receber Email's",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-print",
                            "id": "printer",
                            "name": "Impressão"
                        }
                    ],
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button-mail-subscribe",
                    "value": "Receber Email's"
                },
                {
                    "abbrev": "btp",
                    "align": {
                        "float": "floatLeft",
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Título",
                    "help": "Clique aqui para NÃO receber notificações",
                    "icon": "fa-envelope-o",
                    "id": "btpCancelarnotificaces",
                    "label": true,
                    "name": "Cancelar Notificações",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-print",
                            "id": "printer",
                            "name": "Impressão"
                        }
                    ],
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button-push-unsubscribe",
                    "value": "Cancelar Notificações"
                },
                {
                    "abbrev": "btp",
                    "align": {
                        "float": "floatLeft",
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Título",
                    "help": "Clique aqui para NÃO receber email's",
                    "icon": "fa-envelope-o",
                    "id": "btpCancelarEmail",
                    "label": true,
                    "name": "Cancelar Email's",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-print",
                            "id": "printer",
                            "name": "Impressão"
                        }
                    ],
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button-mail-unsubscribe",
                    "value": "Cancelar Email's"
                },
                {
                    "help": " ",
                    "id": "rule",
                    "name": "Separador (hr)",
                    "platforms": [
                        {
                            "check": true,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-print",
                            "id": "printer",
                            "name": "Impressão"
                        }
                    ],
                    "type": "rule"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "icon": "fa-paragraph",
                    "id": "titulo",
                    "label": true,
                    "name": "Título",
                    "platforms": [],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        }
                    ],
                    "type": "h4",
                    "value": "SIPBS - Sistema de Pagamento Social"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "id": "subtitulo",
                    "label": true,
                    "name": "Sub-título",
                    "platforms": [],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        }
                    ],
                    "type": "h6",
                    "value": "Modelo de Aplicação do PRIMO"
                },
                {
                    "align": {
                        "float": "floatNone text-center",
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "float": "floatLeft",
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "float": "floatNone text-center",
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "float": "floatRight",
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Nome",
                    "extensionrequired": true,
                    "help": "Clique para instalar a versão Mobile",
                    "href": "%URL_SIOGP%/siogp/router/4939/app/layout//LAYOUT-Mobile.apk",
                    "icon": "fa-android",
                    "id": "link",
                    "label": true,
                    "name": "Link",
                    "option": "_blank",
                    "options": null,
                    "optionsname": "Abrir em",
                    "platforms": [
                        {
                            "check": false,
                            "icon": "fa fa-desktop",
                            "id": "desktop",
                            "name": "Desktop"
                        },
                        {
                            "check": true,
                            "icon": "glyphicon glyphicon-globe",
                            "id": "mobile",
                            "name": "Browser Mobile"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-mobile",
                            "id": "nativo",
                            "name": "App Mobile"
                        },
                        {
                            "check": true,
                            "icon": "fa fa-android",
                            "id": "android",
                            "name": "Android"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-apple",
                            "id": "ios",
                            "name": "IOS"
                        },
                        {
                            "check": false,
                            "icon": "fa fa-windows",
                            "id": "winphone",
                            "name": "WinPhone"
                        }
                    ],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        },
                        {
                            "id": "auto",
                            "name": "Auto",
                            "style": "sizeAuto"
                        }
                    ],
                    "type": "link",
                    "value": "Clique para instalar a versão Mobile"
                },
                {
                    "name": "Separador (hr)",
                    "type": "rule"
                },
                {
                    "extension": "Colunas",
                    "extensionType": "list",
                    "extensionrequired": false,
                    "id": "listagem",
                    "name": "Listagem",
                    "platforms": [],
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-4"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-6"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-10"
                        }
                    ],
                    "type": "list",
                    "values": [
                        {
                            "key": "versão",
                            "value": "1.0"
                        },
                        {
                            "key": "data",
                            "value": "12-01-2021"
                        },
                        {
                            "key": "responsável",
                            "value": "Andréa Lourenço"
                        },
                        {
                            "key": "contato",
                            "value": "andrea.lourenco@caixa.gov.br"
                        }
                    ]
                },
                {
                    "name": "Separador (hr)",
                    "type": "rule"
                }
            ],
            "boolATM": false,
            "description": "Sobre",
            "footer": [],
            "group": "Sobre",
            "header": [],
            "icon": "fa-question",
            "id": "sobre",
            "menuHorizontal": false,
            "menuVertical": true,
            "notes": [],
            "telainicial": false,
            "title": "Sobre"
        },
        {
            "body": [
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "icon": "none",
                    "id": "titulo",
                    "label": true,
                    "name": "Título",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "h4",
                    "value": "Por favor informe seu login"
                },
                {
                    "enabled": true,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "Nome de Entrada",
                    "help": "Informe o email",
                    "icon": "fa-keyboard-o",
                    "id": "usuario",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Texto",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-login-user",
                    "value": "Informe o email"
                },
                {
                    "enabled": true,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "Rapoza Dois",
                    "help": "Informe a senha",
                    "icon": "fa-slack",
                    "id": "senha",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Senha",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-login-senha",
                    "value": "Informe a senha"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para logar",
                    "icon": "fa-sign-in",
                    "id": "login",
                    "label": true,
                    "name": "Botão",
                    "option": "principal",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button-login-entrar",
                    "value": "Entrar"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para cadastrar nova senha",
                    "icon": "",
                    "id": "esqueci",
                    "label": true,
                    "name": "Botão",
                    "option": "esquecisenha",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "default",
                        "name": "Neutro"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "Esqueci a senha"
                },
                {
                    "align": {
                        "icon": "fa-align-right",
                        "id": "right",
                        "name": "Direita",
                        "pull": "pull-right",
                        "text": "text-right"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para cadastrar um novo usuário",
                    "icon": "fa-child",
                    "id": "cadastrar",
                    "label": true,
                    "name": "Botão",
                    "option": "cadastrar",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "default",
                        "name": "Neutro"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "Novo usuário"
                }
            ],
            "boolATM": false,
            "description": "Tela de Login",
            "group": "Login",
            "icon": "fa-sign-in",
            "id": "login",
            "locked": false,
            "menuHorizontal": false,
            "menuVertical": true,
            "telainicial": false,
            "title": "Login"
        },
        {
            "body": [
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "icon": "none",
                    "id": "titulo",
                    "label": true,
                    "name": "Título",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "h4",
                    "value": "Quero me cadastrar"
                },
                {
                    "enabled": true,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "usuario@email.com.br",
                    "help": "Informe o email",
                    "icon": "fa-envelope-o",
                    "id": "email",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Email",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-mail",
                    "value": "Informe o email"
                },
                {
                    "enabled": true,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "Nome de Entrada",
                    "help": "Informe o nome completo",
                    "icon": "fa-user",
                    "id": "nomecompleto",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Texto",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-text",
                    "value": "Informe o nome completo"
                },
                {
                    "enabled": true,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "Rapoza Dois",
                    "help": "Informe a senha",
                    "icon": "fa-slack",
                    "id": "senha",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Senha",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-mask",
                    "value": "Informe a senha"
                },
                {
                    "enabled": true,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "Rapoza Dois",
                    "help": "Confirmar a senha",
                    "icon": "fa-slack",
                    "id": "confirmasenha",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Senha",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-mask",
                    "value": "Confirmar a senha"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para cadastrar",
                    "icon": "fa-pencil",
                    "id": "cadastrar",
                    "label": true,
                    "name": "Botão",
                    "option": "login",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "Cadastrar"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para retornar",
                    "icon": "none",
                    "id": "retornar",
                    "label": true,
                    "name": "Botão",
                    "option": "login",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "default",
                        "name": "Neutro"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "retornar"
                }
            ],
            "description": "Tela de Cadastramento",
            "group": "Login",
            "icon": "fa-list-alt",
            "id": "cadastrar",
            "locked": false,
            "menuHorizontal": false,
            "menuVertical": true,
            "title": "Quero me cadastrar"
        },
        {
            "body": [
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "icon": "none",
                    "id": "titulo",
                    "label": true,
                    "name": "Título",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "h4",
                    "value": "Esqueci minha senha"
                },
                {
                    "enabled": true,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "usuario@email.com.br",
                    "help": "Informe o email cadastrado",
                    "icon": "fa-envelope-o",
                    "id": "email",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Email",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-mail",
                    "value": "Informe o email cadastrado"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para enviar nova senha",
                    "icon": "fa-envelope-o",
                    "id": "enviar",
                    "label": true,
                    "name": "Botão",
                    "option": "login",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "Enviar nova senha"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para retornar",
                    "icon": "none",
                    "id": "retornar",
                    "label": true,
                    "name": "Botão",
                    "option": "login",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "default",
                        "name": "Neutro"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "Retornar"
                }
            ],
            "description": "Tela de recuperação de senha",
            "group": "Login",
            "icon": "fa-question",
            "id": "esquecisenha",
            "locked": false,
            "menuHorizontal": false,
            "menuVertical": true,
            "title": "Esqueci minha senha"
        },
        {
            "body": [
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Valor",
                    "extensionrequired": true,
                    "icon": "none",
                    "id": "titulo",
                    "label": true,
                    "name": "Título",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "h4",
                    "value": "Perfil do Usuário"
                },
                {
                    "align": {
                        "icon": "fa-align-center",
                        "id": "center",
                        "name": "Centro",
                        "pull": "",
                        "text": "text-center"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-center",
                            "id": "center",
                            "name": "Centro",
                            "pull": "",
                            "text": "text-center"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "extension": "Arquivo",
                    "extensionType": "file",
                    "extensionrequired": true,
                    "filename": "anonymous-user-small.png",
                    "id": "imagem",
                    "label": true,
                    "name": "Imagem",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "img",
                    "value": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAmjSURBVHja7J3ZTxPvGsdn6XRvh+6FWgRFIQi4QBRU9KcRwTUqKiYEAxGC8cKYeGEM3hC9MNEEY/TKJS6oJBoNxBBcgkoaY4gYNSBg4kKhG3Sn7XSbmXPRk5Nzzu+Xn0edecv09P0D+rafeZbv88z7vIVpmobS639bSBpBGlYaVhpWGlYaVhpWGkEaVhpWGlYa1s+tsbExTlRdyYRF0/TMzAwEQTwe7/Dhwzdv3hwfHw+Hw3MWFi+Je8MwPD4+/ujRo6KiIolEcvTo0SVLluj1epVKJZfLEQTh8/lisVin0+l0OqPRmJGRYTQaURRN2hdOiv0PDAwMDAx8/fo1EAjYbDa3252bm0vTNEEQBEFEIpFYLAZBEEVRJEmSJIlhmEQiEYlEarW6rKxs586dRUVFqQ/rzZs3Fy9efPfuXSwWw3FcIpHw+Xwej0dR1N+YDE3TCWrBYNDlckml0urq6ubm5sWLF6csrGvXrrW3t8vlcoPBgKIoRVG/EmURJBwOW61WBEEOHTp0/PjxFIRlsVg2b94sl8sVCsWvYfovZLOzs2azuaWl5cSJExiGpVQ2fPLkSTAYZIRUIpzJZLL8/PwLFy60tbWlmnT48OGDRCJhhNS/eKEoWlxc3Nvb63A4UgdWOBx++/atRqNhXKmJRKJoNHr79u0UgTU1NXXmzBmfzycWixn/cIqicnJyOjs7m5qaPB4PhwN8KBQ6duzY8PBwOBzW6XQs7YUgSDweHxkZqays7Orq4qRlRSKR1tbWnp4eDMO0Wi17G1EUhSBISUmJyWR69OgRJ2FdvXq1r6+vtLRUJBIl4gvb/i6Xy/v6+rgHiyTJly9fZmdnM5j+fhjsZTKZz+dj76mwBcvtdns8HqlUCrJCEAqFTqfTbrdzDFaiEga8MAzz+/2Jtg+XYGEYhqIo4CodhuF4PB6JRDgGSyqVisXieDwOEhZJkkKhUCaTcQyWSCSSy+XRaBQkrFgsJpfLVSoV96SDQqEADCsej0ulUrlczj1YKpUKcJhPuCGfz+ekZZEkCRiWQCCAYZiTlgVYOiRgcbLcUSqVGIaBVA8JN+QkLJVKJRAIgJU7iQDPXnRnPWaJxWKQYYskSaVSyVU3xHEcsHpQq9VctSylUsle8fHnrgOKorm5uZyEFQgEMAwDFrMoipJKpaw+G7baylNTU01NTfF4nM/nsyd8/rwcDkd7e/vOnTu5ZFlms/nbt28IgoA8x4EgiNPpfPXqFcfckM/n4ziOIAhI6ZDwRKlUyjFYUqkUsMiCIAiG4VgsptfrOQZLLpcLBALAtSFN0zwej72EyBYsrVarVCoJggAJKxKJ6PX64uJijsHi8XiFhYVerxdkKgwGg5mZmQaDgXs6q6KiAnBbORgMclXBl5eXZ2dnB4NBYLqBIIhly5ZxtTasqKiw2+1gPDEcDqtUqi1btnASFgRBGzZsAKMeEASxWCwrV67MysriKqw1a9bodLqxsTEEQdizLwzDnE6n3+9vaWlh95Gw+ulisfj06dNLly4lCIK9luns7KxIJDp16hSrAQsCcwDX6XTu2LFDKBSy0SCHYXhsbOzs2bN1dXWsOzuAgILjuEqlYql5Eo1GtVptaWkpiMgIYA8Mw0pKSpxOJxthKxAI5OTk5OXlpQgsCIL++OMPNtIiDMN+vz8zMxOQlAOzzcaNGwsKCtxuN+OwwuHwhg0bUgoWj8errq52uVzMeqLH41m8eHFVVVVKwYIgaPv27RKJhMFqEUEQm81WW1vLxonxJMPKyckpLCx0OBwIwsymwWDQYDDs3bsX2E8ABwuG4SNHjni9XkY6giiKTkxMrF69mtW3qkmDBUFQZWVlbW0tI3M2BEHodLqmpiaQ3x/0jHRraysEQb8fuaxW6+7duwsLC1MZFkVRjBw2o2maqdg3d2F5PJ5oNPr7AgJFUb/fn+KwwuEwSZKMwAJ2iiKZsCiKYgQW4FdHSYAViUSYkg6hUCjFYaEoGo/Hf9+yYDgJN1KAhvXlyxdGJuUFAoHdbgd8dBzc8xkeHu7q6urv75dKpb+f9WEY9ng8ubm5jY2NVVVVYGQECFh+v7+trW1gYCAUCs2fP5+RMxAwDKMoarFYAoFAXl7euXPnAFy4AuLiHh6P9/HjRwRBFi1alLhehhFRGo/H9Xo9QRBmsxnMq0kQ1isWi/Pz82EYZrxZmkC2YMECo9GYIrBisZjH42FppIbP57vdbq/XmyKwXC6X3W5PjJWzAcvhcAwNDaUIrP7+frvdztJUDQzDGRkZnZ2dqQDL5XJdvnxZo9GwFINpmtZqtUNDQ7du3eI2rNHR0cbGRr/fr1Qq2dMoNE0bjcZLly719PRwUme9f//+4cOHvb29JEkaDAa2T7XxeDyfz2e1WteuXdvQ0LBq1So2JqWZh/X8+fPr169/+vSJIIisrCxgs04IgtA0bbVaI5HI/Pnz9+zZc+DAARzH5yKsUCg0ODjY2dlpMpkwDNPpdICHDf+9wPZ6vTabraCgoKGhYf369UypMAZghUKh+/fv37t3b3JyEkGQrKysX77Pj0FkiWkLt9ut0Wg2bdpUX1+fn5+fTFgWi+X169c3btwYHR1Vq9UKhSLhC9DcWIn8GwqFzGazWq2uq6urrq7+nYPfvwjr+/fvd+7c6e3tdblcMplMo9HQND1nr/xFUTQQCFitVplMtmLFivr6+l87HvHTsEZHR589e3b37t3p6el58+aJxeKk9OF+LQNEo9GpqSkIgmpqanbt2rVu3bqf6u38xO80mUxdXV2vX78OBAJ6vV4mkwGeNmEKWTwen5ychGF40aJFtbW1Bw8eZBKWyWR6/Phxd3c3RVHz5s3j8/lc/2ujRAtkZmbG6/WWlZXt27dv48aNP7xb4Qewurq6Hj58ODIyksAEcjIVDDIYhq1WK0EQmZmZNTU1zc3NfzOj8dew/H7/ixcvHjx4YDKZcBzX6XRzKs2xkTR9Pp/dbs/Ozt63b19NTc3ChQt/DMvv91+5cqWvr29iYkIkEhkMhrmc5hhPmh6Px+l04jheXl7e0tJSUlLy17Cmp6cfPHjQ3d09Pj6u1+sVCgUE5FbDOWhl4XDYZrMJBIKtW7fu379/+fLl/wHr3r17HR0dTqdTo9Go1WqKov7P/50u8cbbZrORJLlt27aOjo5/wnr69GljY6PBYJjj2jIphhaJRD5//rx///7z58/Dnz9/3r59u1qtxnE8lTIds445ODh48uRJFMfxoaEhkBeKcpFXRkbG5OQkKhQKFQoFyOFcLi6hUBiNRhEIgsBc08/plfjTkX8MAL08j7LrOhBZAAAAAElFTkSuQmCC"
                },
                {
                    "enabled": false,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "Nome de Entrada",
                    "icon": "fa-user",
                    "id": "usuario",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Texto",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-text",
                    "value": "Nome"
                },
                {
                    "enabled": false,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "usuario@email.com.br",
                    "help": "Email do usuário",
                    "icon": "fa-envelope-o",
                    "id": "email",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Email",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-mail",
                    "value": "Email do usuário"
                },
                {
                    "enabled": false,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "2016-01-11T16:03:45.130Z",
                    "help": "Data de Cadastramento",
                    "icon": "fa-calendar",
                    "id": "datadecadastro",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Data (calendário)",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-date",
                    "value": "Data de Cadastramento"
                },
                {
                    "enabled": false,
                    "extension": "Items",
                    "extensionType": "list",
                    "extensionrequired": true,
                    "help": "Cargo do Funcionário",
                    "icon": "fa-wrench",
                    "id": "cargo",
                    "inputrequired": true,
                    "label": true,
                    "name": "Entrada de Combo",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "input-select",
                    "value": "Cargo do Funcionário",
                    "values": [
                        "Analista",
                        "Coordenador",
                        "Programador"
                    ]
                },
                {
                    "enabled": false,
                    "extension": "Título",
                    "extensionrequired": false,
                    "fakedata": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus at augue id sem rhoncus ultrices. Aliquam sollicitudin erat quis enim tincidunt, eget consequat neque auctor. Suspendisse nulla purus, lacinia in orci eu, condimentum iaculis augue. Fusce quis ultricies nisi, nec suscipit libero. Aliquam maximus vulputate porttitor. Nunc nec aliquam sem, ac vehicula metus. Donec sit amet nulla nunc.",
                    "icon": "fa-keyboard-o",
                    "id": "descricao",
                    "inputrequired": true,
                    "label": true,
                    "name": "Caixa de Texto",
                    "option": "5",
                    "options": null,
                    "optionsname": "Linhas",
                    "size": {
                        "id": "full",
                        "name": "Linha",
                        "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                    },
                    "sizes": [
                        {
                            "id": "full",
                            "name": "Linha",
                            "style": "col-xs-12 col-sm-12 col-md-12 col-lg-12"
                        },
                        {
                            "id": "small",
                            "name": "Pequeno",
                            "style": "col-xs-6 col-sm-4 col-md-3 col-lg-2"
                        },
                        {
                            "id": "med",
                            "name": "Médio",
                            "style": "col-xs-10 col-sm-8 col-md-6 col-lg-4"
                        },
                        {
                            "id": "large",
                            "name": "Grande",
                            "style": "col-xs-12 col-sm-10 col-md-9 col-lg-8"
                        }
                    ],
                    "type": "text-area",
                    "value": "Descrição da Atividade"
                },
                {
                    "name": "Quebra de linha (br)",
                    "type": "line-break"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para trocar a Senha",
                    "icon": "fa-certificate",
                    "id": "trocasenha",
                    "label": true,
                    "name": "Botão",
                    "option": null,
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "Trocar a Senha"
                },
                {
                    "align": {
                        "icon": "fa-align-right",
                        "id": "right",
                        "name": "Direita",
                        "pull": "pull-right",
                        "text": "text-right"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para retornar",
                    "icon": "fa-sign-out",
                    "id": "retornar",
                    "label": true,
                    "name": "Botão",
                    "option": "principal",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "default",
                        "name": "Neutro"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "Retornar"
                },
                {
                    "align": {
                        "icon": "fa-align-left",
                        "id": "left",
                        "name": "Esquerda",
                        "pull": "pull-left",
                        "text": "text-left"
                    },
                    "aligns": [
                        {
                            "icon": "fa-align-left",
                            "id": "left",
                            "name": "Esquerda",
                            "pull": "pull-left",
                            "text": "text-left"
                        },
                        {
                            "icon": "fa-align-right",
                            "id": "right",
                            "name": "Direita",
                            "pull": "pull-right",
                            "text": "text-right"
                        }
                    ],
                    "enabled": true,
                    "extension": "Título",
                    "help": "Clique para deslogar",
                    "icon": "fa-sign-in",
                    "id": "deslogar",
                    "label": true,
                    "name": "Botão",
                    "option": "login",
                    "options": null,
                    "optionsname": "Ação",
                    "style": {
                        "id": "primary",
                        "name": "Azul Padrão"
                    },
                    "styles": [
                        {
                            "id": "primary",
                            "name": "Azul Padrão"
                        },
                        {
                            "id": "warning",
                            "name": "Laranja Padrão"
                        },
                        {
                            "id": "default",
                            "name": "Neutro"
                        },
                        {
                            "id": "danger",
                            "name": "Atenção"
                        }
                    ],
                    "type": "button",
                    "value": "Deslogar"
                }
            ],
            "description": "Tela de Perfil do Usuário",
            "group": "Login",
            "icon": "fa-user",
            "id": "perfil",
            "locked": false,
            "title": "Perfil"
        }
    ],
    "viewsNotes": [],
    "withSisit": true
}
