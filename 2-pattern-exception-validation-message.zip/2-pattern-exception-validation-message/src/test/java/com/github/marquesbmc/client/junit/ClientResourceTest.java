package com.github.marquesbmc.client.junit;



import static io.restassured.RestAssured.given;

import org.apache.http.entity.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

public class ClientResourceTest {

	@BeforeAll
	public static void setup() {

		RestAssured.reset();

		RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();

		RestAssured.baseURI = "http://localhost";
		RestAssured.port = 8899;
		RestAssured.basePath = "/api";
		// RestAssured.authentication = basic("username", "password");
		// RestAssured.rootPath = "x.y.z";

	}

	@Test
	public void makeSureThatGoogleIsUp() {
		given().when().get("http://www.google.com").then().statusCode(200);
	}
	
	
	@Test
	public void testGreetingEndpoint() {
		given()
			.pathParam("name", "Bruno")
			.log()
		 	.everything()
		 	.contentType(ContentType.JSON)
		.when()
			.get("/client/v1/name")
		.then()
			.log().all()
				.extract()
					.path("id");
            
			
	}
	
	
	
	


	@Test
	public void testListAllEndpoint() {
		
	
		given()
	 	.log()
	 	.everything()
	 	.contentType(ContentType.JSON)
		.when()
				.get("/client/v1/listall")
		.then()
			.assertThat()
				.statusCode(202);
	}


	


	

}