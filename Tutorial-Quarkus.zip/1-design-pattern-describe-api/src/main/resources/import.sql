insert into tb_client(name,birth_date, balance) values('Bruno', '2021-05-31',3.1416);
insert into tb_client(name,birth_date, balance) values('onurB', '2021-05-30',0.46);


