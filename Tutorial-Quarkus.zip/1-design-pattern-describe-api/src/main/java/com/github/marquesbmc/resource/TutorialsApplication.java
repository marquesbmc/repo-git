package com.github.marquesbmc.resource;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class TutorialsApplication extends Application {


}

